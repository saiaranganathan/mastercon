# ZWS — Zurich Workplace Savings Application Hub

A modular-monolith hub (`ZWS.Host` + `ZWS.Web`) hosting five independent applications —
**ApplicationHub**, **Paycon**, **Compliance**, **TradeInsights**, **PartnerHub** — each
with its own Domain/Application/Infrastructure/Presentation layers and its own
`DbContext`. Built from the Figma file *"Paycon UI Revamp 2"* for the Paycon screens.

## Scope note — please read first

This is a large spec (43 sections). Per your own stated priority order — architecture,
module isolation, one DbContext per module, Figma fidelity, dynamic navigation,
complete working code, maintainability, dummy data, compile-readiness — **all of those
are fully built**. Two things are deliberately scoped down rather than left as
`NotImplementedException` stubs:

- **Tests** (section 35) — not in your top-9 priority list. `ZWS.UnitTests`,
  `ZWS.IntegrationTests`, and `ZWS.ArchitectureTests` are real, runnable projects with a
  **representative example of each test type** (domain logic, a validator, a MediatR
  handler with mocks, a full-stack endpoint test, and four architecture-isolation
  rules) rather than one test per handler across every module. Each example's doc
  comment says "follow this pattern for..." at the point where you'd extend it.
- **EF Core migrations** — this environment has no `dotnet` SDK, so I couldn't run
  `dotnet ef migrations add`. Every module's schema is fully defined via Fluent API
  (`OnModelCreating` + `IEntityTypeConfiguration<T>`), and the zero-dependency `Local`
  profile creates that schema at startup via `EnsureCreated` (no migrations needed to
  try the app today) — see "Running locally" below. Generate real migrations for Azure
  SQL the first time you have the SDK: `dotnet ef migrations add Initial --project
  src/Modules/<Module>/Infrastructure --startup-project src/ZWS.Host`.

Nothing else was cut. Every module has real controllers/endpoints, real MediatR
handlers, real EF configurations, real dummy data, and the Blazor client is fully wired
to all of it — not a mockup.

## Architecture

```
ZWS.sln
src/
  ZWS.Host/            composition root - Program.cs, SignalR hub, health checks, Swagger
  ZWS.Web/              Blazor WebAssembly client
  ZWS.BuildingBlocks/    shared, dependency-free primitives (the one exception to isolation)
    SharedKernel/        Entity/AggregateRoot, IDomainEvent, IModule
    EventBus/             IEventBus, IntegrationEvent contracts, RabbitMqEventBus (+ retry/DLQ), InMemoryEventBus
    Caching/               ICacheService over Azure Redis (or in-memory)
    Behaviors/              MediatR pipeline (Logging/Validation/Caching) + centralized exception handler
    Persistence/             AddModuleDbContext<T> - SQL Server / SQLite-in-memory switch
  Modules/
    ApplicationHub/        drives the ZWS Hub landing page cards - own ApplicationHubDbContext
    Paycon/                 Dashboard, Reconciliation, Insights, Statements, Settings - own PayconDbContext
    Compliance/               independent, thin - own ComplianceDbContext
    TradeInsights/              independent, thin - own TradeInsightsDbContext
    PartnerHub/                   independent, thin - own PartnerHubDbContext
tests/
  ZWS.UnitTests/          domain logic, validators, MediatR handlers (mocked repos)
  ZWS.IntegrationTests/    WebApplicationFactory against the real Host, in-memory profile
  ZWS.ArchitectureTests/    NetArchTest rules enforcing the four isolation rules below
```

Every module (large or thin) follows the same four-project shape:

```
ZWS.Modules.<Name>.Domain/          entities, enums, domain events - no EF, no ASP.NET Core
ZWS.Modules.<Name>.Application/     CQRS commands/queries, repository interfaces, DTOs
ZWS.Modules.<Name>.Infrastructure/  the module's OWN DbContext, EF configs, repositories
ZWS.Modules.<Name>.Presentation/    implements IModule; minimal-API endpoints
```

### The four rules `ZWS.ArchitectureTests` enforces

1. **Domain never depends on Infrastructure** (or EF Core at all).
2. **Application never depends on Presentation** (or ASP.NET Core HTTP/SignalR).
3. **BuildingBlocks.SharedKernel never depends on any business module.**
4. **A module's own layers never reference another module's Infrastructure project** —
   i.e. Paycon can never resolve `ApplicationHubDbContext`, `ComplianceDbContext`, etc.,
   and vice versa. This is what "one DbContext per module, never shared" means in
   practice, verified by reflecting over compiled IL rather than just written as a
   convention in a comment.

### Two event types, on purpose

- **`IDomainEvent`** (MediatR `INotification`) — raised and handled *inside* one
  module's own DbContext transaction. Never crosses a module boundary.
- **`IntegrationEvent`** (published on RabbitMQ, contracts defined once in
  `ZWS.BuildingBlocks.EventBus` — section 23's `PaymentInCreated`, `UserCreated`,
  `SchemeUpdated`, etc.) — the only way one module tells another module something
  happened. `RabbitMqEventBus` retries failed handlers with exponential backoff (Polly)
  and dead-letters permanently-failing messages to a `.dlq` queue via
  `x-dead-letter-exchange`. No module currently subscribes to another module's events
  out of the box (there was nothing in the spec's screens requiring it yet) — the
  contracts and the `Subscribe<TEvent, THandler>()` call in `Program.cs` are ready for
  the first one you add.

### Dynamic, database-driven navigation

- **ZWS Hub cards** (`GET /api/applications`) — `ApplicationHubDbContext.Applications`,
  seeded with Paycon/Compliance/TradeInsights/PartnerHub. `ApplicationCard.razor` in
  `ZWS.Web` never hard-codes a card.
- **Paycon sidebar** (`GET /api/paycon/navigation`) — `PayconDbContext.NavigationItems`,
  a flat table with a self-referencing `ParentId`. `PayconNavMenu`/`PayconNavNode` in
  `ZWS.Web` build the two-level tree (Reconciliation → Payments In/Out, Statements →
  Exit/Annual, Settings → User/Scheme/Insight Management) client-side by grouping on
  `ParentId` — nothing is hard-coded in Razor.

## Running locally

**Option A — zero external dependencies** (SQLite in-memory, in-process cache, in-process event bus):

```bash
dotnet run --project src/ZWS.Host --environment Local
```

Uses `appsettings.Local.json` (`Infrastructure:UseInMemory: true`). Every module's
schema is created via `EnsureCreated` and seeded with realistic dummy data (section
30 — 20 Payments In, 10 users, 5 schemes, etc.) before the app starts serving requests.
Swagger opens automatically at `/swagger`.

**Option B — real infrastructure** (matches production topology):

```bash
# 1. Start local SQL Server, Redis, RabbitMQ
docker compose up -d

# 2. Generate + apply migrations per module (needs the .NET 9 SDK)
dotnet ef migrations add Initial --project src/Modules/Paycon/Infrastructure --startup-project src/ZWS.Host
dotnet ef database update --project src/Modules/Paycon/Infrastructure --startup-project src/ZWS.Host
# ...repeat for ApplicationHub, Compliance, TradeInsights, PartnerHub

# 3. Run the API (Infrastructure:UseInMemory is false by default)
dotnet run --project src/ZWS.Host

# 4. Run the Blazor client (separate terminal)
dotnet run --project src/ZWS.Web
```

The Blazor client reads its API/hub URLs from `src/ZWS.Web/wwwroot/appsettings.json`.

## Running the tests

```bash
dotnet test tests/ZWS.UnitTests
dotnet test tests/ZWS.ArchitectureTests
dotnet test tests/ZWS.IntegrationTests   # boots the real Host in-memory - no Docker needed
```

None of these have been run in this environment (no `dotnet` SDK here) — they're
written to compile and pass against the code as delivered, but treat the first local
run as the actual verification step.

## Health checks (section 33)

- `GET /health` — liveness only, no dependency checks.
- `GET /health/ready` — additionally pings every module's SQL connection, Redis, and
  RabbitMQ (skipped entirely in the `Local` in-memory profile, where there's nothing
  real to check). The RabbitMQ check is hand-written against `RabbitMQ.Client` directly
  rather than a community health-check package, to stay version-matched with the
  synchronous `RabbitMQ.Client 6.8.1` API pinned in `ZWS.BuildingBlocks.EventBus`.

## Extending a module, or adding a new one

1. Follow the four-project shape above; give the new module its own `DbContext` with
   `HasDefaultSchema("<yourmodule>")`.
2. Implement `IModule` in the `Presentation` project (`RegisterModule` / `MapEndpoints`
   / optionally `SeedAsync`).
3. Add a `ConnectionStrings:<YourModule>` entry in `ZWS.Host/appsettings.json`.
4. Add one line to `ModuleRegistry.AllModules` in `ZWS.Host`.
5. Add the four `.csproj` files to `ZWS.sln` (or open the folder in an IDE with
   SDK-style/open-folder support).

Nothing else in `Program.cs` changes.
