using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ZWS.BuildingBlocks.Persistence;

/// <summary>
/// Single place every module's Presentation project goes through to register its own
/// DbContext (section 4: one DbContext per module - ApplicationHubDbContext,
/// PayconDbContext, ComplianceDbContext, TradeInsightsDbContext, PartnerHubDbContext).
/// One flag - "Infrastructure:UseInMemory" - switches every module's context at once:
///
///   - false (default): Azure SQL / SQL Server, via a per-module connection string and
///     EF Core migrations (section 26/36).
///   - true: SQLite in-memory (section 26/35's preferred test database) - real SQL
///     semantics, zero external dependencies, schema created via EnsureCreated rather
///     than migrations (see IModuleDbInitializer, invoked once at startup).
/// </summary>
public static class ModuleDbContextExtensions
{
    public static IServiceCollection AddModuleDbContext<TContext>(
        this IServiceCollection services,
        IConfiguration configuration,
        string connectionStringKey,
        string schemaName)
        where TContext : DbContext
    {
        var useInMemory = configuration.GetValue<bool>("Infrastructure:UseInMemory");

        if (useInMemory)
        {
            services.AddSingleton<SqliteInMemoryConnectionHolder<TContext>>();
            services.AddDbContext<TContext>((sp, options) =>
            {
                var holder = sp.GetRequiredService<SqliteInMemoryConnectionHolder<TContext>>();
                options.UseSqlite(holder.Connection);
            });
            services.AddSingleton<IModuleDbInitializer, ModuleDbInitializer<TContext>>();
        }
        else
        {
            var connectionString = configuration.GetConnectionString(connectionStringKey)
                ?? throw new InvalidOperationException(
                    $"No connection string configured for '{connectionStringKey}'. " +
                    "Either provide one under ConnectionStrings, or set Infrastructure:UseInMemory = true to run without a real database.");

            services.AddDbContext<TContext>(options =>
                options.UseSqlServer(connectionString, sql =>
                    sql.MigrationsHistoryTable("__EFMigrationsHistory", schemaName)));
        }

        return services;
    }
}
