using Microsoft.Data.Sqlite;

namespace ZWS.BuildingBlocks.Persistence;

/// <summary>
/// SQLite in-memory only stays alive while at least one connection to it is open, so
/// each module gets exactly one long-lived, singleton-scoped connection that every
/// DbContext instance for that module reuses (see ModuleDbContextExtensions). This is
/// the "prefer SQLite in-memory" path from section 26/35 - a genuinely SQL-compatible
/// engine (real SQL parsing, real constraints), unlike EF Core's non-relational InMemory
/// provider, which matters for integration tests that exercise actual SQL behavior.
/// </summary>
public sealed class SqliteInMemoryConnectionHolder<TContext> : IDisposable where TContext : Microsoft.EntityFrameworkCore.DbContext
{
    public SqliteConnection Connection { get; }

    public SqliteInMemoryConnectionHolder()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    public void Dispose() => Connection.Dispose();
}
