using System.Text.Json;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace ZWS.BuildingBlocks.Behaviors;

/// <summary>Centralized exception handling (section 32) - registered once in ZWS.Host
/// via app.UseExceptionHandler. Returns a consistent error envelope and never leaks
/// stack traces, regardless of which module's handler threw.</summary>
public class GlobalExceptionHandler : IExceptionHandler
{
    private readonly ILogger<GlobalExceptionHandler> _logger;
    public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger) => _logger = logger;

    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        var (statusCode, message) = exception switch
        {
            FluentValidation.ValidationException => (StatusCodes.Status400BadRequest, "One or more validation errors occurred."),
            KeyNotFoundException => (StatusCodes.Status404NotFound, exception.Message),
            _ => (StatusCodes.Status500InternalServerError, "An unexpected error occurred.")
        };

        _logger.LogError(exception, "Unhandled exception (TraceId: {TraceId})", httpContext.TraceIdentifier);

        httpContext.Response.StatusCode = statusCode;
        httpContext.Response.ContentType = "application/json";

        var body = JsonSerializer.Serialize(new
        {
            status = statusCode,
            message,
            traceId = httpContext.TraceIdentifier
        });

        await httpContext.Response.WriteAsync(body, cancellationToken);
        return true;
    }
}
