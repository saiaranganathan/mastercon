using MediatR;
using ZWS.BuildingBlocks.Caching;

namespace ZWS.BuildingBlocks.Behaviors;

public interface ICacheableQuery
{
    string CacheKey { get; }
    TimeSpan? Expiration => null;
}

public interface ICacheInvalidatingCommand
{
    IEnumerable<string> CacheKeysToInvalidate { get; }
}

public class CachingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : notnull
{
    private readonly ICacheService _cache;
    public CachingBehavior(ICacheService cache) => _cache = cache;

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        if (request is ICacheableQuery cacheable)
            return await _cache.GetOrCreateAsync(cacheable.CacheKey, () => next(), cacheable.Expiration, cancellationToken);

        var response = await next();

        if (request is ICacheInvalidatingCommand invalidating)
            foreach (var key in invalidating.CacheKeysToInvalidate)
                await _cache.RemoveAsync(key, cancellationToken);

        return response;
    }
}
