namespace ZWS.BuildingBlocks.Caching;

/// <summary>Thin abstraction over Azure Cache for Redis (section 25). Every module
/// shares the same Redis instance but MUST prefix keys with its own module name to
/// avoid collisions. Recommended cache targets per spec: ZWS application cards, Paycon
/// navigation, dashboard metrics, and reference/configuration data.</summary>
public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
    Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
}
