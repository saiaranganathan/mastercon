using System.Text.Json;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ZWS.BuildingBlocks.Caching;

/// <summary>
/// Works against Azure Cache for Redis (StackExchangeRedisCache) in real environments
/// and against ASP.NET Core's in-process MemoryDistributedCache in the zero-dependency
/// local profile - both are IDistributedCache, so this class is unaware of which one
/// is behind it. If Redis is unreachable at call time, every method falls back to
/// treating the cache as a miss rather than throwing (section 25: "gracefully fall
/// back to SQL" - the MediatR handler's own GetOrCreateAsync factory delegate is what
/// actually re-reads from the module's DbContext on a miss).
/// </summary>
public class RedisCacheService : ICacheService
{
    private readonly IDistributedCache _cache;
    private readonly RedisOptions _options;
    private readonly ILogger<RedisCacheService> _logger;

    public RedisCacheService(IDistributedCache cache, IOptions<RedisOptions> options, ILogger<RedisCacheService> logger)
    {
        _cache = cache;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default)
    {
        try
        {
            var bytes = await _cache.GetAsync(key, cancellationToken);
            return bytes is null ? default : JsonSerializer.Deserialize<T>(bytes);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Cache read failed for key {Key} - falling back to a cache miss", key);
            return default;
        }
    }

    public async Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default)
    {
        try
        {
            var options = new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = expiration ?? TimeSpan.FromMinutes(_options.DefaultAbsoluteExpirationMinutes)
            };
            var bytes = JsonSerializer.SerializeToUtf8Bytes(value);
            await _cache.SetAsync(key, bytes, options, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Cache write failed for key {Key} - continuing without caching this value", key);
        }
    }

    public async Task RemoveAsync(string key, CancellationToken cancellationToken = default)
    {
        try { await _cache.RemoveAsync(key, cancellationToken); }
        catch (Exception ex) { _logger.LogWarning(ex, "Cache removal failed for key {Key}", key); }
    }

    public async Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null, CancellationToken cancellationToken = default)
    {
        var cached = await GetAsync<T>(key, cancellationToken);
        if (cached is not null) return cached;

        var value = await factory(); // SQL fallback happens here, in the caller's factory
        await SetAsync(key, value, expiration, cancellationToken);
        return value;
    }
}
