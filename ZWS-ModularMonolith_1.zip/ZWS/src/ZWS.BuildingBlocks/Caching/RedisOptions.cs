namespace ZWS.BuildingBlocks.Caching;

public class RedisOptions
{
    public const string SectionName = "Redis";
    public string ConnectionString { get; set; } = "localhost:6379";
    public int DefaultAbsoluteExpirationMinutes { get; set; } = 30;
}
