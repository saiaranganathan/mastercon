using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace ZWS.BuildingBlocks.EventBus;

/// <summary>
/// Topic-exchange based event bus with retry and dead-lettering (section 23/43). One
/// exchange is shared by the whole application; the process's single durable queue is
/// bound only to the routing keys any registered module subscribes to. Messages that
/// fail after RetryCount attempts are nacked without requeue and land on the dead-letter
/// queue (via the queue's x-dead-letter-exchange argument) for manual inspection/replay.
/// </summary>
public sealed class RabbitMqEventBus : IEventBus, IDisposable
{
    private readonly IConnection _connection;
    private readonly IModel _channel;
    private readonly RabbitMqOptions _options;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<RabbitMqEventBus> _logger;
    private readonly ConcurrentDictionary<string, Type> _routingKeyToEventType = new();
    private readonly ConcurrentDictionary<Type, List<Type>> _eventTypeToHandlerTypes = new();
    private readonly AsyncRetryPolicy _retryPolicy;

    public RabbitMqEventBus(IOptions<RabbitMqOptions> options, IServiceProvider serviceProvider, ILogger<RabbitMqEventBus> logger)
    {
        _options = options.Value;
        _serviceProvider = serviceProvider;
        _logger = logger;

        _retryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(
                _options.RetryCount,
                attempt => TimeSpan.FromMilliseconds(_options.RetryBaseDelayMilliseconds * Math.Pow(2, attempt - 1)),
                (ex, delay, attempt, _) => _logger.LogWarning(ex, "Integration event handling failed (attempt {Attempt}/{Max}), retrying in {Delay}ms", attempt, _options.RetryCount, delay.TotalMilliseconds));

        var factory = new ConnectionFactory
        {
            HostName = _options.Host,
            Port = _options.Port,
            UserName = _options.Username,
            Password = _options.Password,
            VirtualHost = _options.VirtualHost,
            DispatchConsumersAsync = true
        };

        _connection = factory.CreateConnection("zws-host");
        _channel = _connection.CreateModel();

        _channel.ExchangeDeclare(_options.ExchangeName, ExchangeType.Topic, durable: true);
        _channel.ExchangeDeclare(_options.DeadLetterExchangeName, ExchangeType.Fanout, durable: true);

        _channel.QueueDeclare(_options.DeadLetterQueueName, durable: true, exclusive: false, autoDelete: false);
        _channel.QueueBind(_options.DeadLetterQueueName, _options.DeadLetterExchangeName, routingKey: "");

        var queueArgs = new Dictionary<string, object> { ["x-dead-letter-exchange"] = _options.DeadLetterExchangeName };
        _channel.QueueDeclare(_options.QueueName, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

        var consumer = new AsyncEventingBasicConsumer(_channel);
        consumer.Received += OnMessageReceivedAsync;
        _channel.BasicConsume(_options.QueueName, autoAck: false, consumer);
    }

    public Task PublishAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default) where TEvent : IntegrationEvent
    {
        var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(@event, @event.GetType()));

        var properties = _channel.CreateBasicProperties();
        properties.DeliveryMode = 2; // persistent
        properties.ContentType = "application/json";
        properties.Type = @event.GetType().AssemblyQualifiedName;

        _channel.BasicPublish(_options.ExchangeName, @event.RoutingKey, properties, body);
        _logger.LogInformation("Published {EventType} ({RoutingKey})", typeof(TEvent).Name, @event.RoutingKey);
        return Task.CompletedTask;
    }

    public void Subscribe<TEvent, THandler>()
        where TEvent : IntegrationEvent
        where THandler : IIntegrationEventHandler<TEvent>
    {
        var routingKey = ((TEvent)System.Runtime.Serialization.FormatterServices.GetUninitializedObject(typeof(TEvent))).RoutingKey;

        _channel.QueueBind(_options.QueueName, _options.ExchangeName, routingKey);
        _routingKeyToEventType[routingKey] = typeof(TEvent);

        var handlers = _eventTypeToHandlerTypes.GetOrAdd(typeof(TEvent), _ => new List<Type>());
        handlers.Add(typeof(THandler));

        _logger.LogInformation("Bound queue {Queue} to {RoutingKey} -> {Handler}", _options.QueueName, routingKey, typeof(THandler).Name);
    }

    private async Task OnMessageReceivedAsync(object sender, BasicDeliverEventArgs eventArgs)
    {
        var routingKey = eventArgs.RoutingKey;
        try
        {
            if (!_routingKeyToEventType.TryGetValue(routingKey, out var eventType))
            {
                _channel.BasicAck(eventArgs.DeliveryTag, multiple: false);
                return;
            }

            var message = Encoding.UTF8.GetString(eventArgs.Body.Span);
            var @event = JsonSerializer.Deserialize(message, eventType);
            if (@event is null) { _channel.BasicNack(eventArgs.DeliveryTag, false, requeue: false); return; }

            await _retryPolicy.ExecuteAsync(async () =>
            {
                using var scope = _serviceProvider.CreateScope();
                if (!_eventTypeToHandlerTypes.TryGetValue(eventType, out var handlerTypes)) return;

                foreach (var handlerType in handlerTypes)
                {
                    var handler = scope.ServiceProvider.GetService(handlerType);
                    if (handler is null) continue;
                    var handleMethod = handlerType.GetMethod("Handle");
                    await (Task)handleMethod!.Invoke(handler, new[] { @event, CancellationToken.None })!;
                }
            });

            _channel.BasicAck(eventArgs.DeliveryTag, multiple: false);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Integration event with routing key {RoutingKey} failed after all retries - dead-lettering", routingKey);
            _channel.BasicNack(eventArgs.DeliveryTag, multiple: false, requeue: false); // routes to DLQ via x-dead-letter-exchange
        }
    }

    public void Dispose()
    {
        _channel?.Close();
        _connection?.Close();
    }
}
