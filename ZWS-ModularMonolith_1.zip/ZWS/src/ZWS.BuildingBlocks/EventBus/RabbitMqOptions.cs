namespace ZWS.BuildingBlocks.EventBus;

public class RabbitMqOptions
{
    public const string SectionName = "RabbitMQ";

    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string Username { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string VirtualHost { get; set; } = "/";
    public string ExchangeName { get; set; } = "zws.event-bus";
    /// <summary>Queue name for THIS process. ZWS.Host runs every module in one process,
    /// so one queue is bound to every routing key any module subscribes to.</summary>
    public string QueueName { get; set; } = "zws.queue.host";
    public string DeadLetterExchangeName { get; set; } = "zws.event-bus.dlx";
    public string DeadLetterQueueName { get; set; } = "zws.queue.host.dlq";
    public int RetryCount { get; set; } = 3;
    public int RetryBaseDelayMilliseconds { get; set; } = 200;
}
