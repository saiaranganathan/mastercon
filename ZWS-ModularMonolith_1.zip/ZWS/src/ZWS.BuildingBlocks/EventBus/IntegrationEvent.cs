namespace ZWS.BuildingBlocks.EventBus;

/// <summary>Base type for events published on RabbitMQ to cross module boundaries.
/// Contracts live here (in BuildingBlocks) precisely so two modules can share an event
/// TYPE without referencing each other's Application/Domain projects - e.g. Paycon
/// publishes PaymentInCreated and, if another module ever needs to react to it, that
/// module references only this project, never Paycon.Application.</summary>
public abstract record IntegrationEvent
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
    /// <summary>RabbitMQ routing key, e.g. "paycon.payment-in.created".</summary>
    public abstract string RoutingKey { get; }
}

// ---- Cross-module integration event contracts (section 23) ----

public sealed record PaymentInCreated(Guid PaymentId, string Reference, decimal Amount, string CurrencyCode) : IntegrationEvent
{
    public override string RoutingKey => "paycon.payment-in.created";
}

public sealed record PaymentOutCreated(Guid PaymentId, string Reference, decimal Amount, string CurrencyCode) : IntegrationEvent
{
    public override string RoutingKey => "paycon.payment-out.created";
}

public sealed record PaymentStatusChanged(Guid PaymentId, string Direction, string OldStatus, string NewStatus) : IntegrationEvent
{
    public override string RoutingKey => "paycon.payment.status-changed";
}

public sealed record UserCreated(Guid UserId, string Email, string FullName) : IntegrationEvent
{
    public override string RoutingKey => "paycon.user.created";
}

public sealed record SchemeUpdated(Guid SchemeId, string SchemeCode) : IntegrationEvent
{
    public override string RoutingKey => "paycon.scheme.updated";
}

public sealed record ApplicationLaunched(string ApplicationCode, DateTime LaunchedAtUtc) : IntegrationEvent
{
    public override string RoutingKey => "applicationhub.application.launched";
}
