using System.Collections.Concurrent;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ZWS.BuildingBlocks.EventBus;

/// <summary>
/// Zero-dependency stand-in for RabbitMqEventBus, used when Infrastructure:UseInMemory
/// is true. Publishing invokes subscribed handlers directly, in-process - no broker, no
/// retry, no dead-lettering. For local smoke-testing and integration tests only; swap
/// back to RabbitMqEventBus (the default) for anything beyond that.
/// </summary>
public sealed class InMemoryEventBus : IEventBus
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<InMemoryEventBus> _logger;
    private readonly ConcurrentDictionary<Type, List<Type>> _handlers = new();

    public InMemoryEventBus(IServiceProvider serviceProvider, ILogger<InMemoryEventBus> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    public async Task PublishAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default) where TEvent : IntegrationEvent
    {
        _logger.LogInformation("[InMemoryEventBus] Publishing {EventType} ({RoutingKey})", typeof(TEvent).Name, @event.RoutingKey);
        if (!_handlers.TryGetValue(typeof(TEvent), out var handlerTypes)) return;

        using var scope = _serviceProvider.CreateScope();
        foreach (var handlerType in handlerTypes)
        {
            if (scope.ServiceProvider.GetService(handlerType) is not IIntegrationEventHandler<TEvent> handler) continue;
            await handler.Handle(@event, cancellationToken);
        }
    }

    public void Subscribe<TEvent, THandler>()
        where TEvent : IntegrationEvent
        where THandler : IIntegrationEventHandler<TEvent>
    {
        var handlers = _handlers.GetOrAdd(typeof(TEvent), _ => new List<Type>());
        handlers.Add(typeof(THandler));
        _logger.LogInformation("[InMemoryEventBus] Subscribed {Handler} to {EventType}", typeof(THandler).Name, typeof(TEvent).Name);
    }
}
