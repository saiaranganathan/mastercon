using MediatR;

namespace ZWS.BuildingBlocks.SharedKernel;

/// <summary>Raised and handled INSIDE a single module, in-process, via MediatR's
/// INotification pipeline. Crossing module boundaries requires an IntegrationEvent
/// (see ZWS.BuildingBlocks.EventBus) published on RabbitMQ instead.</summary>
public interface IDomainEvent : INotification
{
    DateTime OccurredOnUtc { get; }
}
