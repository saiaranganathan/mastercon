using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ZWS.BuildingBlocks.SharedKernel;

/// <summary>
/// The ONE public seam of every top-level application module (ApplicationHub, Paycon,
/// Compliance, TradeInsights, PartnerHub). ZWS.Host discovers modules through this
/// interface only - it never references a module's Domain/Application/Infrastructure
/// projects directly, and modules never reference each other's Infrastructure
/// (per-module DbContext) project.
/// </summary>
public interface IModule
{
    string Name { get; }

    /// <summary>Registers the module's own DbContext (own schema/connection), MediatR
    /// handlers, repositories, validators, etc. Called once at Host startup.</summary>
    IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration);

    /// <summary>Maps the module's minimal-API endpoints under its own route group.</summary>
    IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints);

    /// <summary>Optional demo/seed data, run once at Host startup only when running
    /// against the in-memory/test database profile. Default is a no-op.</summary>
    Task SeedAsync(IServiceProvider services, IConfiguration configuration) => Task.CompletedTask;
}
