using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ZWS.Web;
using ZWS.Web.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

var apiBaseUrl = builder.Configuration["ApiBaseUrl"] ?? "https://localhost:7031";

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(apiBaseUrl) });
builder.Services.AddScoped<ApplicationHubApiClient>();
builder.Services.AddScoped<PayconApiClient>();
builder.Services.AddScoped<SignalRService>();

await builder.Build().RunAsync();
