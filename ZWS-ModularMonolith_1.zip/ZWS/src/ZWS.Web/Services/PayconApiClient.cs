using System.Net.Http.Json;

namespace ZWS.Web.Services;

// ---- Navigation ----
public record NavigationItemDto(Guid Id, string Name, string? Route, string? Icon, Guid? ParentId, int DisplayOrder);

// ---- Dashboard ----
public record DashboardMetricDto(Guid Id, string Label, decimal PrimaryValue, decimal? ComparisonValue, string Period, string Category);

// ---- Payments ----
public record PaymentInDto(Guid Id, string Reference, string CustomerName, decimal Amount, string CurrencyCode, string PaymentMethod, DateTime ValueDateUtc, string Status, string? CounterpartyReference);
public record PaymentOutDto(Guid Id, string Reference, string BeneficiaryName, decimal Amount, string CurrencyCode, string PaymentMethod, DateTime ValueDateUtc, string Status);
public record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalCount)
{
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);
}

// ---- Insights / Statements ----
public record InsightDto(Guid Id, string Title, string Description, string Category, decimal Value, string Trend, DateTime GeneratedAtUtc);
public record ExitStatementDto(Guid Id, string MemberName, DateTime PeriodStartUtc, DateTime PeriodEndUtc, string Status);
public record AnnualStatementDto(Guid Id, string MemberName, int StatementYear, string Status);

// ---- Settings: Users / Schemes / Insight Configuration ----
public record UserDto(Guid Id, string Email, string FirstName, string LastName, string Role, string Status, DateTime CreatedAtUtc);
public record CreateUserRequest(string Email, string FirstName, string LastName, string Role);
public record UpdateUserRequest(string FirstName, string LastName, string Role);

public record SchemeDto(Guid Id, string SchemeCode, string SchemeName, string OperatingBank, bool IsActive);
public record CreateSchemeRequest(string SchemeCode, string SchemeName, string OperatingBank);
public record UpdateSchemeRequest(string SchemeName, string OperatingBank);

public record InsightConfigurationDto(Guid Id, string Key, string Value, string? Description);

/// <summary>Typed client for every /api/paycon/* endpoint (section 28: "Services/
/// PayconApiClient"). One client for the whole Paycon feature area, mirroring how the
/// backend keeps Paycon as a single module.</summary>
public class PayconApiClient
{
    private readonly HttpClient _http;
    public PayconApiClient(HttpClient http) => _http = http;

    public async Task<IReadOnlyList<NavigationItemDto>> GetNavigationAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<NavigationItemDto>>("/api/paycon/navigation", ct) ?? new();

    public async Task<IReadOnlyList<DashboardMetricDto>> GetDashboardAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<DashboardMetricDto>>("/api/paycon/dashboard", ct) ?? new();

    public async Task<PagedResult<PaymentInDto>> GetPaymentsInAsync(string? search, string? status, int page, int pageSize, CancellationToken ct = default)
    {
        var url = $"/api/paycon/reconciliation/payments-in?page={page}&pageSize={pageSize}" +
                   (string.IsNullOrWhiteSpace(search) ? "" : $"&search={Uri.EscapeDataString(search)}") +
                   (string.IsNullOrWhiteSpace(status) ? "" : $"&status={Uri.EscapeDataString(status)}");
        return await _http.GetFromJsonAsync<PagedResult<PaymentInDto>>(url, ct) ?? new PagedResult<PaymentInDto>(new List<PaymentInDto>(), page, pageSize, 0);
    }

    public async Task<PagedResult<PaymentOutDto>> GetPaymentsOutAsync(string? search, int page, int pageSize, CancellationToken ct = default)
    {
        var url = $"/api/paycon/reconciliation/payments-out?page={page}&pageSize={pageSize}" +
                   (string.IsNullOrWhiteSpace(search) ? "" : $"&search={Uri.EscapeDataString(search)}");
        return await _http.GetFromJsonAsync<PagedResult<PaymentOutDto>>(url, ct) ?? new PagedResult<PaymentOutDto>(new List<PaymentOutDto>(), page, pageSize, 0);
    }

    public async Task<IReadOnlyList<InsightDto>> GetInsightsAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<InsightDto>>("/api/paycon/insights", ct) ?? new();

    public async Task<IReadOnlyList<ExitStatementDto>> GetExitStatementsAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<ExitStatementDto>>("/api/paycon/statements/exit", ct) ?? new();

    public async Task<IReadOnlyList<AnnualStatementDto>> GetAnnualStatementsAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<AnnualStatementDto>>("/api/paycon/statements/annual", ct) ?? new();

    public async Task<PagedResult<UserDto>> GetUsersAsync(string? search, int page, int pageSize, CancellationToken ct = default)
    {
        var url = $"/api/paycon/settings/users?page={page}&pageSize={pageSize}" +
                   (string.IsNullOrWhiteSpace(search) ? "" : $"&search={Uri.EscapeDataString(search)}");
        return await _http.GetFromJsonAsync<PagedResult<UserDto>>(url, ct) ?? new PagedResult<UserDto>(new List<UserDto>(), page, pageSize, 0);
    }

    public async Task<Guid> CreateUserAsync(CreateUserRequest request, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/api/paycon/settings/users", request, ct);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<CreatedIdResponse>(cancellationToken: ct);
        return result?.Id ?? Guid.Empty;
    }

    public async Task UpdateUserAsync(Guid id, UpdateUserRequest request, CancellationToken ct = default) =>
        (await _http.PutAsJsonAsync($"/api/paycon/settings/users/{id}", request, ct)).EnsureSuccessStatusCode();

    public async Task DeleteUserAsync(Guid id, CancellationToken ct = default) =>
        (await _http.DeleteAsync($"/api/paycon/settings/users/{id}", ct)).EnsureSuccessStatusCode();

    public async Task<PagedResult<SchemeDto>> GetSchemesAsync(string? search, int page, int pageSize, CancellationToken ct = default)
    {
        var url = $"/api/paycon/settings/schemes?page={page}&pageSize={pageSize}" +
                   (string.IsNullOrWhiteSpace(search) ? "" : $"&search={Uri.EscapeDataString(search)}");
        return await _http.GetFromJsonAsync<PagedResult<SchemeDto>>(url, ct) ?? new PagedResult<SchemeDto>(new List<SchemeDto>(), page, pageSize, 0);
    }

    public async Task<Guid> CreateSchemeAsync(CreateSchemeRequest request, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/api/paycon/settings/schemes", request, ct);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<CreatedIdResponse>(cancellationToken: ct);
        return result?.Id ?? Guid.Empty;
    }

    public async Task UpdateSchemeAsync(Guid id, UpdateSchemeRequest request, CancellationToken ct = default) =>
        (await _http.PutAsJsonAsync($"/api/paycon/settings/schemes/{id}", request, ct)).EnsureSuccessStatusCode();

    public async Task DeleteSchemeAsync(Guid id, CancellationToken ct = default) =>
        (await _http.DeleteAsync($"/api/paycon/settings/schemes/{id}", ct)).EnsureSuccessStatusCode();

    public async Task<IReadOnlyList<InsightConfigurationDto>> GetInsightConfigurationsAsync(CancellationToken ct = default) =>
        await _http.GetFromJsonAsync<List<InsightConfigurationDto>>("/api/paycon/settings/insights", ct) ?? new();

    private record CreatedIdResponse(Guid Id);
}
