using System.Net.Http.Json;

namespace ZWS.Web.Services;

public record ApplicationCardDto(Guid Id, string Code, string Name, string? Description, string? Icon, string Route, int DisplayOrder, string Status);

/// <summary>Typed client for GET /api/applications - drives the ZWS Hub landing page.
/// Cards are never hard-coded in Blazor (section 6); this is the only place that data
/// enters the client.</summary>
public class ApplicationHubApiClient
{
    private readonly HttpClient _http;
    public ApplicationHubApiClient(HttpClient http) => _http = http;

    public async Task<IReadOnlyList<ApplicationCardDto>> GetApplicationsAsync(CancellationToken cancellationToken = default) =>
        await _http.GetFromJsonAsync<List<ApplicationCardDto>>("/api/applications", cancellationToken) ?? new List<ApplicationCardDto>();
}
