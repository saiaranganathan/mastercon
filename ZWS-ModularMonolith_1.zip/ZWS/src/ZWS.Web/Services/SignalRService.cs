using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;

namespace ZWS.Web.Services;

/// <summary>One SignalR connection to /payconHub (section 24/28). Payment status
/// changes, reconciliation updates, dashboard metric updates, and generic
/// notifications all arrive through this single connection - the UI never needs a
/// full browser refresh to reflect them.</summary>
public class SignalRService : IAsyncDisposable
{
    private readonly IConfiguration _configuration;
    private HubConnection? _connection;
    private bool _started;

    public event Action<Guid, string, string>? PaymentStatusUpdated;
    public event Action<string, decimal>? DashboardMetricUpdated;

    public SignalRService(IConfiguration configuration) => _configuration = configuration;

    public async Task EnsureStartedAsync()
    {
        if (_started) return;
        _started = true;

        var hubUrl = _configuration["PayconHubUrl"] ?? "https://localhost:7031/payconHub";

        _connection = new HubConnectionBuilder()
            .WithUrl(hubUrl)
            .WithAutomaticReconnect()
            .Build();

        _connection.On<PaymentStatusPayload>("PaymentStatusUpdated", payload =>
            PaymentStatusUpdated?.Invoke(payload.PaymentId, payload.Direction, payload.NewStatus));

        _connection.On<DashboardMetricPayload>("DashboardMetricUpdated", payload =>
            DashboardMetricUpdated?.Invoke(payload.Label, payload.NewValue));

        await _connection.StartAsync();
        await _connection.InvokeAsync("JoinDashboardGroup");
    }

    public async ValueTask DisposeAsync()
    {
        if (_connection is not null)
            await _connection.DisposeAsync();
    }

    private record PaymentStatusPayload(Guid PaymentId, string Direction, string NewStatus);
    private record DashboardMetricPayload(string Label, decimal NewValue);
}
