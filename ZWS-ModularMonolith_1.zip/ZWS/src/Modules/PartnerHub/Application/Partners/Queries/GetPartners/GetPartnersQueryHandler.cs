using MediatR;
using ZWS.Modules.PartnerHub.Application.Abstractions;

namespace ZWS.Modules.PartnerHub.Application.Partners.Queries.GetPartners;

public class GetPartnersQueryHandler : IRequestHandler<GetPartnersQuery, IReadOnlyList<PartnerDto>>
{
    private readonly IPartnerRepository _repository;
    public GetPartnersQueryHandler(IPartnerRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<PartnerDto>> Handle(GetPartnersQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetAllAsync(cancellationToken);
        return items.Select(x => new PartnerDto(x.Id, x.Name, x.Type, x.Status, x.OnboardedAtUtc)).ToList();
    }
}
