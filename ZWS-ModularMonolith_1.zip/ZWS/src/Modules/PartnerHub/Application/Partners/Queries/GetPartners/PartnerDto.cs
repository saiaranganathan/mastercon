namespace ZWS.Modules.PartnerHub.Application.Partners.Queries.GetPartners;

public record PartnerDto(Guid Id, string Name, string Type, string Status, DateTime OnboardedAtUtc);
