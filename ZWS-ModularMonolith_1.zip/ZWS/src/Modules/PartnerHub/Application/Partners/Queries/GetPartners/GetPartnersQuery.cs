using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.PartnerHub.Application.Partners.Queries.GetPartners;

/// <summary>Drives GET /api/partnerhub/partners - the PartnerHub module's basic landing/dashboard data
/// source (section 17), database-driven like every other module rather than
/// hard-coded in Blazor.</summary>
public record GetPartnersQuery : IRequest<IReadOnlyList<PartnerDto>>, ICacheableQuery
{
    public string CacheKey => "partnerhub:partners:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
