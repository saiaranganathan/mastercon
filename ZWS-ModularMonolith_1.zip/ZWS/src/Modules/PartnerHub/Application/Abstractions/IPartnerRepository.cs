using ZWS.Modules.PartnerHub.Domain.Entities;

namespace ZWS.Modules.PartnerHub.Application.Abstractions;

public interface IPartnerRepository
{
    Task<IReadOnlyList<Partner>> GetAllAsync(CancellationToken cancellationToken);
}
