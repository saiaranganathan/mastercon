using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.PartnerHub.Domain.Entities;

namespace ZWS.Modules.PartnerHub.Infrastructure.Persistence.Configurations;

public class PartnerConfiguration : IEntityTypeConfiguration<Partner>
{
    public void Configure(EntityTypeBuilder<Partner> builder)
    {
        builder.ToTable("Partners", PartnerHubDbContext.Schema);
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Name).HasMaxLength(150);
        builder.Property(x => x.Type).HasMaxLength(50);
        builder.Property(x => x.Status).HasMaxLength(30);
        builder.Ignore(x => x.DomainEvents);
    }
}
