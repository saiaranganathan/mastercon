using Microsoft.EntityFrameworkCore;
using ZWS.Modules.PartnerHub.Domain.Entities;

namespace ZWS.Modules.PartnerHub.Infrastructure.Persistence;

/// <summary>This module's own DbContext (section 4) - "partnerhub" schema. PartnerHub is
/// independent of Paycon and every other module; nothing outside this module resolves
/// this type from DI.</summary>
public class PartnerHubDbContext : DbContext
{
    public const string Schema = "partnerhub";

    public PartnerHubDbContext(DbContextOptions<PartnerHubDbContext> options) : base(options) { }

    public DbSet<Partner> Partners => Set<Partner>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(PartnerHubDbContext).Assembly);
    }
}
