using Microsoft.EntityFrameworkCore;
using ZWS.Modules.PartnerHub.Application.Abstractions;
using ZWS.Modules.PartnerHub.Domain.Entities;

namespace ZWS.Modules.PartnerHub.Infrastructure.Persistence.Repositories;

public class PartnerRepository : IPartnerRepository
{
    private readonly PartnerHubDbContext _db;
    public PartnerRepository(PartnerHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<Partner>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Partners.AsNoTracking().ToListAsync(cancellationToken);
}
