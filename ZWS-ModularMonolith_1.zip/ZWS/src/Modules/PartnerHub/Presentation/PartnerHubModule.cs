using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.PartnerHub.Application.Abstractions;
using ZWS.Modules.PartnerHub.Application.Partners.Queries.GetPartners;
using ZWS.Modules.PartnerHub.Domain.Entities;
using ZWS.Modules.PartnerHub.Infrastructure.Persistence;
using ZWS.Modules.PartnerHub.Infrastructure.Persistence.Repositories;

namespace ZWS.Modules.PartnerHub.Presentation;

/// <summary>The ONE public seam of the PartnerHub module (section 17). Independent module
/// structure - own Domain/Application/Infrastructure/Presentation, own PartnerHubDbContext,
/// own seed data, a basic landing/dashboard page - proportionate to spec section 17,
/// which explicitly says these three modules don't need Paycon's level of functionality.</summary>
public class PartnerHubModule : IModule
{
    public string Name => "PartnerHub";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<PartnerHubDbContext>(configuration, "PartnerHub", PartnerHubDbContext.Schema);
        services.AddScoped<IPartnerRepository, PartnerRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetPartnersQuery).Assembly));
        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/partnerhub/partners", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPartnersQuery(), ct)))
            .WithTags("PartnerHub");

        return endpoints;
    }

    /// <summary>Realistic dummy data (section 30) so the PartnerHub landing page isn't empty
    /// on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<PartnerHubDbContext>();
        if (await db.Partners.AnyAsync()) return;

        db.Partners.AddRange(
            Partner.Create("DEWS - Fund Provider", "FundProvider", "Active", DateTime.UtcNow.AddYears(-3)),
            Partner.Create("DAMAN - Fund Provider", "FundProvider", "Active", DateTime.UtcNow.AddYears(-2)),
            Partner.Create("Standard Chartered Bank - UAE", "OperatingBank", "Active", DateTime.UtcNow.AddYears(-4)),
            Partner.Create("Emirates NBD", "OperatingBank", "Active", DateTime.UtcNow.AddYears(-4)),
            Partner.Create("First Abu Dhabi Bank", "OperatingBank", "PendingReview", DateTime.UtcNow.AddMonths(-2)),
            Partner.Create("Qatar National Bank", "OperatingBank", "Active", DateTime.UtcNow.AddYears(-1)));

        await db.SaveChangesAsync();
    }
}
