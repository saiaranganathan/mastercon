using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.PartnerHub.Domain.Entities;

/// <summary>Backs the PartnerHub application's landing/dashboard page (section 17) - a partner or fund-provider relationship.</summary>
public class Partner : AggregateRoot<Guid>
{
    public string Name { get; private set; } = default!;
    public string Type { get; private set; } = default!;
    public string Status { get; private set; } = default!;
    public DateTime OnboardedAtUtc { get; private set; };

    private Partner() { }

    public static Partner Create(string name, string type, string status, DateTime onboardedAtUtc) =>
        new()
        {
            Id = Guid.NewGuid(),
            Name = name,
            Type = type,
            Status = status,
            OnboardedAtUtc = onboardedAtUtc,
        };
}
