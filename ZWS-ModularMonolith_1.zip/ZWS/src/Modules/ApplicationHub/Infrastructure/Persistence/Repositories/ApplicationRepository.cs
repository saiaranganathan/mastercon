using Microsoft.EntityFrameworkCore;
using ZWS.Modules.ApplicationHub.Application.Abstractions;
using ZWS.Modules.ApplicationHub.Domain.Entities;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence.Repositories;

public class ApplicationRepository : IApplicationRepository
{
    private readonly ApplicationHubDbContext _db;
    public ApplicationRepository(ApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<Application>> GetActiveOrderedAsync(CancellationToken cancellationToken) =>
        await _db.Applications.AsNoTracking()
            .Where(a => a.IsActive)
            .OrderBy(a => a.DisplayOrder)
            .ToListAsync(cancellationToken);
}
