using Microsoft.EntityFrameworkCore;
using ZWS.Modules.ApplicationHub.Domain.Entities;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence;

/// <summary>This module's own DbContext (section 4) - "applicationhub" schema. Holds
/// only the Application entity; nothing else in the solution resolves this type.</summary>
public class ApplicationHubDbContext : DbContext
{
    public const string Schema = "applicationhub";

    public ApplicationHubDbContext(DbContextOptions<ApplicationHubDbContext> options) : base(options) { }

    public DbSet<Application> Applications => Set<Application>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationHubDbContext).Assembly);
    }
}
