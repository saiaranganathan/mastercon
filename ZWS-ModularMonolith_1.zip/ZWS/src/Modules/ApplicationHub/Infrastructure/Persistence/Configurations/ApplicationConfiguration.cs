using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.ApplicationHub.Domain.Entities;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence.Configurations;

public class ApplicationConfiguration : IEntityTypeConfiguration<Application>
{
    public void Configure(EntityTypeBuilder<Application> builder)
    {
        builder.ToTable("Applications", ApplicationHubDbContext.Schema);
        builder.HasKey(a => a.Id);
        builder.Property(a => a.Code).HasMaxLength(50).IsRequired();
        builder.HasIndex(a => a.Code).IsUnique();
        builder.Property(a => a.Name).HasMaxLength(150).IsRequired();
        builder.Property(a => a.Description).HasMaxLength(500);
        builder.Property(a => a.Icon).HasMaxLength(50);
        builder.Property(a => a.Route).HasMaxLength(200).IsRequired();
        builder.Property(a => a.Status).HasMaxLength(30);
        builder.Ignore(a => a.DomainEvents);
    }
}
