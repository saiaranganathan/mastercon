using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.ApplicationHub.Application.Abstractions;
using ZWS.Modules.ApplicationHub.Application.Applications.Queries.GetApplications;
using ZWS.Modules.ApplicationHub.Domain.Entities;
using ZWS.Modules.ApplicationHub.Infrastructure.Persistence;
using ZWS.Modules.ApplicationHub.Infrastructure.Persistence.Repositories;
using ZWS.Modules.ApplicationHub.Presentation.Endpoints;

namespace ZWS.Modules.ApplicationHub.Presentation;

/// <summary>The ONE public seam of the ApplicationHub module. Backs the ZWS landing
/// page's database-driven cards (section 6, 43).</summary>
public class ApplicationHubModule : IModule
{
    public string Name => "ApplicationHub";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<ApplicationHubDbContext>(configuration, "ApplicationHub", ApplicationHubDbContext.Schema);
        services.AddScoped<IApplicationRepository, ApplicationRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetApplicationsQuery).Assembly));
        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        ApplicationEndpoints.Map(endpoints);
        return endpoints;
    }

    /// <summary>Seeds Paycon / Compliance / Trade Insights / PartnerHub exactly as
    /// listed in section 6, so the hub is never empty on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationHubDbContext>();
        if (await db.Applications.AnyAsync()) return;

        db.Applications.AddRange(
            Application.Create("PAYCON", "Paycon", "Fund reconciliation, payments and workplace savings statements.", "wallet", "/paycon/dashboard", displayOrder: 1, status: "Live"),
            Application.Create("COMPLIANCE", "Compliance", "Regulatory tracking and compliance case management.", "shield-check", "/compliance/dashboard", displayOrder: 2, status: "Live"),
            Application.Create("TRADE_INSIGHTS", "Trade Insights", "Trade activity analytics and reporting.", "trending-up", "/trade-insights/dashboard", displayOrder: 3, status: "Beta"),
            Application.Create("PARTNER_HUB", "PartnerHub", "Partner and fund-provider relationship management.", "handshake", "/partner-hub/dashboard", displayOrder: 4, status: "Live"));

        await db.SaveChangesAsync();
    }
}
