using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.ApplicationHub.Application.Applications.Queries.GetApplications;

namespace ZWS.Modules.ApplicationHub.Presentation.Endpoints;

/// <summary>GET /api/applications, GET /api/applications/{id} - section 27.</summary>
public static class ApplicationEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/applications").WithTags("Application Hub");

        group.MapGet("/", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetApplicationsQuery(), ct)));

        group.MapGet("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            var all = await sender.Send(new GetApplicationsQuery(), ct);
            var match = all.FirstOrDefault(a => a.Id == id);
            return match is null ? Results.NotFound() : Results.Ok(match);
        });
    }
}
