using ZWS.Modules.ApplicationHub.Domain.Entities;

namespace ZWS.Modules.ApplicationHub.Application.Abstractions;

public interface IApplicationRepository
{
    Task<IReadOnlyList<Application>> GetActiveOrderedAsync(CancellationToken cancellationToken);
}
