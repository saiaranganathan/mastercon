using MediatR;
using ZWS.Modules.ApplicationHub.Application.Abstractions;

namespace ZWS.Modules.ApplicationHub.Application.Applications.Queries.GetApplications;

public class GetApplicationsQueryHandler : IRequestHandler<GetApplicationsQuery, IReadOnlyList<ApplicationDto>>
{
    private readonly IApplicationRepository _repository;
    public GetApplicationsQueryHandler(IApplicationRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<ApplicationDto>> Handle(GetApplicationsQuery request, CancellationToken cancellationToken)
    {
        var applications = await _repository.GetActiveOrderedAsync(cancellationToken);
        return applications
            .Select(a => new ApplicationDto(a.Id, a.Code, a.Name, a.Description, a.Icon, a.Route, a.DisplayOrder, a.Status))
            .ToList();
    }
}
