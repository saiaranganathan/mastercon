namespace ZWS.Modules.ApplicationHub.Application.Applications.Queries.GetApplications;

public record ApplicationDto(
    Guid Id, string Code, string Name, string? Description, string? Icon,
    string Route, int DisplayOrder, string Status);
