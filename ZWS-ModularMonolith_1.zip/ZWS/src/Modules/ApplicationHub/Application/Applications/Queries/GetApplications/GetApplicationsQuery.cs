using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.ApplicationHub.Application.Applications.Queries.GetApplications;

/// <summary>Drives GET /api/applications, which the ZWS Hub landing page calls to
/// render its cards - one of the spec's explicit Redis cache targets (section 25).</summary>
public record GetApplicationsQuery : IRequest<IReadOnlyList<ApplicationDto>>, ICacheableQuery
{
    public string CacheKey => "applicationhub:applications:active";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
