using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.ApplicationHub.Domain.Entities;

/// <summary>Backs one card on the ZWS Application Hub landing page (section 6). Seeded
/// with Paycon / Compliance / Trade Insights / PartnerHub - never hard-coded in Blazor.</summary>
public class Application : AggregateRoot<Guid>
{
    public string Code { get; private set; } = default!;      // e.g. "PAYCON" - used to build the client route
    public string Name { get; private set; } = default!;
    public string? Description { get; private set; }
    public string? Icon { get; private set; }                 // icon key resolved client-side, e.g. "wallet"
    public string Route { get; private set; } = default!;      // e.g. "/paycon/dashboard"
    public int DisplayOrder { get; private set; }
    public bool IsActive { get; private set; } = true;
    public string Status { get; private set; } = "Live";       // e.g. Live, Beta, ComingSoon
    public DateTime CreatedAtUtc { get; private set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; private set; } = DateTime.UtcNow;

    private Application() { }

    public static Application Create(string code, string name, string? description, string? icon, string route, int displayOrder, string status = "Live") =>
        new()
        {
            Id = Guid.NewGuid(),
            Code = code,
            Name = name,
            Description = description,
            Icon = icon,
            Route = route,
            DisplayOrder = displayOrder,
            Status = status
        };

    public void Deactivate()
    {
        IsActive = false;
        UpdatedAtUtc = DateTime.UtcNow;
    }
}
