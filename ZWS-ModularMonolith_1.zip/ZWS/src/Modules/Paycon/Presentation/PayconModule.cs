using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;
using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.Modules.Paycon.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;
using ZWS.Modules.Paycon.Presentation.Endpoints;

namespace ZWS.Modules.Paycon.Presentation;

/// <summary>
/// The ONE public seam of the Paycon module (section 4/43). Everything Paycon-related -
/// Dashboard, Reconciliation (Payments In/Out), Insights, Statements (Exit/Annual),
/// Settings (User/Scheme/Insight Management) - shares the single PayconDbContext
/// registered here. ZWS.Host never references Paycon's Domain/Application/
/// Infrastructure projects directly, only this class.
/// </summary>
public class PayconModule : IModule
{
    public string Name => "Paycon";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<PayconDbContext>(configuration, "Paycon", PayconDbContext.Schema);

        services.AddScoped<INavigationRepository, NavigationRepository>();
        services.AddScoped<IDashboardMetricRepository, DashboardMetricRepository>();
        services.AddScoped<IPaymentInRepository, PaymentInRepository>();
        services.AddScoped<IPaymentOutRepository, PaymentOutRepository>();
        services.AddScoped<IInsightRepository, InsightRepository>();
        services.AddScoped<IStatementRepository, StatementRepository>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<ISchemeRepository, SchemeRepository>();
        services.AddScoped<IInsightConfigurationRepository, InsightConfigurationRepository>();

        // IPayconRealtimeNotifier is implemented in ZWS.Host (it owns /payconHub) and
        // registered there; this module only depends on the abstraction.

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(
            typeof(Application.Navigation.Queries.GetPayconNavigation.GetPayconNavigationQuery).Assembly));

        services.AddValidatorsFromModule();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        NavigationEndpoints.Map(endpoints);
        DashboardEndpoints.Map(endpoints);
        ReconciliationEndpoints.Map(endpoints);
        InsightsEndpoints.Map(endpoints);
        StatementsEndpoints.Map(endpoints);
        SettingsEndpoints.Map(endpoints);
        return endpoints;
    }

    /// <summary>Realistic deterministic dummy data (section 30): navigation tree, dashboard
    /// metrics, 20 Payments In across varied statuses/methods/dates, a Payments Out sample,
    /// 5 schemes, 10 users, several insights, and exit/annual statements.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<PayconDbContext>();
        if (await db.NavigationItems.AnyAsync()) return;

        SeedNavigation(db);
        SeedDashboardMetrics(db);
        SeedPaymentsIn(db);
        SeedPaymentsOut(db);
        SeedInsights(db);
        SeedStatements(db);
        SeedSchemes(db);
        SeedUsers(db);
        SeedInsightConfigurations(db);

        await db.SaveChangesAsync();
    }

    private static void SeedNavigation(PayconDbContext db)
    {
        var dashboard = NavigationItem.Create("Dashboard", "/paycon/dashboard", "home", null, 1);

        var reconciliation = NavigationItem.Create("Reconciliation", null, "refresh-cw", null, 2);
        var paymentsIn = NavigationItem.Create("Payments In", "/paycon/reconciliation/payments-in", "arrow-down-circle", reconciliation.Id, 1);
        var paymentsOut = NavigationItem.Create("Payments Out", "/paycon/reconciliation/payments-out", "arrow-up-circle", reconciliation.Id, 2);

        var insights = NavigationItem.Create("Insights", "/paycon/insights", "bar-chart-2", null, 3);

        var statements = NavigationItem.Create("Statements", null, "file-text", null, 4);
        var exitStatements = NavigationItem.Create("Exit Statements", "/paycon/statements/exit-statements", "file-minus", statements.Id, 1);
        var annualStatements = NavigationItem.Create("Annual Statements", "/paycon/statements/annual-statements", "file-plus", statements.Id, 2);

        var settings = NavigationItem.Create("Settings", null, "settings", null, 5);
        var userManagement = NavigationItem.Create("User Management", "/paycon/settings/user-management", "users", settings.Id, 1);
        var schemeManagement = NavigationItem.Create("Scheme Management", "/paycon/settings/scheme-management", "layers", settings.Id, 2);
        var insightManagement = NavigationItem.Create("Insight Management", "/paycon/settings/insight-management", "sliders", settings.Id, 3);

        db.NavigationItems.AddRange(
            dashboard, reconciliation, paymentsIn, paymentsOut, insights,
            statements, exitStatements, annualStatements,
            settings, userManagement, schemeManagement, insightManagement);
    }

    private static void SeedDashboardMetrics(PayconDbContext db)
    {
        db.DashboardMetrics.AddRange(
            DashboardMetric.Create("Today's Contributions", 23_000_000m, 69_000_000m, "DEC '23", "Contributions", 1),
            DashboardMetric.Create("Mismatches", 4, 16, "DEC '23", "Reconciliation", 2),
            DashboardMetric.Create("Trades", 21_000_000m, 42_000_000m, "DEC '23", "Trades", 3),
            DashboardMetric.Create("Active Schemes", 5, null, "DEC '23", "Schemes", 4));
    }

    private static void SeedPaymentsIn(PayconDbContext db)
    {
        var customers = new[] { "Al Futtaim Group", "Emirates NBD Staff Fund", "DP World Employees", "Jumeirah Group", "Emaar Properties", "DEWA Pension Pool", "Etisalat Retirement Fund", "ADNOC Distribution", "Chalhoub Group", "Majid Al Futtaim" };
        var methods = new[] { "Bank Transfer", "SWIFT", "Direct Debit", "Domestic Wire" };
        var statuses = new[] { PaymentStatus.Matched, PaymentStatus.Pending, PaymentStatus.Mismatched, PaymentStatus.Processed };
        var random = new Random(42); // deterministic per section 30

        for (var i = 1; i <= 20; i++)
        {
            var customer = customers[i % customers.Length];
            var method = methods[i % methods.Length];
            var status = statuses[i % statuses.Length];
            var amount = 15_000m + i * 3_250m + random.Next(0, 999);
            var valueDate = DateTime.UtcNow.Date.AddDays(-random.Next(1, 45));

            var payment = PaymentIn.Create($"PIN-{2026000 + i}", customer, amount, "AED", method, valueDate, status);
            if (status is PaymentStatus.Matched or PaymentStatus.Processed)
                payment.MarkMatched($"CPTY-{3000 + i}");
            payment.ClearDomainEvents(); // seeding shouldn't fan out real domain events

            db.PaymentsIn.Add(payment);
        }
    }

    private static void SeedPaymentsOut(PayconDbContext db)
    {
        var beneficiaries = new[] { "Fatima Al Marri", "James Whitfield", "Rohan Mehta", "Layla Haddad", "Chen Wei", "Priya Nair", "Ahmed Al Suwaidi", "Sofia Ricci" };
        var methods = new[] { "Bank Transfer", "SWIFT", "Domestic Wire" };
        var statuses = new[] { PaymentStatus.Processed, PaymentStatus.Pending, PaymentStatus.Matched };

        for (var i = 1; i <= 12; i++)
        {
            var beneficiary = beneficiaries[i % beneficiaries.Length];
            var method = methods[i % methods.Length];
            var status = statuses[i % statuses.Length];
            var amount = 8_500m + i * 1_450m;
            var valueDate = DateTime.UtcNow.Date.AddDays(-i * 2);

            db.PaymentsOut.Add(PaymentOut.Create($"POUT-{4000 + i}", beneficiary, amount, "AED", method, valueDate, status));
        }
    }

    private static void SeedInsights(PayconDbContext db)
    {
        db.Insights.AddRange(
            Insight.Create("Contribution Growth", "Monthly contributions trending up across all schemes.", "Contributions", 12.4m, TrendDirection.Up),
            Insight.Create("Mismatch Rate", "Mismatch rate down compared to the prior reconciliation cycle.", "Reconciliation", 1.8m, TrendDirection.Down),
            Insight.Create("Average Processing Time", "Average time from payment receipt to match is stable.", "Operations", 2.1m, TrendDirection.Flat),
            Insight.Create("Fund Provider Payout Volume", "DEWS and DAMAN payout volumes both increased this quarter.", "Payouts", 8.6m, TrendDirection.Up));
    }

    private static void SeedStatements(PayconDbContext db)
    {
        var memberNames = new[] { "Omar Al Zaabi", "Grace Thompson", "Naveen Kumar", "Yasmin El Sayed", "Lucas Ferreira" };

        for (var i = 0; i < memberNames.Length; i++)
        {
            var memberId = Guid.NewGuid();
            db.ExitStatements.Add(ExitStatement.Create(memberId, memberNames[i], new DateTime(2025, 1, 1), new DateTime(2025, 12, 31)));
            db.AnnualStatements.Add(AnnualStatement.Create(memberId, memberNames[i], 2025));
        }
    }

    private static void SeedSchemes(PayconDbContext db)
    {
        db.Schemes.AddRange(
            Scheme.Create("DEWS", "DIFC Employee Workplace Savings", "Standard Chartered Bank - UAE"),
            Scheme.Create("DAMAN", "National Health Insurance Company", "Emirates NBD"),
            Scheme.Create("ADGM-WPS", "ADGM Workplace Savings Scheme", "First Abu Dhabi Bank"),
            Scheme.Create("QFC-EOSB", "QFC End of Service Benefits Scheme", "Qatar National Bank"),
            Scheme.Create("BAHRAIN-WPS", "Bahrain Workplace Savings Scheme", "Ahli United Bank"));
    }

    private static void SeedUsers(PayconDbContext db)
    {
        var users = new (string Email, string First, string Last, string Role)[]
        {
            ("admin@paycon.local", "System", "Administrator", "Administrator"),
            ("sara.hassan@paycon.local", "Sara", "Hassan", "Operations Manager"),
            ("michael.brown@paycon.local", "Michael", "Brown", "Reconciliation Analyst"),
            ("aisha.rahman@paycon.local", "Aisha", "Rahman", "Reconciliation Analyst"),
            ("david.oconnor@paycon.local", "David", "O'Connor", "Compliance Officer"),
            ("mei.tanaka@paycon.local", "Mei", "Tanaka", "Finance Controller"),
            ("khalid.ibrahim@paycon.local", "Khalid", "Ibrahim", "Scheme Administrator"),
            ("elena.petrova@paycon.local", "Elena", "Petrova", "Insights Analyst"),
            ("ravi.shah@paycon.local", "Ravi", "Shah", "Reconciliation Analyst"),
            ("noura.alblooshi@paycon.local", "Noura", "Al Blooshi", "Operations Manager"),
        };

        foreach (var (email, first, last, role) in users)
        {
            var user = PayconUser.Create(email, first, last, role);
            user.ClearDomainEvents(); // seeding shouldn't publish real UserCreated integration events
            db.Users.Add(user);
        }
    }

    private static void SeedInsightConfigurations(PayconDbContext db)
    {
        db.InsightConfigurations.AddRange(
            InsightConfiguration.Create("insights.refresh_interval_minutes", "15", "How often insight metrics recalculate."),
            InsightConfiguration.Create("insights.mismatch_alert_threshold_pct", "5", "Mismatch rate that triggers an alert."));
    }
}

file static class ServiceCollectionExtensions
{
    public static IServiceCollection AddValidatorsFromModule(this IServiceCollection services)
    {
        FluentValidation.AssemblyScanner
            .FindValidatorsInAssembly(typeof(Application.Navigation.Queries.GetPayconNavigation.GetPayconNavigationQuery).Assembly)
            .ForEach(result => services.AddScoped(result.InterfaceType, result.ValidatorType));
        return services;
    }
}
