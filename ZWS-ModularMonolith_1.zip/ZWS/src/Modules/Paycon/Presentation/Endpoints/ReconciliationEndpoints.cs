using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentInById;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsOut.Queries.GetPaymentsOut;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

public static class ReconciliationEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var paymentsIn = endpoints.MapGroup("/api/paycon/reconciliation/payments-in").WithTags("Paycon - Payments In");

        paymentsIn.MapGet("/", async (string? search, string? status, int page, int pageSize, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPaymentsInQuery(search, status, page == 0 ? 1 : page, pageSize == 0 ? 10 : pageSize), ct)));

        paymentsIn.MapGet("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            var payment = await sender.Send(new GetPaymentInByIdQuery(id), ct);
            return payment is null ? Results.NotFound() : Results.Ok(payment);
        });

        var paymentsOut = endpoints.MapGroup("/api/paycon/reconciliation/payments-out").WithTags("Paycon - Payments Out");

        paymentsOut.MapGet("/", async (string? search, int page, int pageSize, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPaymentsOutQuery(search, page == 0 ? 1 : page, pageSize == 0 ? 10 : pageSize), ct)));
    }
}
