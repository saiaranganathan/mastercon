using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Settings.InsightManagement.Queries.GetInsightConfigurations;
using ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.CreateScheme;
using ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.DeleteScheme;
using ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.UpdateScheme;
using ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Queries.GetSchemes;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.CreateUser;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.DeleteUser;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.UpdateUser;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Queries.GetUsers;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

/// <summary>User Management (full CRUD, completed Figma design), Scheme Management
/// (full CRUD, completed Figma design), Insight Management (read-only placeholder) -
/// section 27's /api/paycon/settings/* group.</summary>
public static class SettingsEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        // ---- User Management ----
        var users = endpoints.MapGroup("/api/paycon/settings/users").WithTags("Paycon - User Management");

        users.MapGet("/", async (string? search, int page, int pageSize, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetUsersQuery(search, page == 0 ? 1 : page, pageSize == 0 ? 10 : pageSize), ct)));

        users.MapPost("/", async (CreateUserCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/paycon/settings/users/{id}", new { id });
        });

        users.MapPut("/{id:guid}", async (Guid id, UpdateUserRequest request, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new UpdateUserCommand(id, request.FirstName, request.LastName, request.Role), ct);
            return Results.NoContent();
        });

        users.MapDelete("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new DeleteUserCommand(id), ct);
            return Results.NoContent();
        });

        // ---- Scheme Management ----
        var schemes = endpoints.MapGroup("/api/paycon/settings/schemes").WithTags("Paycon - Scheme Management");

        schemes.MapGet("/", async (string? search, int page, int pageSize, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetSchemesQuery(search, page == 0 ? 1 : page, pageSize == 0 ? 10 : pageSize), ct)));

        schemes.MapPost("/", async (CreateSchemeCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/paycon/settings/schemes/{id}", new { id });
        });

        schemes.MapPut("/{id:guid}", async (Guid id, UpdateSchemeRequest request, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new UpdateSchemeCommand(id, request.SchemeName, request.OperatingBank), ct);
            return Results.NoContent();
        });

        schemes.MapDelete("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new DeleteSchemeCommand(id), ct);
            return Results.NoContent();
        });

        // ---- Insight Management (placeholder, read-only) ----
        endpoints.MapGet("/api/paycon/settings/insights", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetInsightConfigurationsQuery(), ct)))
            .WithTags("Paycon - Insight Management");
    }
}

// Small request shapes for PUT bodies, kept next to the endpoints that use them rather
// than in Application, since they exist purely to bind route id + body into a command.
public record UpdateUserRequest(string FirstName, string LastName, string Role);
public record UpdateSchemeRequest(string SchemeName, string OperatingBank);
