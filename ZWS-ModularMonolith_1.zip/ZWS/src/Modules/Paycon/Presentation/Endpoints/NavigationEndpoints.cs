using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Navigation.Queries.GetPayconNavigation;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

public static class NavigationEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/paycon/navigation", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPayconNavigationQuery(), ct)))
            .WithTags("Paycon - Navigation");
    }
}
