using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Dashboard.Queries.GetPayconDashboard;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

public static class DashboardEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/paycon/dashboard", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPayconDashboardQuery(), ct)))
            .WithTags("Paycon - Dashboard");
    }
}
