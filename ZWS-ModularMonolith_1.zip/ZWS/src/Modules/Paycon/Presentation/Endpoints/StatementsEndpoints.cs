using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Statements.Queries.GetAnnualStatements;
using ZWS.Modules.Paycon.Application.Statements.Queries.GetExitStatements;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

public static class StatementsEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/paycon/statements/exit", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetExitStatementsQuery(), ct)))
            .WithTags("Paycon - Statements");

        endpoints.MapGet("/api/paycon/statements/annual", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetAnnualStatementsQuery(), ct)))
            .WithTags("Paycon - Statements");
    }
}
