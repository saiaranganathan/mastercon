using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using ZWS.Modules.Paycon.Application.Insights.Queries.GetInsights;

namespace ZWS.Modules.Paycon.Presentation.Endpoints;

public static class InsightsEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/paycon/insights", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetInsightsQuery(), ct)))
            .WithTags("Paycon - Insights");
    }
}
