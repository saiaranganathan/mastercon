using MediatR;
using ZWS.BuildingBlocks.EventBus;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.CreateUser;

public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, Guid>
{
    private readonly IUserRepository _repository;
    private readonly IEventBus _eventBus;

    public CreateUserCommandHandler(IUserRepository repository, IEventBus eventBus)
    {
        _repository = repository;
        _eventBus = eventBus;
    }

    public async Task<Guid> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        var user = PayconUser.Create(request.Email, request.FirstName, request.LastName, request.Role);
        await _repository.AddAsync(user, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        // Cross-module integration event (section 23) - any module can subscribe without referencing Paycon directly.
        await _eventBus.PublishAsync(new UserCreated(user.Id, user.Email, $"{user.FirstName} {user.LastName}"), cancellationToken);

        return user.Id;
    }
}
