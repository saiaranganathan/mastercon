namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Queries.GetUsers;

public record UserDto(Guid Id, string Email, string FirstName, string LastName, string Role, string Status, DateTime CreatedAtUtc);
