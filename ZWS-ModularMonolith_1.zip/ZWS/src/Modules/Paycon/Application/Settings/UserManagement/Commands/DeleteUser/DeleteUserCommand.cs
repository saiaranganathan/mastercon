using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.DeleteUser;

public record DeleteUserCommand(Guid UserId) : IRequest;
