using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Queries.GetUsers;

public class GetUsersQueryHandler : IRequestHandler<GetUsersQuery, PagedResult<UserDto>>
{
    private readonly IUserRepository _repository;
    public GetUsersQueryHandler(IUserRepository repository) => _repository = repository;

    public async Task<PagedResult<UserDto>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _repository.SearchAsync(request.Search, request.Page, request.PageSize, cancellationToken);
        var dtos = items.Select(u => new UserDto(u.Id, u.Email, u.FirstName, u.LastName, u.Role, u.Status.ToString(), u.CreatedAtUtc)).ToList();
        return new PagedResult<UserDto>(dtos, request.Page, request.PageSize, totalCount);
    }
}
