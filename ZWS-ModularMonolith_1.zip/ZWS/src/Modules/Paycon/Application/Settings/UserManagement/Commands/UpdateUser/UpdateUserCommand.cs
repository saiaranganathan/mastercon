using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.UpdateUser;

public record UpdateUserCommand(Guid UserId, string FirstName, string LastName, string Role) : IRequest;
