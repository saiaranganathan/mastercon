using MediatR;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Queries.GetUsers;

/// <summary>Drives GET /api/paycon/settings/users - search, pagination, per the
/// completed User Management Figma design (section 14).</summary>
public record GetUsersQuery(string? Search, int Page = 1, int PageSize = 10) : IRequest<PagedResult<UserDto>>;
