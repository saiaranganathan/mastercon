using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.CreateUser;

public record CreateUserCommand(string Email, string FirstName, string LastName, string Role) : IRequest<Guid>;
