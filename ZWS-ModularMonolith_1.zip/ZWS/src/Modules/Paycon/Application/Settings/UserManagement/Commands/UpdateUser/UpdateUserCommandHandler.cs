using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.UpdateUser;

public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand>
{
    private readonly IUserRepository _repository;
    public UpdateUserCommandHandler(IUserRepository repository) => _repository = repository;

    public async Task Handle(UpdateUserCommand request, CancellationToken cancellationToken)
    {
        var user = await _repository.GetByIdAsync(request.UserId, cancellationToken)
            ?? throw new KeyNotFoundException($"User {request.UserId} not found.");
        user.UpdateDetails(request.FirstName, request.LastName, request.Role);
        await _repository.SaveChangesAsync(cancellationToken);
    }
}
