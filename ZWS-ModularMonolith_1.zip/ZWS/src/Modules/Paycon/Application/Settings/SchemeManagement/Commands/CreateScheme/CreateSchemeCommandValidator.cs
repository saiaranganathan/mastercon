using FluentValidation;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.CreateScheme;

public class CreateSchemeCommandValidator : AbstractValidator<CreateSchemeCommand>
{
    public CreateSchemeCommandValidator()
    {
        RuleFor(x => x.SchemeCode).NotEmpty().MaximumLength(50);
        RuleFor(x => x.SchemeName).NotEmpty().MaximumLength(200);
        RuleFor(x => x.OperatingBank).NotEmpty().MaximumLength(200);
    }
}
