using MediatR;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Queries.GetSchemes;

public record GetSchemesQuery(string? Search, int Page = 1, int PageSize = 10) : IRequest<PagedResult<SchemeDto>>;
