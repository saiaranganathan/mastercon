namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Queries.GetSchemes;

public record SchemeDto(Guid Id, string SchemeCode, string SchemeName, string OperatingBank, bool IsActive);
