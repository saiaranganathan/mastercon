using FluentValidation;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.UpdateScheme;

public class UpdateSchemeCommandValidator : AbstractValidator<UpdateSchemeCommand>
{
    public UpdateSchemeCommandValidator()
    {
        RuleFor(x => x.SchemeName).NotEmpty().MaximumLength(200);
        RuleFor(x => x.OperatingBank).NotEmpty().MaximumLength(200);
    }
}
