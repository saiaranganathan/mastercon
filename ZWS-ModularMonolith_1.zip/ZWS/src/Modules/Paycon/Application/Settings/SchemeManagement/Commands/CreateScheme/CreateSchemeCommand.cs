using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.CreateScheme;

public record CreateSchemeCommand(string SchemeCode, string SchemeName, string OperatingBank) : IRequest<Guid>;
