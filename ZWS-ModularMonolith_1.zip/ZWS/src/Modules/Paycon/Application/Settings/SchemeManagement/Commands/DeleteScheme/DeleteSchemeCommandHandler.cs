using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.DeleteScheme;

public class DeleteSchemeCommandHandler : IRequestHandler<DeleteSchemeCommand>
{
    private readonly ISchemeRepository _repository;
    public DeleteSchemeCommandHandler(ISchemeRepository repository) => _repository = repository;

    public async Task Handle(DeleteSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = await _repository.GetByIdAsync(request.SchemeId, cancellationToken)
            ?? throw new KeyNotFoundException($"Scheme {request.SchemeId} not found.");
        _repository.Remove(scheme);
        await _repository.SaveChangesAsync(cancellationToken);
    }
}
