using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.DeleteScheme;

public record DeleteSchemeCommand(Guid SchemeId) : IRequest;
