using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Queries.GetSchemes;

public class GetSchemesQueryHandler : IRequestHandler<GetSchemesQuery, PagedResult<SchemeDto>>
{
    private readonly ISchemeRepository _repository;
    public GetSchemesQueryHandler(ISchemeRepository repository) => _repository = repository;

    public async Task<PagedResult<SchemeDto>> Handle(GetSchemesQuery request, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _repository.SearchAsync(request.Search, request.Page, request.PageSize, cancellationToken);
        var dtos = items.Select(s => new SchemeDto(s.Id, s.SchemeCode, s.SchemeName, s.OperatingBank, s.IsActive)).ToList();
        return new PagedResult<SchemeDto>(dtos, request.Page, request.PageSize, totalCount);
    }
}
