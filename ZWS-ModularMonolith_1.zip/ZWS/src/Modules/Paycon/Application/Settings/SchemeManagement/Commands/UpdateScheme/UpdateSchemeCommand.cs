using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.UpdateScheme;

public record UpdateSchemeCommand(Guid SchemeId, string SchemeName, string OperatingBank) : IRequest;
