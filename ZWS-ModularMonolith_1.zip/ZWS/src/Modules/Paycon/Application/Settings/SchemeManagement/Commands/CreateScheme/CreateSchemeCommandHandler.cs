using MediatR;
using ZWS.BuildingBlocks.EventBus;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.CreateScheme;

public class CreateSchemeCommandHandler : IRequestHandler<CreateSchemeCommand, Guid>
{
    private readonly ISchemeRepository _repository;
    private readonly IEventBus _eventBus;

    public CreateSchemeCommandHandler(ISchemeRepository repository, IEventBus eventBus)
    {
        _repository = repository;
        _eventBus = eventBus;
    }

    public async Task<Guid> Handle(CreateSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = Scheme.Create(request.SchemeCode, request.SchemeName, request.OperatingBank);
        await _repository.AddAsync(scheme, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventBus.PublishAsync(new SchemeUpdated(scheme.Id, scheme.SchemeCode), cancellationToken);
        return scheme.Id;
    }
}
