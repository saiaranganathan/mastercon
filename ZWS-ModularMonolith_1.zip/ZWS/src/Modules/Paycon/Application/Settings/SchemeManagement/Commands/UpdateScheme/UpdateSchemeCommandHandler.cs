using MediatR;
using ZWS.BuildingBlocks.EventBus;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Settings.SchemeManagement.Commands.UpdateScheme;

public class UpdateSchemeCommandHandler : IRequestHandler<UpdateSchemeCommand>
{
    private readonly ISchemeRepository _repository;
    private readonly IEventBus _eventBus;

    public UpdateSchemeCommandHandler(ISchemeRepository repository, IEventBus eventBus)
    {
        _repository = repository;
        _eventBus = eventBus;
    }

    public async Task Handle(UpdateSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = await _repository.GetByIdAsync(request.SchemeId, cancellationToken)
            ?? throw new KeyNotFoundException($"Scheme {request.SchemeId} not found.");
        scheme.UpdateDetails(request.SchemeName, request.OperatingBank);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventBus.PublishAsync(new SchemeUpdated(scheme.Id, scheme.SchemeCode), cancellationToken);
    }
}
