using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Settings.InsightManagement.Queries.GetInsightConfigurations;

public class GetInsightConfigurationsQueryHandler : IRequestHandler<GetInsightConfigurationsQuery, IReadOnlyList<InsightConfigurationDto>>
{
    private readonly IInsightConfigurationRepository _repository;
    public GetInsightConfigurationsQueryHandler(IInsightConfigurationRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<InsightConfigurationDto>> Handle(GetInsightConfigurationsQuery request, CancellationToken cancellationToken)
    {
        var configs = await _repository.GetAllAsync(cancellationToken);
        return configs.Select(c => new InsightConfigurationDto(c.Id, c.Key, c.Value, c.Description)).ToList();
    }
}
