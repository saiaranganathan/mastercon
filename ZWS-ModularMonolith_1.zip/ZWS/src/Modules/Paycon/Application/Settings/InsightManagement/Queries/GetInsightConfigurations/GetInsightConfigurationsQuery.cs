using MediatR;

namespace ZWS.Modules.Paycon.Application.Settings.InsightManagement.Queries.GetInsightConfigurations;

/// <summary>Drives GET /api/paycon/settings/insights - deliberately read-only and
/// minimal, per section 16: "clean placeholder... ready to replace... later", not an
/// invented CRUD surface the Figma design hasn't specified.</summary>
public record GetInsightConfigurationsQuery : IRequest<IReadOnlyList<InsightConfigurationDto>>;
