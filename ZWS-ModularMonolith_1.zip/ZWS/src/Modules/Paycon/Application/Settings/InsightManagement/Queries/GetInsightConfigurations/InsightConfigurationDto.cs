namespace ZWS.Modules.Paycon.Application.Settings.InsightManagement.Queries.GetInsightConfigurations;

public record InsightConfigurationDto(Guid Id, string Key, string Value, string? Description);
