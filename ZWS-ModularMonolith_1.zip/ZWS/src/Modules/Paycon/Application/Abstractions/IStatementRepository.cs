using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IStatementRepository
{
    Task<IReadOnlyList<ExitStatement>> GetExitStatementsAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<AnnualStatement>> GetAnnualStatementsAsync(CancellationToken cancellationToken);
}
