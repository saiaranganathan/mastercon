using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IDashboardMetricRepository
{
    Task<IReadOnlyList<DashboardMetric>> GetAllOrderedAsync(CancellationToken cancellationToken);
}
