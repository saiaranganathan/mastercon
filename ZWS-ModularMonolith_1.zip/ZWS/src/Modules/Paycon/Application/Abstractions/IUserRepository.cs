using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IUserRepository
{
    Task<(IReadOnlyList<PayconUser> Items, int TotalCount)> SearchAsync(string? search, int page, int pageSize, CancellationToken cancellationToken);
    Task<PayconUser?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task AddAsync(PayconUser user, CancellationToken cancellationToken);
    void Remove(PayconUser user);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
