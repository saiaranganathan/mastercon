using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface INavigationRepository
{
    Task<IReadOnlyList<NavigationItem>> GetVisibleOrderedAsync(CancellationToken cancellationToken);
}
