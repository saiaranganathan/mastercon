using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IInsightRepository
{
    Task<IReadOnlyList<Insight>> GetAllAsync(CancellationToken cancellationToken);
}
