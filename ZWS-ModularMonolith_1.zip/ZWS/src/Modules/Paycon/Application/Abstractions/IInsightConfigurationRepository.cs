using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IInsightConfigurationRepository
{
    Task<IReadOnlyList<InsightConfiguration>> GetAllAsync(CancellationToken cancellationToken);
}
