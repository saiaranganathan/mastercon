namespace ZWS.Modules.Paycon.Application.Abstractions;

/// <summary>Pushes live updates to /payconHub (section 24). Implemented in ZWS.Host,
/// which owns the SignalR hub; Application depends only on this abstraction, so it has
/// no reference to Microsoft.AspNetCore.SignalR.</summary>
public interface IPayconRealtimeNotifier
{
    Task NotifyPaymentStatusUpdatedAsync(Guid paymentId, string direction, string newStatus, CancellationToken cancellationToken);
    Task NotifyDashboardMetricUpdatedAsync(string label, decimal newValue, CancellationToken cancellationToken);
}
