using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IPaymentOutRepository
{
    Task<(IReadOnlyList<PaymentOut> Items, int TotalCount)> SearchAsync(
        string? search, int page, int pageSize, CancellationToken cancellationToken);
}
