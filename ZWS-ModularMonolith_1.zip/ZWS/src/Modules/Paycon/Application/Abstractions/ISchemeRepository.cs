using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface ISchemeRepository
{
    Task<(IReadOnlyList<Scheme> Items, int TotalCount)> SearchAsync(string? search, int page, int pageSize, CancellationToken cancellationToken);
    Task<Scheme?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task AddAsync(Scheme scheme, CancellationToken cancellationToken);
    void Remove(Scheme scheme);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
