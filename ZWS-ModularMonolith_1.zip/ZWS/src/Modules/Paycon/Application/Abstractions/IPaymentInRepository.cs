using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Application.Abstractions;

public interface IPaymentInRepository
{
    Task<(IReadOnlyList<PaymentIn> Items, int TotalCount)> SearchAsync(
        string? search, string? status, int page, int pageSize, CancellationToken cancellationToken);
    Task<PaymentIn?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task AddAsync(PaymentIn payment, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
