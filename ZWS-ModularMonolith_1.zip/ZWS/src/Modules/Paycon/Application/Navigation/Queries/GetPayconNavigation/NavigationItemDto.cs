namespace ZWS.Modules.Paycon.Application.Navigation.Queries.GetPayconNavigation;

/// <summary>Flat DTO - the Blazor sidebar builds the tree client-side by grouping on
/// ParentId (section 8/21), so the API stays a simple flat list rather than baking
/// tree-shape into the wire contract.</summary>
public record NavigationItemDto(Guid Id, string Name, string? Route, string? Icon, Guid? ParentId, int DisplayOrder);
