using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Navigation.Queries.GetPayconNavigation;

public class GetPayconNavigationQueryHandler : IRequestHandler<GetPayconNavigationQuery, IReadOnlyList<NavigationItemDto>>
{
    private readonly INavigationRepository _repository;
    public GetPayconNavigationQueryHandler(INavigationRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<NavigationItemDto>> Handle(GetPayconNavigationQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetVisibleOrderedAsync(cancellationToken);
        return items.Select(n => new NavigationItemDto(n.Id, n.Name, n.Route, n.Icon, n.ParentId, n.DisplayOrder)).ToList();
    }
}
