using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.Paycon.Application.Navigation.Queries.GetPayconNavigation;

/// <summary>Drives GET /api/paycon/navigation (sections 7, 25 - a named cache target).</summary>
public record GetPayconNavigationQuery : IRequest<IReadOnlyList<NavigationItemDto>>, ICacheableQuery
{
    public string CacheKey => "paycon:navigation:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(15);
}
