using MediatR;

namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetAnnualStatements;

/// <summary>Drives GET /api/paycon/statements/annual - placeholder screen (section 12)
/// but a fully working endpoint, same pattern as GetExitStatementsQuery.</summary>
public record GetAnnualStatementsQuery : IRequest<IReadOnlyList<AnnualStatementDto>>;
