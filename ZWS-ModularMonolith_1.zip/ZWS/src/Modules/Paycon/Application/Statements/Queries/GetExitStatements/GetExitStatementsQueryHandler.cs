using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetExitStatements;

public class GetExitStatementsQueryHandler : IRequestHandler<GetExitStatementsQuery, IReadOnlyList<ExitStatementDto>>
{
    private readonly IStatementRepository _repository;
    public GetExitStatementsQueryHandler(IStatementRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<ExitStatementDto>> Handle(GetExitStatementsQuery request, CancellationToken cancellationToken)
    {
        var statements = await _repository.GetExitStatementsAsync(cancellationToken);
        return statements.Select(s => new ExitStatementDto(s.Id, s.MemberName, s.PeriodStartUtc, s.PeriodEndUtc, s.Status.ToString())).ToList();
    }
}
