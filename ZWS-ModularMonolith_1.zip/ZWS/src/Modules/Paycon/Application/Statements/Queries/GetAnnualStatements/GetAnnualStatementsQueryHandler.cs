using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetAnnualStatements;

public class GetAnnualStatementsQueryHandler : IRequestHandler<GetAnnualStatementsQuery, IReadOnlyList<AnnualStatementDto>>
{
    private readonly IStatementRepository _repository;
    public GetAnnualStatementsQueryHandler(IStatementRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<AnnualStatementDto>> Handle(GetAnnualStatementsQuery request, CancellationToken cancellationToken)
    {
        var statements = await _repository.GetAnnualStatementsAsync(cancellationToken);
        return statements.Select(s => new AnnualStatementDto(s.Id, s.MemberName, s.StatementYear, s.Status.ToString())).ToList();
    }
}
