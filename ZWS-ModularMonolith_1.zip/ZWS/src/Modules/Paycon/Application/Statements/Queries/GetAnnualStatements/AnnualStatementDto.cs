namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetAnnualStatements;

public record AnnualStatementDto(Guid Id, string MemberName, int StatementYear, string Status);
