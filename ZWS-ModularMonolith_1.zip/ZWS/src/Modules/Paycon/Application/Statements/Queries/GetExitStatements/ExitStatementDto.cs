namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetExitStatements;

public record ExitStatementDto(Guid Id, string MemberName, DateTime PeriodStartUtc, DateTime PeriodEndUtc, string Status);
