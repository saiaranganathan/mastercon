using MediatR;

namespace ZWS.Modules.Paycon.Application.Statements.Queries.GetExitStatements;

public record GetExitStatementsQuery : IRequest<IReadOnlyList<ExitStatementDto>>;
