using MediatR;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsOut.Queries.GetPaymentsOut;

/// <summary>Drives GET /api/paycon/reconciliation/payments-out - a placeholder page
/// per section 10, but a fully working, paginated endpoint (not a stub).</summary>
public record GetPaymentsOutQuery(string? Search, int Page = 1, int PageSize = 10) : IRequest<PagedResult<PaymentOutDto>>;
