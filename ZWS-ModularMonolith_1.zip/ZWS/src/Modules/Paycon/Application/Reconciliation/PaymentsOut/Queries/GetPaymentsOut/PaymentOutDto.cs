namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsOut.Queries.GetPaymentsOut;

public record PaymentOutDto(Guid Id, string Reference, string BeneficiaryName, decimal Amount, string CurrencyCode, string PaymentMethod, DateTime ValueDateUtc, string Status);
