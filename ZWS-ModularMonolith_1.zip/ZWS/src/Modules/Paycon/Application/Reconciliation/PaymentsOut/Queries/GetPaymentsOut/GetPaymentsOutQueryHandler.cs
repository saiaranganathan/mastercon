using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsOut.Queries.GetPaymentsOut;

public class GetPaymentsOutQueryHandler : IRequestHandler<GetPaymentsOutQuery, PagedResult<PaymentOutDto>>
{
    private readonly IPaymentOutRepository _repository;
    public GetPaymentsOutQueryHandler(IPaymentOutRepository repository) => _repository = repository;

    public async Task<PagedResult<PaymentOutDto>> Handle(GetPaymentsOutQuery request, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _repository.SearchAsync(request.Search, request.Page, request.PageSize, cancellationToken);
        var dtos = items.Select(p => new PaymentOutDto(p.Id, p.Reference, p.BeneficiaryName, p.Amount, p.CurrencyCode, p.PaymentMethod, p.ValueDateUtc, p.Status.ToString())).ToList();
        return new PagedResult<PaymentOutDto>(dtos, request.Page, request.PageSize, totalCount);
    }
}
