using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentInById;

public class GetPaymentInByIdQueryHandler : IRequestHandler<GetPaymentInByIdQuery, PaymentInDto?>
{
    private readonly IPaymentInRepository _repository;
    public GetPaymentInByIdQueryHandler(IPaymentInRepository repository) => _repository = repository;

    public async Task<PaymentInDto?> Handle(GetPaymentInByIdQuery request, CancellationToken cancellationToken)
    {
        var p = await _repository.GetByIdAsync(request.PaymentId, cancellationToken);
        return p is null ? null : new PaymentInDto(p.Id, p.Reference, p.CustomerName, p.Amount, p.CurrencyCode, p.PaymentMethod, p.ValueDateUtc, p.Status.ToString(), p.CounterpartyReference);
    }
}
