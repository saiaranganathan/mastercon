using MediatR;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

/// <summary>Drives GET /api/paycon/reconciliation/payments-in - search, status filter,
/// and pagination, per the completed Payments In Figma design (section 10).</summary>
public record GetPaymentsInQuery(string? Search, string? Status, int Page = 1, int PageSize = 10)
    : IRequest<PagedResult<PaymentInDto>>;
