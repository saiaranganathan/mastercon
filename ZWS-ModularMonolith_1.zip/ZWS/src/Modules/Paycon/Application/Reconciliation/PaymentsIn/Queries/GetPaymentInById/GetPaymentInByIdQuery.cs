using MediatR;
using ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentInById;

public record GetPaymentInByIdQuery(Guid PaymentId) : IRequest<PaymentInDto?>;
