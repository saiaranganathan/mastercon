namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

public record PaymentInDto(
    Guid Id, string Reference, string CustomerName, decimal Amount, string CurrencyCode,
    string PaymentMethod, DateTime ValueDateUtc, string Status, string? CounterpartyReference);

public record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalCount)
{
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);
}
