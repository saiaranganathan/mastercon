using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Reconciliation.PaymentsIn.Queries.GetPaymentsIn;

public class GetPaymentsInQueryHandler : IRequestHandler<GetPaymentsInQuery, PagedResult<PaymentInDto>>
{
    private readonly IPaymentInRepository _repository;
    public GetPaymentsInQueryHandler(IPaymentInRepository repository) => _repository = repository;

    public async Task<PagedResult<PaymentInDto>> Handle(GetPaymentsInQuery request, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _repository.SearchAsync(request.Search, request.Status, request.Page, request.PageSize, cancellationToken);
        var dtos = items.Select(p => new PaymentInDto(p.Id, p.Reference, p.CustomerName, p.Amount, p.CurrencyCode, p.PaymentMethod, p.ValueDateUtc, p.Status.ToString(), p.CounterpartyReference)).ToList();
        return new PagedResult<PaymentInDto>(dtos, request.Page, request.PageSize, totalCount);
    }
}
