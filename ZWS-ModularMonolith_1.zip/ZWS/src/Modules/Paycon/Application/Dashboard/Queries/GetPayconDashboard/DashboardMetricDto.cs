namespace ZWS.Modules.Paycon.Application.Dashboard.Queries.GetPayconDashboard;

public record DashboardMetricDto(Guid Id, string Label, decimal PrimaryValue, decimal? ComparisonValue, string Period, string Category);
