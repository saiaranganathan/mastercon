using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Dashboard.Queries.GetPayconDashboard;

public class GetPayconDashboardQueryHandler : IRequestHandler<GetPayconDashboardQuery, IReadOnlyList<DashboardMetricDto>>
{
    private readonly IDashboardMetricRepository _repository;
    public GetPayconDashboardQueryHandler(IDashboardMetricRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<DashboardMetricDto>> Handle(GetPayconDashboardQuery request, CancellationToken cancellationToken)
    {
        var metrics = await _repository.GetAllOrderedAsync(cancellationToken);
        return metrics.Select(m => new DashboardMetricDto(m.Id, m.Label, m.PrimaryValue, m.ComparisonValue, m.Period, m.Category)).ToList();
    }
}
