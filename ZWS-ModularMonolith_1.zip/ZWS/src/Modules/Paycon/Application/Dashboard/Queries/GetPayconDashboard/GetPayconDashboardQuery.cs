using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.Paycon.Application.Dashboard.Queries.GetPayconDashboard;

/// <summary>Drives GET /api/paycon/dashboard (section 9.1, 25 - a named cache target).</summary>
public record GetPayconDashboardQuery : IRequest<IReadOnlyList<DashboardMetricDto>>, ICacheableQuery
{
    public string CacheKey => "paycon:dashboard:metrics";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(2);
}
