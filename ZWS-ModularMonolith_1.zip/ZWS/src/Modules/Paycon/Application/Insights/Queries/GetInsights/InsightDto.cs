namespace ZWS.Modules.Paycon.Application.Insights.Queries.GetInsights;

public record InsightDto(Guid Id, string Title, string Description, string Category, decimal Value, string Trend, DateTime GeneratedAtUtc);
