using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.Paycon.Application.Insights.Queries.GetInsights;

public record GetInsightsQuery : IRequest<IReadOnlyList<InsightDto>>, ICacheableQuery
{
    public string CacheKey => "paycon:insights:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(5);
}
