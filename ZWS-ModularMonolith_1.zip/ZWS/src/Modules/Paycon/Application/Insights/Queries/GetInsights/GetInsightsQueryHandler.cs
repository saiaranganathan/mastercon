using MediatR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Modules.Paycon.Application.Insights.Queries.GetInsights;

public class GetInsightsQueryHandler : IRequestHandler<GetInsightsQuery, IReadOnlyList<InsightDto>>
{
    private readonly IInsightRepository _repository;
    public GetInsightsQueryHandler(IInsightRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<InsightDto>> Handle(GetInsightsQuery request, CancellationToken cancellationToken)
    {
        var insights = await _repository.GetAllAsync(cancellationToken);
        return insights.Select(i => new InsightDto(i.Id, i.Title, i.Description, i.Category, i.Value, i.Trend.ToString(), i.GeneratedAtUtc)).ToList();
    }
}
