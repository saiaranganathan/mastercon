namespace ZWS.Modules.Paycon.Domain.Enums;

public enum PaymentStatus { Pending, Matched, Mismatched, Processed, Failed }
public enum UserStatus { Active, Inactive, Locked, PendingActivation }
public enum StatementStatus { Generated, Downloaded, Sent }
public enum TrendDirection { Up, Down, Flat }
