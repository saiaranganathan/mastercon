using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Events;

public record UserCreatedDomainEvent(Guid UserId, string Email, string FullName) : IDomainEvent
{
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
}
