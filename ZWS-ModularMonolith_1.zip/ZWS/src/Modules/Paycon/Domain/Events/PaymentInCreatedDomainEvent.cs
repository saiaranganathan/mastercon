using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Events;

public record PaymentInCreatedDomainEvent(Guid PaymentId, string Reference, decimal Amount, string CurrencyCode) : IDomainEvent
{
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
}
