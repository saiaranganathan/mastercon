using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.Modules.Paycon.Domain.Events;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/settings/user-management (section 14). Named PayconUser
/// (rather than User) to avoid any ambiguity with a future auth/identity provider.</summary>
public class PayconUser : AggregateRoot<Guid>
{
    public string Email { get; private set; } = default!;
    public string FirstName { get; private set; } = default!;
    public string LastName { get; private set; } = default!;
    public string Role { get; private set; } = default!;
    public UserStatus Status { get; private set; } = UserStatus.Active;
    public DateTime CreatedAtUtc { get; private set; } = DateTime.UtcNow;

    private PayconUser() { }

    public static PayconUser Create(string email, string firstName, string lastName, string role)
    {
        var user = new PayconUser { Id = Guid.NewGuid(), Email = email, FirstName = firstName, LastName = lastName, Role = role };
        user.Raise(new UserCreatedDomainEvent(user.Id, email, $"{firstName} {lastName}"));
        return user;
    }

    public void UpdateDetails(string firstName, string lastName, string role)
    {
        FirstName = firstName;
        LastName = lastName;
        Role = role;
    }

    public void Deactivate() => Status = UserStatus.Inactive;
}
