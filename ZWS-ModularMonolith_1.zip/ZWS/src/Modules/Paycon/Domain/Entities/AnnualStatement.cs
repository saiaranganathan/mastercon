using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/statements/annual-statements (section 12) - placeholder
/// implementation, same shape as ExitStatement per the shared design system.</summary>
public class AnnualStatement : AggregateRoot<Guid>
{
    public Guid MemberId { get; private set; }
    public string MemberName { get; private set; } = default!;
    public int StatementYear { get; private set; }
    public StatementStatus Status { get; private set; } = StatementStatus.Generated;
    public DateTime GeneratedAtUtc { get; private set; } = DateTime.UtcNow;

    private AnnualStatement() { }

    public static AnnualStatement Create(Guid memberId, string memberName, int statementYear) =>
        new() { Id = Guid.NewGuid(), MemberId = memberId, MemberName = memberName, StatementYear = statementYear };
}
