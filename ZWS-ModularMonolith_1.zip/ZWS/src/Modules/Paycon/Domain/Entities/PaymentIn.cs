using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.Modules.Paycon.Domain.Events;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/reconciliation/payments-in (section 10) - the module's most
/// fully-built Figma screen: search, filter, pagination, status badges.</summary>
public class PaymentIn : AggregateRoot<Guid>
{
    public string Reference { get; private set; } = default!;
    public string CustomerName { get; private set; } = default!;
    public decimal Amount { get; private set; }
    public string CurrencyCode { get; private set; } = "AED";
    public string PaymentMethod { get; private set; } = default!;
    public DateTime ValueDateUtc { get; private set; }
    public PaymentStatus Status { get; private set; } = PaymentStatus.Pending;
    public string? CounterpartyReference { get; private set; }

    private PaymentIn() { }

    public static PaymentIn Create(string reference, string customerName, decimal amount, string currencyCode, string paymentMethod, DateTime valueDateUtc, PaymentStatus status = PaymentStatus.Pending)
    {
        var payment = new PaymentIn
        {
            Id = Guid.NewGuid(),
            Reference = reference,
            CustomerName = customerName,
            Amount = amount,
            CurrencyCode = currencyCode,
            PaymentMethod = paymentMethod,
            ValueDateUtc = valueDateUtc,
            Status = status
        };
        payment.Raise(new PaymentInCreatedDomainEvent(payment.Id, reference, amount, currencyCode));
        return payment;
    }

    public void MarkMatched(string counterpartyReference)
    {
        Status = PaymentStatus.Matched;
        CounterpartyReference = counterpartyReference;
    }

    public void MarkMismatched() => Status = PaymentStatus.Mismatched;
}
