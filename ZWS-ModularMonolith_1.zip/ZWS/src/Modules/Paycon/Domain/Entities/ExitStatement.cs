using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/statements/exit-statements (section 12).</summary>
public class ExitStatement : AggregateRoot<Guid>
{
    public Guid MemberId { get; private set; }
    public string MemberName { get; private set; } = default!;
    public DateTime PeriodStartUtc { get; private set; }
    public DateTime PeriodEndUtc { get; private set; }
    public StatementStatus Status { get; private set; } = StatementStatus.Generated;
    public DateTime GeneratedAtUtc { get; private set; } = DateTime.UtcNow;

    private ExitStatement() { }

    public static ExitStatement Create(Guid memberId, string memberName, DateTime periodStartUtc, DateTime periodEndUtc) =>
        new() { Id = Guid.NewGuid(), MemberId = memberId, MemberName = memberName, PeriodStartUtc = periodStartUtc, PeriodEndUtc = periodEndUtc };
}
