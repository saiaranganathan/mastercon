using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Drives the Paycon sidebar (sections 7, 8, 21) - never hard-coded in Razor.
/// Self-referencing ParentId supports the two-level hierarchy the design calls for
/// (Reconciliation > Payments In/Out, Statements > Exit/Annual, Settings > User/Scheme/
/// Insight Management).</summary>
public class NavigationItem : AggregateRoot<Guid>
{
    public string ApplicationCode { get; private set; } = "PAYCON";
    public string Name { get; private set; } = default!;
    public string? Route { get; private set; }
    public string? Icon { get; private set; }
    public Guid? ParentId { get; private set; }
    public int DisplayOrder { get; private set; }
    public bool IsActive { get; private set; } = true;
    public bool IsVisible { get; private set; } = true;

    private NavigationItem() { }

    public static NavigationItem Create(string name, string? route, string? icon, Guid? parentId, int displayOrder) =>
        new()
        {
            Id = Guid.NewGuid(),
            Name = name,
            Route = route,
            Icon = icon,
            ParentId = parentId,
            DisplayOrder = displayOrder
        };
}
