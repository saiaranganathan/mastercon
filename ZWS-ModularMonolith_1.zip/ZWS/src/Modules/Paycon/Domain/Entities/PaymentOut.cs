using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/reconciliation/payments-out (section 10) - same shape as
/// PaymentIn, since no Figma design exists yet and the spec asks for a placeholder
/// "based on the Payments In design language", not a divergent model.</summary>
public class PaymentOut : AggregateRoot<Guid>
{
    public string Reference { get; private set; } = default!;
    public string BeneficiaryName { get; private set; } = default!;
    public decimal Amount { get; private set; }
    public string CurrencyCode { get; private set; } = "AED";
    public string PaymentMethod { get; private set; } = default!;
    public DateTime ValueDateUtc { get; private set; }
    public PaymentStatus Status { get; private set; } = PaymentStatus.Pending;

    private PaymentOut() { }

    public static PaymentOut Create(string reference, string beneficiaryName, decimal amount, string currencyCode, string paymentMethod, DateTime valueDateUtc, PaymentStatus status = PaymentStatus.Pending) =>
        new()
        {
            Id = Guid.NewGuid(),
            Reference = reference,
            BeneficiaryName = beneficiaryName,
            Amount = amount,
            CurrencyCode = currencyCode,
            PaymentMethod = paymentMethod,
            ValueDateUtc = valueDateUtc,
            Status = status
        };
}
