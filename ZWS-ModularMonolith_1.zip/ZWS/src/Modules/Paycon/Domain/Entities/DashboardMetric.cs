using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs the Dashboard's summary cards (section 9.1) - e.g. "Today's
/// Contributions", "Mismatches", "Trades".</summary>
public class DashboardMetric : AggregateRoot<Guid>
{
    public string Label { get; private set; } = default!;
    public decimal PrimaryValue { get; private set; }
    public decimal? ComparisonValue { get; private set; }
    public string Period { get; private set; } = default!;
    public string Category { get; private set; } = default!;
    public int DisplayOrder { get; private set; }

    private DashboardMetric() { }

    public static DashboardMetric Create(string label, decimal primaryValue, decimal? comparisonValue, string period, string category, int displayOrder) =>
        new()
        {
            Id = Guid.NewGuid(),
            Label = label,
            PrimaryValue = primaryValue,
            ComparisonValue = comparisonValue,
            Period = period,
            Category = category,
            DisplayOrder = displayOrder
        };
}
