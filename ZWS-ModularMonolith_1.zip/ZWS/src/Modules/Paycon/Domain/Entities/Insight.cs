using ZWS.Modules.Paycon.Domain.Enums;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/insights (section 11).</summary>
public class Insight : AggregateRoot<Guid>
{
    public string Title { get; private set; } = default!;
    public string Description { get; private set; } = default!;
    public string Category { get; private set; } = default!;
    public decimal Value { get; private set; }
    public TrendDirection Trend { get; private set; }
    public DateTime GeneratedAtUtc { get; private set; } = DateTime.UtcNow;

    private Insight() { }

    public static Insight Create(string title, string description, string category, decimal value, TrendDirection trend) =>
        new() { Id = Guid.NewGuid(), Title = title, Description = description, Category = category, Value = value, Trend = trend };
}
