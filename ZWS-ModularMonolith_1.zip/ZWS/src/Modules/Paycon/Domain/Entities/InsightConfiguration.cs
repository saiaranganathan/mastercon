using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/settings/insight-management (section 16) - a placeholder
/// screen per the spec, so this entity intentionally stays generic (a key/value
/// configuration row) rather than anticipating features the design hasn't specified yet.</summary>
public class InsightConfiguration : AggregateRoot<Guid>
{
    public string Key { get; private set; } = default!;
    public string Value { get; private set; } = default!;
    public string? Description { get; private set; }

    private InsightConfiguration() { }

    public static InsightConfiguration Create(string key, string value, string? description) =>
        new() { Id = Guid.NewGuid(), Key = key, Value = value, Description = description };
}
