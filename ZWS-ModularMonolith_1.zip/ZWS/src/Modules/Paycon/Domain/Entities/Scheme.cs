using ZWS.Modules.Paycon.Domain.Events;
using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Paycon.Domain.Entities;

/// <summary>Backs /paycon/settings/scheme-management (section 15).</summary>
public class Scheme : AggregateRoot<Guid>
{
    public string SchemeCode { get; private set; } = default!;
    public string SchemeName { get; private set; } = default!;
    public string OperatingBank { get; private set; } = default!;
    public bool IsActive { get; private set; } = true;

    private Scheme() { }

    public static Scheme Create(string schemeCode, string schemeName, string operatingBank) =>
        new() { Id = Guid.NewGuid(), SchemeCode = schemeCode, SchemeName = schemeName, OperatingBank = operatingBank };

    public void UpdateDetails(string schemeName, string operatingBank)
    {
        SchemeName = schemeName;
        OperatingBank = operatingBank;
    }

    public void Deactivate() => IsActive = false;
}
