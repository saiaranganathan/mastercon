using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class SchemeRepository : ISchemeRepository
{
    private readonly PayconDbContext _db;
    public SchemeRepository(PayconDbContext db) => _db = db;

    public async Task<(IReadOnlyList<Scheme> Items, int TotalCount)> SearchAsync(string? search, int page, int pageSize, CancellationToken cancellationToken)
    {
        var query = _db.Schemes.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(s => s.SchemeCode.Contains(search) || s.SchemeName.Contains(search));

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query.OrderBy(s => s.SchemeName).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(cancellationToken);
        return (items, totalCount);
    }

    public Task<Scheme?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Schemes.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    public Task AddAsync(Scheme scheme, CancellationToken cancellationToken)
    {
        _db.Schemes.Add(scheme);
        return Task.CompletedTask;
    }

    public void Remove(Scheme scheme) => _db.Schemes.Remove(scheme);

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
