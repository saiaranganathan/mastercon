using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class UserRepository : IUserRepository
{
    private readonly PayconDbContext _db;
    public UserRepository(PayconDbContext db) => _db = db;

    public async Task<(IReadOnlyList<PayconUser> Items, int TotalCount)> SearchAsync(string? search, int page, int pageSize, CancellationToken cancellationToken)
    {
        var query = _db.Users.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(u => u.Email.Contains(search) || u.FirstName.Contains(search) || u.LastName.Contains(search));

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query.OrderBy(u => u.LastName).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(cancellationToken);
        return (items, totalCount);
    }

    public Task<PayconUser?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Users.FirstOrDefaultAsync(u => u.Id == id, cancellationToken);

    public Task AddAsync(PayconUser user, CancellationToken cancellationToken)
    {
        _db.Users.Add(user);
        return Task.CompletedTask;
    }

    public void Remove(PayconUser user) => _db.Users.Remove(user);

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
