using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;
using ZWS.Modules.Paycon.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class NavigationRepository : INavigationRepository
{
    private readonly PayconDbContext _db;
    public NavigationRepository(PayconDbContext db) => _db = db;

    public async Task<IReadOnlyList<NavigationItem>> GetVisibleOrderedAsync(CancellationToken cancellationToken) =>
        await _db.NavigationItems.AsNoTracking()
            .Where(n => n.IsActive && n.IsVisible)
            .OrderBy(n => n.DisplayOrder)
            .ToListAsync(cancellationToken);
}
