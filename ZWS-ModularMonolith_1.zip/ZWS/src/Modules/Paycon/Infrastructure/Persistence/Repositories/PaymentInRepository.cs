using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;
using ZWS.Modules.Paycon.Domain.Enums;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class PaymentInRepository : IPaymentInRepository
{
    private readonly PayconDbContext _db;
    public PaymentInRepository(PayconDbContext db) => _db = db;

    public async Task<(IReadOnlyList<PaymentIn> Items, int TotalCount)> SearchAsync(
        string? search, string? status, int page, int pageSize, CancellationToken cancellationToken)
    {
        var query = _db.PaymentsIn.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(p => p.Reference.Contains(search) || p.CustomerName.Contains(search));

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<PaymentStatus>(status, true, out var parsedStatus))
            query = query.Where(p => p.Status == parsedStatus);

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderByDescending(p => p.ValueDateUtc)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return (items, totalCount);
    }

    public Task<PaymentIn?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.PaymentsIn.FirstOrDefaultAsync(p => p.Id == id, cancellationToken);

    public Task AddAsync(PaymentIn payment, CancellationToken cancellationToken)
    {
        _db.PaymentsIn.Add(payment);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
