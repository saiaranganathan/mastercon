using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class InsightConfigurationRepository : IInsightConfigurationRepository
{
    private readonly PayconDbContext _db;
    public InsightConfigurationRepository(PayconDbContext db) => _db = db;

    public async Task<IReadOnlyList<InsightConfiguration>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.InsightConfigurations.AsNoTracking().OrderBy(c => c.Key).ToListAsync(cancellationToken);
}
