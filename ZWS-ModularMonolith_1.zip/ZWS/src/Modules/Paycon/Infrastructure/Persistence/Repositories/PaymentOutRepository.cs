using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class PaymentOutRepository : IPaymentOutRepository
{
    private readonly PayconDbContext _db;
    public PaymentOutRepository(PayconDbContext db) => _db = db;

    public async Task<(IReadOnlyList<PaymentOut> Items, int TotalCount)> SearchAsync(
        string? search, int page, int pageSize, CancellationToken cancellationToken)
    {
        var query = _db.PaymentsOut.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(p => p.Reference.Contains(search) || p.BeneficiaryName.Contains(search));

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderByDescending(p => p.ValueDateUtc)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return (items, totalCount);
    }
}
