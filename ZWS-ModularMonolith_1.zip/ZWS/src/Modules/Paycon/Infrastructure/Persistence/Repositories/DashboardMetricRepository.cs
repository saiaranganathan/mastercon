using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class DashboardMetricRepository : IDashboardMetricRepository
{
    private readonly PayconDbContext _db;
    public DashboardMetricRepository(PayconDbContext db) => _db = db;

    public async Task<IReadOnlyList<DashboardMetric>> GetAllOrderedAsync(CancellationToken cancellationToken) =>
        await _db.DashboardMetrics.AsNoTracking().OrderBy(m => m.DisplayOrder).ToListAsync(cancellationToken);
}
