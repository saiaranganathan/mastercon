using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class InsightRepository : IInsightRepository
{
    private readonly PayconDbContext _db;
    public InsightRepository(PayconDbContext db) => _db = db;

    public async Task<IReadOnlyList<Insight>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Insights.AsNoTracking().OrderByDescending(i => i.GeneratedAtUtc).ToListAsync(cancellationToken);
}
