using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Repositories;

public class StatementRepository : IStatementRepository
{
    private readonly PayconDbContext _db;
    public StatementRepository(PayconDbContext db) => _db = db;

    public async Task<IReadOnlyList<ExitStatement>> GetExitStatementsAsync(CancellationToken cancellationToken) =>
        await _db.ExitStatements.AsNoTracking().OrderByDescending(s => s.GeneratedAtUtc).ToListAsync(cancellationToken);

    public async Task<IReadOnlyList<AnnualStatement>> GetAnnualStatementsAsync(CancellationToken cancellationToken) =>
        await _db.AnnualStatements.AsNoTracking().OrderByDescending(s => s.StatementYear).ToListAsync(cancellationToken);
}
