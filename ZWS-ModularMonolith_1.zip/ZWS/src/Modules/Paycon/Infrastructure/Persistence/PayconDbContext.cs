using MediatR;
using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence;

/// <summary>
/// THE single DbContext for the entire Paycon module (section 4/43: one DbContext per
/// module, not per feature). Every Paycon entity - navigation, dashboard metrics,
/// payments, insights, statements, users, schemes, insight configuration - lives here,
/// under the "paycon" schema. Nothing outside this module ever resolves this type from
/// DI, and Compliance/TradeInsights/PartnerHub never reference it.
/// </summary>
public class PayconDbContext : DbContext
{
    public const string Schema = "paycon";

    private readonly IPublisher? _publisher;

    public PayconDbContext(DbContextOptions<PayconDbContext> options, IPublisher? publisher = null) : base(options)
    {
        _publisher = publisher;
    }

    public DbSet<NavigationItem> NavigationItems => Set<NavigationItem>();
    public DbSet<DashboardMetric> DashboardMetrics => Set<DashboardMetric>();
    public DbSet<PaymentIn> PaymentsIn => Set<PaymentIn>();
    public DbSet<PaymentOut> PaymentsOut => Set<PaymentOut>();
    public DbSet<Insight> Insights => Set<Insight>();
    public DbSet<ExitStatement> ExitStatements => Set<ExitStatement>();
    public DbSet<AnnualStatement> AnnualStatements => Set<AnnualStatement>();
    public DbSet<PayconUser> Users => Set<PayconUser>();
    public DbSet<Scheme> Schemes => Set<Scheme>();
    public DbSet<InsightConfiguration> InsightConfigurations => Set<InsightConfiguration>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(PayconDbContext).Assembly);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var entitiesWithEvents = ChangeTracker.Entries<Entity<Guid>>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Count != 0)
            .ToList();

        var result = await base.SaveChangesAsync(cancellationToken);

        if (_publisher is not null)
        {
            foreach (var entity in entitiesWithEvents)
            {
                var events = entity.DomainEvents.ToList();
                entity.ClearDomainEvents();
                foreach (var domainEvent in events)
                    await _publisher.Publish(domainEvent, cancellationToken);
            }
        }

        return result;
    }
}
