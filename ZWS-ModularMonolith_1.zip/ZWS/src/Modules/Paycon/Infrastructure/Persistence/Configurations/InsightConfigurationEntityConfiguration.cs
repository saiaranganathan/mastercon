using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class InsightConfigurationEntityConfiguration : IEntityTypeConfiguration<InsightConfiguration>
{
    public void Configure(EntityTypeBuilder<InsightConfiguration> builder)
    {
        builder.ToTable("InsightConfigurations", PayconDbContext.Schema);
        builder.HasKey(c => c.Id);
        builder.Property(c => c.Key).HasMaxLength(100).IsRequired();
        builder.HasIndex(c => c.Key).IsUnique();
        builder.Property(c => c.Value).HasMaxLength(500).IsRequired();
        builder.Property(c => c.Description).HasMaxLength(500);
        builder.Ignore(c => c.DomainEvents);
    }
}
