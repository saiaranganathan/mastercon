using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class PaymentOutConfiguration : IEntityTypeConfiguration<PaymentOut>
{
    public void Configure(EntityTypeBuilder<PaymentOut> builder)
    {
        builder.ToTable("PaymentsOut", PayconDbContext.Schema);
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Reference).HasMaxLength(100).IsRequired();
        builder.Property(p => p.BeneficiaryName).HasMaxLength(200).IsRequired();
        builder.Property(p => p.Amount).HasColumnType("decimal(18,2)");
        builder.Property(p => p.CurrencyCode).HasMaxLength(3);
        builder.Property(p => p.PaymentMethod).HasMaxLength(50);
        builder.Property(p => p.Status).HasConversion<string>().HasMaxLength(20);
        builder.Ignore(p => p.DomainEvents);
    }
}
