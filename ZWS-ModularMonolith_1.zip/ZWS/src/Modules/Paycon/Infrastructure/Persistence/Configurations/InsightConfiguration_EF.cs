using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

// Named with an _EF suffix on the file (not the class) purely to avoid a same-named-file
// clash with Domain.Entities.InsightConfiguration in tooling that flattens paths.
public class InsightEntityConfiguration : IEntityTypeConfiguration<Insight>
{
    public void Configure(EntityTypeBuilder<Insight> builder)
    {
        builder.ToTable("Insights", PayconDbContext.Schema);
        builder.HasKey(i => i.Id);
        builder.Property(i => i.Title).HasMaxLength(200).IsRequired();
        builder.Property(i => i.Description).HasMaxLength(1000);
        builder.Property(i => i.Category).HasMaxLength(50);
        builder.Property(i => i.Value).HasColumnType("decimal(18,2)");
        builder.Property(i => i.Trend).HasConversion<string>().HasMaxLength(10);
        builder.Ignore(i => i.DomainEvents);
    }
}
