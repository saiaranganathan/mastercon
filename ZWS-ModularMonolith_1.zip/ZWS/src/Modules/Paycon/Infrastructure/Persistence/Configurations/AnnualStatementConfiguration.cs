using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class AnnualStatementConfiguration : IEntityTypeConfiguration<AnnualStatement>
{
    public void Configure(EntityTypeBuilder<AnnualStatement> builder)
    {
        builder.ToTable("AnnualStatements", PayconDbContext.Schema);
        builder.HasKey(s => s.Id);
        builder.HasIndex(s => s.MemberId);
        builder.Property(s => s.MemberName).HasMaxLength(200).IsRequired();
        builder.Property(s => s.Status).HasConversion<string>().HasMaxLength(20);
        builder.Ignore(s => s.DomainEvents);
    }
}
