using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class DashboardMetricConfiguration : IEntityTypeConfiguration<DashboardMetric>
{
    public void Configure(EntityTypeBuilder<DashboardMetric> builder)
    {
        builder.ToTable("DashboardMetrics", PayconDbContext.Schema);
        builder.HasKey(m => m.Id);
        builder.Property(m => m.Label).HasMaxLength(150).IsRequired();
        builder.Property(m => m.PrimaryValue).HasColumnType("decimal(18,2)");
        builder.Property(m => m.ComparisonValue).HasColumnType("decimal(18,2)");
        builder.Property(m => m.Period).HasMaxLength(30);
        builder.Property(m => m.Category).HasMaxLength(50);
        builder.Ignore(m => m.DomainEvents);
    }
}
