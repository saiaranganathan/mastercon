using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class SchemeConfiguration : IEntityTypeConfiguration<Scheme>
{
    public void Configure(EntityTypeBuilder<Scheme> builder)
    {
        builder.ToTable("Schemes", PayconDbContext.Schema);
        builder.HasKey(s => s.Id);
        builder.Property(s => s.SchemeCode).HasMaxLength(50).IsRequired();
        builder.HasIndex(s => s.SchemeCode).IsUnique();
        builder.Property(s => s.SchemeName).HasMaxLength(200).IsRequired();
        builder.Property(s => s.OperatingBank).HasMaxLength(200);
        builder.Ignore(s => s.DomainEvents);
    }
}
