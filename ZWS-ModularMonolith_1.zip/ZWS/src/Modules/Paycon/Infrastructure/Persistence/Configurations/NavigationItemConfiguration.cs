using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;
using ZWS.Modules.Paycon.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class NavigationItemConfiguration : IEntityTypeConfiguration<NavigationItem>
{
    public void Configure(EntityTypeBuilder<NavigationItem> builder)
    {
        builder.ToTable("NavigationItems", PayconDbContext.Schema);
        builder.HasKey(n => n.Id);
        builder.Property(n => n.ApplicationCode).HasMaxLength(50);
        builder.Property(n => n.Name).HasMaxLength(150).IsRequired();
        builder.Property(n => n.Route).HasMaxLength(200);
        builder.Property(n => n.Icon).HasMaxLength(50);
        builder.HasIndex(n => n.ParentId);
        builder.Ignore(n => n.DomainEvents);
    }
}
