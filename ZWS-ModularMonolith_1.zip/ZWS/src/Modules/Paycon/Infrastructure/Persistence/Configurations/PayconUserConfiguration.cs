using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Domain.Entities;

namespace ZWS.Modules.Paycon.Infrastructure.Persistence.Configurations;

public class PayconUserConfiguration : IEntityTypeConfiguration<PayconUser>
{
    public void Configure(EntityTypeBuilder<PayconUser> builder)
    {
        builder.ToTable("Users", PayconDbContext.Schema);
        builder.HasKey(u => u.Id);
        builder.Property(u => u.Email).HasMaxLength(256).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique();
        builder.Property(u => u.FirstName).HasMaxLength(100).IsRequired();
        builder.Property(u => u.LastName).HasMaxLength(100).IsRequired();
        builder.Property(u => u.Role).HasMaxLength(50);
        builder.Property(u => u.Status).HasConversion<string>().HasMaxLength(30);
        builder.Ignore(u => u.DomainEvents);
    }
}
