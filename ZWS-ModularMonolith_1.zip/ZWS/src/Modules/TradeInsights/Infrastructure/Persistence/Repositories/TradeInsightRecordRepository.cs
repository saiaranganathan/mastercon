using Microsoft.EntityFrameworkCore;
using ZWS.Modules.TradeInsights.Application.Abstractions;
using ZWS.Modules.TradeInsights.Domain.Entities;

namespace ZWS.Modules.TradeInsights.Infrastructure.Persistence.Repositories;

public class TradeInsightRecordRepository : ITradeInsightRecordRepository
{
    private readonly TradeInsightsDbContext _db;
    public TradeInsightRecordRepository(TradeInsightsDbContext db) => _db = db;

    public async Task<IReadOnlyList<TradeInsightRecord>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.TradeInsightRecords.AsNoTracking().ToListAsync(cancellationToken);
}
