using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.TradeInsights.Domain.Entities;

namespace ZWS.Modules.TradeInsights.Infrastructure.Persistence.Configurations;

public class TradeInsightRecordConfiguration : IEntityTypeConfiguration<TradeInsightRecord>
{
    public void Configure(EntityTypeBuilder<TradeInsightRecord> builder)
    {
        builder.ToTable("TradeInsightRecords", TradeInsightsDbContext.Schema);
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Title).HasMaxLength(200);
        builder.Property(x => x.Market).HasMaxLength(50);
        builder.Property(x => x.ValueUsd).HasColumnType("decimal(18,2)");
        builder.Ignore(x => x.DomainEvents);
    }
}
