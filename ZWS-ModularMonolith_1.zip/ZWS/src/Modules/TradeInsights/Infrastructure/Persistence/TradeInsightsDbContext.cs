using Microsoft.EntityFrameworkCore;
using ZWS.Modules.TradeInsights.Domain.Entities;

namespace ZWS.Modules.TradeInsights.Infrastructure.Persistence;

/// <summary>This module's own DbContext (section 4) - "tradeinsights" schema. TradeInsights is
/// independent of Paycon and every other module; nothing outside this module resolves
/// this type from DI.</summary>
public class TradeInsightsDbContext : DbContext
{
    public const string Schema = "tradeinsights";

    public TradeInsightsDbContext(DbContextOptions<TradeInsightsDbContext> options) : base(options) { }

    public DbSet<TradeInsightRecord> TradeInsightRecords => Set<TradeInsightRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(TradeInsightsDbContext).Assembly);
    }
}
