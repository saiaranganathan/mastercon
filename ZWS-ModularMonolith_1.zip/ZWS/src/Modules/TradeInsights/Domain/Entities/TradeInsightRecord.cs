using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.TradeInsights.Domain.Entities;

/// <summary>Backs the Trade Insights application's landing/dashboard page (section 17) - a trade activity analytics record.</summary>
public class TradeInsightRecord : AggregateRoot<Guid>
{
    public string Title { get; private set; } = default!;
    public string Market { get; private set; } = default!;
    public decimal ValueUsd { get; private set; };
    public DateTime ObservedAtUtc { get; private set; };

    private TradeInsightRecord() { }

    public static TradeInsightRecord Create(string title, string market, decimal valueUsd, DateTime observedAtUtc) =>
        new()
        {
            Id = Guid.NewGuid(),
            Title = title,
            Market = market,
            ValueUsd = valueUsd,
            ObservedAtUtc = observedAtUtc,
        };
}
