using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.TradeInsights.Application.Abstractions;
using ZWS.Modules.TradeInsights.Application.TradeInsightRecords.Queries.GetTradeInsightRecords;
using ZWS.Modules.TradeInsights.Domain.Entities;
using ZWS.Modules.TradeInsights.Infrastructure.Persistence;
using ZWS.Modules.TradeInsights.Infrastructure.Persistence.Repositories;

namespace ZWS.Modules.TradeInsights.Presentation;

/// <summary>The ONE public seam of the TradeInsights module (section 17). Independent module
/// structure - own Domain/Application/Infrastructure/Presentation, own TradeInsightsDbContext,
/// own seed data, a basic landing/dashboard page - proportionate to spec section 17,
/// which explicitly says these three modules don't need Paycon's level of functionality.</summary>
public class TradeInsightsModule : IModule
{
    public string Name => "TradeInsights";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<TradeInsightsDbContext>(configuration, "TradeInsights", TradeInsightsDbContext.Schema);
        services.AddScoped<ITradeInsightRecordRepository, TradeInsightRecordRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetTradeInsightRecordsQuery).Assembly));
        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/tradeinsights/trade-insight-records", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetTradeInsightRecordsQuery(), ct)))
            .WithTags("TradeInsights");

        return endpoints;
    }

    /// <summary>Realistic dummy data (section 30) so the TradeInsights landing page isn't empty
    /// on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<TradeInsightsDbContext>();
        if (await db.TradeInsightRecords.AnyAsync()) return;

        db.TradeInsightRecords.AddRange(
            TradeInsightRecord.Create("Equity allocation shift toward MENA markets", "Equities", 4200000m, DateTime.UtcNow.AddDays(-1)),
            TradeInsightRecord.Create("Fixed income yield compression observed", "Fixed Income", 1850000m, DateTime.UtcNow.AddDays(-3)),
            TradeInsightRecord.Create("Increased FX hedging activity - AED/USD", "FX", 950000m, DateTime.UtcNow.AddDays(-2)),
            TradeInsightRecord.Create("Commodity exposure rebalancing", "Commodities", 610000m, DateTime.UtcNow.AddDays(-6)),
            TradeInsightRecord.Create("Alternative assets inflow - real estate funds", "Alternatives", 2300000m, DateTime.UtcNow.AddDays(-4)));

        await db.SaveChangesAsync();
    }
}
