using ZWS.Modules.TradeInsights.Domain.Entities;

namespace ZWS.Modules.TradeInsights.Application.Abstractions;

public interface ITradeInsightRecordRepository
{
    Task<IReadOnlyList<TradeInsightRecord>> GetAllAsync(CancellationToken cancellationToken);
}
