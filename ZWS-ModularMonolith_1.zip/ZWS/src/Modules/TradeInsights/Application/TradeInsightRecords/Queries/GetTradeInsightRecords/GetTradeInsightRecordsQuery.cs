using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.TradeInsights.Application.TradeInsightRecords.Queries.GetTradeInsightRecords;

/// <summary>Drives GET /api/tradeinsights/trade-insight-records - the TradeInsights module's basic landing/dashboard data
/// source (section 17), database-driven like every other module rather than
/// hard-coded in Blazor.</summary>
public record GetTradeInsightRecordsQuery : IRequest<IReadOnlyList<TradeInsightRecordDto>>, ICacheableQuery
{
    public string CacheKey => "tradeinsights:tradeinsightrecords:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
