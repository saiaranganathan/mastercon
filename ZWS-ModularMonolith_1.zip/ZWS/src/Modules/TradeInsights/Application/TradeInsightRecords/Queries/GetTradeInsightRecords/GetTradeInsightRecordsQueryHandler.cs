using MediatR;
using ZWS.Modules.TradeInsights.Application.Abstractions;

namespace ZWS.Modules.TradeInsights.Application.TradeInsightRecords.Queries.GetTradeInsightRecords;

public class GetTradeInsightRecordsQueryHandler : IRequestHandler<GetTradeInsightRecordsQuery, IReadOnlyList<TradeInsightRecordDto>>
{
    private readonly ITradeInsightRecordRepository _repository;
    public GetTradeInsightRecordsQueryHandler(ITradeInsightRecordRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<TradeInsightRecordDto>> Handle(GetTradeInsightRecordsQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetAllAsync(cancellationToken);
        return items.Select(x => new TradeInsightRecordDto(x.Id, x.Title, x.Market, x.ValueUsd, x.ObservedAtUtc)).ToList();
    }
}
