namespace ZWS.Modules.TradeInsights.Application.TradeInsightRecords.Queries.GetTradeInsightRecords;

public record TradeInsightRecordDto(Guid Id, string Title, string Market, decimal ValueUsd, DateTime ObservedAtUtc);
