using MediatR;
using ZWS.BuildingBlocks.Behaviors;

namespace ZWS.Modules.Compliance.Application.ComplianceCases.Queries.GetComplianceCases;

/// <summary>Drives GET /api/compliance/compliance-cases - the Compliance module's basic landing/dashboard data
/// source (section 17), database-driven like every other module rather than
/// hard-coded in Blazor.</summary>
public record GetComplianceCasesQuery : IRequest<IReadOnlyList<ComplianceCaseDto>>, ICacheableQuery
{
    public string CacheKey => "compliance:compliancecases:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
