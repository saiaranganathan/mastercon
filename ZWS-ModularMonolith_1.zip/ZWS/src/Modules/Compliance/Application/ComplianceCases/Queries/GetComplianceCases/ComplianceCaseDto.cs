namespace ZWS.Modules.Compliance.Application.ComplianceCases.Queries.GetComplianceCases;

public record ComplianceCaseDto(Guid Id, string Title, string Status, string Severity, DateTime DueDateUtc);
