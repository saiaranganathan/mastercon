using MediatR;
using ZWS.Modules.Compliance.Application.Abstractions;

namespace ZWS.Modules.Compliance.Application.ComplianceCases.Queries.GetComplianceCases;

public class GetComplianceCasesQueryHandler : IRequestHandler<GetComplianceCasesQuery, IReadOnlyList<ComplianceCaseDto>>
{
    private readonly IComplianceCaseRepository _repository;
    public GetComplianceCasesQueryHandler(IComplianceCaseRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<ComplianceCaseDto>> Handle(GetComplianceCasesQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetAllAsync(cancellationToken);
        return items.Select(x => new ComplianceCaseDto(x.Id, x.Title, x.Status, x.Severity, x.DueDateUtc)).ToList();
    }
}
