using ZWS.Modules.Compliance.Domain.Entities;

namespace ZWS.Modules.Compliance.Application.Abstractions;

public interface IComplianceCaseRepository
{
    Task<IReadOnlyList<ComplianceCase>> GetAllAsync(CancellationToken cancellationToken);
}
