using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Compliance.Application.Abstractions;
using ZWS.Modules.Compliance.Domain.Entities;

namespace ZWS.Modules.Compliance.Infrastructure.Persistence.Repositories;

public class ComplianceCaseRepository : IComplianceCaseRepository
{
    private readonly ComplianceDbContext _db;
    public ComplianceCaseRepository(ComplianceDbContext db) => _db = db;

    public async Task<IReadOnlyList<ComplianceCase>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.ComplianceCases.AsNoTracking().ToListAsync(cancellationToken);
}
