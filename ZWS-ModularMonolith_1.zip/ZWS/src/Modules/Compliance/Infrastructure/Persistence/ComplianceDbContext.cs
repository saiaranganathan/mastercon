using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Compliance.Domain.Entities;

namespace ZWS.Modules.Compliance.Infrastructure.Persistence;

/// <summary>This module's own DbContext (section 4) - "compliance" schema. Compliance is
/// independent of Paycon and every other module; nothing outside this module resolves
/// this type from DI.</summary>
public class ComplianceDbContext : DbContext
{
    public const string Schema = "compliance";

    public ComplianceDbContext(DbContextOptions<ComplianceDbContext> options) : base(options) { }

    public DbSet<ComplianceCase> ComplianceCases => Set<ComplianceCase>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ComplianceDbContext).Assembly);
    }
}
