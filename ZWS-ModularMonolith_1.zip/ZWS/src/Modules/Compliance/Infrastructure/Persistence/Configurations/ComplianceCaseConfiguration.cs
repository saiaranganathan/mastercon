using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Compliance.Domain.Entities;

namespace ZWS.Modules.Compliance.Infrastructure.Persistence.Configurations;

public class ComplianceCaseConfiguration : IEntityTypeConfiguration<ComplianceCase>
{
    public void Configure(EntityTypeBuilder<ComplianceCase> builder)
    {
        builder.ToTable("ComplianceCases", ComplianceDbContext.Schema);
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Title).HasMaxLength(200);
        builder.Property(x => x.Status).HasMaxLength(30);
        builder.Property(x => x.Severity).HasMaxLength(20);
        builder.Ignore(x => x.DomainEvents);
    }
}
