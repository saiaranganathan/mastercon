using ZWS.BuildingBlocks.SharedKernel;

namespace ZWS.Modules.Compliance.Domain.Entities;

/// <summary>Backs the Compliance application's landing/dashboard page (section 17) - a regulatory tracking case.</summary>
public class ComplianceCase : AggregateRoot<Guid>
{
    public string Title { get; private set; } = default!;
    public string Status { get; private set; } = default!;
    public string Severity { get; private set; } = default!;
    public DateTime DueDateUtc { get; private set; };

    private ComplianceCase() { }

    public static ComplianceCase Create(string title, string status, string severity, DateTime dueDateUtc) =>
        new()
        {
            Id = Guid.NewGuid(),
            Title = title,
            Status = status,
            Severity = severity,
            DueDateUtc = dueDateUtc,
        };
}
