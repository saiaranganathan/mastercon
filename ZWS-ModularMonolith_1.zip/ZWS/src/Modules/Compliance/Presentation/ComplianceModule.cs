using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.Compliance.Application.Abstractions;
using ZWS.Modules.Compliance.Application.ComplianceCases.Queries.GetComplianceCases;
using ZWS.Modules.Compliance.Domain.Entities;
using ZWS.Modules.Compliance.Infrastructure.Persistence;
using ZWS.Modules.Compliance.Infrastructure.Persistence.Repositories;

namespace ZWS.Modules.Compliance.Presentation;

/// <summary>The ONE public seam of the Compliance module (section 17). Independent module
/// structure - own Domain/Application/Infrastructure/Presentation, own ComplianceDbContext,
/// own seed data, a basic landing/dashboard page - proportionate to spec section 17,
/// which explicitly says these three modules don't need Paycon's level of functionality.</summary>
public class ComplianceModule : IModule
{
    public string Name => "Compliance";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<ComplianceDbContext>(configuration, "Compliance", ComplianceDbContext.Schema);
        services.AddScoped<IComplianceCaseRepository, ComplianceCaseRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetComplianceCasesQuery).Assembly));
        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/compliance/compliance-cases", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetComplianceCasesQuery(), ct)))
            .WithTags("Compliance");

        return endpoints;
    }

    /// <summary>Realistic dummy data (section 30) so the Compliance landing page isn't empty
    /// on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ComplianceDbContext>();
        if (await db.ComplianceCases.AnyAsync()) return;

        db.ComplianceCases.AddRange(
            ComplianceCase.Create("KYC refresh overdue - DEWS members", "Open", "High", DateTime.UtcNow.AddDays(5)),
            ComplianceCase.Create("Annual AML training compliance check", "InProgress", "Medium", DateTime.UtcNow.AddDays(12)),
            ComplianceCase.Create("Sanctions screening false-positive review", "Open", "Low", DateTime.UtcNow.AddDays(3)),
            ComplianceCase.Create("Data retention policy audit - Q1", "Resolved", "Medium", DateTime.UtcNow.AddDays(-10)),
            ComplianceCase.Create("Regulatory filing - DFSA quarterly return", "InProgress", "High", DateTime.UtcNow.AddDays(8)),
            ComplianceCase.Create("Vendor due diligence renewal - Custodian Bank", "Open", "Medium", DateTime.UtcNow.AddDays(20)));

        await db.SaveChangesAsync();
    }
}
