using ZWS.BuildingBlocks.SharedKernel;
using ZWS.Modules.ApplicationHub.Presentation;
using ZWS.Modules.Compliance.Presentation;
using ZWS.Modules.PartnerHub.Presentation;
using ZWS.Modules.Paycon.Presentation;
using ZWS.Modules.TradeInsights.Presentation;

namespace ZWS.Host;

/// <summary>
/// The complete list of modules in the ZWS application (section 6: ApplicationHub,
/// then Paycon, Compliance, TradeInsights, PartnerHub). This is the single file you
/// touch to add/remove a module - nothing else in Program.cs changes. ApplicationHub
/// is registered first since nothing else depends on it, but registration order
/// otherwise doesn't matter - modules never depend on each other's registration.
/// </summary>
public static class ModuleRegistry
{
    public static IReadOnlyList<IModule> AllModules { get; } = new IModule[]
    {
        new ApplicationHubModule(),
        new PayconModule(),
        new ComplianceModule(),
        new TradeInsightsModule(),
        new PartnerHubModule(),
    };
}
