using System.Text.Json;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Serilog;
using ZWS.BuildingBlocks.Behaviors;
using ZWS.BuildingBlocks.Caching;
using ZWS.BuildingBlocks.EventBus;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Host;
using ZWS.Host.HealthChecks;
using ZWS.Host.Hubs;
using ZWS.Modules.Paycon.Application.Abstractions;

var builder = WebApplication.CreateBuilder(args);

// ---------- Logging (section 33/38: proper logging) ----------
builder.Host.UseSerilog((context, configuration) => configuration
    .ReadFrom.Configuration(context.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console());

// ---------- CORS for the Blazor WebAssembly client (ZWS.Web) ----------
const string BlazorClientCors = "BlazorClient";
builder.Services.AddCors(options =>
{
    options.AddPolicy(BlazorClientCors, policy => policy
        .WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? new[] { "https://localhost:5031" })
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowCredentials()); // required for SignalR
});

// ---------- Zero-dependency local/test mode: one flag switches every module's database
// (see ZWS.BuildingBlocks.Persistence, used inside each module's RegisterModule), the
// cache, and the message bus together (section 26/35's "in-memory SQL-compatible
// database" requirement, extended consistently to the other two infra dependencies). ----------
var useInMemoryInfrastructure = builder.Configuration.GetValue<bool>("Infrastructure:UseInMemory");

// ---------- Cache: Azure Cache for Redis in real environments, in-process memory cache
// in the zero-dependency profile (section 25). Both are IDistributedCache. ----------
builder.Services.Configure<RedisOptions>(builder.Configuration.GetSection(RedisOptions.SectionName));
if (useInMemoryInfrastructure)
{
    builder.Services.AddDistributedMemoryCache();
}
else
{
    builder.Services.AddStackExchangeRedisCache(options =>
    {
        options.Configuration = builder.Configuration.GetSection(RedisOptions.SectionName)["ConnectionString"];
        options.InstanceName = "zws:";
    });
}
builder.Services.AddSingleton<ICacheService, RedisCacheService>();

// ---------- Event bus: RabbitMQ with retry + DLQ in real environments (section 23), an
// in-process, no-broker bus in the zero-dependency profile. ----------
builder.Services.Configure<RabbitMqOptions>(builder.Configuration.GetSection(RabbitMqOptions.SectionName));
if (useInMemoryInfrastructure)
{
    builder.Services.AddSingleton<IEventBus, InMemoryEventBus>();
}
else
{
    builder.Services.AddSingleton<IEventBus, RabbitMqEventBus>();
}

// ---------- SignalR (section 24: real-time Paycon updates) ----------
builder.Services.AddSignalR();

// ---------- MediatR pipeline behaviors, shared by every module's registered handlers ----------
builder.Services.AddMediatR(cfg =>
{
    cfg.AddOpenBehavior(typeof(LoggingBehavior<,>));
    cfg.AddOpenBehavior(typeof(ValidationBehavior<,>));
    cfg.AddOpenBehavior(typeof(CachingBehavior<,>));
});

// ---------- Host-side adapter satisfying Paycon's SignalR abstraction ----------
builder.Services.AddScoped<IPayconRealtimeNotifier, PayconRealtimeNotifierAdapter>();

// ---------- Centralized exception handling (section 32) ----------
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();

// ---------- Register every module: its own DbContext (own schema/connection), its own
// MediatR handlers, its own repositories/validators. See ModuleRegistry.cs. ----------
foreach (var module in ModuleRegistry.AllModules)
{
    module.RegisterModule(builder.Services, builder.Configuration);
}

// ---------- Health checks (section 33): /health is a cheap liveness probe; /health/ready
// additionally verifies SQL, Redis, and RabbitMQ - skipped in the in-memory profile,
// where there's no real infrastructure to check. ----------
var healthChecksBuilder = builder.Services.AddHealthChecks();
if (!useInMemoryInfrastructure)
{
    var connectionStrings = builder.Configuration.GetSection("ConnectionStrings").GetChildren();
    foreach (var cs in connectionStrings)
    {
        if (string.IsNullOrWhiteSpace(cs.Value)) continue;
        healthChecksBuilder.AddSqlServer(cs.Value, name: $"sql-{cs.Key.ToLowerInvariant()}", tags: new[] { "ready" });
    }

    var redisConnectionString = builder.Configuration.GetSection(RedisOptions.SectionName)["ConnectionString"];
    if (!string.IsNullOrWhiteSpace(redisConnectionString))
        healthChecksBuilder.AddRedis(redisConnectionString, name: "redis", tags: new[] { "ready" });

    healthChecksBuilder.AddCheck<RabbitMqHealthCheck>("rabbitmq", tags: new[] { "ready" });
}

// ---------- OpenAPI / Swagger (section 34) ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "ZWS API", Version = "v1", Description = "ZWS Application Hub - modular monolith (ApplicationHub, Paycon, Compliance, TradeInsights, PartnerHub)" });
});

var app = builder.Build();

app.UseExceptionHandler();

// ---------- Placeholder for cross-module integration event subscriptions. No module
// currently subscribes to another module's events out of the box (the contracts in
// ZWS.BuildingBlocks.EventBus are ready for it - e.g. a future Compliance handler for
// UserCreated) - resolve IEventBus and add eventBus.Subscribe<TEvent, THandler>() calls
// here as those handlers are built. ----------

// ---------- In the zero-dependency profile: create every module's schema (EnsureCreated,
// no migrations needed) before seeding. ----------
if (useInMemoryInfrastructure)
{
    var initializers = app.Services.GetServices<IModuleDbInitializer>();
    foreach (var initializer in initializers)
        await initializer.InitializeAsync(app.Services);

    foreach (var module in ModuleRegistry.AllModules)
        await module.SeedAsync(app.Services, builder.Configuration);
}

if (app.Environment.IsDevelopment() || app.Environment.IsEnvironment("Local"))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors(BlazorClientCors);
app.UseAuthentication();
app.UseAuthorization();

// ---------- Map every module's minimal-API endpoints under its own route group. ----------
foreach (var module in ModuleRegistry.AllModules)
{
    module.MapEndpoints(app);
}

app.MapHub<PayconHub>("/payconHub");

// ---------- Health checks (section 33) ----------
app.MapHealthChecks("/health", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = _ => false, // liveness only - no dependency checks
    ResponseWriter = WriteHealthResponseAsync
});
app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = WriteHealthResponseAsync
});

app.Run();

// Top-level statements generate an internal Program class by default; WebApplicationFactory<Program>
// in ZWS.IntegrationTests needs it to be public to reference it.
public partial class Program { }

static Task WriteHealthResponseAsync(HttpContext context, Microsoft.Extensions.Diagnostics.HealthChecks.HealthReport report)
{
    context.Response.ContentType = "application/json";
    var payload = JsonSerializer.Serialize(new
    {
        status = report.Status.ToString(),
        checks = report.Entries.Select(e => new { name = e.Key, status = e.Value.Status.ToString(), description = e.Value.Description }),
        totalDurationMs = report.TotalDuration.TotalMilliseconds
    });
    return context.Response.WriteAsync(payload);
}
