using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using ZWS.BuildingBlocks.EventBus;

namespace ZWS.Host.HealthChecks;

/// <summary>
/// Hand-rolled rather than a community NuGet package, so it stays exactly in sync with
/// the RabbitMQ.Client version this solution pins in ZWS.BuildingBlocks.EventBus
/// (6.8.1, synchronous CreateConnection) - avoids a version-mismatch risk against a
/// health-check package built for a different RabbitMQ.Client major version.
/// </summary>
public class RabbitMqHealthCheck : IHealthCheck
{
    private readonly RabbitMqOptions _options;
    public RabbitMqHealthCheck(IOptions<RabbitMqOptions> options) => _options = options.Value;

    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var factory = new ConnectionFactory
            {
                HostName = _options.Host,
                Port = _options.Port,
                UserName = _options.Username,
                Password = _options.Password,
                VirtualHost = _options.VirtualHost,
                RequestedConnectionTimeout = TimeSpan.FromSeconds(3)
            };

            using var connection = factory.CreateConnection("zws-healthcheck");
            return Task.FromResult(connection.IsOpen
                ? HealthCheckResult.Healthy("RabbitMQ connection established.")
                : HealthCheckResult.Unhealthy("RabbitMQ connection could not be opened."));
        }
        catch (Exception ex)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy("RabbitMQ is unreachable.", ex));
        }
    }
}
