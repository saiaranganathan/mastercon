using Microsoft.AspNetCore.SignalR;
using ZWS.Modules.Paycon.Application.Abstractions;

namespace ZWS.Host.Hubs;

/// <summary>Host-side implementation of Paycon's SignalR abstraction. This is the ONLY
/// place SignalR-specific code exists for Paycon - Paycon.Application never references
/// Microsoft.AspNetCore.SignalR.</summary>
public class PayconRealtimeNotifierAdapter : IPayconRealtimeNotifier
{
    private readonly IHubContext<PayconHub> _hub;
    public PayconRealtimeNotifierAdapter(IHubContext<PayconHub> hub) => _hub = hub;

    public Task NotifyPaymentStatusUpdatedAsync(Guid paymentId, string direction, string newStatus, CancellationToken cancellationToken) =>
        _hub.Clients.Group("paycon-dashboard").SendAsync("PaymentStatusUpdated", new { paymentId, direction, newStatus }, cancellationToken);

    public Task NotifyDashboardMetricUpdatedAsync(string label, decimal newValue, CancellationToken cancellationToken) =>
        _hub.Clients.Group("paycon-dashboard").SendAsync("DashboardMetricUpdated", new { label, newValue }, cancellationToken);
}
