using Microsoft.AspNetCore.SignalR;

namespace ZWS.Host.Hubs;

/// <summary>
/// The Paycon real-time hub (section 24), mounted at /payconHub. Modules never
/// reference this class directly - they depend on IPayconRealtimeNotifier
/// (Paycon.Application), which PayconRealtimeNotifierAdapter below implements against
/// this hub. Supports PaymentStatusUpdated, ReconciliationUpdated,
/// DashboardMetricUpdated, NotificationReceived per the spec.
/// </summary>
public class PayconHub : Hub
{
    public async Task JoinDashboardGroup() => await Groups.AddToGroupAsync(Context.ConnectionId, "paycon-dashboard");
}
