using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.ApplicationHub;

/// <summary>Representative endpoint integration test (section 35: "Test: API
/// endpoints"), exercising the full stack - real routing, real MediatR handler, real
/// (in-memory) DbContext, real seed data. Follow this pattern for the remaining
/// endpoints across every module.</summary>
public class ApplicationsEndpointTests : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client;
    public ApplicationsEndpointTests(ZwsWebApplicationFactory factory) => _client = factory.CreateClient();

    [Fact]
    public async Task GetApplications_ReturnsSeededApplications()
    {
        var response = await _client.GetAsync("/api/applications");

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var applications = await response.Content.ReadFromJsonAsync<List<ApplicationDto>>();

        applications.Should().NotBeNull();
        applications!.Select(a => a.Code).Should().Contain(new[] { "PAYCON", "COMPLIANCE", "TRADE_INSIGHTS", "PARTNER_HUB" });
    }

    private record ApplicationDto(Guid Id, string Code, string Name, string? Description, string? Icon, string Route, int DisplayOrder, string Status);
}
