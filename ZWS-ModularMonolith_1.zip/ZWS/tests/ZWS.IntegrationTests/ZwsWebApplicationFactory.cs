using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace ZWS.IntegrationTests;

/// <summary>
/// Boots the real ZWS.Host pipeline - every module, every MediatR handler, real
/// endpoint routing - but forces Infrastructure:UseInMemory = true (section 26/35's
/// preferred SQLite in-memory database) and points the environment at "Local" so no
/// external SQL/Redis/RabbitMQ is required to run these tests.
/// </summary>
public class ZwsWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Local");
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Infrastructure:UseInMemory"] = "true"
            });
        });
    }
}
