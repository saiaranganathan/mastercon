using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Paycon;

public class PayconNavigationEndpointTests : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client;
    public PayconNavigationEndpointTests(ZwsWebApplicationFactory factory) => _client = factory.CreateClient();

    [Fact]
    public async Task GetNavigation_ReturnsHierarchicalItemsIncludingParentAndChildEntries()
    {
        var response = await _client.GetAsync("/api/paycon/navigation");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var items = await response.Content.ReadFromJsonAsync<List<NavigationItemDto>>();
        items.Should().NotBeNull();

        var reconciliation = items!.Single(i => i.Name == "Reconciliation" && i.ParentId == null);
        var paymentsIn = items.Single(i => i.Name == "Payments In");

        paymentsIn.ParentId.Should().Be(reconciliation.Id);
        paymentsIn.Route.Should().Be("/paycon/reconciliation/payments-in");
    }

    private record NavigationItemDto(Guid Id, string Name, string? Route, string? Icon, Guid? ParentId, int DisplayOrder);
}
