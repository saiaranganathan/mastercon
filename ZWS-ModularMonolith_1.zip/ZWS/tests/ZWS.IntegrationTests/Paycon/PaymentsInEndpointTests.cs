using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Paycon;

public class PaymentsInEndpointTests : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client;
    public PaymentsInEndpointTests(ZwsWebApplicationFactory factory) => _client = factory.CreateClient();

    [Fact]
    public async Task GetPaymentsIn_ReturnsPagedSeededResults()
    {
        var response = await _client.GetAsync("/api/paycon/reconciliation/payments-in?page=1&pageSize=5");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var result = await response.Content.ReadFromJsonAsync<PagedResultDto>();
        result.Should().NotBeNull();
        result!.Items.Should().HaveCount(5);
        result.TotalCount.Should().Be(20); // section 30: "at least 20 realistic payment records"
    }

    private record PaymentInDto(Guid Id, string Reference, string CustomerName, decimal Amount);
    private record PagedResultDto(List<PaymentInDto> Items, int Page, int PageSize, int TotalCount);
}
