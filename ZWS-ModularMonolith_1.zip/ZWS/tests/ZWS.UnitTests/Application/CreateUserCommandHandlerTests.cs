using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.EventBus;
using ZWS.Modules.Paycon.Application.Abstractions;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.CreateUser;
using ZWS.Modules.Paycon.Domain.Entities;
using Xunit;

namespace ZWS.UnitTests.Application;

/// <summary>Representative MediatR handler test with a mocked repository and event bus
/// (section 35: "Test: MediatR handlers"). Follow this pattern for the remaining
/// command/query handlers across every module.</summary>
public class CreateUserCommandHandlerTests
{
    [Fact]
    public async Task Handle_AddsUserAndPublishesUserCreatedIntegrationEvent()
    {
        var repositoryMock = new Mock<IUserRepository>();
        var eventBusMock = new Mock<IEventBus>();
        PayconUser? addedUser = null;
        repositoryMock
            .Setup(r => r.AddAsync(It.IsAny<PayconUser>(), It.IsAny<CancellationToken>()))
            .Callback<PayconUser, CancellationToken>((user, _) => addedUser = user)
            .Returns(Task.CompletedTask);

        var handler = new CreateUserCommandHandler(repositoryMock.Object, eventBusMock.Object);
        var command = new CreateUserCommand("jane.doe@paycon.local", "Jane", "Doe", "Operations Manager");

        var userId = await handler.Handle(command, CancellationToken.None);

        userId.Should().NotBeEmpty();
        addedUser.Should().NotBeNull();
        addedUser!.Email.Should().Be("jane.doe@paycon.local");
        repositoryMock.Verify(r => r.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
        eventBusMock.Verify(b => b.PublishAsync(It.Is<UserCreated>(e => e.Email == "jane.doe@paycon.local"), It.IsAny<CancellationToken>()), Times.Once);
    }
}
