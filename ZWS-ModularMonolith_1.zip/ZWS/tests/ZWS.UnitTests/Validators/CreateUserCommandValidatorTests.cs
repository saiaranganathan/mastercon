using FluentAssertions;
using ZWS.Modules.Paycon.Application.Settings.UserManagement.Commands.CreateUser;
using Xunit;

namespace ZWS.UnitTests.Validators;

/// <summary>Representative validator tests (section 35: "Test: Validators"). Follow
/// this pattern for CreateSchemeCommandValidator, UpdateUserCommandValidator, etc.</summary>
public class CreateUserCommandValidatorTests
{
    private readonly CreateUserCommandValidator _validator = new();

    [Fact]
    public void Validate_WithValidCommand_HasNoErrors()
    {
        var command = new CreateUserCommand("jane.doe@paycon.local", "Jane", "Doe", "Operations Manager");

        var result = _validator.Validate(command);

        result.IsValid.Should().BeTrue();
    }

    [Theory]
    [InlineData("", "Jane", "Doe", "Operations Manager")]     // missing email
    [InlineData("not-an-email", "Jane", "Doe", "Operations Manager")] // invalid email
    [InlineData("jane.doe@paycon.local", "", "Doe", "Operations Manager")] // missing first name
    [InlineData("jane.doe@paycon.local", "Jane", "", "Operations Manager")] // missing last name
    [InlineData("jane.doe@paycon.local", "Jane", "Doe", "")]  // missing role
    public void Validate_WithInvalidCommand_HasErrors(string email, string firstName, string lastName, string role)
    {
        var command = new CreateUserCommand(email, firstName, lastName, role);

        var result = _validator.Validate(command);

        result.IsValid.Should().BeFalse();
    }
}
