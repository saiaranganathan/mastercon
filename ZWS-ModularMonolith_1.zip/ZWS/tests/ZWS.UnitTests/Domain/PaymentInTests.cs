using FluentAssertions;
using ZWS.Modules.Paycon.Domain.Entities;
using ZWS.Modules.Paycon.Domain.Enums;
using Xunit;

namespace ZWS.UnitTests.Domain;

/// <summary>Representative domain-logic tests (section 35: "Unit Tests / Test: Domain
/// logic"). Follow this pattern for the remaining aggregates (User, Scheme,
/// ReconciliationBatch-equivalent entities, ...).</summary>
public class PaymentInTests
{
    [Fact]
    public void Create_SetsInitialStatusToPending()
    {
        var payment = PaymentIn.Create("PIN-1001", "Acme Corp", 15_000m, "AED", "Bank Transfer", DateTime.UtcNow);

        payment.Status.Should().Be(PaymentStatus.Pending);
        payment.Reference.Should().Be("PIN-1001");
    }

    [Fact]
    public void Create_RaisesPaymentInCreatedDomainEvent()
    {
        var payment = PaymentIn.Create("PIN-1002", "Acme Corp", 15_000m, "AED", "Bank Transfer", DateTime.UtcNow);

        payment.DomainEvents.Should().ContainSingle(e => e.GetType().Name == "PaymentInCreatedDomainEvent");
    }

    [Fact]
    public void MarkMatched_SetsStatusAndCounterpartyReference()
    {
        var payment = PaymentIn.Create("PIN-1003", "Acme Corp", 15_000m, "AED", "Bank Transfer", DateTime.UtcNow);

        payment.MarkMatched("CPTY-500");

        payment.Status.Should().Be(PaymentStatus.Matched);
        payment.CounterpartyReference.Should().Be("CPTY-500");
    }

    [Fact]
    public void MarkMismatched_SetsStatusToMismatched()
    {
        var payment = PaymentIn.Create("PIN-1004", "Acme Corp", 15_000m, "AED", "Bank Transfer", DateTime.UtcNow);

        payment.MarkMismatched();

        payment.Status.Should().Be(PaymentStatus.Mismatched);
    }
}
