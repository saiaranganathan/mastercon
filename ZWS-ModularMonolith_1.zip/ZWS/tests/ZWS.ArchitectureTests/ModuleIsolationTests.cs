using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace ZWS.ArchitectureTests;

/// <summary>
/// Enforces section 35's four architecture rules by reflecting over the compiled
/// assemblies (NetArchTest inspects IL, so these only pass if the rule is actually
/// true in the built binaries, not just in intent). Assembly names are the source of
/// truth for "which module/layer a type belongs to" - see each project's
/// AssemblyName/namespace, which follow the ZWS.Modules.{Module}.{Layer} convention
/// throughout the solution.
/// </summary>
public class ModuleIsolationTests
{
    [Fact]
    public void Domain_Assemblies_ShouldNotDependOn_Infrastructure()
    {
        var result = Types.InAssemblies(LoadedAssemblies.All)
            .That().ResideInNamespaceContaining(".Domain")
            .Should().NotHaveDependencyOnAny(".Infrastructure", "Microsoft.EntityFrameworkCore")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FormatFailures(result));
    }

    [Fact]
    public void Application_Assemblies_ShouldNotDependOn_Presentation()
    {
        var result = Types.InAssemblies(LoadedAssemblies.All)
            .That().ResideInNamespaceContaining(".Application")
            .And().DoNotResideInNamespaceContaining(".Infrastructure") // Infrastructure legitimately depends on Application
            .Should().NotHaveDependencyOnAny(".Presentation", "Microsoft.AspNetCore.Http", "Microsoft.AspNetCore.SignalR")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FormatFailures(result));
    }

    [Fact]
    public void SharedKernel_ShouldNotDependOn_AnyBusinessModule()
    {
        var result = Types.InAssembly(typeof(ZWS.BuildingBlocks.SharedKernel.Entity<>).Assembly)
            .Should().NotHaveDependencyOnAny("ZWS.Modules")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FormatFailures(result));
    }

    [Fact]
    public void PayconModule_ShouldNotDependOn_OtherModulesInfrastructure()
    {
        // The DbContext-per-module rule (section 4/43): Paycon's own layers must never
        // reference ApplicationHub/Compliance/TradeInsights/PartnerHub's Infrastructure
        // (i.e. never resolve another module's DbContext).
        var result = Types.InAssemblies(new[]
            {
                typeof(ZWS.Modules.Paycon.Domain.Entities.PayconUser).Assembly,
                typeof(ZWS.Modules.Paycon.Application.Abstractions.IUserRepository).Assembly,
                typeof(ZWS.Modules.Paycon.Infrastructure.Persistence.PayconDbContext).Assembly,
                typeof(ZWS.Modules.Paycon.Presentation.PayconModule).Assembly,
            })
            .Should().NotHaveDependencyOnAny(
                "ZWS.Modules.ApplicationHub.Infrastructure",
                "ZWS.Modules.Compliance.Infrastructure",
                "ZWS.Modules.TradeInsights.Infrastructure",
                "ZWS.Modules.PartnerHub.Infrastructure")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FormatFailures(result));
    }

    private static string FormatFailures(TestResult result) =>
        result.FailingTypes is null ? "" : string.Join(", ", result.FailingTypes.Select(t => t.FullName));
}

/// <summary>Explicit list of one representative type per referenced assembly, so every
/// module/layer is guaranteed to be loaded before reflection runs - relying on
/// AppDomain.CurrentDomain.GetAssemblies() alone is unreliable here, since a project
/// reference doesn't force a CLR assembly load until something actually touches a type
/// from it, and xUnit test execution order isn't guaranteed.</summary>
internal static class LoadedAssemblies
{
    public static System.Reflection.Assembly[] All { get; } = new[]
    {
        typeof(ZWS.BuildingBlocks.SharedKernel.Entity<>).Assembly,
        typeof(ZWS.BuildingBlocks.EventBus.IEventBus).Assembly,
        typeof(ZWS.BuildingBlocks.Caching.ICacheService).Assembly,
        typeof(ZWS.BuildingBlocks.Behaviors.LoggingBehavior<,>).Assembly,
        typeof(ZWS.BuildingBlocks.Persistence.IModuleDbInitializer).Assembly,

        typeof(ZWS.Modules.ApplicationHub.Domain.Entities.Application).Assembly,
        typeof(ZWS.Modules.ApplicationHub.Application.Abstractions.IApplicationRepository).Assembly,
        typeof(ZWS.Modules.ApplicationHub.Infrastructure.Persistence.ApplicationHubDbContext).Assembly,
        typeof(ZWS.Modules.ApplicationHub.Presentation.ApplicationHubModule).Assembly,

        typeof(ZWS.Modules.Paycon.Domain.Entities.PayconUser).Assembly,
        typeof(ZWS.Modules.Paycon.Application.Abstractions.IUserRepository).Assembly,
        typeof(ZWS.Modules.Paycon.Infrastructure.Persistence.PayconDbContext).Assembly,
        typeof(ZWS.Modules.Paycon.Presentation.PayconModule).Assembly,

        typeof(ZWS.Modules.Compliance.Domain.Entities.ComplianceCase).Assembly,
        typeof(ZWS.Modules.Compliance.Infrastructure.Persistence.ComplianceDbContext).Assembly,

        typeof(ZWS.Modules.TradeInsights.Domain.Entities.TradeInsightRecord).Assembly,
        typeof(ZWS.Modules.TradeInsights.Infrastructure.Persistence.TradeInsightsDbContext).Assembly,

        typeof(ZWS.Modules.PartnerHub.Domain.Entities.Partner).Assembly,
        typeof(ZWS.Modules.PartnerHub.Infrastructure.Persistence.PartnerHubDbContext).Assembly,
    }.Distinct().ToArray();
}
