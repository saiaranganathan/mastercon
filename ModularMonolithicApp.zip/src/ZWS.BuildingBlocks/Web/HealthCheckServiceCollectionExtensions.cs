using HealthChecks.Rabbitmq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ZWS.BuildingBlocks.Web;

public static class HealthCheckServiceCollectionExtensions
{
    /// <summary>Requirement 33: /health and /health/ready, checking SQL, Redis, RabbitMQ and app availability.</summary>
    public static IServiceCollection AddZwsHealthChecks(this IServiceCollection services, IConfiguration configuration, string primaryConnectionStringName)
    {
        var builder = services.AddHealthChecks()
            .AddCheck("self", () => Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy(), tags: ["ready"]);

        var sqlConnectionString = configuration.GetConnectionString(primaryConnectionStringName);
        if (!string.IsNullOrWhiteSpace(sqlConnectionString))
        {
            builder.AddSqlServer(sqlConnectionString, name: "sql-server", tags: ["ready"]);
        }

        var redisConnectionString = configuration["Redis:ConnectionString"];
        if (!string.IsNullOrWhiteSpace(redisConnectionString))
        {
            builder.AddRedis(redisConnectionString, name: "redis", tags: ["ready"]);
        }

        var rabbitHost = configuration["RabbitMQ:Host"];
        if (!string.IsNullOrWhiteSpace(rabbitHost))
        {
            var user = configuration["RabbitMQ:Username"] ?? "guest";
            var pass = configuration["RabbitMQ:Password"] ?? "guest";
            var vhost = configuration["RabbitMQ:VirtualHost"] ?? "/";
            var port = configuration["RabbitMQ:Port"] ?? "5672";
            var uri = $"amqp://{user}:{pass}@{rabbitHost}:{port}{vhost}";
            builder.AddRabbitMQ(rabbitConnectionString: uri, name: "rabbitmq", tags: ["ready"]);
        }

        return services;
    }
}
