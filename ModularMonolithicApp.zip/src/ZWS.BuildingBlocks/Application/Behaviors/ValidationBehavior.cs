using FluentValidation;
using MediatR;
using ZWS.BuildingBlocks.Application.Common;

namespace ZWS.BuildingBlocks.Application.Behaviors;

/// <summary>
/// Runs every registered FluentValidation validator for the incoming request
/// before the handler executes. Failures are translated into a failed Result
/// rather than an exception, so commands/queries fail predictably.
/// </summary>
public sealed class ValidationBehavior<TRequest, TResponse>(IEnumerable<IValidator<TRequest>> validators)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        if (!validators.Any())
            return await next(cancellationToken);

        var context = new ValidationContext<TRequest>(request);

        var failures = (await Task.WhenAll(validators.Select(v => v.ValidateAsync(context, cancellationToken))))
            .SelectMany(result => result.Errors)
            .Where(failure => failure is not null)
            .ToList();

        if (failures.Count == 0)
            return await next(cancellationToken);

        var message = string.Join(" | ", failures.Select(f => f.ErrorMessage));
        var error = Error.Validation("Validation.Failed", message);

        // TResponse is always Result or Result<T> for commands/queries in this codebase.
        var resultType = typeof(TResponse);
        if (resultType == typeof(Result))
            return (TResponse)(object)Result.Failure(error);

        if (resultType.IsGenericType && resultType.GetGenericTypeDefinition() == typeof(Result<>))
        {
            var failureMethod = typeof(Result)
                .GetMethod(nameof(Result.Failure), 1, [typeof(Error)])!
                .MakeGenericMethod(resultType.GetGenericArguments());
            return (TResponse)failureMethod.Invoke(null, [error])!;
        }

        throw new ValidationException(failures);
    }
}
