using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Paycon.SharedKernel;

/// <summary>
/// Every module (Identity, Reconciliation, Insights, SchemeManagement, Statements,
/// Notifications, ...) exposes exactly one of these from its .Api project. The Host
/// discovers and wires every module through this single seam - the Host never
/// references a module's Domain/Application/Infrastructure projects directly, and
/// modules never reference each other's Infrastructure (per-module DbContext) project.
/// </summary>
public interface IModule
{
    string Name { get; }

    /// <summary>Registers the module's DbContext (own schema + connection string),
    /// MediatR handlers, repositories, validators, etc. Called once at Host startup.</summary>
    IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration);

    /// <summary>Maps the module's minimal-API endpoints under its own route group.</summary>
    IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints);
}
