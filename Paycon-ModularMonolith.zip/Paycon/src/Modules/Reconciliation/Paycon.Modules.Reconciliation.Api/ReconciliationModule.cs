using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Infrastructure.Persistence;
using Paycon.Modules.Reconciliation.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Api;

public class ReconciliationModule : IModule
{
    public string Name => "Reconciliation";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("ReconciliationDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the Reconciliation module (ConnectionStrings:ReconciliationDb).");

        services.AddDbContext<ReconciliationDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", ReconciliationDbContext.Schema)));

        services.AddScoped<IReconciliationRepository, ReconciliationRepository>();

        // IReconciliationNotifier is implemented in the Host (it owns the SignalR hub) and
        // registered there; this module only depends on the abstraction.

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(
            typeof(Application.Batches.Commands.RunReconciliation.RunReconciliationCommand).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        Endpoints.ReconciliationEndpoints.Map(endpoints);
        return endpoints;
    }
}
