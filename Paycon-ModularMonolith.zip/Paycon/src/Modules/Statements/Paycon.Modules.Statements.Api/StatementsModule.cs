using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Statements.Application.Abstractions;
using Paycon.Modules.Statements.Application.Statements.Queries.GetStatementsForMember;
using Paycon.Modules.Statements.Infrastructure.Persistence;
using Paycon.Modules.Statements.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.Statements.Api;

public class StatementsModule : IModule
{
    public string Name => "Statements";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("StatementsDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the Statements module.");

        services.AddDbContext<StatementsDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", StatementsDbContext.Schema)));

        services.AddScoped<IStatementRepository, StatementRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetStatementsForMemberQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/statements/members/{memberId:guid}", async (Guid memberId, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetStatementsForMemberQuery(memberId), ct)))
            .WithTags("Statements");

        return endpoints;
    }
}
