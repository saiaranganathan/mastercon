using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Insights.Application.Abstractions;
using Paycon.Modules.Insights.Application.Payouts.Commands.ApprovePayout;
using Paycon.Modules.Insights.Application.Payouts.Queries.GetApprovalQueue;
using Paycon.Modules.Insights.Infrastructure.Persistence;
using Paycon.Modules.Insights.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.Insights.Api;

public class InsightsModule : IModule
{
    public string Name => "Insights";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("InsightsDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the Insights module.");

        services.AddDbContext<InsightsDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", InsightsDbContext.Schema)));

        services.AddScoped<IFundProviderPayoutRepository, FundProviderPayoutRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetApprovalQueueQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/insights").WithTags("Insights");

        group.MapGet("/approval-queue", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetApprovalQueueQuery(), ct)));

        group.MapPost("/payouts/{id:guid}/approve", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new ApprovePayoutCommand(id), ct);
            return Results.NoContent();
        });

        return endpoints;
    }
}
