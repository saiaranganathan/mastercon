using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Infrastructure.Persistence;
using Paycon.Modules.Identity.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Api;

/// <summary>
/// The ONE public seam of the Identity module. The Host discovers this class via
/// reflection/assembly scanning and calls RegisterModule + MapEndpoints - it never
/// touches IdentityDbContext, repositories or handlers directly.
/// </summary>
public class IdentityModule : IModule
{
    public string Name => "Identity";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        // DbContext-per-module: its own connection string key and its own schema.
        // Same Azure SQL Server/database is fine; the schema keeps tables isolated,
        // and nothing outside this module ever resolves IdentityDbContext from DI.
        var connectionString = configuration.GetConnectionString("IdentityDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the Identity module (ConnectionStrings:IdentityDb).");

        services.AddDbContext<IdentityDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", IdentityDbContext.Schema)));

        services.AddScoped<IUserRepository, UserRepository>();

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(
            typeof(Application.Users.Commands.CreateUser.CreateUserCommand).Assembly));

        services.AddValidatorsFromModule();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        Endpoints.UserEndpoints.Map(endpoints);
        return endpoints;
    }
}

file static class ServiceCollectionExtensions
{
    public static IServiceCollection AddValidatorsFromModule(this IServiceCollection services)
    {
        FluentValidation.AssemblyScanner
            .FindValidatorsInAssembly(typeof(Application.Users.Commands.CreateUser.CreateUserCommand).Assembly)
            .ForEach(result => services.AddScoped(result.InterfaceType, result.ValidatorType));
        return services;
    }
}
