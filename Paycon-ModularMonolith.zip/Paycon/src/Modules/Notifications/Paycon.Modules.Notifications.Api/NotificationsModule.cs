using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.EventBus;
using Paycon.Modules.Notifications.Application.Abstractions;
using Paycon.Modules.Notifications.Application.EventHandlers;
using Paycon.Modules.Notifications.Application.Notifications.Queries.GetRecentNotifications;
using Paycon.Modules.Notifications.Infrastructure.Persistence;
using Paycon.Modules.Notifications.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.Notifications.Api;

public class NotificationsModule : IModule
{
    public string Name => "Notifications";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("NotificationsDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the Notifications module.");

        services.AddDbContext<NotificationsDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", NotificationsDbContext.Schema)));

        services.AddScoped<INotificationLogRepository, NotificationLogRepository>();
        services.AddScoped<ReconciliationCompletedIntegrationEventHandler>();
        services.AddScoped<UserProvisionedIntegrationEventHandler>();

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetRecentNotificationsQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/notifications/recent", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetRecentNotificationsQuery(), ct)))
            .WithTags("Notifications");

        return endpoints;
    }

    /// <summary>Called once by the Host after the RabbitMQ IEventBus is registered, to bind
    /// this module's queue to the routing keys it cares about.</summary>
    public static void SubscribeToIntegrationEvents(IEventBus eventBus)
    {
        eventBus.Subscribe<ReconciliationCompletedIntegrationEvent, ReconciliationCompletedIntegrationEventHandler>();
        eventBus.Subscribe<UserProvisionedIntegrationEvent, UserProvisionedIntegrationEventHandler>();
    }
}
