using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.SchemeManagement.Application.Abstractions;
using Paycon.Modules.SchemeManagement.Application.Schemes.Commands.CreateScheme;
using Paycon.Modules.SchemeManagement.Application.Schemes.Queries.GetSchemes;
using Paycon.Modules.SchemeManagement.Infrastructure.Persistence;
using Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Repositories;
using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Api;

public class SchemeManagementModule : IModule
{
    public string Name => "SchemeManagement";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("SchemeManagementDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("No connection string configured for the SchemeManagement module.");

        services.AddDbContext<SchemeManagementDbContext>(options =>
            options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", SchemeManagementDbContext.Schema)));

        services.AddScoped<ISchemeRepository, SchemeRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetSchemesQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/scheme-management").WithTags("Scheme Management");

        group.MapGet("/schemes", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetSchemesQuery(), ct)));

        group.MapPost("/schemes", async (CreateSchemeCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/scheme-management/schemes/{id}", new { id });
        });

        return endpoints;
    }
}
