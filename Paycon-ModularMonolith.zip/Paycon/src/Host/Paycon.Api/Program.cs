using MediatR;
using Microsoft.OpenApi.Models;
using Paycon.Api;
using Paycon.Api.Hubs;
using Paycon.Behaviors;
using Paycon.Caching;
using Paycon.EventBus;
using Paycon.Modules.Notifications.Api;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Notifications.Application.Abstractions;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ---------- Logging ----------
builder.Host.UseSerilog((context, configuration) => configuration
    .ReadFrom.Configuration(context.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console());

// ---------- CORS for the Blazor WebAssembly client ----------
const string BlazorClientCors = "BlazorClient";
builder.Services.AddCors(options =>
{
    options.AddPolicy(BlazorClientCors, policy => policy
        .WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? new[] { "https://localhost:5031" })
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowCredentials()); // required for SignalR
});

// ---------- Azure Redis Cache (shared distributed cache, module-prefixed keys) ----------
builder.Services.Configure<RedisOptions>(builder.Configuration.GetSection(RedisOptions.SectionName));
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetSection(RedisOptions.SectionName)["ConnectionString"];
    options.InstanceName = "paycon:";
});
builder.Services.AddSingleton<ICacheService, RedisCacheService>();

// ---------- RabbitMQ event bus (one shared exchange, one queue per module at runtime) ----------
builder.Services.Configure<RabbitMqOptions>(builder.Configuration.GetSection(RabbitMqOptions.SectionName));
builder.Services.AddSingleton<IEventBus, RabbitMqEventBus>();

// ---------- SignalR (real-time push consumed by the Blazor WASM client) ----------
builder.Services.AddSignalR();

// ---------- MediatR pipeline behaviors, shared by every module's registered handlers ----------
builder.Services.AddMediatR(cfg =>
{
    // Behaviors are global; each module separately registers its own handler assembly
    // inside its RegisterModule() call below.
    cfg.AddOpenBehavior(typeof(LoggingBehavior<,>));
    cfg.AddOpenBehavior(typeof(ValidationBehavior<,>));
    cfg.AddOpenBehavior(typeof(CachingBehavior<,>));
});

// ---------- Host-side adapters that satisfy module-owned notifier abstractions ----------
builder.Services.AddScoped<IReconciliationNotifier, ReconciliationNotifierAdapter>();
builder.Services.AddScoped<INotificationPusher, NotificationPusherAdapter>();

// ---------- Register every module: its own DbContext (own schema/connection), its own
// MediatR handlers, its own repositories/validators. See ModuleRegistry.cs. ----------
foreach (var module in ModuleRegistry.AllModules)
{
    module.RegisterModule(builder.Services, builder.Configuration);
}

// ---------- OpenAPI / Swagger ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "PayCon API", Version = "v1", Description = "Modular monolith - Zurich Workplace Savings" });
});

var app = builder.Build();

// ---------- Bind each module's queue to the integration events it subscribes to,
// now that the RabbitMQ IEventBus singleton exists. ----------
var eventBus = app.Services.GetRequiredService<IEventBus>();
NotificationsModule.SubscribeToIntegrationEvents(eventBus);

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors(BlazorClientCors);
app.UseAuthentication();
app.UseAuthorization();

// ---------- Map every module's minimal-API endpoints under its own route group. ----------
foreach (var module in ModuleRegistry.AllModules)
{
    module.MapEndpoints(app);
}

app.MapHub<NotificationsHub>("/hubs/notifications");
app.MapGet("/health", () => Results.Ok(new { status = "healthy", timestampUtc = DateTime.UtcNow }));

app.Run();
