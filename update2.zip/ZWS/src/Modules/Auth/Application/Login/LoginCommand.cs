using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Auth.Application.Login;

/// <summary>
/// Master-only, dev-mode login: no password (there is no credential store yet - see the
/// TODO(auth) history in ICurrentUserService). Picking/entering a seeded user's email issues a
/// real signed JWT carrying that user's groups/roles/page-permissions - a placeholder for real
/// OKTA/SSO later, but every downstream app validates a genuine token either way.
/// </summary>
public sealed record LoginCommand(string Email) : ICommand<LoginResultDto>;

public sealed record LoginResultDto(string Token, Guid UserId, string FullName, string Email);
