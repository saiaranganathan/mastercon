using MediatR;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Auth;
using ZWS.Modules.UserManagement.Application.Auth;

namespace ZWS.Modules.Auth.Application.Login;

/// <summary>
/// Sends UserManagement's own public query in-process (both modules live in Master - the
/// sanctioned same-process cross-module pattern this codebase already uses elsewhere), then
/// mints the JWT from the result. Edit is expanded to both "{page}:View" and "{page}:Edit" perm
/// claims here at mint time, so every downstream ICurrentUserService.HasPermission check stays
/// a plain string match with no page-catalog knowledge required (see JwtUserClaims).
/// </summary>
public sealed class LoginCommandHandler(ISender sender, IJwtTokenIssuer tokenIssuer) : ICommandHandler<LoginCommand, LoginResultDto>
{
    public async Task<Result<LoginResultDto>> Handle(LoginCommand request, CancellationToken cancellationToken)
    {
        var profileResult = await sender.Send(new GetUserAuthProfileByEmailQuery(request.Email), cancellationToken);
        if (profileResult.IsFailure) return Result.Failure<LoginResultDto>(profileResult.Error);

        var profile = profileResult.Value;
        var permissionClaims = profile.Permissions
            .SelectMany(p => p.Access == "Edit" ? new[] { $"{p.PageKey}:View", $"{p.PageKey}:Edit" } : [$"{p.PageKey}:{p.Access}"])
            .Distinct()
            .ToList();

        var token = tokenIssuer.IssueToken(new JwtUserClaims(
            profile.Id.ToString(), profile.FullName, profile.Email,
            profile.GroupNames, profile.RoleNames, permissionClaims));

        return Result.Success(new LoginResultDto(token, profile.Id, profile.FullName, profile.Email));
    }
}
