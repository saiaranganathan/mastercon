using Microsoft.Extensions.DependencyInjection;

namespace ZWS.Modules.Auth;

/// <summary>
/// Master-only module. No DbContext of its own - Auth is stateless, orchestrating
/// UserManagement's queries (in-process, both live in Master) and IJwtTokenIssuer
/// (registered separately by AddZwsJwtIssuer in Master.Host's Program.cs). This registration
/// method is deliberately near-empty: it exists so Master.Host's module wiring reads the same
/// `AddXModule(...)` shape as every other module, and as the one obvious place to add
/// Auth-specific services if this module ever needs its own state.
/// </summary>
public static class AuthModule
{
    public static IServiceCollection AddAuthModule(this IServiceCollection services) => services;
}
