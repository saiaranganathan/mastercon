using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Dashboard.Domain;

/// <summary>PayconDashboardMetric - one KPI card ("Today's Contributions", "Mismatches", "Trades" in the Figma design).</summary>
public sealed class DashboardMetric : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public string PeriodLabel { get; private set; } = default!;
    public string FromValueDisplay { get; private set; } = default!;
    public string ToValueDisplay { get; private set; } = default!;
    public int DisplayOrder { get; private set; }

    private DashboardMetric() { }

    public static DashboardMetric Create(string title, string periodLabel, string fromValue, string toValue, int displayOrder) => new()
    {
        Title = title, PeriodLabel = periodLabel, FromValueDisplay = fromValue, ToValueDisplay = toValue, DisplayOrder = displayOrder
    };
}

public sealed class DashboardQuickAction : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public string Icon { get; private set; } = default!;
    public string Route { get; private set; } = default!;
    public int DisplayOrder { get; private set; }

    private DashboardQuickAction() { }

    public static DashboardQuickAction Create(string title, string icon, string route, int displayOrder) => new()
    {
        Title = title, Icon = icon, Route = route, DisplayOrder = displayOrder
    };
}

public sealed class DashboardRecentActivity : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public DateTime OccurredAt { get; private set; }
    public string Icon { get; private set; } = default!;

    private DashboardRecentActivity() { }

    public static DashboardRecentActivity Create(string title, DateTime occurredAt, string icon) => new()
    {
        Title = title, OccurredAt = occurredAt, Icon = icon
    };
}

public sealed class DashboardProgressSegment : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public decimal Percentage { get; private set; }
    public string ColorHex { get; private set; } = "#1B2A63";
    public int DisplayOrder { get; private set; }

    private DashboardProgressSegment() { }

    public static DashboardProgressSegment Create(string title, decimal percentage, string colorHex, int displayOrder) => new()
    {
        Title = title, Percentage = percentage, ColorHex = colorHex, DisplayOrder = displayOrder
    };
}
