namespace ZWS.Modules.Paycon.Dashboard.Application.Dtos;

public sealed record DashboardMetricDto(string Title, string PeriodLabel, string FromValueDisplay, string ToValueDisplay);
public sealed record DashboardQuickActionDto(string Title, string Icon, string Route);
public sealed record DashboardRecentActivityDto(string Title, DateTime OccurredAt, string Icon);
public sealed record DashboardProgressSegmentDto(string Title, decimal Percentage, string ColorHex);
public sealed record DashboardNotificationDto(string Title, string Description, string Severity, DateTime OccurredAt, bool IsRead);

public sealed record DashboardSnapshotDto(
    IReadOnlyCollection<DashboardMetricDto> Metrics,
    IReadOnlyCollection<DashboardQuickActionDto> QuickActions,
    IReadOnlyCollection<DashboardRecentActivityDto> RecentActivities,
    IReadOnlyCollection<DashboardProgressSegmentDto> ProgressBreakdown,
    IReadOnlyCollection<DashboardNotificationDto> Notifications,
    DateTime LastUpdatedAt);
