using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Navigation.Application.Dtos;
using ZWS.Modules.Paycon.Navigation.Application.Repositories;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Application.Queries;

public sealed class GetPayconNavigationQueryHandler(INavigationItemRepository repository, ICurrentUserService currentUser)
    : IQueryHandler<GetPayconNavigationQuery, IReadOnlyCollection<NavigationItemDto>>
{
    public async Task<Result<IReadOnlyCollection<NavigationItemDto>>> Handle(GetPayconNavigationQuery request, CancellationToken cancellationToken)
    {
        var flat = await repository.GetTreeAsync("PAYCON", cancellationToken);
        var tree = BuildTree(flat, null);
        return Result.Success<IReadOnlyCollection<NavigationItemDto>>(tree);
    }

    /// <summary>
    /// Builds the tree, then drops any item whose RequiredPermission isn't granted ("{key}:View"
    /// - Edit always implies View, see LoginCommandHandler) and any pure group header
    /// (RequiredPermission null, Route null - e.g. Reconciliation, Statements, Settings) left
    /// with zero visible children. A leaf item with no RequiredPermission is always visible.
    /// </summary>
    private List<NavigationItemDto> BuildTree(IReadOnlyCollection<NavigationItem> all, Guid? parentId) =>
        all.Where(i => i.ParentId == parentId)
           .OrderBy(i => i.DisplayOrder)
           .Select(i => (Item: i, Children: BuildTree(all, i.Id)))
           .Where(x => IsVisible(x.Item, x.Children))
           .Select(x => new NavigationItemDto(x.Item.Id, x.Item.Name, x.Item.Route, x.Item.Icon, x.Item.DisplayOrder, x.Children))
           .ToList();

    private bool IsVisible(NavigationItem item, IReadOnlyCollection<NavigationItemDto> children)
    {
        if (item.RequiredPermission is { } key) return currentUser.HasPermission($"{key}:View");

        // A pure group header (no permission key of its own) is only worth showing if at least
        // one child survived filtering - an empty "Settings" flyout with nothing inside it isn't
        // useful to anyone.
        return children.Count > 0 || item.Route is not null;
    }
}
