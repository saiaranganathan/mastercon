using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Navigation.Application.Dtos;

namespace ZWS.Modules.Paycon.Navigation.Application.Queries;

/// <summary>
/// GET /api/paycon/navigation - builds the sidebar tree straight from the database (requirement
/// 7), pruned to what the caller's JWT permissions actually grant (see
/// GetPayconNavigationQueryHandler). PermissionsHash - a stable digest of the caller's sorted
/// permission set, computed by the controller - keeps the cache correct per distinct
/// permission set instead of leaking one user's filtered menu to everyone else; two users with
/// identical permissions share a cache entry, which is the point of passing a hash rather than
/// just the raw user id.
/// </summary>
public sealed record GetPayconNavigationQuery(string PermissionsHash) : IQuery<IReadOnlyCollection<NavigationItemDto>>, ICacheableQuery
{
    public string CacheKey => CacheKeys.PayconNavigation(PermissionsHash);
    public TimeSpan? Expiration => TimeSpan.FromMinutes(30);
}
