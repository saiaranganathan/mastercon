using System.Security.Cryptography;
using System.Text;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Navigation.Application.Queries;

namespace ZWS.Modules.Paycon.Navigation.Presentation.Controllers;

[ApiController]
[Route("api/paycon/navigation")]
public sealed class PayconNavigationController(ISender sender, ICurrentUserService currentUser) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetNavigation(CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetPayconNavigationQuery(PermissionsHash(currentUser)), cancellationToken);
        return result.ToActionResult();
    }

    /// <summary>A short, stable digest of the caller's sorted permission set - see
    /// GetPayconNavigationQuery for why this (not the raw user id) is the right cache key.</summary>
    private static string PermissionsHash(ICurrentUserService user)
    {
        if (!user.IsAuthenticated) return "anonymous";

        var joined = string.Join('|', user.Permissions.OrderBy(p => p, StringComparer.Ordinal));
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(joined));
        return Convert.ToHexString(hash)[..16];
    }
}
