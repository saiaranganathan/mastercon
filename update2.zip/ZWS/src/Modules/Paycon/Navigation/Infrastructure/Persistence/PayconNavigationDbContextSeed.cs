using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence;

/// <summary>Seeds the exact navigation tree specified in section 8 of the requirements.</summary>
public static class PayconNavigationDbContextSeed
{
    public static async Task SeedAsync(PayconNavigationDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);

        if (await context.NavigationItems.AnyAsync(cancellationToken)) return;

        // RequiredPermission holds a bare PermissionPageCatalog key (e.g. "dashboard",
        // "settings.scheme-management") - GetPayconNavigationQueryHandler checks
        // "{key}:View" against the caller's JWT perm claims, so these must match that catalog
        // exactly (see ZWS.Modules.UserManagement.Domain.PermissionPageCatalog). A null
        // RequiredPermission means "always visible" - used only for pure group headers
        // (Reconciliation/Statements/Settings) whose own visibility instead follows from
        // whether any child survives filtering.
        var dashboard = NavigationItem.Create("Dashboard", "/paycon/dashboard", "tabler-icon-smart-home", null, 1, requiredPermission: "dashboard");
        var reconciliation = NavigationItem.Create("Reconciliation", null, "tabler-icon-refresh", null, 2);
        var insights = NavigationItem.Create("Insights", "/paycon/insights", "tabler-icon-chart-bar", null, 3, requiredPermission: "insights");
        var statements = NavigationItem.Create("Statements", null, "tabler-icon-file-text", null, 4);
        var settings = NavigationItem.Create("Settings", null, "tabler-icon-settings", null, 5);

        context.NavigationItems.AddRange(dashboard, reconciliation, insights, statements, settings);
        await context.SaveChangesAsync(cancellationToken);

        var paymentsIn = NavigationItem.Create("Payments In", "/paycon/reconciliation/payments-in", "tabler-icon-arrow-down-circle", reconciliation.Id, 1, requiredPermission: "reconciliation.payments-in");
        var paymentsOut = NavigationItem.Create("Payments Out", "/paycon/reconciliation/payments-out", "tabler-icon-arrow-up-circle", reconciliation.Id, 2, requiredPermission: "reconciliation.payments-out");
        var exitStatements = NavigationItem.Create("Exit Statements", "/paycon/statements/exit-statements", "tabler-icon-file-minus", statements.Id, 1, requiredPermission: "statements.exit-statements");
        var annualStatements = NavigationItem.Create("Annual Statements", "/paycon/statements/annual-statements", "tabler-icon-calendar-stats", statements.Id, 2, requiredPermission: "statements.annual-statements");
        // "User Management" is deliberately not seeded here any more: Users/Groups/Roles/
        // Permissions moved to the Master app's own Settings screens (UserManagement module
        // now lives under Modules/UserManagement, not Modules/Paycon/Settings). A "Manage
        // users" deep link back out to Master's Settings page belongs here once Paycon has its
        // own deployable Web app with a configured Master base URL to link to.
        var schemeManagement = NavigationItem.Create("Scheme Management", "/paycon/settings/scheme-management", "tabler-icon-building-bank", settings.Id, 1, requiredPermission: "settings.scheme-management");
        var insightManagement = NavigationItem.Create("Insight Management", "/paycon/settings/insight-management", "tabler-icon-bulb", settings.Id, 2, requiredPermission: "settings.insight-management");

        context.NavigationItems.AddRange(paymentsIn, paymentsOut, exitStatements, annualStatements, schemeManagement, insightManagement);
        await context.SaveChangesAsync(cancellationToken);
    }
}
