namespace ZWS.Modules.UserManagement.Domain;

public enum GroupState { Active, Inactive }

public enum RoleState { Active, Inactive }

public enum UserState { Active, Inactive, Terminated }

/// <summary>
/// PR_UM 2.1: the access level an admin grants a Role or User against one entry in the
/// <see cref="PermissionPageCatalog"/>. Edit implies View - there is no separate "view AND
/// edit" combination to pick. A page simply absent from a Role's/User's permission list
/// means no access at all, so there is deliberately no "None" member here.
/// </summary>
public enum AccessLevel { View, Edit }

/// <summary>
/// One row of a Role's or User's Permissions matrix: the page being granted access to,
/// and the level of that access. <see cref="PageKey"/> must match a key in
/// <see cref="PermissionPageCatalog"/>.
/// </summary>
public sealed record PagePermissionAssignment(string PageKey, AccessLevel Access);
