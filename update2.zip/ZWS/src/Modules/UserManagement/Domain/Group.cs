using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.UserManagement.Domain;

/// <summary>
/// PR_UM-1.x: a business unit (Finance, Operations, Compliance, CRM, IT, System...)
/// that plans are assigned to and users/roles belong to.
/// </summary>
public sealed class Group : AuditableEntity
{
    public string Name { get; private set; } = default!;
    public GroupState State { get; private set; } = GroupState.Active;

    /// <summary>PR_UM-1.5: whether users in this group may receive plan access beyond what the group grants.</summary>
    public bool OverridePlanPermissionAtUserLevel { get; private set; }

    private readonly List<GroupSchemeAssignment> _schemeAssignments = [];
    public IReadOnlyCollection<GroupSchemeAssignment> SchemeAssignments => _schemeAssignments.AsReadOnly();

    private Group() { } // EF Core

    public static Group Create(string name, GroupState state, bool overridePlanPermission, IEnumerable<(Guid SchemeId, string SchemeName)> schemes)
    {
        var group = new Group { Name = name, State = state, OverridePlanPermissionAtUserLevel = overridePlanPermission };
        foreach (var (schemeId, schemeName) in schemes)
            group._schemeAssignments.Add(GroupSchemeAssignment.Create(group.Id, schemeId, schemeName));
        return group;
    }

    public void UpdateDetails(string name, GroupState state, bool overridePlanPermission, IEnumerable<(Guid SchemeId, string SchemeName)> schemes)
    {
        Name = name;
        State = state;
        OverridePlanPermissionAtUserLevel = overridePlanPermission;

        _schemeAssignments.Clear();
        foreach (var (schemeId, schemeName) in schemes)
            _schemeAssignments.Add(GroupSchemeAssignment.Create(Id, schemeId, schemeName));
    }
}

/// <summary>Denormalized reference to a Scheme owned by the SchemeManagement module - never a cross-context FK.</summary>
public sealed class GroupSchemeAssignment
{
    public Guid Id { get; private set; }
    public Guid GroupId { get; private set; }
    public Guid SchemeId { get; private set; }
    public string SchemeName { get; private set; } = default!;

    private GroupSchemeAssignment() { }

    public static GroupSchemeAssignment Create(Guid groupId, Guid schemeId, string schemeName) => new()
    {
        Id = Guid.NewGuid(),
        GroupId = groupId,
        SchemeId = schemeId,
        SchemeName = schemeName
    };
}
