using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Infrastructure.ExternalServices;
using ZWS.Modules.UserManagement.Infrastructure.Persistence;
using ZWS.Modules.UserManagement.Infrastructure.Repositories;

namespace ZWS.Modules.UserManagement;

public static class UserManagementModule
{
    public static IServiceCollection AddUserManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        // Own connection string now that UserManagement is a Master module, not a Paycon one -
        // it no longer shares Paycon's "Paycon" connection string / database.
        var connectionString = configuration.GetConnectionString("UserManagement");

        services.AddDbContext<UserManagementDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=user_management.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "user_management"));
        });

        services.AddScoped<IUserManagementDbContext>(sp => sp.GetRequiredService<UserManagementDbContext>());
        services.AddScoped<IGroupRepository, GroupRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IUserRepository, UserRepository>();

        // Typed HttpClient into Paycon's own API (see SchemeReferenceService) - UserManagement
        // and SchemeManagement are two different App Services now, so this replaces what used
        // to be an in-process MediatR call. Falls back to the ambient BaseAddress (none - see
        // SchemeReferenceService's try/catch) if PayconApiBaseUrl isn't configured, e.g. in tests.
        services.AddHttpClient<ISchemeReferenceService, SchemeReferenceService>((sp, client) =>
        {
            var payconApiBaseUrl = configuration["PayconApiBaseUrl"];
            if (!string.IsNullOrWhiteSpace(payconApiBaseUrl))
                client.BaseAddress = new Uri(payconApiBaseUrl);
        });

        return services;
    }

    public static async Task SeedUserManagementModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<UserManagementDbContext>();
        await UserManagementDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
