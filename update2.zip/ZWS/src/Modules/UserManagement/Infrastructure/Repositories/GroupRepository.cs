using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using ZWS.Modules.UserManagement.Infrastructure.Persistence;

namespace ZWS.Modules.UserManagement.Infrastructure.Repositories;

public sealed class GroupRepository(UserManagementDbContext context) : IGroupRepository
{
    public async Task<(IReadOnlyCollection<Group> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.Groups.Include(g => g.SchemeAssignments).AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(g =>
                EF.Functions.Like(g.Name, $"%{term}%") ||
                EF.Functions.Like(g.CreatedBy, $"%{term}%") ||
                EF.Functions.Like(g.UpdatedBy ?? "", $"%{term}%") ||
                g.SchemeAssignments.Any(s => EF.Functions.Like(s.SchemeName, $"%{term}%")));
        }

        query = (request.SortBy?.ToLowerInvariant(), request.SortDescending) switch
        {
            ("name", false) => query.OrderBy(g => g.Name),
            ("name", true) => query.OrderByDescending(g => g.Name),
            ("createdat", true) => query.OrderByDescending(g => g.CreatedAt),
            ("createdat", false) => query.OrderBy(g => g.CreatedAt),
            _ => query.OrderBy(g => g.Name)
        };

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, totalCount);
    }

    public Task<Group?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.Groups.Include(g => g.SchemeAssignments).FirstOrDefaultAsync(g => g.Id == id, cancellationToken);

    public Task<bool> ExistsByNameAsync(string name, Guid? excludeId, CancellationToken cancellationToken) =>
        context.Groups.AnyAsync(g => g.Name == name && (excludeId == null || g.Id != excludeId), cancellationToken);

    public async Task<int> CountActiveUsersAsync(Guid groupId, CancellationToken cancellationToken) =>
        await context.UserGroupAssignments
            .Where(a => a.GroupId == groupId)
            .Join(context.Users.Where(u => u.State == UserState.Active), a => a.UserId, u => u.Id, (a, u) => u.Id)
            .CountAsync(cancellationToken);

    public void Add(Group group) => context.Groups.Add(group);
    public void Remove(Group group) => context.Groups.Remove(group);
}
