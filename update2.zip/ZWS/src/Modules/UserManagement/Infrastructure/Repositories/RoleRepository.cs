using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using ZWS.Modules.UserManagement.Infrastructure.Persistence;

namespace ZWS.Modules.UserManagement.Infrastructure.Repositories;

public sealed class RoleRepository(UserManagementDbContext context) : IRoleRepository
{
    public async Task<(IReadOnlyCollection<Role> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.Roles.Include(r => r.Permissions).AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            var groupIds = await context.Groups.Where(g => EF.Functions.Like(g.Name, $"%{term}%")).Select(g => g.Id).ToListAsync(cancellationToken);
            query = query.Where(r =>
                EF.Functions.Like(r.Name, $"%{term}%") ||
                EF.Functions.Like(r.Description ?? "", $"%{term}%") ||
                groupIds.Contains(r.GroupId));
        }

        query = (request.SortBy?.ToLowerInvariant(), request.SortDescending) switch
        {
            ("name", true) => query.OrderByDescending(r => r.Name),
            ("createdat", true) => query.OrderByDescending(r => r.CreatedAt),
            ("createdat", false) => query.OrderBy(r => r.CreatedAt),
            _ => query.OrderBy(r => r.Name)
        };

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, totalCount);
    }

    public Task<Role?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.Roles.Include(r => r.Permissions).FirstOrDefaultAsync(r => r.Id == id, cancellationToken);

    public Task<bool> ExistsByNameAsync(string groupQualifiedName, Guid? excludeId, CancellationToken cancellationToken)
    {
        var parts = groupQualifiedName.Split("::", 2);
        var groupId = Guid.Parse(parts[0]);
        var name = parts[1];
        return context.Roles.AnyAsync(r => r.GroupId == groupId && r.Name == name && (excludeId == null || r.Id != excludeId), cancellationToken);
    }

    public async Task<int> CountActiveUsersAsync(Guid roleId, CancellationToken cancellationToken) =>
        await context.UserRoleAssignments
            .Where(a => a.RoleId == roleId)
            .Join(context.Users.Where(u => u.State == UserState.Active), a => a.UserId, u => u.Id, (a, u) => u.Id)
            .CountAsync(cancellationToken);

    public void Add(Role role) => context.Roles.Add(role);
    public void Remove(Role role) => context.Roles.Remove(role);
}
