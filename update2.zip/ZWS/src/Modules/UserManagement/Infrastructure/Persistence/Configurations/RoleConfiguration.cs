using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Infrastructure.Persistence.Configurations;

public sealed class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.ToTable("Roles");
        builder.HasKey(r => r.Id);
        builder.Property(r => r.Name).HasMaxLength(150).IsRequired();
        builder.Property(r => r.Description).HasMaxLength(500);
        builder.Property(r => r.State).HasConversion<string>().HasMaxLength(20);
        builder.Property(r => r.CreatedBy).HasMaxLength(100);
        builder.Property(r => r.UpdatedBy).HasMaxLength(100);
        builder.Property(r => r.DeletedBy).HasMaxLength(100);
        builder.HasIndex(r => new { r.GroupId, r.Name }).IsUnique().HasFilter("[IsDeleted] = 0");

        builder.HasMany(r => r.Permissions).WithOne().HasForeignKey(p => p.RoleId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(Role.Permissions))!.SetPropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class RolePagePermissionConfiguration : IEntityTypeConfiguration<RolePagePermission>
{
    public void Configure(EntityTypeBuilder<RolePagePermission> builder)
    {
        builder.ToTable("RolePagePermissions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PageKey).HasMaxLength(100).IsRequired();
        builder.Property(x => x.Access).HasConversion<string>().HasMaxLength(10);
        builder.HasIndex(x => new { x.RoleId, x.PageKey }).IsUnique();
    }
}
