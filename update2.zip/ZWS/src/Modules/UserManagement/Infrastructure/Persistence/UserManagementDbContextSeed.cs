using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.SeedData;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Infrastructure.Persistence;

/// <summary>Realistic dummy data mirroring the Figma Users/Groups/Roles screens (requirement 30).</summary>
public static class UserManagementDbContextSeed
{
    private static PagePermissionAssignment Grant(string pageKey, AccessLevel access) => new(pageKey, access);

    public static async Task SeedAsync(UserManagementDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Groups.AnyAsync(cancellationToken)) return;

        (Guid Id, string Name)[] schemes =
        [
            (WellKnownSeedIds.SchemeDews, "DEWS"),
            (WellKnownSeedIds.SchemeDubaiGovernment, "Dubai Government"),
            (WellKnownSeedIds.SchemeDaman, "DAMAN"),
            (WellKnownSeedIds.SchemeDubaiGovernmentAed, "Dubai Government AED"),
            (WellKnownSeedIds.SchemeAdnoc, "ADNOC")
        ];

        var finance = Group.Create("Finance", GroupState.Active, true, [schemes[0], schemes[1], schemes[2], schemes[3]]);
        var operations = Group.Create("Operations", GroupState.Active, true, [schemes[0], schemes[1]]);
        var compliance = Group.Create("Compliance", GroupState.Active, false, [schemes[0]]);
        var crm = Group.Create("CRM", GroupState.Active, true, [schemes[1], schemes[2]]);
        var it = Group.Create("IT", GroupState.Active, false, [schemes[0], schemes[1], schemes[2], schemes[3], schemes[4]]);
        var system = Group.Create("System", GroupState.Inactive, false, [schemes[4]]);

        context.Groups.AddRange(finance, operations, compliance, crm, it, system);
        await context.SaveChangesAsync(cancellationToken);

        // PR_UM 2.1: every Role's Permissions matrix grants View/Edit against the actual
        // page/sub-page catalog (see PermissionPageCatalog) rather than a flat capability list.
        var financeRole = Role.Create("FinanceAnalyst", finance.Id, "Reconciliation and payments analyst.", RoleState.Active,
        [
            Grant("dashboard", AccessLevel.View),
            Grant("reconciliation", AccessLevel.Edit),
            Grant("reconciliation.payments-in", AccessLevel.Edit),
            Grant("reconciliation.payments-out", AccessLevel.Edit),
            Grant("statements", AccessLevel.View),
            Grant("statements.exit-statements", AccessLevel.View),
            Grant("statements.annual-statements", AccessLevel.View)
        ]);

        var opsRole = Role.Create("OperationsLead", operations.Id, "Operations team lead.", RoleState.Active,
        [
            Grant("dashboard", AccessLevel.Edit),
            Grant("reconciliation", AccessLevel.Edit),
            Grant("reconciliation.payments-in", AccessLevel.Edit),
            Grant("reconciliation.payments-out", AccessLevel.Edit),
            Grant("statements", AccessLevel.Edit),
            Grant("statements.exit-statements", AccessLevel.Edit),
            Grant("statements.annual-statements", AccessLevel.Edit),
            Grant("insights", AccessLevel.View),
            Grant("settings.user-management", AccessLevel.View),
            Grant("settings.user-management.users", AccessLevel.View)
        ]);

        var itAdminRole = Role.Create("ITAdministrator", it.Id, "Full system administration.", RoleState.Active,
            PermissionPageCatalog.Pages.Select(p => Grant(p.Key, AccessLevel.Edit)).ToList());

        var crmViewerRole = Role.Create("CRMViewer", crm.Id, "Read-only access to CRM data.", RoleState.Active,
        [
            Grant("dashboard", AccessLevel.View),
            Grant("insights", AccessLevel.View)
        ]);

        context.Roles.AddRange(financeRole, opsRole, itAdminRole, crmViewerRole);
        await context.SaveChangesAsync(cancellationToken);

        var shelby = User.Create("Shelby Goode", "userfour@zurich.com", null, null, true, UserState.Active,
            [(operations.Id, operations.Name)], [(opsRole.Id, opsRole.Name)],
            [Grant("settings.user-management.users", AccessLevel.Edit), Grant("settings.user-management.roles", AccessLevel.View)], []);
        var robert = User.Create("Robert Bacins", "userthree@zurich.com", null, null, true, UserState.Active,
            [(it.Id, it.Name)], [(itAdminRole.Id, itAdminRole.Name)],
            [Grant("settings.user-management.permissions", AccessLevel.Edit)], []);
        var john = User.Create("John Carilo", "usertwo@zurich.com", robert.Id, robert.FullName, true, UserState.Active,
            [(crm.Id, crm.Name)], [(crmViewerRole.Id, crmViewerRole.Name)],
            [Grant("dashboard", AccessLevel.View)], []);

        context.Users.AddRange(shelby, robert, john);
        await context.SaveChangesAsync(cancellationToken);

        var adriene = User.Create("Adriene Watson", "userone@zurich.com", shelby.Id, shelby.FullName, false, UserState.Active,
            [(finance.Id, finance.Name)], [(financeRole.Id, financeRole.Name)],
            [Grant("dashboard", AccessLevel.View), Grant("statements.annual-statements", AccessLevel.Edit)], [(schemes[4].Id, schemes[4].Name)]);
        var johnDeo = User.Create("John Deo", "userfive@zurich.com", shelby.Id, shelby.FullName, false, UserState.Inactive,
            [(finance.Id, finance.Name)], [(financeRole.Id, financeRole.Name)],
            [Grant("dashboard", AccessLevel.View)], []);
        var terminatedUser = User.Create("Priya Sharma", "usersix@zurich.com", robert.Id, robert.FullName, false, UserState.Terminated,
            [(compliance.Id, compliance.Name)], [(crmViewerRole.Id, crmViewerRole.Name)],
            [Grant("dashboard", AccessLevel.View)], []);

        context.Users.AddRange(adriene, johnDeo, terminatedUser);
        await context.SaveChangesAsync(cancellationToken);
    }
}
