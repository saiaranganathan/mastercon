using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Infrastructure.ExternalServices;

/// <summary>
/// UserManagement now lives in the Master app, while SchemeManagement stays in Paycon - two
/// separately deployed App Services - so the in-process MediatR call this used to be is now a
/// plain HTTP call to Paycon's own public API (GET .../scheme-management/schemes/reference,
/// the same endpoint SchemeManagementApiClient calls from the Blazor client). The HttpClient's
/// BaseAddress is set from "PayconApiBaseUrl" in AddUserManagementModule. If Paycon is
/// unreachable this degrades to an empty list, same failure shape the in-process call had when
/// SchemeManagement returned a failed Result.
/// </summary>
public sealed class SchemeReferenceService(HttpClient http, ILogger<SchemeReferenceService> logger) : ISchemeReferenceService
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<IReadOnlyCollection<SchemeRefDto>> GetActiveSchemesAsync(CancellationToken cancellationToken)
    {
        try
        {
            var schemes = await http.GetFromJsonAsync<List<PayconSchemeReferenceItem>>(
                "api/paycon/settings/scheme-management/schemes/reference", JsonOptions, cancellationToken);
            return schemes?.Select(s => new SchemeRefDto(s.Id, s.Name)).ToList() ?? [];
        }
        catch (Exception ex)
        {
            // Paycon unreachable/erroring - the "Assigned Plans" picker just shows an empty
            // list rather than failing the whole User Management screen.
            logger.LogWarning(ex, "Could not reach Paycon's scheme-management API for the active-schemes reference list.");
            return [];
        }
    }

    private sealed record PayconSchemeReferenceItem(Guid Id, string Name);
}
