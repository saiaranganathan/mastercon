namespace ZWS.Modules.UserManagement.Application.Dtos;

public sealed record UserListItemDto(
    Guid Id, string FullName, string Email, string AssignedPlans, string? SupervisorName, string State, bool IsSupervisor,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record UserDetailDto(
    Guid Id, string FullName, string Email,
    IReadOnlyCollection<SchemeRefDto> AssignedPlans,
    Guid? SupervisorId, string? SupervisorName, bool IsSupervisor, string State,
    IReadOnlyCollection<GroupRefDto> Groups,
    IReadOnlyCollection<RoleRefDto> Roles,
    IReadOnlyCollection<PagePermissionDto> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record GroupRefDto(Guid GroupId, string GroupName);
public sealed record RoleRefDto(Guid RoleId, string RoleName);
public sealed record SupervisorOptionDto(Guid Id, string FullName);
