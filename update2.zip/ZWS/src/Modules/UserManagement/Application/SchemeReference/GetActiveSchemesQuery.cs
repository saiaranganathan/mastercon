using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.SchemeReference;

/// <summary>
/// Powers the "Assigned plans" checklist on the Groups and Users forms. Backed by
/// <see cref="ZWS.Modules.UserManagement.Application.Repositories.ISchemeReferenceService"/>,
/// which since the app split calls out to Paycon's API over HTTP rather than an in-process
/// query - this query just gives the browser something in Master's own API to call, so the
/// frontend never has to reach across to Paycon directly.
/// </summary>
public sealed record GetActiveSchemesQuery : IQuery<IReadOnlyCollection<SchemeRefDto>>;
