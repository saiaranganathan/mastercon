using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.SchemeReference;

public sealed class GetActiveSchemesQueryHandler(ISchemeReferenceService schemeReferenceService)
    : IQueryHandler<GetActiveSchemesQuery, IReadOnlyCollection<SchemeRefDto>>
{
    public async Task<Result<IReadOnlyCollection<SchemeRefDto>>> Handle(GetActiveSchemesQuery request, CancellationToken cancellationToken)
    {
        var schemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        return Result.Success(schemes);
    }
}
