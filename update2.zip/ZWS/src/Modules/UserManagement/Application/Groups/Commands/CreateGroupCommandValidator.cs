using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

public sealed class CreateGroupCommandValidator : AbstractValidator<CreateGroupCommand>
{
    public CreateGroupCommandValidator(IGroupRepository groupRepository)
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Group Name is required.")
            .Length(4, 150).WithMessage("Group Name must be between 4 and 150 characters.")
            .Matches("^[A-Za-z0-9_-]+$").WithMessage("Group Name may only contain letters, numbers, underscore and hyphen.")
            .MustAsync(async (name, ct) => !await groupRepository.ExistsByNameAsync(name, null, ct))
            .WithMessage("Group Name must be unique across the system.");

        RuleFor(x => x.SchemeIds)
            .NotEmpty().WithMessage("At least one plan must be assigned to the group.");

        RuleFor(x => x.State).IsInEnum();
    }
}
