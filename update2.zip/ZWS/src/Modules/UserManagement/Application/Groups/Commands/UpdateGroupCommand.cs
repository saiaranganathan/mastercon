using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

/// <summary>PR_UM-1.3: Edit Group.</summary>
public sealed record UpdateGroupCommand(
    Guid Id,
    string Name,
    GroupState State,
    bool OverridePlanPermissionAtUserLevel,
    IReadOnlyCollection<Guid> SchemeIds) : ICommand;
