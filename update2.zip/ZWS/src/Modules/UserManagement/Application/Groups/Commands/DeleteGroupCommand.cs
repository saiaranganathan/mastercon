using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

/// <summary>PR_UM-1.4: logical delete, blocked while the group has active users.</summary>
public sealed record DeleteGroupCommand(Guid Id) : ICommand;
