using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

public sealed class UpdateGroupCommandValidator : AbstractValidator<UpdateGroupCommand>
{
    public UpdateGroupCommandValidator(IGroupRepository groupRepository)
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .Length(4, 150)
            .Matches("^[A-Za-z0-9_-]+$")
            .MustAsync(async (command, name, ct) => !await groupRepository.ExistsByNameAsync(name, command.Id, ct))
            .WithMessage("Group Name must be unique across the system.");

        RuleFor(x => x.SchemeIds).NotEmpty().WithMessage("At least one plan must be assigned to the group.");
        RuleFor(x => x.State).IsInEnum();
    }
}
