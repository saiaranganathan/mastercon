using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

public sealed class DeleteGroupCommandHandler(IGroupRepository groupRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<DeleteGroupCommand>
{
    public async Task<Result> Handle(DeleteGroupCommand request, CancellationToken cancellationToken)
    {
        var group = await groupRepository.GetByIdAsync(request.Id, cancellationToken);
        if (group is null)
            return Result.Failure(Error.NotFound("Group.NotFound", $"Group '{request.Id}' was not found."));

        var activeUsers = await groupRepository.CountActiveUsersAsync(group.Id, cancellationToken);
        if (activeUsers > 0)
            return Result.Failure(Error.Conflict("Group.HasActiveUsers", "This group cannot be deleted because there are active users assigned to it."));

        groupRepository.Remove(group); // interceptor turns this into a logical delete
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
