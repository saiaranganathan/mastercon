using MediatR;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

public sealed class CreateGroupCommandHandler(
    IGroupRepository groupRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext) : ICommandHandler<CreateGroupCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreateGroupCommand request, CancellationToken cancellationToken)
    {
        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var selectedSchemes = allSchemes
            .Where(s => request.SchemeIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        var group = Group.Create(request.Name, request.State, request.OverridePlanPermissionAtUserLevel, selectedSchemes);
        groupRepository.Add(group);
        await dbContext.SaveChangesAsync(cancellationToken);

        return Result.Success(group.Id);
    }
}
