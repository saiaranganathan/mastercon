using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

/// <summary>PR_UM-1.5: Create Group.</summary>
public sealed record CreateGroupCommand(
    string Name,
    GroupState State,
    bool OverridePlanPermissionAtUserLevel,
    IReadOnlyCollection<Guid> SchemeIds) : ICommand<Guid>;
