using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Groups.Queries;

/// <summary>PR_UM 1.6: read-only View Group modal.</summary>
public sealed record GetGroupByIdQuery(Guid Id) : IQuery<GroupDetailDto>;
