using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Users.Queries;

/// <summary>Powers the Supervisor drop-down (PR_UM 3.0/3.1) - every user tagged IsSupervisor = Yes.</summary>
public sealed record GetSupervisorCandidatesQuery : IQuery<IReadOnlyCollection<SupervisorOptionDto>>;
