using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Users.Queries;

/// <summary>PR_UM 3.0: paginated/searchable/sortable User list (search by full name, email, group, role).</summary>
public sealed record GetUsersQuery(PagedRequest Paging) : IQuery<PagedResult<UserListItemDto>>;
