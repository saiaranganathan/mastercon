using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class DeleteUserCommandHandler(IUserRepository userRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<DeleteUserCommand>
{
    public async Task<Result> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByIdAsync(request.Id, cancellationToken);
        if (user is null)
            return Result.Failure(Error.NotFound("User.NotFound", $"User '{request.Id}' was not found."));

        if (user.State == UserState.Active)
            return Result.Failure(Error.Conflict("User.ActiveUserCannotBeDeleted", "Active user cannot be deleted."));

        userRepository.Remove(user);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
