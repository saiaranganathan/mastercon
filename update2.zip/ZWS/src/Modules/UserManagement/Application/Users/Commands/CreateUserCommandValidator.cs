using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
{
    public CreateUserCommandValidator(IUserRepository userRepository)
    {
        RuleFor(x => x.FullName)
            .NotEmpty().WithMessage("Full Name is required.")
            .Length(3, 150).WithMessage("Full Name must be between 3 and 150 characters.")
            .Matches(@"^[A-Za-z' ]+$").WithMessage("Full Name may only contain letters, spaces and an apostrophe (e.g. D'souza).");

        RuleFor(x => x.Email)
            .NotEmpty().EmailAddress()
            .MustAsync(async (email, ct) => !await userRepository.ExistsByEmailAsync(email, null, ct))
            .WithMessage("A user with this email address already exists.");

        RuleFor(x => x.GroupIds).NotEmpty().WithMessage("At least one Group must be selected.");
        RuleFor(x => x.RoleIds).NotEmpty().WithMessage("At least one Role must be selected.");
        RuleFor(x => x.Permissions).NotEmpty().WithMessage("At least one page permission must be selected.");
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
        RuleFor(x => x.State).IsInEnum();
    }
}
