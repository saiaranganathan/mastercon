using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

/// <summary>PR_UM 3.2: Edit User. Full Name and Email are non-editable, per the BRD.</summary>
public sealed record UpdateUserCommand(
    Guid Id,
    Guid? SupervisorId,
    bool IsSupervisor,
    UserState State,
    IReadOnlyCollection<Guid> GroupIds,
    IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions,
    IReadOnlyCollection<Guid> SchemeOverrideIds) : ICommand;
