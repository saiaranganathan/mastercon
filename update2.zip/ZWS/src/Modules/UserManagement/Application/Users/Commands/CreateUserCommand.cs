using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

/// <summary>PR_UM3.1: Create User.</summary>
public sealed record CreateUserCommand(
    string FullName,
    string Email,
    Guid? SupervisorId,
    bool IsSupervisor,
    UserState State,
    IReadOnlyCollection<Guid> GroupIds,
    IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions,
    IReadOnlyCollection<Guid> SchemeOverrideIds) : ICommand<Guid>;
