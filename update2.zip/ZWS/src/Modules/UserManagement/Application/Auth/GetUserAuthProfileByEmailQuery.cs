using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.UserManagement.Application.Auth;

/// <summary>Public query the Master Auth module sends in-process at login to build the JWT's
/// claim set - see AuthController.Login / LoginCommandHandler.</summary>
public sealed record GetUserAuthProfileByEmailQuery(string Email) : IQuery<UserAuthProfileDto>;
