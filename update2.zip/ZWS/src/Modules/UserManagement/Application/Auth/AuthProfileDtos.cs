using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Auth;

/// <summary>One row for the Master Auth module's dev-mode login picker.</summary>
public sealed record LoginCandidateDto(Guid Id, string FullName, string Email);

/// <summary>
/// Everything the Auth module needs to mint a JWT for a user - deliberately not UserDetailDto:
/// no AssignedPlans/audit fields, just identity + the group/role/permission claims that end up
/// in the token. See Modules/Auth's LoginCommandHandler.
/// </summary>
public sealed record UserAuthProfileDto(
    Guid Id,
    string FullName,
    string Email,
    IReadOnlyCollection<string> GroupNames,
    IReadOnlyCollection<string> RoleNames,
    IReadOnlyCollection<PagePermissionDto> Permissions);
