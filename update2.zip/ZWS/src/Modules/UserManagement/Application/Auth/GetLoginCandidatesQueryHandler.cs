using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Auth;

public sealed class GetLoginCandidatesQueryHandler(IUserRepository userRepository)
    : IQueryHandler<GetLoginCandidatesQuery, IReadOnlyCollection<LoginCandidateDto>>
{
    public async Task<Result<IReadOnlyCollection<LoginCandidateDto>>> Handle(GetLoginCandidatesQuery request, CancellationToken cancellationToken)
    {
        var users = await userRepository.GetActiveForLoginAsync(cancellationToken);
        IReadOnlyCollection<LoginCandidateDto> dtos = users.Select(u => new LoginCandidateDto(u.Id, u.FullName, u.Email)).ToList();
        return Result.Success(dtos);
    }
}
