using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Auth;

public sealed class GetUserAuthProfileByEmailQueryHandler(IUserRepository userRepository, IRoleRepository roleRepository)
    : IQueryHandler<GetUserAuthProfileByEmailQuery, UserAuthProfileDto>
{
    public async Task<Result<UserAuthProfileDto>> Handle(GetUserAuthProfileByEmailQuery request, CancellationToken cancellationToken)
    {
        var user = await userRepository.FindByEmailAsync(request.Email, cancellationToken);
        if (user is null)
            return Result.Failure<UserAuthProfileDto>(Error.NotFound("User.NotFound", $"No user found with email '{request.Email}'."));

        // The JWT's perm claims must be the user's EFFECTIVE permissions - everything their
        // Role(s) grant, plus their own direct per-page overrides "in addition to" that (see
        // UserPagePermission's doc comment). user.Permissions alone (what LoginCommandHandler
        // used to read) is only ever the direct-override rows - for every seeded user, actual
        // page access mostly comes from their Role, so that left almost every claim out of the
        // token: Paycon's sidebar came back nearly empty and no seeded user had a *direct* grant
        // on "settings.user-management" itself (only ITAdministrator's ROLE grants it), so the
        // Master settings gear never appeared for anyone. Merge both here, taking the higher
        // access level (Edit > View) wherever a page appears in more than one source.
        var effective = new Dictionary<string, AccessLevel>();

        foreach (var roleAssignment in user.Roles)
        {
            var role = await roleRepository.GetByIdAsync(roleAssignment.RoleId, cancellationToken);
            if (role is null) continue; // role since deleted/renamed away - ignore rather than fail login

            foreach (var grant in role.Permissions)
            {
                if (!effective.TryGetValue(grant.PageKey, out var existing) || grant.Access > existing)
                    effective[grant.PageKey] = grant.Access;
            }
        }

        foreach (var grant in user.Permissions)
        {
            if (!effective.TryGetValue(grant.PageKey, out var existing) || grant.Access > existing)
                effective[grant.PageKey] = grant.Access;
        }

        var dto = new UserAuthProfileDto(
            user.Id, user.FullName, user.Email,
            user.Groups.Select(g => g.GroupName).ToList(),
            user.Roles.Select(r => r.RoleName).ToList(),
            effective.Select(kv => new PagePermissionDto(kv.Key, PermissionPageCatalog.LabelFor(kv.Key), kv.Value.ToString())).ToList());

        return Result.Success(dto);
    }
}
