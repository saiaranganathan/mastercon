using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.UserManagement.Application.Auth;

/// <summary>Public query the Master Auth module sends in-process (both live in Master) to
/// populate its dev-mode login picker - see AuthController.GetLoginCandidates.</summary>
public sealed record GetLoginCandidatesQuery : IQuery<IReadOnlyCollection<LoginCandidateDto>>;
