using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Roles.Queries;

public sealed class GetRolesQueryHandler(IRoleRepository roleRepository, IGroupRepository groupRepository)
    : IQueryHandler<GetRolesQuery, PagedResult<RoleListItemDto>>
{
    public async Task<Result<PagedResult<RoleListItemDto>>> Handle(GetRolesQuery request, CancellationToken cancellationToken)
    {
        var (roles, totalCount) = await roleRepository.SearchAsync(request.Paging, cancellationToken);

        var items = new List<RoleListItemDto>();
        foreach (var role in roles)
        {
            var group = await groupRepository.GetByIdAsync(role.GroupId, cancellationToken);
            var activeUsers = await roleRepository.CountActiveUsersAsync(role.Id, cancellationToken);
            items.Add(new RoleListItemDto(
                role.Id, role.Name, role.GroupId, group?.Name ?? "-", role.Description, activeUsers, role.State.ToString(),
                role.CreatedAt, role.CreatedBy, role.UpdatedAt, role.UpdatedBy));
        }

        return Result.Success(new PagedResult<RoleListItemDto>(items, totalCount, request.Paging.Page, request.Paging.PageSize));
    }
}
