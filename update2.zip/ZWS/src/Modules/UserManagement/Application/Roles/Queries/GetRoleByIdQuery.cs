using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Roles.Queries;

/// <summary>PR_UM 2.3: read-only View Role modal, including its Permissions sub-modal.</summary>
public sealed record GetRoleByIdQuery(Guid Id) : IQuery<RoleDetailDto>;
