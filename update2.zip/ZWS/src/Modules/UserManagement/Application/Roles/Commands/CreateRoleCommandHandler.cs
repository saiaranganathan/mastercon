using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

public sealed class CreateRoleCommandHandler(IRoleRepository roleRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<CreateRoleCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
    {
        var role = Role.Create(request.Name, request.GroupId, request.Description, request.State, request.Permissions);
        roleRepository.Add(role);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success(role.Id);
    }
}
