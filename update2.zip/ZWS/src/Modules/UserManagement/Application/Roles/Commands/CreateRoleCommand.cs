using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

/// <summary>PR_UM 2.1: Create Role.</summary>
public sealed record CreateRoleCommand(
    string Name,
    Guid GroupId,
    string? Description,
    RoleState State,
    IReadOnlyCollection<PagePermissionAssignment> Permissions) : ICommand<Guid>;
