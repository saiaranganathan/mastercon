using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

/// <summary>PR_UM 2.2: Edit Role. Group cannot change while the role has active users.</summary>
public sealed record UpdateRoleCommand(
    Guid Id,
    string Name,
    string? Description,
    RoleState State,
    IReadOnlyCollection<PagePermissionAssignment> Permissions) : ICommand;
