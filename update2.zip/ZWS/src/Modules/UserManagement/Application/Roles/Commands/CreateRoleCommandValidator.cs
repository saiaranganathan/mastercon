using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

public sealed class CreateRoleCommandValidator : AbstractValidator<CreateRoleCommand>
{
    public CreateRoleCommandValidator(IRoleRepository roleRepository, IGroupRepository groupRepository)
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Role Name is required.")
            .Matches("^[A-Za-z0-9]+$").WithMessage("Role Name must be alphanumeric only.")
            .Length(4, 150).WithMessage("Role Name must be between 4 and 150 characters.");

        RuleFor(x => x.GroupId)
            .NotEmpty().WithMessage("Group is required.")
            .MustAsync(async (id, ct) => await groupRepository.GetByIdAsync(id, ct) is not null)
            .WithMessage("Selected Group does not exist.");

        RuleFor(x => x)
            // group + role name combination must be unique, per the BRD's clarifying annotation on PR_UM 2.1
            .MustAsync(async (command, ct) => !await roleRepository.ExistsByNameAsync($"{command.GroupId}::{command.Name}", null, ct))
            .WithMessage("Role Name must be unique within the selected Group.");

        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.State).IsInEnum();
        RuleFor(x => x.Permissions).NotEmpty().WithMessage("At least one page permission must be selected.");
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
    }
}
