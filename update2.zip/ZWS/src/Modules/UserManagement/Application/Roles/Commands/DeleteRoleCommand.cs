using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

/// <summary>PR_UM 2.4: a role can be deleted only if no users are assigned.</summary>
public sealed record DeleteRoleCommand(Guid Id) : ICommand;
