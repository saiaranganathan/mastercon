using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

public sealed class DeleteRoleCommandHandler(IRoleRepository roleRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<DeleteRoleCommand>
{
    public async Task<Result> Handle(DeleteRoleCommand request, CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.Id, cancellationToken);
        if (role is null)
            return Result.Failure(Error.NotFound("Role.NotFound", $"Role '{request.Id}' was not found."));

        var activeUsers = await roleRepository.CountActiveUsersAsync(role.Id, cancellationToken);
        if (activeUsers > 0)
            return Result.Failure(Error.Conflict("Role.HasActiveUsers", "This role cannot be deleted because users are currently assigned to it."));

        roleRepository.Remove(role);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
