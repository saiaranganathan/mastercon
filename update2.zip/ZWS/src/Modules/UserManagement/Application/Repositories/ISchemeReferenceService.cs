using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Repositories;

/// <summary>
/// UserManagement's window into Paycon's SchemeManagement module. UserManagement lives in the
/// Master app now; SchemeManagement stays in Paycon - a different App Service - so this is
/// implemented in Infrastructure as an HTTP call to Paycon's public API rather than the
/// in-process MediatR query it used to be when both lived in the same process.
/// </summary>
public interface ISchemeReferenceService
{
    Task<IReadOnlyCollection<SchemeRefDto>> GetActiveSchemesAsync(CancellationToken cancellationToken);
}
