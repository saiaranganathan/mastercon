using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.SchemeReference;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

/// <summary>
/// The "Assigned plans" checklist on Master.Web's Groups/Users forms calls this instead of
/// reaching across to Paycon directly - keeps the browser only ever talking to the one app it
/// logged into, with Master.Host proxying to Paycon server-to-server via ISchemeReferenceService.
/// </summary>
[ApiController]
[Route("api/paycon/settings/user-management/schemes")]
public sealed class SchemeReferenceController(ISender sender) : ControllerBase
{
    [HttpGet("reference")]
    public async Task<IActionResult> GetActiveSchemes(CancellationToken cancellationToken) =>
        (await sender.Send(new GetActiveSchemesQuery(), cancellationToken)).ToActionResult();
}
