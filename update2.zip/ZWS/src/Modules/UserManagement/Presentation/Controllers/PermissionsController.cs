using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.Permissions;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

[ApiController]
[Route("api/paycon/settings/user-management/permissions")]
public sealed class PermissionsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetPermissions(CancellationToken cancellationToken) =>
        (await sender.Send(new GetPermissionsQuery(), cancellationToken)).ToActionResult();
}
