using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.Roles.Commands;
using ZWS.Modules.UserManagement.Application.Roles.Queries;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

/// <summary>/paycon/settings/user-management -> Roles tab (PR_UM 2.x).</summary>
[ApiController]
[Route("api/paycon/settings/user-management/roles")]
public sealed class RolesController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetRoles([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetRolesQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetRole(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GetRoleByIdQuery(id), cancellationToken)).ToActionResult();

    [HttpPost]
    public async Task<IActionResult> CreateRole([FromBody] CreateRoleRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreateRoleCommand(request.Name, request.GroupId, request.Description, request.State, request.Permissions), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> UpdateRole(Guid id, [FromBody] UpdateRoleRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateRoleCommand(id, request.Name, request.Description, request.State, request.Permissions), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> DeleteRole(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteRoleCommand(id), cancellationToken)).ToActionResult();
}

public sealed record CreateRoleRequest(string Name, Guid GroupId, string? Description, RoleState State, IReadOnlyCollection<PagePermissionAssignment> Permissions);
public sealed record UpdateRoleRequest(string Name, string? Description, RoleState State, IReadOnlyCollection<PagePermissionAssignment> Permissions);
