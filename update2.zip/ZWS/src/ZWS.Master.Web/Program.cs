using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ZWS.Master.Web;
using ZWS.Master.Web.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// The API base address is provided by wwwroot/appsettings*.json ("ApiBaseAddress"). It defaults
// to the ZWS.Master.Host dev port (see src/ZWS.Master.Host/Properties/launchSettings.json) so
// `dotnet run` works out of the box against a locally running Master.Host.
var apiBaseAddress = builder.Configuration["ApiBaseAddress"] ?? "https://localhost:5211";

builder.Services.AddScoped<TokenStore>();
builder.Services.AddScoped<PermissionService>();
builder.Services.AddScoped<AppLinkBuilder>();
builder.Services.AddTransient<AuthMessageHandler>();

// Every typed API client is built from the same named HttpClient so AuthMessageHandler attaches
// "Authorization: Bearer {token}" once, in one place, instead of each client re-implementing it.
builder.Services.AddHttpClient("ZwsMasterApi", client => client.BaseAddress = new Uri(apiBaseAddress))
    .AddHttpMessageHandler<AuthMessageHandler>();

builder.Services.AddScoped(sp => sp.GetRequiredService<IHttpClientFactory>().CreateClient("ZwsMasterApi"));

builder.Services.AddScoped<ApplicationHubApiClient>();
builder.Services.AddScoped<UserManagementApiClient>();
builder.Services.AddScoped<AuthApiClient>();

await builder.Build().RunAsync();
