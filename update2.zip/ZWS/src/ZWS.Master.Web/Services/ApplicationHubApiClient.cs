using ZWS.Master.Web.Models;

namespace ZWS.Master.Web.Services;

public sealed class ApplicationHubApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<ApplicationCardDto>>> GetCardsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<ApplicationCardDto>>("api/applications", cancellationToken);
}
