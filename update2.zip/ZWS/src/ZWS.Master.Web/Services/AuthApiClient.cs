using ZWS.Master.Web.Models;

namespace ZWS.Master.Web.Services;

/// <summary>Backs the dev-mode "pick a user" login page - a placeholder for real OKTA (see
/// the TODO(auth) already in the backend). GET users is intentionally unauthenticated so the
/// picker can populate before anyone is signed in.</summary>
public sealed class AuthApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<LoginCandidateDto>>> GetUsersAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<LoginCandidateDto>>("api/auth/users", cancellationToken);

    public Task<ApiResult<LoginResultDto>> LoginAsync(string email, CancellationToken cancellationToken = default) =>
        PostAsync<LoginRequest, LoginResultDto>("api/auth/login", new LoginRequest(email), cancellationToken);
}
