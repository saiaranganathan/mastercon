using System.Net.Http.Headers;

namespace ZWS.Master.Web.Services;

/// <summary>
/// Attaches "Authorization: Bearer {token}" to every call the app makes to its own API, once
/// signed in. Registered via AddHttpMessageHandler on the named "ZwsApi" HttpClient in
/// Program.cs, so every typed client built from ApiClientBase gets this for free.
/// </summary>
public sealed class AuthMessageHandler(TokenStore tokenStore) : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        if (tokenStore.IsAuthenticated)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenStore.Token);
        }

        return base.SendAsync(request, cancellationToken);
    }
}
