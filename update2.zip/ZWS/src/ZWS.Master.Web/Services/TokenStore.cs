using System.Text.Json;
using Microsoft.JSInterop;
using ZWS.Master.Web.Models;

namespace ZWS.Master.Web.Services;

/// <summary>
/// Holds the signed-in user's JWT (issued by Master's own POST api/auth/login - see
/// Modules/Auth) for the lifetime of the browser tab. Kept in memory plus mirrored to
/// sessionStorage so a page refresh doesn't sign the user back out; sessionStorage (not
/// localStorage) is deliberate - the session should end with the tab, matching the dev-mode
/// "pick a user" login this stands in for until real OKTA lands.
/// </summary>
public sealed class TokenStore(IJSRuntime js)
{
    private const string StorageKey = "zws.master.auth";

    public string? Token { get; private set; }
    public Guid? UserId { get; private set; }
    public string? FullName { get; private set; }
    public string? Email { get; private set; }
    public bool IsAuthenticated => !string.IsNullOrWhiteSpace(Token);

    /// <summary>Raised after sign-in/sign-out so MainLayout and the sidebar can re-render.</summary>
    public event Action? Changed;

    private bool _initialized;

    public async Task InitializeAsync()
    {
        if (_initialized) return;
        _initialized = true;

        try
        {
            var json = await js.InvokeAsync<string?>("sessionStorage.getItem", StorageKey);
            if (!string.IsNullOrWhiteSpace(json))
            {
                var stored = JsonSerializer.Deserialize<StoredAuth>(json);
                if (stored is not null && !string.IsNullOrWhiteSpace(stored.Token))
                {
                    Token = stored.Token;
                    UserId = stored.UserId;
                    FullName = stored.FullName;
                    Email = stored.Email;
                }
            }
        }
        catch
        {
            // sessionStorage unreachable (private browsing, prerender, etc.) - just start signed out.
        }
    }

    public async Task SetAsync(LoginResultDto result)
    {
        Token = result.Token;
        UserId = result.UserId;
        FullName = result.FullName;
        Email = result.Email;

        try
        {
            var json = JsonSerializer.Serialize(new StoredAuth(Token, UserId, FullName, Email));
            await js.InvokeVoidAsync("sessionStorage.setItem", StorageKey, json);
        }
        catch
        {
            // Non-fatal - the in-memory copy still works for the rest of this tab's lifetime.
        }

        Changed?.Invoke();
    }

    public async Task ClearAsync()
    {
        Token = null;
        UserId = null;
        FullName = null;
        Email = null;

        try { await js.InvokeVoidAsync("sessionStorage.removeItem", StorageKey); }
        catch { /* non-fatal */ }

        Changed?.Invoke();
    }

    private sealed record StoredAuth(string? Token, Guid? UserId, string? FullName, string? Email);
}
