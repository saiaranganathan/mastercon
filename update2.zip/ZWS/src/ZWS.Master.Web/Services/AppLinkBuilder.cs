using Microsoft.Extensions.Configuration;
using ZWS.Master.Web.Models;

namespace ZWS.Master.Web.Services;

/// <summary>
/// Builds the URL for a Hub card's target app. Every other app (Paycon, Compliance, Trade
/// Insights, PartnerHub) is a separate deployable with its own base URL - configured per
/// environment under "AppBaseUrls" in wwwroot/appsettings*.json, keyed by ApplicationCard.Code.
/// Clicking a card is a real browser navigation, not an in-SPA route change, and the user's
/// JWT rides along in the URL fragment (never a query string, so it never reaches server
/// access logs) - the target app reads window.location.hash on startup, stores the token the
/// same way this app does, then strips the hash via history.replaceState. Until that target
/// app exists and reads the fragment (Stage B/C), the token is still attached and simply
/// ignored by the app on the other end.
/// </summary>
public sealed class AppLinkBuilder(TokenStore tokenStore, IConfiguration configuration)
{
    public string BuildHref(ApplicationCardDto card)
    {
        var route = card.Route.StartsWith('/') ? card.Route : $"/{card.Route}";
        var baseUrl = configuration[$"AppBaseUrls:{card.Code}"];

        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            // No base URL configured for this app yet - fall back to an in-SPA relative link so
            // the Hub still renders something clickable rather than a dead card.
            return route;
        }

        var fragment = tokenStore.IsAuthenticated ? $"#access_token={Uri.EscapeDataString(tokenStore.Token!)}" : string.Empty;
        return $"{baseUrl.TrimEnd('/')}{route}{fragment}";
    }
}
