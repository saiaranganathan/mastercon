namespace ZWS.Master.Web.Models;

/// <summary>Mirrors ZWS.BuildingBlocks.Application.Common.PagedResult&lt;T&gt; on the wire - the
/// browser only ever sees the public JSON contract, never the server-side type.</summary>
public sealed class PagedResult<T>
{
    public IReadOnlyCollection<T> Items { get; set; } = [];
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages { get; set; }
    public bool HasPreviousPage { get; set; }
    public bool HasNextPage { get; set; }
}

public sealed class ApiError
{
    public int Status { get; set; }
    public string Message { get; set; } = "An unexpected error occurred.";
    public string TraceId { get; set; } = string.Empty;
    public Dictionary<string, string[]>? Errors { get; set; }
}
