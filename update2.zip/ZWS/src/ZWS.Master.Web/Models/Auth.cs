namespace ZWS.Master.Web.Models;

/// <summary>One entry in the dev-mode login picker (GET api/auth/users) - a placeholder for a
/// real identity provider (OKTA), per the TODO(auth) already in the codebase.</summary>
public sealed record LoginCandidateDto(Guid Id, string FullName, string Email);

public sealed record LoginRequest(string Email);

/// <summary>POST api/auth/login's response - the signed JWT plus a little display info for the
/// top bar. The JWT's group/role/perm claims are what every other app trusts once the user
/// clicks a Hub card and lands there with the token in the URL fragment.</summary>
public sealed record LoginResultDto(string Token, Guid UserId, string FullName, string Email);
