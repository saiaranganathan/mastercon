namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// What IJwtTokenIssuer bakes into a token at login. Populated by the Master-only Auth module
/// from UserManagement's Users/Groups/Roles/Permissions (see Modules/Auth). Permissions are
/// already fully expanded strings (e.g. "settings.user-management.users:View" and
/// "settings.user-management.users:Edit" both present when access is Edit - Edit implies View,
/// expanded once here at mint time so every downstream ICurrentUserService.HasPermission check
/// stays a plain string match with no page-catalog knowledge required).
/// </summary>
public sealed record JwtUserClaims(
    string UserId,
    string UserName,
    string Email,
    IReadOnlyCollection<string> Groups,
    IReadOnlyCollection<string> Roles,
    IReadOnlyCollection<string> Permissions);
