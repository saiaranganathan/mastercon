using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// The real ICurrentUserService, reading the JWT claims AddZwsJwtAuthentication's JwtBearer
/// handler already validated onto HttpContext.User. Registered by AddZwsJwtAuthentication in
/// every app's Program.cs in place of the manual
/// `services.AddScoped&lt;ICurrentUserService, SystemCurrentUserService&gt;()` line each one
/// used to have (that TODO(auth) is now resolved - by a dev-mode JWT rather than real OKTA,
/// but a real signed/validated token end to end). Falls back to SystemCurrentUserService's own
/// behavior when there's no HTTP request at all (seeding, background jobs) - the same case
/// SystemCurrentUserService exists for, so this delegates to an instance of it rather than
/// duplicating that fallback logic.
/// </summary>
public sealed class ClaimsPrincipalCurrentUserService(IHttpContextAccessor httpContextAccessor) : ICurrentUserService
{
    private static readonly SystemCurrentUserService NoRequestFallback = new();

    private ClaimsPrincipal? User => httpContextAccessor.HttpContext?.User;

    public bool IsAuthenticated => User?.Identity?.IsAuthenticated ?? false;

    public string UserId => IsAuthenticated ? User!.FindFirst(JwtRegisteredClaimNames.Sub)?.Value ?? NoRequestFallback.UserId : NoRequestFallback.UserId;

    public string UserName => IsAuthenticated ? User!.FindFirst(JwtRegisteredClaimNames.Name)?.Value ?? NoRequestFallback.UserName : NoRequestFallback.UserName;

    public string? Email => IsAuthenticated ? User!.FindFirst(JwtRegisteredClaimNames.Email)?.Value : NoRequestFallback.Email;

    public IReadOnlyCollection<string> Permissions => IsAuthenticated
        ? User!.FindAll(JwtTokenIssuer.PermissionClaimType).Select(c => c.Value).ToList()
        : NoRequestFallback.Permissions;

    public bool HasPermission(string permission) => IsAuthenticated ? Permissions.Contains(permission) : NoRequestFallback.HasPermission(permission);
}
