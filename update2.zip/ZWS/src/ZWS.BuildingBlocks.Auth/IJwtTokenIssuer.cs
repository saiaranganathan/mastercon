namespace ZWS.BuildingBlocks.Auth;

/// <summary>Master-only (see AddZwsJwtIssuer) - mints the signed JWT issued at login.</summary>
public interface IJwtTokenIssuer
{
    string IssueToken(JwtUserClaims claims);
}
