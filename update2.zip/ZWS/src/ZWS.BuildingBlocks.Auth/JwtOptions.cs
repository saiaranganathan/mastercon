namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// Bound from the "Jwt" configuration section. Every ZWS app service shares the same
/// SigningKey - Master mints tokens with it, every other app validates them with the same
/// key, no callback to Master per request (hub-issues/spokes-trust). Placeholder value in
/// appsettings.json, real value via User Secrets (dev) or Key Vault (production) - same
/// convention this repo already uses for the SQL/Redis passwords.
/// </summary>
public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    /// <summary>
    /// Used by BOTH JwtTokenIssuer (Master, minting) and AddZwsJwtAuthentication (every app,
    /// validating) whenever "Jwt:SigningKey" is blank - which it deliberately is out of the box
    /// in every appsettings.Development.json, so a fresh checkout still boots and every app's
    /// dev tokens validate against each other before anyone has run `dotnet user-secrets set`.
    /// Defined once, here, and shared by both call sites - they used to each hardcode their own
    /// copy, and the issuer's copy had silently drifted into throwing instead of falling back
    /// (see JwtTokenIssuer.IssueToken), which broke login end-to-end for every app on a fresh
    /// checkout: no token was ever issued, so nothing downstream had anything to validate.
    /// </summary>
    public const string DevOnlyFallbackSigningKey = "dev-only-placeholder-signing-key-0000000000000000";

    public string SigningKey { get; set; } = string.Empty;
    public string Issuer { get; set; } = "zws-master";
    public string Audience { get; set; } = "zws";
    public int ExpiryMinutes { get; set; } = 480;
}
