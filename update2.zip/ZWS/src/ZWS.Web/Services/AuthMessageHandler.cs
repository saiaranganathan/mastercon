using System.Net.Http.Headers;

namespace ZWS.Web.Services;

/// <summary>
/// Attaches "Authorization: Bearer {token}" to every call this app makes to its own API, once
/// a token has been picked up (from the URL fragment or sessionStorage - see TokenStore).
/// Registered via AddHttpMessageHandler on the named "ZwsPayconApi" HttpClient in Program.cs,
/// so every existing typed API client gets this for free with no change to how each one is
/// constructed.
/// </summary>
public sealed class AuthMessageHandler(TokenStore tokenStore) : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        if (tokenStore.IsAuthenticated)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenStore.Token);
        }

        return base.SendAsync(request, cancellationToken);
    }
}
