using Microsoft.JSInterop;

namespace ZWS.Web.Services;

/// <summary>
/// Holds the JWT this Paycon app was handed when the user clicked into it from Master's Hub.
/// Paycon never issues tokens itself (only Master does, via POST api/auth/login) - it only
/// ever receives one, either fresh off the URL fragment (see Program.cs, which calls
/// SetFromFragmentAsync once at startup) or restored from sessionStorage on a page refresh.
/// </summary>
public sealed class TokenStore(IJSRuntime js)
{
    private const string StorageKey = "zws.paycon.auth";

    public string? Token { get; private set; }
    public bool IsAuthenticated => !string.IsNullOrWhiteSpace(Token);

    /// <summary>Raised whenever the token changes, so layout/permission-gated UI can re-render.</summary>
    public event Action? Changed;

    private bool _initialized;

    public async Task InitializeAsync()
    {
        if (_initialized) return;
        _initialized = true;

        try
        {
            var stored = await js.InvokeAsync<string?>("sessionStorage.getItem", StorageKey);
            if (!string.IsNullOrWhiteSpace(stored)) Token = stored;
        }
        catch
        {
            // sessionStorage unreachable (private browsing, prerender, etc.) - start signed out;
            // Program.cs still gets a chance to pick up a fresh token from the URL fragment.
        }
    }

    /// <summary>Called once at startup with whatever rode in on "#access_token=..." when the
    /// user arrived here from a Hub card click on Master. A fresh arrival always overwrites
    /// whatever was previously stored.</summary>
    public async Task SetFromFragmentAsync(string token)
    {
        Token = token;

        try { await js.InvokeVoidAsync("sessionStorage.setItem", StorageKey, token); }
        catch { /* non-fatal - the in-memory copy still works for the rest of this tab */ }

        Changed?.Invoke();
    }

    public async Task ClearAsync()
    {
        Token = null;

        try { await js.InvokeVoidAsync("sessionStorage.removeItem", StorageKey); }
        catch { /* non-fatal */ }

        Changed?.Invoke();
    }
}
