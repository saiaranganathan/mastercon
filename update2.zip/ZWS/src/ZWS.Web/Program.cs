using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ZWS.Web;
using ZWS.Web.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// The API base address is provided by wwwroot/appsettings*.json ("ApiBaseAddress").
// It defaults to the ZWS.Host dev port (see src/ZWS.Host/Properties/launchSettings.json)
// so `dotnet run` works out of the box against a locally running Host.
var apiBaseAddress = builder.Configuration["ApiBaseAddress"] ?? "https://localhost:5201";

builder.Services.AddScoped<TokenStore>();
builder.Services.AddScoped<PermissionService>();
builder.Services.AddTransient<AuthMessageHandler>();

// Every typed API client below still just takes a plain HttpClient (unchanged) - it now comes
// from this named, handler-wrapped client instead of a bare `new HttpClient`, so
// AuthMessageHandler attaches "Authorization: Bearer {token}" in one place for all of them.
builder.Services.AddHttpClient("ZwsPayconApi", client => client.BaseAddress = new Uri(apiBaseAddress))
    .AddHttpMessageHandler<AuthMessageHandler>();
builder.Services.AddScoped(sp => sp.GetRequiredService<IHttpClientFactory>().CreateClient("ZwsPayconApi"));

builder.Services.AddScoped<PayconNavigationApiClient>();
builder.Services.AddScoped<DashboardApiClient>();
builder.Services.AddScoped<PaymentsInApiClient>();
builder.Services.AddScoped<PaymentsOutApiClient>();
builder.Services.AddScoped<InsightsApiClient>();
builder.Services.AddScoped<ExitStatementsApiClient>();
builder.Services.AddScoped<AnnualStatementsApiClient>();
// UserManagementApiClient moved to ZWS.Master.Web - User Management now lives on the Master app.
builder.Services.AddScoped<SchemeManagementApiClient>();
builder.Services.AddScoped<InsightManagementApiClient>();
builder.Services.AddScoped<NotificationsApiClient>();
builder.Services.AddScoped<ComplianceApiClient>();
builder.Services.AddScoped<TradeInsightsApiClient>();
builder.Services.AddScoped<PartnerHubApiClient>();

// Single shared SignalR connection to /payconHub (requirement 24), consumed by
// any page/component that needs live PaymentStatusUpdated / ReconciliationUpdated /
// DashboardMetricUpdated / NotificationReceived events.
builder.Services.AddSingleton(sp => new PayconRealtimeService(apiBaseAddress));

var host = builder.Build();

var tokenStore = host.Services.GetRequiredService<TokenStore>();
await tokenStore.InitializeAsync();

// If the user just arrived here from a Hub card click on Master, the JWT rides in on the URL
// fragment as "#access_token={jwt}" (never a query string, so it never reaches server access
// logs). Pick it up once at startup, store it the same way Master.Web does, then strip it from
// the address bar via NavigateTo(replace: true) so it doesn't linger in browser history.
var navigationManager = host.Services.GetRequiredService<NavigationManager>();
var fragment = new Uri(navigationManager.Uri).Fragment;
const string tokenFragmentPrefix = "#access_token=";
if (fragment.StartsWith(tokenFragmentPrefix, StringComparison.Ordinal))
{
    var token = Uri.UnescapeDataString(fragment[tokenFragmentPrefix.Length..]);
    await tokenStore.SetFromFragmentAsync(token);

    var hashIndex = navigationManager.Uri.IndexOf('#');
    var cleanUrl = hashIndex >= 0 ? navigationManager.Uri[..hashIndex] : navigationManager.Uri;
    navigationManager.NavigateTo(cleanUrl, replace: true);
}

await host.RunAsync();
