# Migrating ZWS's schemas and seed data to SQL Server

## The short version

This codebase does **not** use `dotnet ef migrations` today — no `Migrations/` folders exist in any module. Instead, every module's `Seed{X}ModuleAsync()` (all called from `ZWS.Host/Program.cs` on startup) calls `context.Database.EnsureCreatedAsync()` before inserting its seed rows. `EnsureCreatedAsync` builds the database schema straight from the current EF Core model — no migration files needed — and each module's seed method is idempotent (`if (await context.Groups.AnyAsync(...)) return;`, or equivalent), so it only inserts data once.

That means the whole "migrate schema + insert seed data" job you're asking about reduces to two steps:

1. Point the app's connection strings at a real SQL Server instead of leaving them blank (blank = falls back to local SQLite `.dev.db` files — see the `_comment` in `appsettings.Development.json`).
2. Run `ZWS.Host` once.

Every schema, every table, and every seed row appears automatically on that first run. There is no separate script to write or run.

I can't execute this myself — I have no reachable `dotnet` SDK and no network path to your SQL Server from this sandbox — so everything below is written for you to run in Visual Studio / a terminal on your machine.

## 1. Get a SQL Server instance

Pick whichever is easiest for you:

- **SQL Server LocalDB** — already ships with Visual Studio, zero extra install. Connection string: `Server=(localdb)\MSSQLLocalDB;Database=<db-name>;Trusted_Connection=True;TrustServerCertificate=True;`
- **SQL Server Developer/Express** (local instance) — `Server=localhost;Database=<db-name>;Trusted_Connection=True;TrustServerCertificate=True;`
- **Docker** — `docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=Your_password123" -p 1433:1433 -d mcr.microsoft.com/mssql/server:2022-latest`, then `Server=localhost;Database=<db-name>;User Id=sa;Password=Your_password123;TrustServerCertificate=True;`
- **Azure SQL** — the placeholder strings already in `appsettings.json` point here (`zws-sql.database.windows.net`). If you use Azure SQL, you must pre-create the 5 databases yourself (Azure won't let `EnsureCreated` create a *new* database through a connection string that targets it directly — you'd need to connect to `master` first). For local dev, skip this and use LocalDB/Express/Docker instead — `EnsureCreated` will create the database itself.

## 2. Set the 5 connection strings

The app reads exactly 5 named connection strings (`ConnectionStrings:ApplicationHub`, `:Paycon`, `:Compliance`, `:TradeInsights`, `:PartnerHub`) — one per physical database. 11 of the 15 modules share the single `Paycon` connection string and are distinguished by SQL **schema**, not by database.

`ZWS.Host.csproj` already has a `UserSecretsId`, so the recommended way (keeps credentials out of source control) is `dotnet user-secrets`, run from `src/ZWS.Host`:

```
cd src/ZWS.Host
dotnet user-secrets set "ConnectionStrings:ApplicationHub" "Server=(localdb)\MSSQLLocalDB;Database=zws-application-hub;Trusted_Connection=True;TrustServerCertificate=True;"
dotnet user-secrets set "ConnectionStrings:Paycon"          "Server=(localdb)\MSSQLLocalDB;Database=zws-paycon;Trusted_Connection=True;TrustServerCertificate=True;"
dotnet user-secrets set "ConnectionStrings:Compliance"      "Server=(localdb)\MSSQLLocalDB;Database=zws-compliance;Trusted_Connection=True;TrustServerCertificate=True;"
dotnet user-secrets set "ConnectionStrings:TradeInsights"   "Server=(localdb)\MSSQLLocalDB;Database=zws-trade-insights;Trusted_Connection=True;TrustServerCertificate=True;"
dotnet user-secrets set "ConnectionStrings:PartnerHub"      "Server=(localdb)\MSSQLLocalDB;Database=zws-partner-hub;Trusted_Connection=True;TrustServerCertificate=True;"
```

(Swap the `Server=...` portion for whichever option you picked in step 1.)

If you'd rather not use user-secrets, editing the 5 blank values directly in `src/ZWS.Host/appsettings.Development.json` works exactly the same for local dev — that file is literally already set up with empty placeholders waiting for this.

## 3. Run the app once

From Visual Studio: set `ZWS.Host` as the startup project and hit F5 (Development environment). From a terminal with a working `dotnet` SDK: `dotnet run --project src/ZWS.Host`.

On that first run, in order, `Program.cs` will:

1. For each of the 15 modules, `Add{X}Module(...)` sees a non-blank connection string and calls `UseSqlServer(...)` instead of falling back to SQLite.
2. For each of the 15 modules, `Seed{X}ModuleAsync()` calls `EnsureCreatedAsync()` — this issues `CREATE SCHEMA` (if missing) + `CREATE TABLE` for every entity in that module's `DbContext`, directly from the current C# model.
3. Each seed method checks whether its tables are already populated; since they're empty, it inserts the deterministic seed rows baked into that `*DbContextSeed.cs` file.

Restarting the app afterward is safe and a no-op — `EnsureCreatedAsync` skips schema creation once it exists, and every seed method's `AnyAsync()` guard skips re-inserting.

## 4. Where everything lands

| Connection string | Database (dev name suggestion) | Modules → SQL schema inside it |
|---|---|---|
| `ApplicationHub` | `zws-application-hub` | ApplicationHub → **hub** |
| `Paycon` | `zws-paycon` | Navigation → **paycon_navigation**; Dashboard → **paycon_dashboard**; Reconciliation.PaymentsIn → **paycon_payments_in**; Reconciliation.PaymentsOut → **paycon_payments_out**; Insights → **paycon_insights**; Statements.ExitStatements → **paycon_exit_statements**; Statements.AnnualStatements → **paycon_annual_statements**; Settings.UserManagement → **paycon_user_management**; Settings.SchemeManagement → **paycon_scheme_management**; Settings.InsightManagement → **paycon_insight_management**; Notifications → **paycon_notifications** |
| `Compliance` | `zws-compliance` | Compliance → **compliance** |
| `TradeInsights` | `zws-trade-insights` | TradeInsights → **trade_insights** |
| `PartnerHub` | `zws-partner-hub` | PartnerHub → **partner_hub** |

So `zws-paycon` ends up with 11 schemas in one database (that's intentional — one DbContext per module, but they're allowed to share a physical SQL Server database via distinct schemas), while the other 4 modules each get their own database.

## 5. Verify

Connect with SSMS or Azure Data Studio and check you see 5 databases, with the schema/table layout above. A quick sanity query per module, e.g.:

```sql
SELECT COUNT(*) FROM paycon_user_management.Groups;   -- expect 6 (Finance/Operations/Compliance/CRM/IT/System)
SELECT COUNT(*) FROM paycon_user_management.Users;
SELECT COUNT(*) FROM hub.ApplicationCards;
```

If a table comes back empty, the app's seed method ran but found the table non-empty (already seeded) or the connection string for that module is still blank/pointing elsewhere — double check step 2 for that specific module.

## Important caveat: this only handles *creating* the schema, not evolving it

Because `EnsureCreatedAsync` builds tables straight from today's model and never touches them again, it has no concept of "the model changed, alter the existing table." If you already stood up a database before we reshaped the User Management permissions tables (`RolePermission`/`UserPermissionAssignment` → `RolePagePermission`/`UserPagePermission`), `EnsureCreatedAsync` will see the `paycon_user_management` schema already exists and silently do nothing — the app will then fail at runtime hitting columns that no longer match. If that happens, drop the `paycon_user_management` schema (or the whole `zws-paycon` database, since seeding is idempotent per-module anyway) and re-run.

More generally: this project already references `Microsoft.EntityFrameworkCore.Design` in every module, so real EF Core Migrations are available if/when you want production-grade, incremental schema versioning instead of `EnsureCreated`. That's a bigger change (adding a `Migrations/` folder and `dotnet ef migrations add`/`database update` per module) — happy to wire that up if you'd rather go that route, but it's not what's connected today.
