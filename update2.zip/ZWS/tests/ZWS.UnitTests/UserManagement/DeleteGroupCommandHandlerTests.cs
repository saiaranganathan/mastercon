using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Groups.Commands;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>PR_UM-1.4: a group with active users must not be deletable.</summary>
public class DeleteGroupCommandHandlerTests
{
    private readonly Mock<IGroupRepository> _groupRepository = new();
    private readonly Mock<IUserManagementDbContext> _dbContext = new();

    [Fact]
    public async Task Handle_WhenGroupNotFound_ShouldReturnNotFound()
    {
        _groupRepository.Setup(r => r.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>())).ReturnsAsync((Group?)null);
        var handler = new DeleteGroupCommandHandler(_groupRepository.Object, _dbContext.Object);

        var result = await handler.Handle(new DeleteGroupCommand(Guid.NewGuid()), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.NotFound);
    }

    [Fact]
    public async Task Handle_WhenGroupHasActiveUsers_ShouldReturnConflict()
    {
        var group = Group.Create("Finance", GroupState.Active, false, []);
        _groupRepository.Setup(r => r.GetByIdAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(group);
        _groupRepository.Setup(r => r.CountActiveUsersAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(3);

        var handler = new DeleteGroupCommandHandler(_groupRepository.Object, _dbContext.Object);

        var result = await handler.Handle(new DeleteGroupCommand(group.Id), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.Conflict);
        _groupRepository.Verify(r => r.Remove(It.IsAny<Group>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenGroupHasNoActiveUsers_ShouldRemoveGroup()
    {
        var group = Group.Create("Finance", GroupState.Active, false, []);
        _groupRepository.Setup(r => r.GetByIdAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(group);
        _groupRepository.Setup(r => r.CountActiveUsersAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(0);
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = new DeleteGroupCommandHandler(_groupRepository.Object, _dbContext.Object);

        var result = await handler.Handle(new DeleteGroupCommand(group.Id), CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        _groupRepository.Verify(r => r.Remove(group), Times.Once);
    }
}
