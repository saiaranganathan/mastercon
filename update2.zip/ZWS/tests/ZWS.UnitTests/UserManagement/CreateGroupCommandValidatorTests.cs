using FluentAssertions;
using Moq;
using ZWS.Modules.UserManagement.Application.Groups.Commands;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

public class CreateGroupCommandValidatorTests
{
    private readonly Mock<IGroupRepository> _repository = new();

    [Fact]
    public async Task Validate_WithValidCommand_ShouldSucceed()
    {
        _repository.Setup(r => r.ExistsByNameAsync("Finance", null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateGroupCommandValidator(_repository.Object);
        var command = new CreateGroupCommand("Finance", GroupState.Active, false, [Guid.NewGuid()]);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeTrue();
    }

    [Fact]
    public async Task Validate_WithDuplicateName_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByNameAsync("Finance", null, It.IsAny<CancellationToken>())).ReturnsAsync(true);
        var validator = new CreateGroupCommandValidator(_repository.Object);
        var command = new CreateGroupCommand("Finance", GroupState.Active, false, [Guid.NewGuid()]);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateGroupCommand.Name) && e.ErrorMessage.Contains("unique"));
    }

    [Theory]
    [InlineData("Fi")] // too short
    [InlineData("Finance Team!")] // invalid character
    public async Task Validate_WithInvalidName_ShouldFail(string name)
    {
        _repository.Setup(r => r.ExistsByNameAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateGroupCommandValidator(_repository.Object);
        var command = new CreateGroupCommand(name, GroupState.Active, false, [Guid.NewGuid()]);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateGroupCommand.Name));
    }

    [Fact]
    public async Task Validate_WithNoSchemes_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByNameAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateGroupCommandValidator(_repository.Object);
        var command = new CreateGroupCommand("Finance", GroupState.Active, false, []);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateGroupCommand.SchemeIds));
    }
}
