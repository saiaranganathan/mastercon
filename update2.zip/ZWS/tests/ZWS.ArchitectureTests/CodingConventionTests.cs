using FluentAssertions;
using NetArchTest.Rules;
using ZWS.Modules.UserManagement;
using Xunit;

namespace ZWS.ArchitectureTests;

/// <summary>Requirement 26/27: consistent, predictable code shape across every module.</summary>
public class CodingConventionTests
{
    [Fact]
    public void CommandAndQueryHandlers_ShouldBeSealed()
    {
        var result = Types.InAssembly(typeof(UserManagementModule).Assembly)
            .That()
            .HaveNameEndingWith("CommandHandler")
            .Or()
            .HaveNameEndingWith("QueryHandler")
            .Should()
            .BeSealed()
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Controllers_ShouldBeSealedAndLiveInPresentationControllersNamespace()
    {
        var result = Types.InAssembly(typeof(UserManagementModule).Assembly)
            .That()
            .HaveNameEndingWith("Controller")
            .Should()
            .BeSealed()
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Controllers_ShouldResideInAPresentationControllersNamespace()
    {
        var result = Types.InAssembly(typeof(UserManagementModule).Assembly)
            .That()
            .HaveNameEndingWith("Controller")
            .Should()
            .ResideInNamespaceMatching(@"\.Presentation\.Controllers$")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void DomainEntities_ShouldNotHavePublicConstructors()
    {
        // Every aggregate in this codebase is created via a static Create()
        // factory (private/EF-only parameterless ctor) so invariants can never
        // be bypassed by `new Group()` from outside the aggregate.
        var result = Types.InAssembly(typeof(UserManagementModule).Assembly)
            .That()
            .ResideInNamespace("ZWS.Modules.UserManagement.Domain")
            .And()
            .AreClasses()
            .Should()
            .NotHavePublicConstructor()
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }
}
