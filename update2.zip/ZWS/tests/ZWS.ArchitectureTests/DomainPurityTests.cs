using FluentAssertions;
using NetArchTest.Rules;
using ZWS.Modules.Paycon.Dashboard;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn;
using ZWS.Modules.Paycon.Settings.SchemeManagement;
using ZWS.Modules.UserManagement;
using Xunit;

namespace ZWS.ArchitectureTests;

/// <summary>
/// The Domain layer must stay persistence- and mediator-ignorant: entities
/// are plain C# with no EF Core / MediatR / ASP.NET Core dependency, so
/// business rules never quietly couple to infrastructure (requirement 26).
/// </summary>
public class DomainPurityTests
{
    public static IEnumerable<object[]> DomainAssemblies =>
    [
        [typeof(UserManagementModule).Assembly, "ZWS.Modules.UserManagement.Domain"],
        [typeof(SchemeManagementModule).Assembly, "ZWS.Modules.Paycon.Settings.SchemeManagement.Domain"],
        [typeof(DashboardModule).Assembly, "ZWS.Modules.Paycon.Dashboard.Domain"],
        [typeof(PaymentsInModule).Assembly, "ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain"]
    ];

    [Theory]
    [MemberData(nameof(DomainAssemblies))]
    public void DomainTypes_ShouldNotDependOnEntityFrameworkCore(System.Reflection.Assembly assembly, string domainNamespace)
    {
        var result = Types.InAssembly(assembly)
            .That().ResideInNamespace(domainNamespace)
            .ShouldNot()
            .HaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Theory]
    [MemberData(nameof(DomainAssemblies))]
    public void DomainTypes_ShouldNotDependOnMediatR(System.Reflection.Assembly assembly, string domainNamespace)
    {
        var result = Types.InAssembly(assembly)
            .That().ResideInNamespace(domainNamespace)
            .ShouldNot()
            .HaveDependencyOn("MediatR")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Theory]
    [MemberData(nameof(DomainAssemblies))]
    public void DomainTypes_ShouldNotDependOnAspNetCore(System.Reflection.Assembly assembly, string domainNamespace)
    {
        var result = Types.InAssembly(assembly)
            .That().ResideInNamespace(domainNamespace)
            .ShouldNot()
            .HaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }
}
