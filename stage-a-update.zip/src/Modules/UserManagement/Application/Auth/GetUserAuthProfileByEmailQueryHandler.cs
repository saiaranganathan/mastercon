using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Auth;

public sealed class GetUserAuthProfileByEmailQueryHandler(IUserRepository userRepository)
    : IQueryHandler<GetUserAuthProfileByEmailQuery, UserAuthProfileDto>
{
    public async Task<Result<UserAuthProfileDto>> Handle(GetUserAuthProfileByEmailQuery request, CancellationToken cancellationToken)
    {
        var user = await userRepository.FindByEmailAsync(request.Email, cancellationToken);
        if (user is null)
            return Result.Failure<UserAuthProfileDto>(Error.NotFound("User.NotFound", $"No user found with email '{request.Email}'."));

        var dto = new UserAuthProfileDto(
            user.Id, user.FullName, user.Email,
            user.Groups.Select(g => g.GroupName).ToList(),
            user.Roles.Select(r => r.RoleName).ToList(),
            user.Permissions.Select(p => new PagePermissionDto(p.PageKey, PermissionPageCatalog.LabelFor(p.PageKey), p.Access.ToString())).ToList());

        return Result.Success(dto);
    }
}
