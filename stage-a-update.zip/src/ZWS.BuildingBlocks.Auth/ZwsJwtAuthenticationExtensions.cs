using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.BuildingBlocks.Auth;

public static class ZwsJwtAuthenticationExtensions
{
    /// <summary>
    /// Every app service (Master, Paycon, Compliance, TradeInsights, PartnerHub) calls this
    /// once in Program.cs. Registers standard JwtBearer validation against the shared
    /// "Jwt:SigningKey" (see JwtOptions), `app.UseAuthentication()`/`UseAuthorization()`
    /// middleware wiring is still the caller's job same as any ASP.NET Core app, and registers
    /// ClaimsPrincipalCurrentUserService as the real ICurrentUserService. Only Master
    /// additionally calls AddZwsJwtIssuer to mint tokens - every app validates, only Master issues.
    /// </summary>
    public static IServiceCollection AddZwsJwtAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));
        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUserService, ClaimsPrincipalCurrentUserService>();

        var jwtSection = configuration.GetSection(JwtOptions.SectionName);
        var signingKey = jwtSection["SigningKey"];
        var issuer = jwtSection["Issuer"] ?? "zws-master";
        var audience = jwtSection["Audience"] ?? "zws";

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = issuer,
                    ValidateAudience = true,
                    ValidAudience = audience,
                    ValidateIssuerSigningKey = true,
                    // A dev-only fallback key so an app with no "Jwt:SigningKey" set yet still
                    // boots (tokens just won't validate against a *different* app's real key
                    // until every app's User Secrets are set to the same real value).
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
                        string.IsNullOrWhiteSpace(signingKey) ? "dev-only-placeholder-signing-key-0000000000000000" : signingKey)),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(1)
                };
            });

        services.AddAuthorization();

        return services;
    }

    /// <summary>Master-only: registers IJwtTokenIssuer so the Auth module can mint tokens at login.</summary>
    public static IServiceCollection AddZwsJwtIssuer(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));
        services.AddScoped<IJwtTokenIssuer, JwtTokenIssuer>();
        return services;
    }
}
