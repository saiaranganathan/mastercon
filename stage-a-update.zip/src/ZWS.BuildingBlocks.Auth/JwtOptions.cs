namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// Bound from the "Jwt" configuration section. Every ZWS app service shares the same
/// SigningKey - Master mints tokens with it, every other app validates them with the same
/// key, no callback to Master per request (hub-issues/spokes-trust). Placeholder value in
/// appsettings.json, real value via User Secrets (dev) or Key Vault (production) - same
/// convention this repo already uses for the SQL/Redis passwords.
/// </summary>
public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    public string SigningKey { get; set; } = string.Empty;
    public string Issuer { get; set; } = "zws-master";
    public string Audience { get; set; } = "zws";
    public int ExpiryMinutes { get; set; } = 480;
}
