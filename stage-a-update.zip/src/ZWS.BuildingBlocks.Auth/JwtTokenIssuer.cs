using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// Mints the signed JWT Master issues at login. Every other app service validates this same
/// token via AddZwsJwtAuthentication, against the same shared "Jwt:SigningKey" - a real hub-
/// issues/spokes-trust handoff, not a callback to Master on every request.
/// </summary>
public sealed class JwtTokenIssuer(IOptions<JwtOptions> options) : IJwtTokenIssuer
{
    /// <summary>Claim type carrying one Group name. Repeated, one per group.</summary>
    public const string GroupClaimType = "group";
    /// <summary>Claim type carrying one Role name. Repeated, one per role.</summary>
    public const string RoleClaimType = "role";
    /// <summary>Claim type carrying one "{pageKey}:{View|Edit}" permission string. Repeated -
    /// see JwtUserClaims for why Edit is expanded to both View and Edit at mint time.</summary>
    public const string PermissionClaimType = "perm";

    public string IssueToken(JwtUserClaims claims)
    {
        var jwtOptions = options.Value;
        if (string.IsNullOrWhiteSpace(jwtOptions.SigningKey))
        {
            throw new InvalidOperationException(
                "Jwt:SigningKey is not configured. Set it via `dotnet user-secrets set \"Jwt:SigningKey\" \"...\"` " +
                "(dev) or Key Vault (production) - never check a real signing key into appsettings.json.");
        }

        var securityClaims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, claims.UserId),
            new(JwtRegisteredClaimNames.Name, claims.UserName),
            new(JwtRegisteredClaimNames.Email, claims.Email),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        securityClaims.AddRange(claims.Groups.Select(g => new Claim(GroupClaimType, g)));
        securityClaims.AddRange(claims.Roles.Select(r => new Claim(RoleClaimType, r)));
        securityClaims.AddRange(claims.Permissions.Select(p => new Claim(PermissionClaimType, p)));

        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SigningKey));
        var credentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: jwtOptions.Issuer,
            audience: jwtOptions.Audience,
            claims: securityClaims,
            expires: DateTime.UtcNow.AddMinutes(jwtOptions.ExpiryMinutes),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
