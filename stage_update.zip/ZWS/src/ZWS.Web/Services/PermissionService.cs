namespace ZWS.Web.Services;

/// <summary>
/// Thin, always-current wrapper over JwtPermissions - pages/components inject this instead of
/// re-decoding the token themselves, and it re-parses automatically whenever TokenStore's
/// token changes (fresh arrival from Master, or sign-out).
/// </summary>
public sealed class PermissionService
{
    private readonly TokenStore _tokenStore;
    private string? _lastToken;
    private JwtPermissions _current = JwtPermissions.Empty;

    public PermissionService(TokenStore tokenStore)
    {
        _tokenStore = tokenStore;
        _tokenStore.Changed += () => Recompute();
        Recompute();
    }

    public bool HasView(string pageKey) { Recompute(); return _current.HasView(pageKey); }
    public bool HasEdit(string pageKey) { Recompute(); return _current.HasEdit(pageKey); }

    private void Recompute()
    {
        if (_tokenStore.Token == _lastToken) return;
        _lastToken = _tokenStore.Token;
        _current = JwtPermissions.Parse(_tokenStore.Token);
    }
}
