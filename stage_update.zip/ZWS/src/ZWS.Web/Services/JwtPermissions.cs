using System.Text;
using System.Text.Json;

namespace ZWS.Web.Services;

/// <summary>
/// A client-side read of the signed-in user's JWT claims (group/role/perm), used only to
/// decide what the UI should SHOW - which sidebar sections to render, whether Edit controls
/// appear. It is never the source of truth for authorization: every write still goes through
/// the server, which independently validates the same token via AddZwsJwtAuthentication and
/// would reject anything the token doesn't actually grant. Decoding here is just base64url +
/// JSON on the token's own payload - no signature check needed for a UI-only decision.
/// </summary>
public sealed class JwtPermissions
{
    public static readonly JwtPermissions Empty = new([], [], []);

    public IReadOnlySet<string> Groups { get; }
    public IReadOnlySet<string> Roles { get; }
    public IReadOnlySet<string> Permissions { get; }

    private JwtPermissions(IEnumerable<string> groups, IEnumerable<string> roles, IEnumerable<string> permissions)
    {
        Groups = groups.ToHashSet();
        Roles = roles.ToHashSet();
        Permissions = permissions.ToHashSet();
    }

    /// <summary>True if the token grants View OR Edit on this page key (Edit always implies
    /// View - see LoginCommandHandler, which expands Edit into both claims at mint time).</summary>
    public bool HasView(string pageKey) => Permissions.Contains($"{pageKey}:View") || HasEdit(pageKey);

    public bool HasEdit(string pageKey) => Permissions.Contains($"{pageKey}:Edit");

    public static JwtPermissions Parse(string? jwt)
    {
        if (string.IsNullOrWhiteSpace(jwt)) return Empty;

        try
        {
            var parts = jwt.Split('.');
            if (parts.Length < 2) return Empty;

            var payloadJson = Encoding.UTF8.GetString(Base64UrlDecode(parts[1]));
            using var doc = JsonDocument.Parse(payloadJson);
            var root = doc.RootElement;

            return new JwtPermissions(
                ReadClaimValues(root, "group"),
                ReadClaimValues(root, "role"),
                ReadClaimValues(root, "perm"));
        }
        catch
        {
            // Malformed/unexpected token shape - fail safe to "no permissions" rather than
            // throw, since this only ever gates what the UI shows.
            return Empty;
        }
    }

    private static IEnumerable<string> ReadClaimValues(JsonElement root, string claimType)
    {
        // System.IdentityModel.Tokens.Jwt collapses multiple claims of the same type into a
        // JSON array; a single claim of that type serializes as a bare string instead - handle
        // both shapes (and "claim absent entirely", e.g. a user with zero groups).
        if (!root.TryGetProperty(claimType, out var value)) return [];

        return value.ValueKind switch
        {
            JsonValueKind.Array => value.EnumerateArray().Select(e => e.GetString()).Where(s => s is not null).Select(s => s!),
            JsonValueKind.String => value.GetString() is { } s ? [s] : [],
            _ => []
        };
    }

    private static byte[] Base64UrlDecode(string input)
    {
        var padded = input.Replace('-', '+').Replace('_', '/');
        padded += (padded.Length % 4) switch { 2 => "==", 3 => "=", _ => "" };
        return Convert.FromBase64String(padded);
    }
}
