using FluentAssertions;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>A user can switch off a plan inherited from a Group (for that user only) and add others.</summary>
public class UserPlanOverrideTests
{
    private static readonly Guid Dews = Guid.NewGuid();
    private static readonly Guid Adnoc = Guid.NewGuid();

    [Fact]
    public void Create_WithExcludedScheme_ShouldKeepItApartFromAddedSchemes()
    {
        var user = User.Create("Anna Aiden", "anna@example.com", null, null, false, UserState.Active,
            [], [], [], [(Adnoc, "ADNOC")], [(Dews, "DEWS")]);

        user.AddedSchemes.Select(s => s.SchemeId).Should().Equal(Adnoc);
        user.ExcludedSchemes.Select(s => s.SchemeId).Should().Equal(Dews);
        user.ExcludedSchemes.Single().PlanName.Should().Be("DEWS");
        user.AddedSchemes.Single().PlanName.Should().Be("ADNOC");
    }

    [Fact]
    public void UpdateDetails_ShouldReplaceBothAddedAndExcludedSchemes()
    {
        var user = User.Create("Anna Aiden", "anna@example.com", null, null, false, UserState.Active,
            [], [], [], [(Adnoc, "ADNOC")], [(Dews, "DEWS")]);

        user.UpdateDetails(null, null, false, UserState.Active, [], [], [], [], []);

        user.AddedSchemes.Should().BeEmpty();
        user.ExcludedSchemes.Should().BeEmpty();
    }

    [Fact]
    public void Create_WithoutExcludedSchemes_ShouldBehaveAsBefore()
    {
        var user = User.Create("Anna Aiden", "anna@example.com", null, null, false, UserState.Active,
            [], [], [], [(Adnoc, "ADNOC")]);

        user.AddedSchemes.Should().ContainSingle();
        user.ExcludedSchemes.Should().BeEmpty();
    }
}
