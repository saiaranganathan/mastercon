using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

public sealed class AnnualStatementRepository(AnnualStatementsDbContext context) : IAnnualStatementRepository
{
    public async Task<(IReadOnlyCollection<AnnualStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, AnnualStatementFilter? filter, CancellationToken cancellationToken)
    {
        var query = Filtered(request.Search, filter);

        var total = await query.CountAsync(cancellationToken);
        var items = await Sorted(query, request.SortBy, request.SortDescending).Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public async Task<IReadOnlyCollection<AnnualStatement>> ListAsync(string? search, AnnualStatementFilter? filter, CancellationToken cancellationToken) =>
        await Sorted(Filtered(search, filter), null, false).ToListAsync(cancellationToken);

    public async Task<IReadOnlyCollection<Guid>> ListIdsAsync(string? search, AnnualStatementFilter? filter, CancellationToken cancellationToken) =>
        await Filtered(search, filter).Select(s => s.Id).ToListAsync(cancellationToken);

    public async Task<IReadOnlyCollection<long>> GetEmployerIdsAsync(CancellationToken cancellationToken) =>
        await context.AnnualStatements.AsNoTracking().Select(s => s.EmployerId).Distinct().OrderBy(id => id).ToListAsync(cancellationToken);

    public async Task<IReadOnlyCollection<AnnualStatement>> GetByIdsAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken) =>
        await context.AnnualStatements.Where(s => ids.Contains(s.Id)).ToListAsync(cancellationToken);

    public async Task<AnnualStatement?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        await context.AnnualStatements.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    /// <summary>Orders the grid by a column the user clicked (whitelisted - never a raw column name
    /// from the query string). Default is newest due date first. Always ends with name + id so
    /// paging stays stable when the sort column has ties.</summary>
    private static IOrderedQueryable<AnnualStatement> Sorted(IQueryable<AnnualStatement> query, string? sortBy, bool descending)
    {
        IOrderedQueryable<AnnualStatement> ordered = (sortBy ?? string.Empty).Trim().ToLowerInvariant() switch
        {
            "employeeid" => descending ? query.OrderByDescending(s => s.EmployeeId) : query.OrderBy(s => s.EmployeeId),
            "employerid" => descending ? query.OrderByDescending(s => s.EmployerId) : query.OrderBy(s => s.EmployerId),
            "employeefullname" or "name" => descending ? query.OrderByDescending(s => s.EmployeeFullName) : query.OrderBy(s => s.EmployeeFullName),
            "duedate" or "statementduedate" => descending ? query.OrderByDescending(s => s.StatementDueDate) : query.OrderBy(s => s.StatementDueDate),
            "sentdate" or "statementsentdate" => descending ? query.OrderByDescending(s => s.StatementSentDate) : query.OrderBy(s => s.StatementSentDate),
            "status" or "statementsentstatus" => descending ? query.OrderByDescending(s => s.StatementSentStatus) : query.OrderBy(s => s.StatementSentStatus),
            _ => query.OrderByDescending(s => s.StatementDueDate)
        };
        return ordered.ThenBy(s => s.EmployeeFullName).ThenBy(s => s.Id);
    }

    /// <summary>Shared by the paged list, the CSV export and Select All so they always agree on
    /// what "matches". Not ordered - callers apply <see cref="Sorted"/>.</summary>
    private IQueryable<AnnualStatement> Filtered(string? search, AnnualStatementFilter? filter)
    {
        var query = context.AnnualStatements.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            // Case-insensitive on every provider (SQLite's Contains is case-sensitive, SQL Server's
            // depends on collation) - matches the employee name, employee id or employer id.
            var term = search.Trim().ToLower();
            query = query.Where(s => s.EmployeeFullName.ToLower().Contains(term)
                                  || s.EmployeeId.ToString().Contains(term)
                                  || s.EmployerId.ToString().Contains(term));
        }

        if (filter is not null)
        {
            if (!string.IsNullOrWhiteSpace(filter.EmployeeId))
            {
                var id = filter.EmployeeId.Trim();
                query = query.Where(s => s.EmployeeId.ToString().Contains(id));
            }

            if (filter.EmployerId is { } employerId)
                query = query.Where(s => s.EmployerId == employerId);

            if (!string.IsNullOrWhiteSpace(filter.Status) && Enum.TryParse<AnnualStatementSentStatus>(filter.Status.Trim(), ignoreCase: true, out var status))
                query = query.Where(s => s.StatementSentStatus == status);

            if (filter.DueDateFrom is { } dueFrom)
            {
                var from = dueFrom.Date;
                query = query.Where(s => s.StatementDueDate >= from);
            }

            if (filter.DueDateTo is { } dueTo)
            {
                var before = dueTo.Date.AddDays(1);
                query = query.Where(s => s.StatementDueDate < before);
            }

            if (filter.SentDateFrom is { } sentFrom)
            {
                var from = sentFrom.Date;
                query = query.Where(s => s.StatementSentDate != null && s.StatementSentDate >= from);
            }

            if (filter.SentDateTo is { } sentTo)
            {
                var before = sentTo.Date.AddDays(1);
                query = query.Where(s => s.StatementSentDate != null && s.StatementSentDate < before);
            }
        }

        return query;
    }
}
