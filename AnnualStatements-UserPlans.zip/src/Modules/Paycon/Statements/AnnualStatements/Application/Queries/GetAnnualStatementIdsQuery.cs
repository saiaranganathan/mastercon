using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

/// <summary>Ids of every annual statement matching the current search/filters (not just the
/// visible page) - backs the "Select All" button, so Bulk trigger can act on the whole list.</summary>
public sealed record GetAnnualStatementIdsQuery(string? Search, AnnualStatementFilter? Filter = null) : IQuery<IReadOnlyCollection<Guid>>;

public sealed class GetAnnualStatementIdsQueryHandler(IAnnualStatementRepository repository)
    : IQueryHandler<GetAnnualStatementIdsQuery, IReadOnlyCollection<Guid>>
{
    public async Task<Result<IReadOnlyCollection<Guid>>> Handle(GetAnnualStatementIdsQuery request, CancellationToken cancellationToken) =>
        Result.Success(await repository.ListIdsAsync(request.Search, request.Filter, cancellationToken));
}
