using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Infrastructure.Persistence.Configurations;

public sealed class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("Users");
        builder.HasKey(u => u.Id);
        builder.Property(u => u.FullName).HasMaxLength(150).IsRequired();
        builder.Property(u => u.Email).HasMaxLength(256).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique().HasFilter("[IsDeleted] = 0");
        builder.Property(u => u.SupervisorName).HasMaxLength(150);
        builder.Property(u => u.State).HasConversion<string>().HasMaxLength(20);
        builder.Property(u => u.CreatedBy).HasMaxLength(100);
        builder.Property(u => u.UpdatedBy).HasMaxLength(100);
        builder.Property(u => u.DeletedBy).HasMaxLength(100);

        builder.HasMany(u => u.Groups).WithOne().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(User.Groups))!.SetPropertyAccessMode(PropertyAccessMode.Field);

        builder.HasMany(u => u.Roles).WithOne().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(User.Roles))!.SetPropertyAccessMode(PropertyAccessMode.Field);

        builder.HasMany(u => u.Permissions).WithOne().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(User.Permissions))!.SetPropertyAccessMode(PropertyAccessMode.Field);

        builder.HasMany(u => u.SchemeOverrides).WithOne().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(User.SchemeOverrides))!.SetPropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class UserGroupAssignmentConfiguration : IEntityTypeConfiguration<UserGroupAssignment>
{
    public void Configure(EntityTypeBuilder<UserGroupAssignment> builder)
    {
        builder.ToTable("UserGroupAssignments");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.GroupName).HasMaxLength(150);
    }
}

public sealed class UserRoleAssignmentConfiguration : IEntityTypeConfiguration<UserRoleAssignment>
{
    public void Configure(EntityTypeBuilder<UserRoleAssignment> builder)
    {
        builder.ToTable("UserRoleAssignments");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.RoleName).HasMaxLength(150);
    }
}

public sealed class UserPagePermissionConfiguration : IEntityTypeConfiguration<UserPagePermission>
{
    public void Configure(EntityTypeBuilder<UserPagePermission> builder)
    {
        builder.ToTable("UserPagePermissions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PageKey).HasMaxLength(100).IsRequired();
        builder.Property(x => x.Access).HasConversion<string>().HasMaxLength(10);
        builder.HasIndex(x => new { x.UserId, x.PageKey }).IsUnique();
    }
}

public sealed class UserSchemeOverrideConfiguration : IEntityTypeConfiguration<UserSchemeOverride>
{
    public void Configure(EntityTypeBuilder<UserSchemeOverride> builder)
    {
        builder.ToTable("UserSchemeOverrides");
        builder.HasKey(x => x.Id);
        builder.Ignore(x => x.IsExclusion);
        builder.Ignore(x => x.PlanName);
        builder.Property(x => x.SchemeName).HasMaxLength(150);
    }
}
