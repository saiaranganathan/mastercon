using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class CreateUserCommandHandler(
    IUserRepository userRepository,
    IGroupRepository groupRepository,
    IRoleRepository roleRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext,
    IEventBus eventBus,
    ICurrentUserService currentUser) : ICommandHandler<CreateUserCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        var groups = new List<(Guid, string)>();
        var anyGroupAllowsPlanOverride = false;
        var inheritedPlans = new Dictionary<Guid, string>(); // plans the selected groups grant - the only ones that can be switched off per user
        foreach (var groupId in request.GroupIds)
        {
            var group = await groupRepository.GetByIdAsync(groupId, cancellationToken);
            if (group is null) continue;
            // BUS-4563: inactive groups cannot be assigned to a user.
            if (group.State != GroupState.Active)
                return Result.Failure<Guid>(Error.Validation("User.GroupInactive", $"Group '{group.Name}' is inactive and cannot be assigned to a user."));
            groups.Add((group.Id, group.Name));
            anyGroupAllowsPlanOverride |= group.OverridePlanPermissionAtUserLevel;
            foreach (var assignment in group.SchemeAssignments) inheritedPlans[assignment.SchemeId] = assignment.SchemeName;
        }

        // BUS-4534: plan overrides at user level are only allowed when at least one of the user's
        // Groups has "Override Plan Permission at user level" switched on.
        if ((request.SchemeOverrideIds.Count > 0 || request.ExcludedSchemeIds is { Count: > 0 }) && !anyGroupAllowsPlanOverride)
            return Result.Failure<Guid>(Error.Validation("User.PlanOverrideNotAllowed",
                "Plans cannot be overridden at user level - none of the selected Groups allows it."));

        var roles = new List<(Guid, string)>();
        var anyRoleGrantsPermissions = false;
        foreach (var roleId in request.RoleIds)
        {
            var role = await roleRepository.GetByIdAsync(roleId, cancellationToken);
            if (role is null) continue;
            // An inactive role cannot be assigned to a user.
            if (role.State != RoleState.Active)
                return Result.Failure<Guid>(Error.Validation("User.RoleInactive", $"Role '{role.Name}' is inactive and cannot be assigned to a user."));
            roles.Add((role.Id, role.Name));
            anyRoleGrantsPermissions |= role.Permissions.Count > 0;
        }

        // BUS-4565: permissions now come from the selected Roles (plus user-level additions /
        // overrides), so the direct list may legitimately be empty - but the user must end up
        // with at least one permission overall.
        if (request.Permissions.Count == 0 && !anyRoleGrantsPermissions)
            return Result.Failure<Guid>(Error.Validation("User.NoPermissions", "At least one page permission must be selected."));

        // BUS-4569 / BUS-4570: Supervisor is mandatory (except SuperAdmin / SEO) and must be an
        // active user flagged as Supervisor.
        User? supervisorUser = null;
        if (request.SupervisorId is { } supervisorId)
            supervisorUser = await userRepository.GetByIdAsync(supervisorId, cancellationToken);
        if (SupervisorRules.Validate(null, request.SupervisorId, supervisorUser, roles.Select(r => r.Item2)) is { } supervisorError)
            return Result.Failure<Guid>(supervisorError);
        var supervisorName = supervisorUser?.FullName;

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var schemeOverrides = allSchemes
            .Where(s => request.SchemeOverrideIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        // Plans inherited from a Group that were switched off for THIS user only (the Group is not changed).
        var excludedSchemes = (request.ExcludedSchemeIds ?? [])
            .Where(inheritedPlans.ContainsKey)
            .Distinct()
            .Select(id => (id, inheritedPlans[id]))
            .ToList();

        // BUS-4561: leading/trailing spaces are trimmed automatically.
        var user = User.Create(
            request.FullName.Trim(), request.Email.Trim(), request.SupervisorId, supervisorName, request.IsSupervisor, request.State,
            groups, roles, request.Permissions, schemeOverrides, excludedSchemes);

        userRepository.Add(user);
        await dbContext.SaveChangesAsync(cancellationToken);

        await eventBus.PublishAsync(
            new UserCreatedIntegrationEvent(user.Id, user.FullName, user.Email, currentUser.IsAuthenticated ? currentUser.UserId : "system"),
            cancellationToken);

        return Result.Success(user.Id);
    }
}
