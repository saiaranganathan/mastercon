using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Queries;

public sealed class GetUsersQueryHandler(IUserRepository userRepository, IGroupRepository groupRepository, ISchemeReferenceService schemeReferenceService)
    : IQueryHandler<GetUsersQuery, PagedResult<UserListItemDto>>
{
    public async Task<Result<PagedResult<UserListItemDto>>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
    {
        var (users, totalCount) = await userRepository.SearchAsync(request.Paging, cancellationToken);
        var codes = await userRepository.GetUserCodesAsync(cancellationToken);

        // BUS-4561: the list shows Plan IDs (the plan's Code), not names.
        // Plans Paycon no longer lists as active (deleted or deactivated) are hidden - they used
        // to fall back to their stored name and so kept showing under "Assigned plans". If Paycon
        // itself can't be reached (activeSchemes == null) nothing is hidden, so an outage doesn't
        // make every plan disappear.
        var activeSchemes = await schemeReferenceService.TryGetActiveSchemesAsync(cancellationToken);
        var activePlanIds = activeSchemes?.Select(s => s.SchemeId).ToHashSet();
        var planCodes = (activeSchemes ?? [])
            .Where(s => !string.IsNullOrWhiteSpace(s.SchemeCode))
            .GroupBy(s => s.SchemeId)
            .ToDictionary(g => g.Key, g => g.First().SchemeCode!);

        var groupCache = new Dictionary<Guid, Group?>();
        async Task<Group?> LoadGroup(Guid id)
        {
            if (!groupCache.TryGetValue(id, out var group))
                groupCache[id] = group = await groupRepository.GetByIdAsync(id, cancellationToken);
            return group;
        }

        var items = new List<UserListItemDto>();
        foreach (var user in users)
        {
            var plans = new List<(Guid Id, string Label)>();
            var anyGroupAllowsOverride = false;
            foreach (var membership in user.Groups)
            {
                var group = await LoadGroup(membership.GroupId);
                if (group is null) continue;
                anyGroupAllowsOverride |= group.OverridePlanPermissionAtUserLevel;
                plans.AddRange(group.SchemeAssignments.Where(s => (activePlanIds is null || activePlanIds.Contains(s.SchemeId))).Select(s => (s.SchemeId, planCodes.GetValueOrDefault(s.SchemeId) ?? s.SchemeName)));
            }
            // BUS-4550: overrides only count while a Group still allows them - both the plans added
            // for this user and the inherited plans switched off for this user only.
            if (anyGroupAllowsOverride)
            {
                var excludedIds = user.ExcludedSchemes.Select(s => s.SchemeId).ToHashSet();
                plans.RemoveAll(p => excludedIds.Contains(p.Id));
                plans.AddRange(user.AddedSchemes.Where(s => (activePlanIds is null || activePlanIds.Contains(s.SchemeId))).Select(s => (s.SchemeId, planCodes.GetValueOrDefault(s.SchemeId) ?? s.PlanName)));
            }

            var planText = string.Join(", ", plans.DistinctBy(p => p.Id).Select(p => p.Label).DefaultIfEmpty("-"));

            // BUS-4571: show the supervisor's User ID next to the name so same-named users can be told apart.
            string? supervisor = user.SupervisorName;
            if (supervisor is not null && user.SupervisorId is { } supId && codes.TryGetValue(supId, out var supCode))
                supervisor = $"{supervisor} ({supCode})";

            items.Add(new UserListItemDto(
                user.Id, codes.GetValueOrDefault(user.Id, string.Empty), user.FullName, user.Email, planText,
                supervisor, user.State.ToString(), user.IsSupervisor,
                user.CreatedAt, user.CreatedBy, user.UpdatedAt, user.UpdatedBy));
        }

        return Result.Success(new PagedResult<UserListItemDto>(items, totalCount, request.Paging.Page, request.Paging.PageSize));
    }
}
