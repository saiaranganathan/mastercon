using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.UserManagement.Domain;

/// <summary>PR_UM 3.x: a Paycon end user - the heart of the User Management module.</summary>
public sealed class User : AuditableEntity
{
    public string FullName { get; private set; } = default!;
    public string Email { get; private set; } = default!;
    public Guid? SupervisorId { get; private set; }
    public string? SupervisorName { get; private set; }
    public bool IsSupervisor { get; private set; }
    public UserState State { get; private set; } = UserState.Active;

    private readonly List<UserGroupAssignment> _groups = [];
    public IReadOnlyCollection<UserGroupAssignment> Groups => _groups.AsReadOnly();

    private readonly List<UserRoleAssignment> _roles = [];
    public IReadOnlyCollection<UserRoleAssignment> Roles => _roles.AsReadOnly();

    private readonly List<UserPagePermission> _permissions = [];
    public IReadOnlyCollection<UserPagePermission> Permissions => _permissions.AsReadOnly();

    /// <summary>User-level plan changes, only meaningful when a group has "Override Plan Permission" enabled (PR_UM3.1):
    /// rows that add a plan beyond what the user's groups grant, and exclusion rows (see
    /// <see cref="UserSchemeOverride.IsExclusion"/>) that switch off a plan inherited from a group for THIS user only -
    /// the Group itself is never touched.</summary>
    private readonly List<UserSchemeOverride> _schemeOverrides = [];
    public IReadOnlyCollection<UserSchemeOverride> SchemeOverrides => _schemeOverrides.AsReadOnly();

    /// <summary>Plans added for this user on top of the groups' plans.</summary>
    public IEnumerable<UserSchemeOverride> AddedSchemes => _schemeOverrides.Where(s => !s.IsExclusion);

    /// <summary>Plans inherited from a group that this user has had switched off.</summary>
    public IEnumerable<UserSchemeOverride> ExcludedSchemes => _schemeOverrides.Where(s => s.IsExclusion);

    private User() { }

    public static User Create(
        string fullName, string email, Guid? supervisorId, string? supervisorName, bool isSupervisor, UserState state,
        IEnumerable<(Guid GroupId, string GroupName)> groups,
        IEnumerable<(Guid RoleId, string RoleName)> roles,
        IEnumerable<PagePermissionAssignment> permissions,
        IEnumerable<(Guid SchemeId, string SchemeName)> schemeOverrides,
        IEnumerable<(Guid SchemeId, string SchemeName)>? excludedSchemes = null)
    {
        var user = new User
        {
            FullName = fullName,
            Email = email,
            SupervisorId = supervisorId,
            SupervisorName = supervisorName,
            IsSupervisor = isSupervisor,
            State = state
        };

        foreach (var (groupId, groupName) in groups) user._groups.Add(UserGroupAssignment.Create(user.Id, groupId, groupName));
        foreach (var (roleId, roleName) in roles) user._roles.Add(UserRoleAssignment.Create(user.Id, roleId, roleName));
        foreach (var permission in permissions.DistinctBy(p => p.PageKey)) user._permissions.Add(UserPagePermission.Create(user.Id, permission.PageKey, permission.Access));
        foreach (var (schemeId, schemeName) in schemeOverrides) user._schemeOverrides.Add(UserSchemeOverride.Create(user.Id, schemeId, schemeName));
        foreach (var (schemeId, schemeName) in excludedSchemes ?? []) user._schemeOverrides.Add(UserSchemeOverride.CreateExclusion(user.Id, schemeId, schemeName));

        return user;
    }

    public void UpdateDetails(
        Guid? supervisorId, string? supervisorName, bool isSupervisor, UserState state,
        IEnumerable<(Guid GroupId, string GroupName)> groups,
        IEnumerable<(Guid RoleId, string RoleName)> roles,
        IEnumerable<PagePermissionAssignment> permissions,
        IEnumerable<(Guid SchemeId, string SchemeName)> schemeOverrides,
        IEnumerable<(Guid SchemeId, string SchemeName)>? excludedSchemes = null)
    {
        // PR_UM 3.2: Full Name and Email are non-editable once created.
        SupervisorId = supervisorId;
        SupervisorName = supervisorName;
        IsSupervisor = isSupervisor;
        State = state;

        _groups.Clear();
        foreach (var (groupId, groupName) in groups) _groups.Add(UserGroupAssignment.Create(Id, groupId, groupName));

        _roles.Clear();
        foreach (var (roleId, roleName) in roles) _roles.Add(UserRoleAssignment.Create(Id, roleId, roleName));

        _permissions.Clear();
        foreach (var permission in permissions.DistinctBy(p => p.PageKey)) _permissions.Add(UserPagePermission.Create(Id, permission.PageKey, permission.Access));

        _schemeOverrides.Clear();
        foreach (var (schemeId, schemeName) in schemeOverrides) _schemeOverrides.Add(UserSchemeOverride.Create(Id, schemeId, schemeName));
        foreach (var (schemeId, schemeName) in excludedSchemes ?? []) _schemeOverrides.Add(UserSchemeOverride.CreateExclusion(Id, schemeId, schemeName));
    }
}

public sealed class UserGroupAssignment
{
    public Guid Id { get; private set; }
    public Guid UserId { get; private set; }
    public Guid GroupId { get; private set; }
    public string GroupName { get; private set; } = default!;
    private UserGroupAssignment() { }
    public static UserGroupAssignment Create(Guid userId, Guid groupId, string groupName) =>
        new() { Id = Guid.NewGuid(), UserId = userId, GroupId = groupId, GroupName = groupName };
}

public sealed class UserRoleAssignment
{
    public Guid Id { get; private set; }
    public Guid UserId { get; private set; }
    public Guid RoleId { get; private set; }
    public string RoleName { get; private set; } = default!;
    private UserRoleAssignment() { }
    public static UserRoleAssignment Create(Guid userId, Guid roleId, string roleName) =>
        new() { Id = Guid.NewGuid(), UserId = userId, RoleId = roleId, RoleName = roleName };
}

/// <summary>Grants one User View or Edit access to one page/sub-page from the <see cref="PermissionPageCatalog"/>,
/// in addition to whatever the user's Roles already grant.</summary>
public sealed class UserPagePermission
{
    public Guid Id { get; private set; }
    public Guid UserId { get; private set; }
    public string PageKey { get; private set; } = default!;
    public AccessLevel Access { get; private set; }
    private UserPagePermission() { }
    public static UserPagePermission Create(Guid userId, string pageKey, AccessLevel access) =>
        new() { Id = Guid.NewGuid(), UserId = userId, PageKey = pageKey, Access = access };
}

/// <summary>
/// One user-level plan change. A normal row ADDS a plan for the user on top of their groups' plans.
/// An exclusion row switches off a plan the user would otherwise inherit from a group - for this
/// user only. Exclusions live in the same table (marked in <see cref="SchemeName"/>) so no schema
/// change / database rebuild is needed; use <see cref="IsExclusion"/> and <see cref="PlanName"/>
/// instead of reading SchemeName directly.
/// </summary>
public sealed class UserSchemeOverride
{
    private const string ExclusionMarker = "~excl~";

    public Guid Id { get; private set; }
    public Guid UserId { get; private set; }
    public Guid SchemeId { get; private set; }
    public string SchemeName { get; private set; } = default!;

    public bool IsExclusion => SchemeName.StartsWith(ExclusionMarker, StringComparison.Ordinal);
    public string PlanName => IsExclusion ? SchemeName[ExclusionMarker.Length..] : SchemeName;

    private UserSchemeOverride() { }
    public static UserSchemeOverride Create(Guid userId, Guid schemeId, string schemeName) =>
        new() { Id = Guid.NewGuid(), UserId = userId, SchemeId = schemeId, SchemeName = schemeName };
    public static UserSchemeOverride CreateExclusion(Guid userId, Guid schemeId, string schemeName) =>
        new() { Id = Guid.NewGuid(), UserId = userId, SchemeId = schemeId, SchemeName = ExclusionMarker + (schemeName.Length > 140 ? schemeName[..140] : schemeName) };
}
