using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.ExternalServices;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements;

public static class AnnualStatementsModule
{
    public static IServiceCollection AddAnnualStatementsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<AnnualStatementsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=annual_statements.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "ANNUAL"));
        });

        services.AddScoped<IAnnualStatementsDbContext>(sp => sp.GetRequiredService<AnnualStatementsDbContext>());
        services.AddScoped<IAnnualStatementRepository, AnnualStatementRepository>();
        services.AddScoped<IAnnualStatementDataRepository, AnnualStatementDataRepository>();

        // Two separate typed HttpClients, one per external API service - PDF rendering and ACS
        // email are independently deployed *.azurewebsites.net services, not each other's
        // concern, so a failure/timeout talking to one has its own BaseAddress and doesn't get
        // conflated with the other in logs or config. Both base URLs are real Azure hosts with
        // valid CA-issued certificates in every environment (unlike the internal Paycon<->Master
        // call in UserManagementModule), so neither needs the dev-only certificate bypass that
        // SchemeReferenceService's HttpClient does.
        services.AddHttpClient<IPdfGeneratorService, PdfGeneratorService>((sp, client) =>
        {
            var baseUrl = configuration["PdfServiceBaseUrl"];
            if (!string.IsNullOrWhiteSpace(baseUrl)) client.BaseAddress = new Uri(baseUrl);
        });

        services.AddHttpClient<IEmailSenderService, AcsEmailSenderService>((sp, client) =>
        {
            var baseUrl = configuration["AesServiceBaseUrl"];
            if (!string.IsNullOrWhiteSpace(baseUrl)) client.BaseAddress = new Uri(baseUrl);
        });

        return services;
    }

    public static async Task SeedAnnualStatementsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<AnnualStatementsDbContext>();
        await AnnualStatementsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
