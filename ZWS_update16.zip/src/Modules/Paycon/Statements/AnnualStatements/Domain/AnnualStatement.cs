using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

/// <summary>
/// Route: /paycon/statements/annual-statements. Mirrors [ANNUAL].[AnnualStatements] exactly -
/// this table holds only the basic per-employee record the grid/UI works off (who, which
/// employer, due date, whether/when it was sent). The actual statement content (contribution
/// figures, valuation amounts, the pre-rendered PDF/email HTML) lives in the separate
/// [ANNUAL].[AnnualStatement_Data] table - see AnnualStatementData - which Send/Bulk trigger
/// joins in by EmployeeId at send time. Kept as two tables/types on purpose, matching the SQL
/// schema: AnnualStatements is the thing the grid lists and the thing Send/Bulk trigger acts on,
/// AnnualStatementData is the working payload an upstream job populates ahead of a send cycle.
/// </summary>
public enum AnnualStatementSentStatus
{
    Pending,
    Sent,
    Failed
}

public sealed class AnnualStatement : AuditableEntity
{
    public long EmployeeId { get; private set; }
    public long EmployerId { get; private set; }
    public string EmployeeFullName { get; private set; } = default!;
    public DateTime StatementDueDate { get; private set; }
    public DateTime? StatementSentDate { get; private set; }
    public AnnualStatementSentStatus StatementSentStatus { get; private set; } = AnnualStatementSentStatus.Pending;

    private AnnualStatement() { }

    public static AnnualStatement Create(long employeeId, long employerId, string employeeFullName, DateTime statementDueDate) => new()
    {
        EmployeeId = employeeId,
        EmployerId = employerId,
        EmployeeFullName = employeeFullName,
        StatementDueDate = statementDueDate,
        StatementSentStatus = AnnualStatementSentStatus.Pending
    };

    /// <summary>Called once the PDF has been generated and the email has actually been accepted
    /// by the ACS send API - never called speculatively before the send succeeds.</summary>
    public void MarkSent(DateTime sentAtUtc)
    {
        StatementSentStatus = AnnualStatementSentStatus.Sent;
        StatementSentDate = sentAtUtc;
    }

    /// <summary>PDF generation or the email send failed for this employee - the row is left in a
    /// retryable state (a later Send/Bulk trigger click will pick it up again, since only
    /// already-Sent rows are skipped - see SendAnnualStatementsCommandHandler).</summary>
    public void MarkFailed() => StatementSentStatus = AnnualStatementSentStatus.Failed;
}
