namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

/// <summary>
/// Read mapping onto [ANNUAL].[AnnualStatement_Data] - the working table an upstream
/// valuation/ETL job populates with the current cycle's per-employee figures and the already-
/// rendered PdfContent/EmailContent HTML for that employee's statement. This table has no
/// declared primary key in SQL (EmpID is not unique/PK-constrained there), so it's mapped as an
/// EF Core keyless entity type - see AnnualStatementsDbContext.OnModelCreating. It's also marked
/// ExcludeFromMigrations there: this table is owned/populated by that upstream job, not by this
/// app, so `dotnet ef migrations add` must never try to create or alter it.
///
/// Send/Bulk trigger only ever reads this table (by EmpID, joined against the selected
/// AnnualStatements.EmployeeId rows) and, on a successful send, stamps its own sentAt column via
/// a direct ExecuteUpdateAsync keyed on EmpID (see IAnnualStatementsDbContext.MarkDataSentAsync) -
/// never through the change tracker, since a keyless entity type can't be tracked for updates.
///
/// Only the columns Send/Bulk trigger actually needs are mapped here (join key, recipient
/// addresses, and the two pre-rendered content blobs). Every other column from the CREATE TABLE
/// (valuation amounts, dividend/rewards figures, state/stateChange, etc.) belongs to whatever
/// renders EmailContent/PdfContent in the first place - not to this send flow - so they're
/// intentionally left unmapped rather than carried around unused.
/// </summary>
public sealed class AnnualStatementData
{
    public long EmpID { get; private set; }
    public DateTime? sentAt { get; private set; }
    public string? EmpEmail { get; private set; }
    public string? EmpSecEmail { get; private set; }

    /// <summary>The per-employee HTML email body - goes into the ACS PayconSendEmail request's
    /// "templateContent" field, not any field named "body"/"htmlContent" (the sample payload in
    /// the ACS API doc omits it, but the real request does accept it under that name).</summary>
    public string? EmailContent { get; private set; }

    /// <summary>The per-employee HTML the PDF conversion API renders into the attached PDF - goes
    /// into the ConverterPDFBytes request's "htmlContent" field.</summary>
    public string? PdfContent { get; private set; }

    private AnnualStatementData() { }
}
