using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Presentation.Controllers;

/// <summary>Route: /paycon/statements/annual-statements.</summary>
[ApiController]
[Route("api/paycon/statements/annual-statements")]
[RequirePermission("statements.annual-statements")]
public sealed class AnnualStatementsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAnnualStatements([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetAnnualStatementsQuery(paging), cancellationToken)).ToActionResult();

    /// <summary>Backs both the per-row "Send" button (one id in the body) and the toolbar "Bulk
    /// trigger" button (every checked id) - see SendAnnualStatementsCommand.</summary>
    [HttpPost("send")]
    [RequirePermission("statements.annual-statements", PermissionAccess.Edit)]
    public async Task<IActionResult> Send([FromBody] SendAnnualStatementsCommand command, CancellationToken cancellationToken) =>
        (await sender.Send(command, cancellationToken)).ToActionResult();
}
