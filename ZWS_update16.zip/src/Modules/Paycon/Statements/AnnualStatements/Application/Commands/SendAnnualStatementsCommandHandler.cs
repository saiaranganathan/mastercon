using Microsoft.Extensions.Logging;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;

/// <summary>
/// For every selected AnnualStatements row not already Sent: looks up its matching
/// [ANNUAL].[AnnualStatement_Data] row by EmployeeId, calls the PDF conversion API against
/// PdfContent, then the ACS send-email API with EmailContent as the body and the generated PDF
/// as the attachment, and marks the row Sent (or Failed) accordingly.
///
/// Each employee is fully independent - one employee's PDF/email failure must not abort the rest
/// of a bulk send, so the per-employee work is wrapped in its own try/catch, and SaveChangesAsync
/// is called once per employee rather than once at the end of the loop. Saving per-employee
/// matters for correctness, not just crash-safety: the email send is a real side effect with no
/// way to undo it, so as soon as ACS has accepted employee N's email, that row's Sent status must
/// be durable before employee N+1 is even attempted - otherwise a crash (or just a slow batch a
/// user navigates away from) after employee N's email went out, but before the DB write landed,
/// would leave that row Pending/Failed and a later retry would email that employee again.
/// </summary>
public sealed class SendAnnualStatementsCommandHandler(
    IAnnualStatementRepository repository,
    IAnnualStatementDataRepository dataRepository,
    IAnnualStatementsDbContext dbContext,
    IPdfGeneratorService pdfGenerator,
    IEmailSenderService emailSender,
    ILogger<SendAnnualStatementsCommandHandler> logger)
    : ICommandHandler<SendAnnualStatementsCommand, SendAnnualStatementsResultDto>
{
    public async Task<Result<SendAnnualStatementsResultDto>> Handle(SendAnnualStatementsCommand request, CancellationToken cancellationToken)
    {
        var statements = await repository.GetByIdsAsync(request.StatementIds, cancellationToken);
        if (statements.Count == 0)
            return Result.Failure<SendAnnualStatementsResultDto>(Error.NotFound("AnnualStatements.NotFound", "None of the selected statements were found."));

        // Already-sent rows are left untouched (not re-sent, not treated as an error) - agreed
        // behavior for both the single "Send" button and "Bulk trigger".
        var alreadySent = statements.Where(s => s.StatementSentStatus == AnnualStatementSentStatus.Sent).ToList();
        var toSend = statements.Where(s => s.StatementSentStatus != AnnualStatementSentStatus.Sent).ToList();

        var dataByEmployeeId = (await dataRepository.GetByEmployeeIdsAsync(toSend.Select(s => s.EmployeeId).Distinct().ToList(), cancellationToken))
            .ToDictionary(d => d.EmpID);

        var outcomes = new List<AnnualStatementSendOutcomeDto>(statements.Count);
        foreach (var statement in alreadySent)
            outcomes.Add(new AnnualStatementSendOutcomeDto(statement.Id, statement.EmployeeId, statement.EmployeeFullName, "Skipped", "Already sent."));

        var sentCount = 0;
        var failedCount = 0;

        foreach (var statement in toSend)
        {
            if (!dataByEmployeeId.TryGetValue(statement.EmployeeId, out var data) || string.IsNullOrWhiteSpace(data.EmpEmail))
            {
                statement.MarkFailed();
                await dbContext.SaveChangesAsync(cancellationToken);
                failedCount++;
                outcomes.Add(new AnnualStatementSendOutcomeDto(statement.Id, statement.EmployeeId, statement.EmployeeFullName, "Failed",
                    "No annual statement data (or no email address) found for this employee."));
                logger.LogWarning("Annual statement {StatementId}: no AnnualStatement_Data row / email address for employee {EmployeeId}.",
                    statement.Id, statement.EmployeeId);
                continue;
            }

            try
            {
                var fileName = $"{statement.EmployeeFullName}-annual-statement-{statement.StatementDueDate:yyyy}.pdf";
                var pdfBytes = await pdfGenerator.ConvertToPdfBytesAsync(fileName, data.PdfContent ?? string.Empty, cancellationToken);

                await emailSender.SendAsync(new AnnualStatementEmailRequest(
                    Subject: $"Your {statement.StatementDueDate:yyyy} Annual Benefit Statement",
                    ToAddress: new EmailAddress(data.EmpEmail!, statement.EmployeeFullName),
                    HtmlBody: data.EmailContent ?? string.Empty,
                    AttachmentBytes: pdfBytes,
                    AttachmentFileNameWithExt: fileName,
                    CcAddress: string.IsNullOrWhiteSpace(data.EmpSecEmail) ? null : new EmailAddress(data.EmpSecEmail!)), cancellationToken);

                var sentAtUtc = DateTime.UtcNow;
                statement.MarkSent(sentAtUtc);
                await dbContext.SaveChangesAsync(cancellationToken);
                await dbContext.MarkDataSentAsync(statement.EmployeeId, sentAtUtc, cancellationToken);

                sentCount++;
                outcomes.Add(new AnnualStatementSendOutcomeDto(statement.Id, statement.EmployeeId, statement.EmployeeFullName, "Sent", null));
            }
            catch (Exception ex)
            {
                statement.MarkFailed();
                await dbContext.SaveChangesAsync(cancellationToken);
                failedCount++;
                outcomes.Add(new AnnualStatementSendOutcomeDto(statement.Id, statement.EmployeeId, statement.EmployeeFullName, "Failed", ex.Message));
                logger.LogError(ex, "Failed to send annual statement {StatementId} for employee {EmployeeId}.", statement.Id, statement.EmployeeId);
            }
        }

        return Result.Success(new SendAnnualStatementsResultDto(sentCount, alreadySent.Count, failedCount, outcomes));
    }
}
