using FluentValidation;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;

public sealed class SendAnnualStatementsCommandValidator : AbstractValidator<SendAnnualStatementsCommand>
{
    public SendAnnualStatementsCommandValidator()
    {
        RuleFor(x => x.StatementIds).NotEmpty().WithMessage("Select at least one employee to send.");
        RuleFor(x => x.StatementIds).Must(ids => ids.Distinct().Count() == ids.Count)
            .When(x => x.StatementIds.Count > 0)
            .WithMessage("The same employee was selected more than once.");
    }
}
