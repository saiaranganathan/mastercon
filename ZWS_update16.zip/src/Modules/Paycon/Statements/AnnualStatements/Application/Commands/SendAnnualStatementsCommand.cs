using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;

/// <summary>
/// Backs both the per-row "Send" button (a single id) and the toolbar "Bulk trigger" button
/// (every checked id) - same command, same handler, just a different-sized StatementIds list, so
/// there's exactly one code path that talks to the PDF/ACS services and updates status.
/// </summary>
public sealed record SendAnnualStatementsCommand(IReadOnlyCollection<Guid> StatementIds) : ICommand<SendAnnualStatementsResultDto>;
