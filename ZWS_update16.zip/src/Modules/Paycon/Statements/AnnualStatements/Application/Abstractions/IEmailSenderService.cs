namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

/// <summary>One recipient/CC entry for the ACS send email request - mirrors PayconSendEmail's
/// { address, displayName } shape for both toAddresses and ccAddresses entries.</summary>
public sealed record EmailAddress(string Address, string? DisplayName = null);

/// <summary>
/// Everything AcsEmailSenderService needs to build one POST /api/AES/PayconSendEmail call.
/// AttachmentBytes is passed as byte[] here and base64-encoded at the HTTP boundary (ACS's
/// "attachment" field is a base64 string) so the Application layer never has to think about wire
/// encoding - only Infrastructure/ExternalServices/AcsEmailSenderService does.
/// </summary>
public sealed record AnnualStatementEmailRequest(
    string Subject,
    EmailAddress ToAddress,
    string HtmlBody,
    byte[] AttachmentBytes,
    string AttachmentFileNameWithExt,
    EmailAddress? CcAddress = null);

/// <summary>
/// Wraps the separate ACS email-trigger API service (POST /api/AES/PayconSendEmail). Implemented
/// by Infrastructure/ExternalServices/AcsEmailSenderService. Throws on any non-success response -
/// SendAnnualStatementsCommandHandler catches per-employee so one failure doesn't abort the rest
/// of a bulk send.
/// </summary>
public interface IEmailSenderService
{
    Task SendAsync(AnnualStatementEmailRequest request, CancellationToken cancellationToken);
}
