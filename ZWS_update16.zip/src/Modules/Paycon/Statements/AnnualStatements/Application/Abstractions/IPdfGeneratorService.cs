namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

/// <summary>
/// Wraps the separate PDF-rendering API service (POST /api/PDF/ConverterPDFBytes) - takes the
/// per-employee HTML already sitting in AnnualStatementData.PdfContent and returns the rendered
/// PDF as raw bytes, ready to attach to the ACS send email request. Implemented by
/// Infrastructure/ExternalServices/PdfGeneratorService.
/// </summary>
public interface IPdfGeneratorService
{
    Task<byte[]> ConvertToPdfBytesAsync(string fileName, string htmlContent, CancellationToken cancellationToken);
}
