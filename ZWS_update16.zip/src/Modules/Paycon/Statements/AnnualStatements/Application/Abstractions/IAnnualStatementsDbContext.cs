using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

public interface IAnnualStatementsDbContext : IAppDbContext
{
    /// <summary>
    /// Stamps [ANNUAL].[AnnualStatement_Data].sentAt for a single employee via a direct SQL
    /// UPDATE (EF Core's ExecuteUpdateAsync), keyed on EmpID - AnnualStatementData is mapped as a
    /// keyless entity type (see its own doc comment) since the real table has no declared primary
    /// key, so it can never be loaded into the change tracker and saved the normal way. Called
    /// once per employee, right after that employee's email has actually been sent - see
    /// SendAnnualStatementsCommandHandler.
    /// </summary>
    Task MarkDataSentAsync(long employeeId, DateTime sentAtUtc, CancellationToken cancellationToken);
}
