namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

/// <summary>Per-employee outcome of one Send/Bulk trigger call - lets the UI show which rows
/// actually went out versus which failed (and why) instead of one opaque success/failure for
/// the whole batch.</summary>
public sealed record AnnualStatementSendOutcomeDto(Guid StatementId, long EmployeeId, string EmployeeFullName, string Status, string? ErrorMessage);

/// <summary>
/// SentCount/SkippedCount/FailedCount always add up to the number of selected IDs that matched an
/// existing row (see IAnnualStatementRepository.GetByIdsAsync - a stale/deleted id is simply
/// absent, not counted as failed). SkippedCount counts rows that were already
/// StatementSentStatus = Sent - per the agreed behavior, Send/Bulk trigger silently leaves those
/// alone rather than re-sending or erroring.
/// </summary>
public sealed record SendAnnualStatementsResultDto(
    int SentCount,
    int SkippedCount,
    int FailedCount,
    IReadOnlyCollection<AnnualStatementSendOutcomeDto> Outcomes);
