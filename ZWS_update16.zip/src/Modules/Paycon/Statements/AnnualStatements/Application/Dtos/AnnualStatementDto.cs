namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

public sealed record AnnualStatementDto(
    Guid Id,
    long EmployeeId,
    long EmployerId,
    string EmployeeFullName,
    DateTime StatementDueDate,
    DateTime? StatementSentDate,
    string StatementSentStatus);
