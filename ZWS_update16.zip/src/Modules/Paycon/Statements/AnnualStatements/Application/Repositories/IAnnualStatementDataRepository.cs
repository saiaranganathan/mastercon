using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

/// <summary>Read access onto [ANNUAL].[AnnualStatement_Data] - separate from
/// IAnnualStatementRepository because it's a different table with no primary key of its own
/// (see AnnualStatementData), not a second repository for the same aggregate.</summary>
public interface IAnnualStatementDataRepository
{
    Task<IReadOnlyCollection<AnnualStatementData>> GetByEmployeeIdsAsync(IReadOnlyCollection<long> employeeIds, CancellationToken cancellationToken);
}
