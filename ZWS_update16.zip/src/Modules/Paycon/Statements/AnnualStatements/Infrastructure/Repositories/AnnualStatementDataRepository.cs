using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

public sealed class AnnualStatementDataRepository(AnnualStatementsDbContext context) : IAnnualStatementDataRepository
{
    public async Task<IReadOnlyCollection<AnnualStatementData>> GetByEmployeeIdsAsync(IReadOnlyCollection<long> employeeIds, CancellationToken cancellationToken)
    {
        if (employeeIds.Count == 0) return [];
        return await context.AnnualStatementData.Where(d => employeeIds.Contains(d.EmpID)).ToListAsync(cancellationToken);
    }
}
