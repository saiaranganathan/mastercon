using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

public sealed class AnnualStatementsDbContext(DbContextOptions<AnnualStatementsDbContext> options)
    : DbContext(options), IAnnualStatementsDbContext
{
    public DbSet<AnnualStatement> AnnualStatements => Set<AnnualStatement>();
    public DbSet<AnnualStatementData> AnnualStatementData => Set<AnnualStatementData>();

    public Task MarkDataSentAsync(long employeeId, DateTime sentAtUtc, CancellationToken cancellationToken) =>
        AnnualStatementData
            .Where(d => d.EmpID == employeeId)
            .ExecuteUpdateAsync(setters => setters.SetProperty(d => d.sentAt, sentAtUtc), cancellationToken);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Real SQL Server schema is [ANNUAL] (was "paycon_annual_statements" for this module's
        // earlier placeholder tables, which never matched any real schema - this module now maps
        // onto the actual [ANNUAL].[AnnualStatements] / [ANNUAL].[AnnualStatement_Data] tables).
        modelBuilder.HasDefaultSchema("ANNUAL");

        modelBuilder.Entity<AnnualStatement>(b =>
        {
            b.ToTable("AnnualStatements");
            b.HasKey(x => x.Id);
            b.Property(x => x.EmployeeFullName).HasMaxLength(150).IsRequired();

            // The real columns are SQL [datetime], not the [datetime2] EF's SqlServer provider
            // would map DateTime/DateTime? to by convention - explicit here so a generated
            // migration matches the existing table instead of trying to widen its precision.
            b.Property(x => x.StatementDueDate).HasColumnType("datetime");
            b.Property(x => x.StatementSentDate).HasColumnType("datetime");

            // Stored as the plain enum name ("Pending"/"Sent"/"Failed") in the nvarchar(50)
            // StatementSentStatus column - readable directly in SQL/Swagger without a lookup
            // table, and 50 chars leaves headroom for a longer status name later.
            b.Property(x => x.StatementSentStatus).HasConversion<string>().HasMaxLength(50).IsRequired();

            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });

        modelBuilder.Entity<AnnualStatementData>(b =>
        {
            // Keyless: [ANNUAL].[AnnualStatement_Data] has no declared primary key in SQL (see
            // the CREATE TABLE the UI/backend requirement was written against), and this app only
            // ever reads it by EmpID or updates it via a raw ExecuteUpdateAsync - never tracks an
            // instance for a normal SaveChangesAsync. ExcludeFromMigrations because this table is
            // owned and populated by the upstream valuation/ETL job, not by this module - `dotnet
            // ef migrations add` must never try to create, alter, or drop it.
            b.HasNoKey();
            b.ToTable("AnnualStatement_Data", t => t.ExcludeFromMigrations());

            b.Property(x => x.EmpID).HasColumnName("EmpID");
            b.Property(x => x.sentAt).HasColumnName("sentAt").HasColumnType("datetime");
            b.Property(x => x.EmpEmail).HasColumnName("EmpEmail").HasMaxLength(255);
            b.Property(x => x.EmpSecEmail).HasColumnName("EmpSecEmail").HasMaxLength(255);
            b.Property(x => x.EmailContent).HasColumnName("EmailContent");
            b.Property(x => x.PdfContent).HasColumnName("PdfContent");
        });
    }
}
