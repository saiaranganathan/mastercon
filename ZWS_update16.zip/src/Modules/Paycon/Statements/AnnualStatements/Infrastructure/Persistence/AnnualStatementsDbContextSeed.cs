using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

public static class AnnualStatementsDbContextSeed
{
    public static async Task SeedAsync(AnnualStatementsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.AnnualStatements.AnyAsync(cancellationToken)) return;

        var dueDate = new DateTime(DateTime.UtcNow.Year, 12, 31);

        context.AnnualStatements.AddRange(
            AnnualStatement.Create(1001, 501, "Adriene Watson", dueDate),
            AnnualStatement.Create(1002, 501, "John Carilo", dueDate),
            AnnualStatement.Create(1003, 502, "Robert Bacins", dueDate));

        await context.SaveChangesAsync(cancellationToken);

        // AnnualStatement_Data is normally populated by an upstream valuation/ETL job, not by
        // this app - EnsureCreatedAsync above does create the table locally (dev-only SQLite/
        // LocalDB path; ExcludeFromMigrations only affects real `dotnet ef migrations`), so a
        // small amount of matching dev data is seeded here purely so Send/Bulk trigger has
        // something to work against locally. Never runs against the real [ANNUAL] schema, where
        // this table already exists with real data before this module ever seeds anything. Only
        // inserts the columns AnnualStatementData actually maps (see its own doc comment) - the
        // locally-created dev table has no other columns to insert into.
        if (!await context.AnnualStatementData.AnyAsync(cancellationToken))
        {
            await context.Database.ExecuteSqlRawAsync(
                """
                INSERT INTO AnnualStatement_Data (EmpID, EmpEmail, EmpSecEmail, EmailContent, PdfContent)
                VALUES
                    (1001, 'adriene.watson@example.com', NULL, '<p>Dear Adriene, your annual statement is attached.</p>', '<html><body><h1>Annual Statement</h1></body></html>'),
                    (1002, 'john.carilo@example.com', NULL, '<p>Dear John, your annual statement is attached.</p>', '<html><body><h1>Annual Statement</h1></body></html>'),
                    (1003, 'robert.bacins@example.com', NULL, '<p>Dear Robert, your annual statement is attached.</p>', '<html><body><h1>Annual Statement</h1></body></html>')
                """, cancellationToken);
        }
    }
}
