using System.Net.Http.Json;
using System.Text.Json;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.ExternalServices;

/// <summary>
/// Calls the separate PDF-rendering API service: POST {PdfServiceBaseUrl}/api/PDF/ConverterPDFBytes.
/// The HttpClient's BaseAddress is set from "PdfServiceBaseUrl" in AnnualStatementsModule.
/// </summary>
public sealed class PdfGeneratorService(HttpClient http) : IPdfGeneratorService
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<byte[]> ConvertToPdfBytesAsync(string fileName, string htmlContent, CancellationToken cancellationToken)
    {
        var response = await http.PostAsJsonAsync("api/PDF/ConverterPDFBytes", new PdfRequest(fileName, 0, 0, 0, 0, htmlContent), JsonOptions, cancellationToken);
        response.EnsureSuccessStatusCode();

        // The API doc says the response is "byte[]" but doesn't say which wire shape that takes -
        // a raw application/octet-stream body (the byte[] as-is), or a JSON response where
        // System.Text.Json's default byte[] serialization (a base64 string) applies. Handling
        // both here means this doesn't silently corrupt the PDF attachment if the real service
        // turns out to use the JSON shape rather than a raw stream.
        var contentType = response.Content.Headers.ContentType?.MediaType;
        if (contentType is not null && contentType.Contains("json", StringComparison.OrdinalIgnoreCase))
        {
            var base64 = await response.Content.ReadFromJsonAsync<string>(JsonOptions, cancellationToken);
            if (string.IsNullOrEmpty(base64))
                throw new InvalidOperationException("PDF conversion API returned an empty response.");
            return Convert.FromBase64String(base64);
        }

        return await response.Content.ReadAsByteArrayAsync(cancellationToken);
    }

    private sealed record PdfRequest(string FileName, int MarginLeft, int MarginRight, int MarginTop, int MarginBottom, string HtmlContent);
}
