using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.ExternalServices;

/// <summary>
/// Calls the separate ACS email-trigger API service: POST {AesServiceBaseUrl}/api/AES/PayconSendEmail.
/// The HttpClient's BaseAddress is set from "AesServiceBaseUrl" in AnnualStatementsModule. The
/// sender identity is a fixed app-level setting (AnnualStatementsEmail:SenderAddress/
/// SenderDisplayName), not something Send/Bulk trigger passes per call - it's the same "From" for
/// every annual statement email this module ever sends.
/// </summary>
public sealed class AcsEmailSenderService(HttpClient http, IConfiguration configuration) : IEmailSenderService
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task SendAsync(AnnualStatementEmailRequest request, CancellationToken cancellationToken)
    {
        var senderAddress = configuration["AnnualStatementsEmail:SenderAddress"] ?? string.Empty;
        var senderDisplayName = configuration["AnnualStatementsEmail:SenderDisplayName"];

        var wireRequest = new AcsSendEmailRequest(
            SenderEmail: new AcsAddress(senderAddress, senderDisplayName),
            Subject: request.Subject,
            ToAddresses: [new AcsAddress(request.ToAddress.Address, request.ToAddress.DisplayName)],
            Attachment: Convert.ToBase64String(request.AttachmentBytes),
            AttachmentFileNameWithExt: request.AttachmentFileNameWithExt,
            CcAddresses: request.CcAddress is null ? [] : [new AcsAddress(request.CcAddress.Address, request.CcAddress.DisplayName)],
            // "templateContent" carries the per-employee HTML body (AnnualStatementData.EmailContent) -
            // the field name confirmed against the real ACS API (it isn't in the trimmed sample the
            // PayconSendEmail doc shows, which only lists subject/addresses/attachment).
            TemplateContent: request.HtmlBody);

        var response = await http.PostAsJsonAsync("api/AES/PayconSendEmail", wireRequest, JsonOptions, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    private sealed record AcsAddress(string Address, string? DisplayName);

    private sealed record AcsSendEmailRequest(
        AcsAddress SenderEmail,
        string Subject,
        List<AcsAddress> ToAddresses,
        string Attachment,
        string AttachmentFileNameWithExt,
        List<AcsAddress> CcAddresses,
        string TemplateContent);
}
