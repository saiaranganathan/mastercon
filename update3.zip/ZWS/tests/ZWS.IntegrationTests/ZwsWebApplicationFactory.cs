using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ZWS.IntegrationTests;

/// <summary>
/// Boots the real ZWS.Host pipeline (Program.cs) against an in-memory
/// TestServer. Every module's DbContext falls back to its own local
/// SQLite *.dev.db file (see each Module.cs) since connection strings stay
/// blank here, exactly as it would running `dotnet run` locally without
/// Azure SQL configured. RabbitMQ and Redis are explicitly turned off so
/// the suite never depends on infrastructure that isn't running in CI.
/// </summary>
public sealed class ZwsWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");

        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["RabbitMQ:Enabled"] = "false",
                ["RabbitMQ:Host"] = string.Empty, // blank => AddZwsHealthChecks skips the RabbitMQ readiness check entirely
                ["Redis:ConnectionString"] = string.Empty
            });
        });

        // AddZwsJwtAuthentication now sets a RequireAuthenticatedUser() fallback policy on every
        // endpoint that isn't explicitly [AllowAnonymous] (real JWT-bearer auth previously had
        // nothing actually enforcing it - every endpoint was reachable anonymously regardless of
        // whether a token was sent). Swap in TestAuthHandler as the default scheme so this suite
        // keeps exercising real endpoint behavior instead of getting 401 on everything.
        builder.ConfigureTestServices(services =>
        {
            services.AddAuthentication(TestAuthHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, TestAuthHandler>(TestAuthHandler.SchemeName, _ => { });

            services.PostConfigure<AuthenticationOptions>(options =>
            {
                options.DefaultScheme = TestAuthHandler.SchemeName;
                options.DefaultAuthenticateScheme = TestAuthHandler.SchemeName;
                options.DefaultChallengeScheme = TestAuthHandler.SchemeName;
            });
        });
    }
}
