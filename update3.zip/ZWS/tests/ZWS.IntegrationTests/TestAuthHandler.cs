using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ZWS.BuildingBlocks.Auth;

namespace ZWS.IntegrationTests;

/// <summary>
/// Registered by ZwsWebApplicationFactory as the default authentication scheme, replacing real
/// JwtBearer validation for the test host only. AddZwsJwtAuthentication now sets a
/// RequireAuthenticatedUser() fallback policy on every endpoint that doesn't opt out with
/// [AllowAnonymous] (see ZwsJwtAuthenticationExtensions) - without this, every request this
/// suite makes would come back 401 instead of exercising the actual endpoint. Every request is
/// authenticated as one fixed, fully-permissioned test user (Edit on every page key Paycon's own
/// nav seed - see PayconNavigationDbContextSeed - actually grants), so existing assertions about
/// endpoint behavior and nav visibility keep working exactly as before real auth was wired in.
/// </summary>
public sealed class TestAuthHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "Test";

    /// <summary>Every RequiredPermission key Paycon's own navigation seed currently grants
    /// against - kept in sync with PayconNavigationDbContextSeed.cs. This project intentionally
    /// has no reference to UserManagement's PermissionPageCatalog (UserManagement now lives in
    /// Master, a different app service - see ZWS.Host.csproj), so the set is duplicated here
    /// rather than shared.</summary>
    private static readonly string[] GrantedPageKeys =
    [
        "dashboard",
        "reconciliation", "reconciliation.payments-in", "reconciliation.payments-out",
        "insights",
        "statements", "statements.exit-statements", "statements.annual-statements",
        "settings", "settings.scheme-management", "settings.insight-management"
    ];

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, "test-user"),
            new(JwtRegisteredClaimNames.Name, "Test User"),
            new(JwtRegisteredClaimNames.Email, "test-user@zws.local")
        };
        // Edit is granted directly (rather than expanding to both View and Edit claims here) -
        // ClaimsPrincipalCurrentUserService.HasPermission does an exact string match per call,
        // so both forms must be present for a key to satisfy both a ":View" and an ":Edit" check.
        claims.AddRange(GrantedPageKeys.SelectMany(key => new[]
        {
            new Claim(JwtTokenIssuer.PermissionClaimType, $"{key}:View"),
            new Claim(JwtTokenIssuer.PermissionClaimType, $"{key}:Edit")
        }));

        var identity = new ClaimsIdentity(claims, SchemeName);
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, SchemeName);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}
