using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Auth.Application.Login;
using ZWS.Modules.UserManagement.Application.Auth;

namespace ZWS.Modules.Auth.Presentation.Controllers;

/// <summary>
/// Master-only. Dev-mode login (no password) - see LoginCommand.
/// [AllowAnonymous] is required here now that AddZwsJwtAuthentication sets a
/// RequireAuthenticatedUser() fallback policy for every other endpoint in every app - otherwise
/// login itself would need a token to reach the endpoint that hands one out.
/// </summary>
[ApiController]
[Route("api/auth")]
[AllowAnonymous]
public sealed class AuthController(ISender sender) : ControllerBase
{
    /// <summary>Populates the login picker on Master.Web.</summary>
    [HttpGet("users")]
    public async Task<IActionResult> GetLoginCandidates(CancellationToken cancellationToken) =>
        (await sender.Send(new GetLoginCandidatesQuery(), cancellationToken)).ToActionResult();

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new LoginCommand(request.Email), cancellationToken)).ToActionResult();
}

public sealed record LoginRequest(string Email);
