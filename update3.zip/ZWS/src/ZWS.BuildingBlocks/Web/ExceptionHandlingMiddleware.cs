using System.Net;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ZWS.BuildingBlocks.Web;

/// <summary>
/// Central exception handler (requirement 32). Every unhandled exception is
/// logged with the request's TraceId and converted into a consistent ApiError
/// payload; stack traces are never returned outside Development.
/// </summary>
public sealed class ExceptionHandlingMiddleware(
    RequestDelegate next,
    ILogger<ExceptionHandlingMiddleware> logger,
    IHostEnvironment environment)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled exception. TraceId: {TraceId}", context.TraceIdentifier);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            // DbUpdateConcurrencyException's own Message never says which entity/table it
            // actually failed on ("expected to affect 1 row(s), but actually affected 0") - only
            // ex.Entries carries that. Surfacing it here (Development only, same guard as the
            // rest of this payload) turns "it threw a concurrency exception somewhere in
            // SaveChanges" into an immediate, concrete answer instead of a guess.
            var message = environment.IsDevelopment()
                ? ex is DbUpdateConcurrencyException concurrencyEx
                    ? $"{ex.Message} Entities involved: {string.Join(", ", concurrencyEx.Entries.Select(e => $"{e.Entity.GetType().Name} (state={e.State})"))}"
                    : ex.Message
                : "An unexpected error occurred.";

            var error = new ApiError
            {
                Status = context.Response.StatusCode,
                Message = message,
                TraceId = context.TraceIdentifier
            };

            await context.Response.WriteAsync(JsonSerializer.Serialize(error, new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        }
    }
}
