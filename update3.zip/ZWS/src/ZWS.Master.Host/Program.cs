using System.Text.Json;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using ZWS.BuildingBlocks.Application;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Caching;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.ApplicationHub;
using ZWS.Modules.Auth;
using ZWS.Modules.UserManagement;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------
// Cross-cutting / shared kernel
// ---------------------------------------------------------------------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<AuditableEntitySaveChangesInterceptor>();

builder.Services.AddZwsRedisCache(builder.Configuration);
builder.Services.AddZwsRabbitMq(builder.Configuration);

// JWT: Master both issues (AddZwsJwtIssuer, for AuthController's login) and validates
// (AddZwsJwtAuthentication, registers the real ICurrentUserService) - it's the one app that
// needs both halves of ZWS.BuildingBlocks.Auth. This replaces the old manual
// `AddScoped<ICurrentUserService, SystemCurrentUserService>()` + TODO(auth) comment.
builder.Services.AddZwsJwtAuthentication(builder.Configuration);
builder.Services.AddZwsJwtIssuer(builder.Configuration);

builder.Services.AddControllers()
    // Every module's Presentation/Controllers live in that module's own assembly (never in
    // ZWS.Master.Host), so each one is registered explicitly as an MVC application part.
    .AddApplicationPart(typeof(ZWS.Modules.ApplicationHub.Presentation.Controllers.ApplicationsController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.UserManagement.Presentation.Controllers.UsersController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Auth.Presentation.Controllers.AuthController).Assembly);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "ZWS Master API",
        Version = "v1",
        Description = "The Master app: ZWS Application Hub landing page + User/Group/Role/Permission management + dev-mode login/JWT issuance."
    });
});

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
    ?? ["https://localhost:5111", "http://localhost:5110"];

builder.Services.AddCors(options =>
{
    options.AddPolicy("ZwsMasterWebClient", policy => policy
        .WithOrigins(allowedOrigins)
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowCredentials());
});

// ---------------------------------------------------------------------
// MediatR + FluentValidation across every module's assembly
// ---------------------------------------------------------------------
builder.Services.AddZwsApplicationLayer(
    typeof(ApplicationHubModule).Assembly,
    typeof(UserManagementModule).Assembly,
    typeof(AuthModule).Assembly);

// ---------------------------------------------------------------------
// Modules (one DbContext per module, wired here only)
// ---------------------------------------------------------------------
builder.Services.AddApplicationHubModule(builder.Configuration);
builder.Services.AddUserManagementModule(builder.Configuration);
builder.Services.AddAuthModule();

builder.Services.AddZwsHealthChecks(builder.Configuration, primaryConnectionStringName: "ApplicationHub");

var app = builder.Build();

// ---------------------------------------------------------------------
// Pipeline
// ---------------------------------------------------------------------
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v1/swagger.json", "ZWS Master API v1"));
}

app.UseCors("ZwsMasterWebClient");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

var healthResponseWriter = new Func<HttpContext, HealthReport, Task>((context, report) =>
{
    context.Response.ContentType = "application/json";
    var payload = new
    {
        status = report.Status.ToString(),
        totalDurationMs = report.TotalDuration.TotalMilliseconds,
        checks = report.Entries.Select(e => new
        {
            name = e.Key,
            status = e.Value.Status.ToString(),
            description = e.Value.Description,
            durationMs = e.Value.Duration.TotalMilliseconds
        })
    };
    return context.Response.WriteAsync(JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }));
});

// Liveness: is the process up at all. Anonymous on purpose - an orchestrator probing this
// never carries a JWT, and AddZwsJwtAuthentication's fallback policy now requires one by default
// on every other endpoint.
app.MapHealthChecks("/health", new HealthCheckOptions
{
    Predicate = _ => false,
    ResponseWriter = healthResponseWriter
}).AllowAnonymous();

// Readiness: SQL / Redis / RabbitMQ actually reachable. Anonymous for the same reason as
// /health above.
app.MapHealthChecks("/health/ready", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = healthResponseWriter
}).AllowAnonymous();

// ---------------------------------------------------------------------
// Deterministic dummy/seed data - one DbContext at a time, each module owning and seeding
// only its own schema. Auth has no DbContext of its own, so nothing to seed there.
// ---------------------------------------------------------------------
await app.Services.SeedApplicationHubModuleAsync();
await app.Services.SeedUserManagementModuleAsync();

app.Run();

// Exposed for WebApplicationFactory<Program> in a future ZWS.Master.IntegrationTests project.
public partial class Program;
