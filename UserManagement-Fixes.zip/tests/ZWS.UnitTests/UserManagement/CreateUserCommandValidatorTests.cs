using FluentAssertions;
using Moq;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Application.Users.Commands;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>PR_UM 3.x validation rules from the BRD.</summary>
public class CreateUserCommandValidatorTests
{
    private readonly Mock<IUserRepository> _repository = new();

    private static CreateUserCommand ValidCommand(string fullName = "Shelby Goode", string email = "shelby.goode@example.com") =>
        new(fullName, email, null, false, UserState.Active, [Guid.NewGuid()], [Guid.NewGuid()], [new PagePermissionAssignment("dashboard", AccessLevel.View)], []);

    [Fact]
    public async Task Validate_WithValidCommand_ShouldSucceed()
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand());

        result.IsValid.Should().BeTrue();
    }

    [Theory]
    [InlineData("Shelby3 Goode")] // digits not allowed
    [InlineData("S")] // too short
    public async Task Validate_WithInvalidFullName_ShouldFail(string fullName)
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand(fullName: fullName));

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.FullName));
    }

    [Fact]
    public async Task Validate_WithNameContainingApostrophe_ShouldSucceed()
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand(fullName: "Mary D'souza"));

        result.IsValid.Should().BeTrue();
    }

    [Theory]
    [InlineData("plainaddress")]
    [InlineData("missing-domain@")]
    [InlineData("@no-local.com")]
    [InlineData("no-tld@domain")] // passed FluentValidation's EmailAddress() alone
    [InlineData("a@b")]
    [InlineData("spaces in@example.com")]
    [InlineData("double..dot@example..com")]
    [InlineData("name@example.c")] // 1-letter TLD
    public async Task Validate_WithMalformedEmail_ShouldFail(string email)
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand(email: email));

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.Email));
    }

    [Theory]
    [InlineData("shelby.goode@example.com")]
    [InlineData("first+tag@sub.example.co.uk")]
    [InlineData("o'brien@example.com")]
    public async Task Validate_WithWellFormedEmail_ShouldSucceed(string email)
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand(email: email));

        result.Errors.Should().NotContain(e => e.PropertyName == nameof(CreateUserCommand.Email));
    }

    [Fact]
    public async Task Validate_WithDuplicateEmail_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByEmailAsync("shelby.goode@example.com", null, It.IsAny<CancellationToken>())).ReturnsAsync(true);
        var validator = new CreateUserCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand());

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.Email));
    }

    [Fact]
    public async Task Validate_WithNoGroupsOrRolesOrPermissions_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateUserCommandValidator(_repository.Object);
        var command = new CreateUserCommand("Shelby Goode", "shelby.goode@example.com", null, false, UserState.Active, [], [], [], []);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.GroupIds));
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.RoleIds));
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateUserCommand.Permissions));
    }
}
