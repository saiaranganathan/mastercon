using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

/// <summary>PR_UM 2.2: Edit Role. Group cannot change while the role has active users (BUS-4537:
/// but it can while the role has none - GroupId carries the Group the role should end up in, which
/// is simply the role's current Group when the user didn't change it).</summary>
public sealed record UpdateRoleCommand(
    Guid Id,
    string Name,
    Guid GroupId,
    string? Description,
    RoleState State,
    IReadOnlyCollection<PagePermissionAssignment> Permissions) : ICommand;
