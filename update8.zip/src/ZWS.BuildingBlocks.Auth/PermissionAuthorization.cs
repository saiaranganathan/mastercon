using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace ZWS.BuildingBlocks.Auth;

/// <summary>
/// The two access levels every page in PermissionPageCatalog is granted against (View/Edit -
/// Edit always implies View, expanded to both claims at token-mint time - see JwtUserClaims).
/// Deliberately its own tiny enum here rather than referencing UserManagement's AccessLevel:
/// this project is referenced by every app's Host (Paycon included), and UserManagement is
/// Master-only - the two enums are kept in sync only by the "View"/"Edit" string they both
/// serialize to in the "perm" claim, same pattern PayconNavigationDbContextSeed already
/// documents for its own RequiredPermission strings.
/// </summary>
public enum PermissionAccess { View, Edit }

/// <summary>
/// Server-side per-page/action authorization (the genuine gap identified alongside the already-
/// working menu-hiding in GetPayconNavigationQueryHandler/GetHubApplicationsQueryHandler-style
/// filtering): before this, AddZwsJwtAuthentication's global fallback policy only proved a
/// request carried SOME valid, authenticated user - it never checked whether that user actually
/// held the permission for the page/action being called, so a valid token for any user could
/// call any controller action regardless of their assigned Role/Permissions, including by typing
/// a URL directly. Put this on a controller (class-level) or a single action to require it -
/// e.g. [RequirePermission("dashboard")] for a GET, [RequirePermission("dashboard",
/// PermissionAccess.Edit)] for a mutating action - matching the bare page-key strings already
/// used by NavigationItem.RequiredPermission/PermissionPageCatalog.Key.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public sealed class RequirePermissionAttribute : AuthorizeAttribute
{
    /// <summary>Prefix ZwsPermissionPolicyProvider recognizes as "build me a permission policy",
    /// as opposed to any ordinary named policy an app might also register.</summary>
    public const string PolicyPrefix = "ZwsPermission:";

    public RequirePermissionAttribute(string pageKey, PermissionAccess access = PermissionAccess.View)
    {
        Policy = $"{PolicyPrefix}{pageKey}:{access}";
    }
}

/// <summary>The one requirement PermissionAuthorizationHandler ever evaluates: "does the caller's
/// JWT carry this exact '{pageKey}:{View|Edit}' perm claim".</summary>
public sealed class PermissionRequirement(string permission) : IAuthorizationRequirement
{
    public string Permission { get; } = permission;
}

/// <summary>
/// Checks the requirement against the same "perm" claims ClaimsPrincipalCurrentUserService
/// already reads for the (already-working) menu-hiding logic - this is the identical source of
/// truth, just enforced at the API boundary instead of only shaping what the sidebar renders.
/// </summary>
public sealed class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
    {
        if (context.User.HasClaim(JwtTokenIssuer.PermissionClaimType, requirement.Permission))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

/// <summary>
/// Recognizes the synthetic "ZwsPermission:{pageKey}:{access}" policy names RequirePermission
/// stamps onto [Authorize], and builds a one-off AuthorizationPolicy for each on demand - so
/// every app can use [RequirePermission("...")] freely without each individual permission needing
/// its own `services.AddAuthorization(options => options.AddPolicy(...))` registration. Any other
/// policy name (or the fallback policy itself) is delegated to the framework's own default
/// provider, unchanged.
/// </summary>
public sealed class ZwsPermissionPolicyProvider(IOptions<AuthorizationOptions> options) : IAuthorizationPolicyProvider
{
    private readonly DefaultAuthorizationPolicyProvider _fallback = new(options);

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync() => _fallback.GetFallbackPolicyAsync();

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(RequirePermissionAttribute.PolicyPrefix, StringComparison.Ordinal))
        {
            var permission = policyName[RequirePermissionAttribute.PolicyPrefix.Length..];
            var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(new PermissionRequirement(permission))
                .Build();
            return Task.FromResult<AuthorizationPolicy?>(policy);
        }

        return _fallback.GetPolicyAsync(policyName);
    }
}
