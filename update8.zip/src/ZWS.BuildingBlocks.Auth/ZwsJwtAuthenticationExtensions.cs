using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.BuildingBlocks.Auth;

public static class ZwsJwtAuthenticationExtensions
{
    /// <summary>
    /// Every app service (Master, Paycon, Compliance, TradeInsights, PartnerHub) calls this
    /// once in Program.cs. Registers standard JwtBearer validation against the shared
    /// "Jwt:SigningKey" (see JwtOptions), `app.UseAuthentication()`/`UseAuthorization()`
    /// middleware wiring is still the caller's job same as any ASP.NET Core app, and registers
    /// ClaimsPrincipalCurrentUserService as the real ICurrentUserService. Only Master
    /// additionally calls AddZwsJwtIssuer to mint tokens - every app validates, only Master issues.
    /// </summary>
    public static IServiceCollection AddZwsJwtAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));
        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUserService, ClaimsPrincipalCurrentUserService>();

        var jwtSection = configuration.GetSection(JwtOptions.SectionName);
        var signingKey = jwtSection["SigningKey"];
        var issuer = jwtSection["Issuer"] ?? "zws-master";
        var audience = jwtSection["Audience"] ?? "zws";

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                // Without this, the handler silently remaps short claim types ("sub", "name",
                // "email") to long legacy XML-schema URIs before they ever reach
                // ClaimsPrincipalCurrentUserService, which looks them up by their original JWT
                // names - UserId/UserName would then always miss and quietly fall back to the
                // system placeholder for every real authenticated request. Custom claim types
                // ("group", "role", "perm") were never affected by this mapping, only the
                // registered ones - which is exactly why HasPermission worked while UserId didn't.
                options.MapInboundClaims = false;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = issuer,
                    ValidateAudience = true,
                    ValidAudience = audience,
                    ValidateIssuerSigningKey = true,
                    // A dev-only fallback key so an app with no "Jwt:SigningKey" set yet still
                    // boots (tokens just won't validate against a *different* app's real key
                    // until every app's User Secrets are set to the same real value). Shared with
                    // JwtTokenIssuer via JwtOptions.DevOnlyFallbackSigningKey so minting and
                    // validation can never drift onto two different fallback keys.
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
                        string.IsNullOrWhiteSpace(signingKey) ? JwtOptions.DevOnlyFallbackSigningKey : signingKey)),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(1)
                };
            });

        // No controller in this codebase has ever carried an [Authorize] attribute - that was a
        // known, deliberately-deferred gap (a TODO(auth) placeholder from before real login
        // existed). Now that every app actually validates a real JWT, a bare `AddAuthorization()`
        // left every endpoint reachable anonymously regardless of whether a valid token was sent
        // - running Paycon on its own (no token, since it never went through Master's Hub) loaded
        // every menu and every page's data with nobody checking who was asking. This fallback
        // policy makes "must be an authenticated request" the DEFAULT for every endpoint in every
        // app; the few endpoints that must stay reachable with no token yet (Master's own
        // POST/GET api/auth/*, since a user has no token until they log in; each app's health
        // checks, since orchestrators probing them never carry one) opt out explicitly with
        // [AllowAnonymous] / .AllowAnonymous() at the call site instead.
        services.AddAuthorization(options =>
        {
            options.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        });

        // Per-page/action permission enforcement (issue: "prevented from directly accessing
        // unauthorized pages or routes by manually entering the URL"). The fallback policy above
        // only proves the caller is SOME authenticated user - it was the entire authorization
        // story until now, which is why a valid token for any user could reach any controller
        // action regardless of their assigned Role/Permissions. [RequirePermission("pageKey")] on
        // a controller/action now checks the caller's actual "perm" claims (the same ones
        // GetPayconNavigationQueryHandler already reads to decide what the sidebar shows) via
        // ZwsPermissionPolicyProvider + PermissionAuthorizationHandler registered here.
        services.AddSingleton<IAuthorizationPolicyProvider, ZwsPermissionPolicyProvider>();
        services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();

        return services;
    }

    /// <summary>Master-only: registers IJwtTokenIssuer so the Auth module can mint tokens at login.</summary>
    public static IServiceCollection AddZwsJwtIssuer(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));
        services.AddScoped<IJwtTokenIssuer, JwtTokenIssuer>();
        return services;
    }
}
