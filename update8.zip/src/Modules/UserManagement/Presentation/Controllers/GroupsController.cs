using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.Groups.Commands;
using ZWS.Modules.UserManagement.Application.Groups.Queries;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

/// <summary>/paycon/settings/user-management -> Groups tab (PR_UM-1.x).</summary>
[ApiController]
[Route("api/paycon/settings/user-management/groups")]
[RequirePermission("settings.user-management.groups")]
public sealed class GroupsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetGroups([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetGroupsQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetGroup(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GetGroupByIdQuery(id), cancellationToken)).ToActionResult();

    [HttpPost]
    [RequirePermission("settings.user-management.groups", PermissionAccess.Edit)]
    public async Task<IActionResult> CreateGroup([FromBody] CreateGroupRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreateGroupCommand(request.Name, request.State, request.OverridePlanPermissionAtUserLevel, request.SchemeIds), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    [RequirePermission("settings.user-management.groups", PermissionAccess.Edit)]
    public async Task<IActionResult> UpdateGroup(Guid id, [FromBody] UpdateGroupRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateGroupCommand(id, request.Name, request.State, request.OverridePlanPermissionAtUserLevel, request.SchemeIds), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    [RequirePermission("settings.user-management.groups", PermissionAccess.Edit)]
    public async Task<IActionResult> DeleteGroup(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteGroupCommand(id), cancellationToken)).ToActionResult();
}

public sealed record CreateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);
public sealed record UpdateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);
