using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.Permissions;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

// Deliberately NOT gated behind [RequirePermission("settings.user-management.permissions")]:
// this just returns the fixed PermissionPageCatalog (page keys/labels), not any per-user data,
// and it's called by PermissionMatrix.razor from inside the Users AND Roles tabs alike (e.g. to
// render the "Direct permissions" picker while editing a User) - those callers only need
// "settings.user-management.users"/".roles", not ".permissions" itself, so gating this endpoint
// on ".permissions" would 403 a perfectly authorized User/Role edit. Still requires SOME
// authenticated caller via AddZwsJwtAuthentication's fallback policy, same as before.
[ApiController]
[Route("api/paycon/settings/user-management/permissions")]
public sealed class PermissionsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetPermissions(CancellationToken cancellationToken) =>
        (await sender.Send(new GetPermissionsQuery(), cancellationToken)).ToActionResult();
}
