using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Infrastructure.Persistence;

/// <summary>
/// The ONLY DbContext for the UserManagement module - covers Groups, Roles,
/// Users and their assignment tables. No other module may reference this type.
/// </summary>
public sealed class UserManagementDbContext(DbContextOptions<UserManagementDbContext> options)
    : DbContext(options), IUserManagementDbContext
{
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<GroupSchemeAssignment> GroupSchemeAssignments => Set<GroupSchemeAssignment>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<RolePagePermission> RolePagePermissions => Set<RolePagePermission>();
    public DbSet<User> Users => Set<User>();
    public DbSet<UserGroupAssignment> UserGroupAssignments => Set<UserGroupAssignment>();
    public DbSet<UserRoleAssignment> UserRoleAssignments => Set<UserRoleAssignment>();
    public DbSet<UserPagePermission> UserPagePermissions => Set<UserPagePermission>();
    public DbSet<UserSchemeOverride> UserSchemeOverrides => Set<UserSchemeOverride>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("user_management");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(UserManagementDbContext).Assembly);
        modelBuilder.Entity<Group>().HasQueryFilter(g => !g.IsDeleted);
        modelBuilder.Entity<Role>().HasQueryFilter(r => !r.IsDeleted);
        modelBuilder.Entity<User>().HasQueryFilter(u => !u.IsDeleted);
    }

    /// <summary>
    /// Root cause of the recurring "DbUpdateConcurrencyException, 0 row(s) affected" on User/
    /// Group/Role saves (reproduces identically on all three - CRMViewer role save included):
    /// it is a genuine double-submit race, not a data-loss bug. UsersTab/RolesTab/GroupsTab.razor
    /// had no guard against a second Save click while the first was still in flight (now fixed -
    /// see their own `_saving` guard), so two concurrent requests for the SAME aggregate could
    /// each load their own snapshot of its old child rows (UserGroupAssignment/RolePagePermission/
    /// etc. - see IUserManagementDbContext.RemoveRange) and each stage those same rows for
    /// deletion. Whichever request's SaveChangesAsync commits first genuinely succeeds - that is
    /// why the data ends up saved correctly. The second request's own DELETE then matches zero
    /// rows (the first request already removed them), which EF Core reports as a concurrency
    /// conflict even though "the row is gone" is exactly what this request wanted too - that
    /// exception is what the UI was showing as an error despite the save having actually worked.
    ///
    /// Fixing only the UI guard reduces how often this fires but doesn't eliminate it (two
    /// browser tabs/users editing the same Role, or a client retry after a dropped response, hit
    /// the same race) - so this override makes losing that race harmless instead of fatal: any
    /// entry EF reports as conflicting that this save was itself trying to DELETE is detached
    /// (treated as "already deleted, nothing to do") and the save is retried once. A conflict on
    /// an entry this save was trying to UPDATE/INSERT is a different, real problem and is left to
    /// throw.
    /// </summary>
    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            return await base.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException ex)
        {
            var allDeletes = true;
            foreach (var entry in ex.Entries)
            {
                if (entry.State == EntityState.Deleted)
                {
                    entry.State = EntityState.Detached;
                }
                else
                {
                    allDeletes = false;
                }
            }

            if (!allDeletes) throw;

            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}
