using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Presentation.Controllers;

/// <summary>/paycon/settings/scheme-management (requirement 15).</summary>
[ApiController]
[Route("api/paycon/settings/scheme-management/schemes")]
[RequirePermission("settings.scheme-management")]
public sealed class SchemesController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetSchemes([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetSchemesQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetScheme(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GetSchemeByIdQuery(id), cancellationToken)).ToActionResult();

    // Anonymous on purpose: Master's UserManagement module calls this server-to-server (see
    // ZWS.Modules.UserManagement.Infrastructure.ExternalServices.SchemeReferenceService) to
    // populate the Assigned Plans picker, and that call doesn't carry the signed-in browser
    // user's JWT (it's Master's own backend calling Paycon's, not the browser calling it
    // directly) - now that every other Paycon endpoint requires a valid token by default, this
    // one still needs to stay reachable. Low-sensitivity data (active scheme id/name pairs only).
    [HttpGet("reference")]
    [AllowAnonymous]
    public async Task<IActionResult> GetActiveSchemesForReference(CancellationToken cancellationToken) =>
        (await sender.Send(new GetActiveSchemesForReferenceQuery(), cancellationToken)).ToActionResult();

    [HttpPost]
    [RequirePermission("settings.scheme-management", PermissionAccess.Edit)]
    public async Task<IActionResult> CreateScheme([FromBody] CreateSchemeRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreateSchemeCommand(request.Code, request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    [RequirePermission("settings.scheme-management", PermissionAccess.Edit)]
    public async Task<IActionResult> UpdateScheme(Guid id, [FromBody] UpdateSchemeRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateSchemeCommand(id, request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    [RequirePermission("settings.scheme-management", PermissionAccess.Edit)]
    public async Task<IActionResult> DeleteScheme(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteSchemeCommand(id), cancellationToken)).ToActionResult();
}

public sealed record CreateSchemeRequest(string Code, string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
public sealed record UpdateSchemeRequest(string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
