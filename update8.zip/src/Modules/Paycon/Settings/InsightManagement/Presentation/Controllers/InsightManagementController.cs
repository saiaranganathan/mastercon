using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Commands;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Queries;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Presentation.Controllers;

/// <summary>Route: /paycon/settings/insight-management (requirement 16 - placeholder).</summary>
[ApiController]
[Route("api/paycon/settings/insight-management")]
[RequirePermission("settings.insight-management")]
public sealed class InsightManagementController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetConfigurations(CancellationToken cancellationToken) =>
        (await sender.Send(new GetInsightConfigurationsQuery(), cancellationToken)).ToActionResult();

    [HttpPost("{id:guid}/toggle")]
    [RequirePermission("settings.insight-management", PermissionAccess.Edit)]
    public async Task<IActionResult> Toggle(Guid id, [FromBody] bool isEnabled, CancellationToken cancellationToken) =>
        (await sender.Send(new ToggleInsightConfigurationCommand(id, isEnabled), cancellationToken)).ToActionResult();
}
