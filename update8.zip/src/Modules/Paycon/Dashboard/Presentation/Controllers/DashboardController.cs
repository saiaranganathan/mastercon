using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Dashboard.Application.Queries;

namespace ZWS.Modules.Paycon.Dashboard.Presentation.Controllers;

/// <summary>Route: /paycon/dashboard (requirement 9.1).</summary>
[ApiController]
[Route("api/paycon/dashboard")]
[RequirePermission("dashboard")]
public sealed class DashboardController(ISender sender, ICurrentUserService currentUser) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetSnapshot(CancellationToken cancellationToken)
    {
        var userId = currentUser.IsAuthenticated ? currentUser.UserId : "demo-user";
        var result = await sender.Send(new GetDashboardSnapshotQuery(userId), cancellationToken);
        return result.ToActionResult();
    }
}
