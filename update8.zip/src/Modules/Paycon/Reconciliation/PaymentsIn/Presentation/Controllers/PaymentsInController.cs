using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Queries;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Presentation.Controllers;

/// <summary>Route: /paycon/reconciliation/payments-in (requirement 10).</summary>
[ApiController]
[Route("api/paycon/reconciliation/payments-in")]
[RequirePermission("reconciliation.payments-in")]
public sealed class PaymentsInController(ISender sender) : ControllerBase
{
    [HttpGet("batches")]
    public async Task<IActionResult> GetBatches([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetPaymentBatchesQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("transactions")]
    public async Task<IActionResult> GetTransactions(
        [FromQuery] Guid? batchId, [FromQuery] PaymentTransactionStatus? status, [FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetPaymentTransactionsQuery(batchId, status, paging), cancellationToken)).ToActionResult();

    [HttpPost("upload")]
    [RequirePermission("reconciliation.payments-in", PermissionAccess.Edit)]
    public async Task<IActionResult> UploadFile([FromBody] UploadPaymentFileRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UploadPaymentFileCommand(request.FileName, request.SchemeId, request.SchemeName), cancellationToken)).ToActionResult();

    [HttpPost("transactions/{id:guid}/comment")]
    [RequirePermission("reconciliation.payments-in", PermissionAccess.Edit)]
    public async Task<IActionResult> AddComment(Guid id, [FromBody] AddCommentRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new AddTransactionCommentCommand(id, request.Comment), cancellationToken)).ToActionResult();
}

public sealed record UploadPaymentFileRequest(string FileName, Guid SchemeId, string SchemeName);
public sealed record AddCommentRequest(string Comment);
