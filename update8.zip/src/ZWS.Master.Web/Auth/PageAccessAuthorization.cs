using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace ZWS.Master.Web.Auth;

/// <summary>
/// Master.Web's own copy of ZWS.Web's Auth/PageAccessAuthorization.cs - deliberately duplicated,
/// not shared, since neither Web project references the other or a common project (see each
/// csproj's own header comment: "does NOT reference any module project or ZWS.BuildingBlocks").
/// See ZWS.Web's copy for the full reasoning; this is the client-side route guard for Master's
/// own permission-gated page (currently just Settings/UserManagement.razor).
/// </summary>
public static class PagePolicy
{
    public const string Prefix = "ZwsPage:";

    public static string For(string pageKey) => $"{Prefix}{pageKey}";
}

public sealed class PageAccessRequirement(string pageKey) : IAuthorizationRequirement
{
    public string PageKey { get; } = pageKey;
}

public sealed class PageAccessHandler : AuthorizationHandler<PageAccessRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PageAccessRequirement requirement)
    {
        if (context.User.HasClaim("perm", $"{requirement.PageKey}:View"))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

public sealed class ZwsPagePolicyProvider(IOptions<AuthorizationOptions> options) : IAuthorizationPolicyProvider
{
    private readonly DefaultAuthorizationPolicyProvider _fallback = new(options);

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync() => _fallback.GetFallbackPolicyAsync();

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(PagePolicy.Prefix, StringComparison.Ordinal))
        {
            var pageKey = policyName[PagePolicy.Prefix.Length..];
            var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(new PageAccessRequirement(pageKey))
                .Build();
            return Task.FromResult<AuthorizationPolicy?>(policy);
        }

        return _fallback.GetPolicyAsync(policyName);
    }
}
