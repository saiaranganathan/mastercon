using System.Security.Claims;
using Microsoft.AspNetCore.Components.Authorization;
using ZWS.Master.Web.Services;

namespace ZWS.Master.Web.Auth;

/// <summary>
/// Master.Web's own copy of ZWS.Web's Auth/ZwsAuthenticationStateProvider.cs - see that file for
/// the full reasoning. Builds the ClaimsPrincipal from PermissionService/TokenStore, the same
/// pair MainLayout's sidebar already uses to decide what to show.
/// </summary>
public sealed class ZwsAuthenticationStateProvider : AuthenticationStateProvider
{
    private readonly TokenStore _tokenStore;

    public ZwsAuthenticationStateProvider(TokenStore tokenStore)
    {
        _tokenStore = tokenStore;
        _tokenStore.Changed += () => NotifyAuthenticationStateChanged(Task.FromResult(BuildState()));
    }

    public override Task<AuthenticationState> GetAuthenticationStateAsync() => Task.FromResult(BuildState());

    private AuthenticationState BuildState()
    {
        if (!_tokenStore.IsAuthenticated || _tokenStore.FullName is null)
        {
            return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
        }

        // Parsed straight from the token (same as JwtPermissions/PermissionService already do for
        // menu-hiding), not routed through PermissionService - that type only exposes HasView/
        // HasEdit helpers, not the raw claim set an AuthenticationStateProvider needs.
        var permissions = JwtPermissions.Parse(_tokenStore.Token);

        var claims = new List<Claim> { new(ClaimTypes.Name, _tokenStore.FullName) };
        if (_tokenStore.Email is { } email) claims.Add(new Claim(ClaimTypes.Email, email));
        claims.AddRange(permissions.Roles.Select(r => new Claim(ClaimTypes.Role, r)));
        claims.AddRange(permissions.Permissions.Select(p => new Claim("perm", p)));

        var identity = new ClaimsIdentity(claims, authenticationType: "zws-jwt");
        return new AuthenticationState(new ClaimsPrincipal(identity));
    }
}
