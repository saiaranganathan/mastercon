using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ZWS.Master.Web;
using ZWS.Master.Web.Auth;
using ZWS.Master.Web.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// The API base address is provided by wwwroot/appsettings*.json ("ApiBaseAddress"). It defaults
// to the ZWS.Master.Host dev port (see src/ZWS.Master.Host/Properties/launchSettings.json) so
// `dotnet run` works out of the box against a locally running Master.Host.
var apiBaseAddress = builder.Configuration["ApiBaseAddress"] ?? "https://localhost:5211";

// Singleton, not Scoped: AuthMessageHandler is built by IHttpClientFactory inside its own
// internal DI scope (separate from the scope Razor components resolve from) whenever the
// "ZwsMasterApi" named client's handler pipeline is (re)built. A Scoped TokenStore would hand
// that handler a different instance than the one Login.razor calls SetAsync on, so the token it
// stores would never be visible to AuthMessageHandler - the Authorization header would silently
// never be attached to any request. Singleton guarantees every scope (including the factory's
// internal one) resolves the exact same instance - which is also the semantically correct
// lifetime here anyway, since a standalone Blazor WebAssembly app only ever serves one user per
// tab (Scoped and Singleton already behave the same way for a WASM app's own components).
builder.Services.AddSingleton<TokenStore>();
builder.Services.AddScoped<PermissionService>();
builder.Services.AddScoped<AppLinkBuilder>();
builder.Services.AddTransient<AuthMessageHandler>();

// Every typed API client is built from the same named HttpClient so AuthMessageHandler attaches
// "Authorization: Bearer {token}" once, in one place, instead of each client re-implementing it.
builder.Services.AddHttpClient("ZwsMasterApi", client => client.BaseAddress = new Uri(apiBaseAddress))
    .AddHttpMessageHandler<AuthMessageHandler>();

builder.Services.AddScoped(sp => sp.GetRequiredService<IHttpClientFactory>().CreateClient("ZwsMasterApi"));

builder.Services.AddScoped<ApplicationHubApiClient>();
builder.Services.AddScoped<UserManagementApiClient>();
builder.Services.AddScoped<AuthApiClient>();

// Client-side route guard (the direct-URL-entry half of the RBAC gap). Backed by the same "perm"
// claims PermissionService already decodes from TokenStore - see
// ZwsAuthenticationStateProvider/PageAccessAuthorization. Server-side [RequirePermission] on
// UserManagement's own controllers (see ZWS.BuildingBlocks.Auth) is the real enforcement; this is
// defense in depth so a directly-typed URL doesn't even render the page shell.
builder.Services.AddAuthorizationCore();
builder.Services.AddSingleton<IAuthorizationPolicyProvider, ZwsPagePolicyProvider>();
builder.Services.AddSingleton<IAuthorizationHandler, PageAccessHandler>();
builder.Services.AddScoped<AuthenticationStateProvider, ZwsAuthenticationStateProvider>();

await builder.Build().RunAsync();
