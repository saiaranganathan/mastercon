using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace ZWS.Web.Auth;

/// <summary>
/// Client-side half of the route-protection gap identified alongside the API-level
/// [RequirePermission] fix in ZWS.BuildingBlocks.Auth (server-side; not referenced here on
/// purpose - ZWS.Web talks to ZWS.Host only over HTTP, see the ItemGroup comment in
/// ZWS.Web.csproj). Before this, typing an unauthorized page's URL directly rendered that page's
/// full component tree in the browser (it would then fail to load its data with a 401/403 from
/// the now-protected API, but only after the page itself, and everything a user might see just by
/// having it open, had already rendered) - there was no
/// Microsoft.AspNetCore.Components.Authorization usage anywhere in this project at all. Each
/// @page component now carries `@attribute [Authorize(Policy = PagePolicy.For("pageKey"))]` (see
/// App.razor's AuthorizeRouteView), resolved against the same "perm" claims already decoded by
/// JwtPermissions/PermissionService for menu-hiding - this is the identical source of truth, not
/// a second one to keep in sync.
/// </summary>
public static class PagePolicy
{
    public const string Prefix = "ZwsPage:";

    /// <summary>The policy name to pass to [Authorize(Policy = ...)] for a page gated on the
    /// given PermissionPageCatalog key (View access - the same "can see this page at all" check
    /// GetPayconNavigationQueryHandler already applies server-side to decide what to list).</summary>
    public static string For(string pageKey) => $"{Prefix}{pageKey}";
}

public sealed class PageAccessRequirement(string pageKey) : IAuthorizationRequirement
{
    public string PageKey { get; } = pageKey;
}

public sealed class PageAccessHandler : AuthorizationHandler<PageAccessRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PageAccessRequirement requirement)
    {
        // Edit always implies View (expanded to both "perm" claims at token-mint time - see
        // JwtUserClaims/LoginCommandHandler), so a bare View-claim match is enough here.
        if (context.User.HasClaim("perm", $"{requirement.PageKey}:View"))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

public sealed class ZwsPagePolicyProvider(IOptions<AuthorizationOptions> options) : IAuthorizationPolicyProvider
{
    private readonly DefaultAuthorizationPolicyProvider _fallback = new(options);

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync() => _fallback.GetFallbackPolicyAsync();

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(PagePolicy.Prefix, StringComparison.Ordinal))
        {
            var pageKey = policyName[PagePolicy.Prefix.Length..];
            var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(new PageAccessRequirement(pageKey))
                .Build();
            return Task.FromResult<AuthorizationPolicy?>(policy);
        }

        return _fallback.GetPolicyAsync(policyName);
    }
}
