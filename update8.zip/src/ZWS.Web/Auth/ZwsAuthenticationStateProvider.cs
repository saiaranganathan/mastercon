using System.Security.Claims;
using Microsoft.AspNetCore.Components.Authorization;
using ZWS.Web.Services;

namespace ZWS.Web.Auth;

/// <summary>
/// Feeds Blazor's own CascadingAuthenticationState/AuthorizeRouteView (see App.razor) from the
/// exact same token PermissionService already decodes for menu-hiding - TokenStore is the single
/// source (populated at startup either from Master's #access_token URL fragment, or from
/// sessionStorage on a same-app reload; see Program.cs and TokenStore itself), so there is no
/// second place for the JWT to be parsed or drift out of sync. Fires NotifyAuthenticationStateChanged
/// whenever TokenStore's token changes (fresh login/handoff, or sign-out) so any [Authorize]-gated
/// page re-evaluates immediately instead of only on the next full navigation.
/// </summary>
public sealed class ZwsAuthenticationStateProvider : AuthenticationStateProvider
{
    private readonly TokenStore _tokenStore;

    public ZwsAuthenticationStateProvider(TokenStore tokenStore)
    {
        _tokenStore = tokenStore;
        _tokenStore.Changed += () => NotifyAuthenticationStateChanged(Task.FromResult(BuildState()));
    }

    public override Task<AuthenticationState> GetAuthenticationStateAsync() => Task.FromResult(BuildState());

    private AuthenticationState BuildState()
    {
        var permissions = JwtPermissions.Parse(_tokenStore.Token);

        if (string.IsNullOrWhiteSpace(_tokenStore.Token) || permissions.UserName is null)
        {
            // No token at all (never logged in / signed out) is treated the same as an
            // unparsable one: anonymous, so [Authorize]-gated pages fall through to
            // AuthorizeRouteView's NotAuthorized template rather than throwing.
            return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
        }

        var claims = new List<Claim> { new(ClaimTypes.Name, permissions.UserName) };
        if (permissions.Email is { } email) claims.Add(new Claim(ClaimTypes.Email, email));
        claims.AddRange(permissions.Roles.Select(r => new Claim(ClaimTypes.Role, r)));
        claims.AddRange(permissions.Permissions.Select(p => new Claim("perm", p)));

        var identity = new ClaimsIdentity(claims, authenticationType: "zws-jwt");
        return new AuthenticationState(new ClaimsPrincipal(identity));
    }
}
