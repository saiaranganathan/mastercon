using Microsoft.Extensions.Configuration;
using Microsoft.JSInterop;

namespace ZWS.Web.Services;

/// <summary>
/// Works out where "back to the ZWS Hub" points. Paycon normally runs inside Master's iframe, so
/// the page that embeds it IS the Hub: its origin is detected at runtime (works in any
/// environment - UAT, prod - without editing config). When Paycon is opened on its own, the
/// "MasterHubUrl" setting in wwwroot/appsettings*.json is used instead.
/// </summary>
public sealed class HubLinkService(IConfiguration configuration, IJSRuntime js)
{
    private string? _url;

    public async Task<string> GetUrlAsync()
    {
        if (_url is not null) return _url;

        string? parentOrigin = null;
        try { parentOrigin = await js.InvokeAsync<string?>("zwsParentOrigin"); }
        catch { /* JS helper unavailable - fall back to configuration */ }

        var configured = configuration["MasterHubUrl"];
        _url = !string.IsNullOrWhiteSpace(parentOrigin) ? parentOrigin
             : !string.IsNullOrWhiteSpace(configured) ? configured
             : "/";
        return _url;
    }
}
