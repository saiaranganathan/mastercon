using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Auth;

public sealed class GetUserAuthProfileByEmailQueryHandler(
    IUserRepository userRepository, IRoleRepository roleRepository,
    IGroupRepository groupRepository, ISchemeReferenceService schemeReferenceService)
    : IQueryHandler<GetUserAuthProfileByEmailQuery, UserAuthProfileDto>
{
    public async Task<Result<UserAuthProfileDto>> Handle(GetUserAuthProfileByEmailQuery request, CancellationToken cancellationToken)
    {
        var user = await userRepository.FindByEmailAsync(request.Email, cancellationToken);
        if (user is null)
            return Result.Failure<UserAuthProfileDto>(Error.NotFound("User.NotFound", $"No user found with email '{request.Email}'."));

        // The JWT's perm claims must be the user's EFFECTIVE permissions - everything their
        // Role(s) grant, plus their own direct per-page overrides "in addition to" that (see
        // UserPagePermission's doc comment). user.Permissions alone (what LoginCommandHandler
        // used to read) is only ever the direct-override rows - for every seeded user, actual
        // page access mostly comes from their Role, so that left almost every claim out of the
        // token: Paycon's sidebar came back nearly empty and no seeded user had a *direct* grant
        // on "settings.user-management" itself (only ITAdministrator's ROLE grants it), so the
        // Master settings gear never appeared for anyone. Roles are merged taking the
        // higher level (Edit > View) across roles; user-level rows then override the result.
        var effective = new Dictionary<string, AccessLevel>();

        foreach (var roleAssignment in user.Roles)
        {
            var role = await roleRepository.GetByIdAsync(roleAssignment.RoleId, cancellationToken);
            if (role is null) continue; // role since deleted/renamed away - ignore rather than fail login

            foreach (var grant in role.Permissions)
            {
                if (!effective.TryGetValue(grant.PageKey, out var existing) || grant.Access > existing)
                    effective[grant.PageKey] = grant.Access;
            }
        }

        // BUS-4565: a user-level setting takes precedence over the Role level - it REPLACES what
        // the roles grant for that page (so a user can be held at View where a role gives Edit,
        // or be given Edit where the roles only give View), rather than the higher level winning.
        foreach (var grant in user.Permissions)
            effective[grant.PageKey] = grant.Access;

        // Scheme-restricted pages (e.g. Annual Statements needs scheme code "2"): drop the page from the
        // claims unless one of the user's effective plans carries the required scheme code.
        if (PageSchemeRestrictions.RequiredSchemeCodeByPage.Keys.Any(effective.ContainsKey))
        {
            var planCodes = await ResolvePlanCodesAsync(user, cancellationToken);
            foreach (var (pageKey, requiredCode) in PageSchemeRestrictions.RequiredSchemeCodeByPage)
                if (!planCodes.Contains(requiredCode)) effective.Remove(pageKey);
        }

        var dto = new UserAuthProfileDto(
            user.Id, user.FullName, user.Email,
            user.Groups.Select(g => g.GroupName).ToList(),
            user.Roles.Select(r => r.RoleName).ToList(),
            effective.Select(kv => new PagePermissionDto(kv.Key, PermissionPageCatalog.LabelFor(kv.Key), kv.Value.ToString())).ToList());

        return Result.Success(dto);
    }

    /// <summary>Scheme codes of the user's effective plans: (plans their Groups grant - the ones switched
    /// off for this user) + the plans added for this user; the user-level changes only count while a
    /// Group allows them. Empty when Paycon's scheme list cannot be reached (restricted pages stay hidden).</summary>
    private async Task<HashSet<string>> ResolvePlanCodesAsync(User user, CancellationToken cancellationToken)
    {
        var planIds = new HashSet<Guid>();
        var anyGroupAllowsOverride = false;
        foreach (var membership in user.Groups)
        {
            var group = await groupRepository.GetByIdAsync(membership.GroupId, cancellationToken);
            if (group is null) continue;
            anyGroupAllowsOverride |= group.OverridePlanPermissionAtUserLevel;
            foreach (var assignment in group.SchemeAssignments) planIds.Add(assignment.SchemeId);
        }

        if (anyGroupAllowsOverride)
        {
            planIds.ExceptWith(user.ExcludedSchemes.Select(s => s.SchemeId));
            foreach (var added in user.AddedSchemes) planIds.Add(added.SchemeId);
        }

        var activeSchemes = await schemeReferenceService.TryGetActiveSchemesAsync(cancellationToken);
        return (activeSchemes ?? [])
            .Where(s => planIds.Contains(s.SchemeId) && !string.IsNullOrWhiteSpace(s.SchemeCode))
            .Select(s => s.SchemeCode!.Trim())
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
    }
}
