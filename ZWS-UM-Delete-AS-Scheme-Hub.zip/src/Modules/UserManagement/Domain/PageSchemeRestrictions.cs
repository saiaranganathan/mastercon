namespace ZWS.Modules.UserManagement.Domain;

/// <summary>
/// Pages that only users on a particular plan (scheme) may use. The page key is withheld from the
/// user's permission claims at login unless one of their effective plans carries the required
/// scheme code - so the sidebar entry, the page itself and its API all disappear together.
/// Scheme codes (Paycon scheme reference): 1 = DEWS, 2 = Dubai Government, 3 = Daman,
/// 4 = Dubai Government AED, 5 = ADNOC.
/// </summary>
public static class PageSchemeRestrictions
{
    /// <summary>page key -> scheme code the user must hold.</summary>
    public static readonly IReadOnlyDictionary<string, string> RequiredSchemeCodeByPage =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["statements.annual-statements"] = "2"
        };
}
