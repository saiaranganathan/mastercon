using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Application.Users.Commands;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>Only Terminated users can be deleted (soft delete); Active and Inactive are refused.</summary>
public class DeleteUserCommandHandlerTests
{
    private readonly Mock<IUserRepository> _userRepository = new();
    private readonly Mock<IUserManagementDbContext> _dbContext = new();

    private static User UserIn(UserState state) => User.Create(
        "Test User", "test.user@example.com", null, null, false, state,
        [], [], [new PagePermissionAssignment("statements.annual-statements", AccessLevel.View)], []);

    private async Task<Result> DeleteAsync(User user)
    {
        _userRepository.Setup(r => r.GetByIdAsync(user.Id, It.IsAny<CancellationToken>())).ReturnsAsync(user);
        return await new DeleteUserCommandHandler(_userRepository.Object, _dbContext.Object)
            .Handle(new DeleteUserCommand(user.Id), CancellationToken.None);
    }

    [Theory]
    [InlineData(UserState.Active)]
    [InlineData(UserState.Inactive)]
    public async Task Handle_WhenUserIsNotTerminated_ShouldReturnConflictAndNotDelete(UserState state)
    {
        var result = await DeleteAsync(UserIn(state));

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.Conflict);
        result.Error.Code.Should().Be("User.OnlyTerminatedCanBeDeleted");
        _userRepository.Verify(r => r.Remove(It.IsAny<User>()), Times.Never);
        _dbContext.Verify(d => d.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenUserIsTerminated_ShouldDelete()
    {
        var user = UserIn(UserState.Terminated);

        var result = await DeleteAsync(user);

        result.IsSuccess.Should().BeTrue();
        _userRepository.Verify(r => r.Remove(user), Times.Once);
        _dbContext.Verify(d => d.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }
}
