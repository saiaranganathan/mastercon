# ZWS — Modular Monolith (Paycon + ZWS Application Hub)

ZWS is a strict modular monolith built with ASP.NET Core (.NET 9) and Blazor WebAssembly. It hosts
the **ZWS Application Hub** (a database-driven landing page) and the **Paycon** application, whose
internal modules (Dashboard, Reconciliation, Insights, Statements, Settings, Notifications) each own
their own EF Core `DbContext` and communicate with one another only through MediatR queries or
RabbitMQ integration events — never through a shared `DbContext` or direct table access.

## Solution layout

```
ZWS.sln
Directory.Build.props / Directory.Packages.props   # net9.0, central package versions
docker-compose.yml                                  # RabbitMQ, Redis, SQL Server (local infra)
src/
  ZWS.Host/            # composition root only - no business logic, no DbContext
  ZWS.Web/              # Blazor WebAssembly UI (talks to ZWS.Host over HTTP + SignalR only)
  ZWS.BuildingBlocks/   # shared kernel: CQRS abstractions, Result<T>, caching, messaging, SignalR hub
  Modules/
    ApplicationHub/                     # DB-driven hub cards (PAYCON / COMPLIANCE / TRADEINSIGHTS / PARTNERHUB)
    Compliance/                          # external app placeholder
    TradeInsights/                       # native app, lean
    PartnerHub/                          # external app placeholder
    Paycon/
      Navigation/                        # DB-driven Paycon sidebar tree
      Dashboard/
      Reconciliation/PaymentsIn/         # full Figma-depth: upload, matches/mismatches, comments
      Reconciliation/PaymentsOut/        # functional placeholder
      Insights/
      Statements/ExitStatements/
      Statements/AnnualStatements/       # placeholder
      Settings/UserManagement/           # full BRD depth: Groups / Roles / Users / Permission matrix
      Settings/SchemeManagement/         # full CRUD, cross-module reference contract
      Settings/InsightManagement/        # placeholder
      Notifications/                     # deliberately isolated - RabbitMQ + SignalR only
tests/
  ZWS.UnitTests/            # validators + handlers in isolation, mocked repositories
  ZWS.IntegrationTests/     # WebApplicationFactory<Program> against the real HTTP API
  ZWS.ArchitectureTests/    # NetArchTest rules enforcing module isolation and domain purity
```

## Running locally

You'll need the [.NET 9 SDK](https://dotnet.microsoft.com/download/dotnet/9.0). Docker is optional —
every module falls back to a local SQLite file and the app degrades gracefully with no Redis/RabbitMQ
running, so `dotnet run` works standalone.

### 1. Restore and build

```bash
dotnet restore
dotnet build
```

### 2. (Optional) start local infrastructure

```bash
docker compose up -d
```

This starts RabbitMQ (with management UI on `:15672`), Redis, and SQL Server 2022. If you skip this
step, every module uses its own local SQLite `*.dev.db` file, Redis caching is silently disabled
(reads fall back to SQL), and RabbitMQ publish/consume calls log a warning and no-op — nothing crashes.

### 3. Run the API host

```bash
dotnet run --project src/ZWS.Host
```

Swagger UI opens at `https://localhost:5201/swagger` in Development. `/health` (liveness) and
`/health/ready` (readiness — SQL/Redis/RabbitMQ) are available immediately. On first run, every
module seeds deterministic demo data via `Database.EnsureCreatedAsync()`.

### 4. Run the Blazor WebAssembly UI

```bash
dotnet run --project src/ZWS.Web
```

Open `https://localhost:5101`. The Web app's `wwwroot/appsettings.Development.json` points at
`http://localhost:5200` for the API — update `ApiBaseAddress` there (and the Host's
`Cors:AllowedOrigins`) if you change either project's port.

## Running the tests

```bash
dotnet test
```

- **ZWS.UnitTests** — FluentValidation rules and MediatR handlers against mocked repositories, no I/O.
- **ZWS.IntegrationTests** — boots the real `ZWS.Host` pipeline in-memory and exercises the HTTP API
  end to end (SQLite dev fallback, real seeding, real MediatR pipeline). This assembly runs its test
  classes sequentially (`CollectionBehavior(DisableTestParallelization = true)`) since they share the
  same on-disk SQLite dev files that a real `dotnet run` would also use.
- **ZWS.ArchitectureTests** — NetArchTest rules that fail the build if the Notifications module picks
  up a dependency on another Paycon module, if the UserManagement → SchemeManagement reference runs in
  reverse, or if a Domain type starts depending on EF Core / MediatR / ASP.NET Core.

## Migrations

This build seeds its demo data with `Database.EnsureCreatedAsync()` per module rather than checked-in
EF Core migrations, so the schema always matches the current model with zero migration-history
drift during active development. Before deploying against a real Azure SQL environment, generate a
versioned migration per module, e.g.:

```bash
dotnet ef migrations add InitialCreate \
  --project src/Modules/Paycon/Settings/UserManagement \
  --context UserManagementDbContext \
  --output-dir Infrastructure/Persistence/Migrations
```

Repeat per module (each has its own `DbContext` and its own migration history table, e.g.
`__EFMigrationsHistory` under the module's own schema), then switch each `Module.cs`'s seed call from
`EnsureCreatedAsync()` to `MigrateAsync()`.

## Configuration

Connection strings, Redis, and RabbitMQ are configured per environment in
`src/ZWS.Host/appsettings.json` / `appsettings.Development.json`. Production secrets (SQL password,
Redis password) are intentionally left as placeholders — wire them up via User Secrets, environment
variables, or Azure Key Vault; never commit real credentials into `appsettings.json`.

## Architectural rules this codebase enforces

- **One `DbContext` per module.** No module references another module's `DbContext` or EF
  configuration, ever — verified by `ZWS.ArchitectureTests`.
- **Two sanctioned cross-module communication patterns only:**
  1. A synchronous MediatR query against another module's *public* contract, with an explicit,
     commented project reference (e.g. `UserManagement` → `SchemeManagement`'s
     `GetActiveSchemesForReferenceQuery`, `Dashboard` → `Notifications`' `GetRecentNotificationsQuery`).
  2. An asynchronous RabbitMQ integration event with **zero** project reference — contracts live in
     `ZWS.BuildingBlocks.Messaging.Contracts` (e.g. `UserManagement` → `Notifications`,
     `PaymentsIn` → `Notifications`).
- **Notifications is fully isolated.** No other module references it directly; it hears about the
  rest of the system only through RabbitMQ.
- **Dynamic, database-driven navigation and hub cards.** Nothing about the ZWS Application Hub's
  card grid or Paycon's sidebar is hard-coded — both come from `GET /api/applications` and
  `GET /api/paycon/navigation` respectively, seeded data included.
