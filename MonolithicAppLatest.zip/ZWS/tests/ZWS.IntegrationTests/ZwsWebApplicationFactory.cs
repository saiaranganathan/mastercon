using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace ZWS.IntegrationTests;

/// <summary>
/// Boots the real ZWS.Host pipeline (Program.cs) against an in-memory
/// TestServer. Every module's DbContext falls back to its own local
/// SQLite *.dev.db file (see each Module.cs) since connection strings stay
/// blank here, exactly as it would running `dotnet run` locally without
/// Azure SQL configured. RabbitMQ and Redis are explicitly turned off so
/// the suite never depends on infrastructure that isn't running in CI.
/// </summary>
public sealed class ZwsWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");

        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["RabbitMQ:Enabled"] = "false",
                ["RabbitMQ:Host"] = string.Empty, // blank => AddZwsHealthChecks skips the RabbitMQ readiness check entirely
                ["Redis:ConnectionString"] = string.Empty
            });
        });
    }
}
