using Xunit;

// Every test class boots its own in-process ZWS.Host and writes to shared,
// fixed-path SQLite dev files (the same files a real `dotnet run` would use).
// Running test classes concurrently would race on those files, so the whole
// assembly runs sequentially - slower, but deterministic (requirement 30).
[assembly: CollectionBehavior(DisableTestParallelization = true)]
