using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

public class SchemeManagementEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetReferenceSchemes_ShouldContainTheSeededDewsScheme()
    {
        var response = await _client.GetAsync("/api/paycon/settings/scheme-management/schemes/reference");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var names = doc.RootElement.EnumerateArray().Select(e => e.GetProperty("name").GetString()).ToList();

        names.Should().Contain(n => n != null && n.Contains("DEWS"));
    }

    [Fact]
    public async Task CreateGetUpdateDelete_Scheme_ShouldRoundTrip()
    {
        var uniqueCode = $"IT{DateTime.UtcNow.Ticks % 100000}";
        var createBody = new
        {
            code = uniqueCode,
            name = "Integration Test Scheme",
            currency = "AED",
            operatingBank = "Test Bank",
            description = "Created by an integration test.",
            state = 0, // Active
            toleranceLimit = 50m,
            exchangeRate = 3.6725m
        };

        var createResponse = await _client.PostAsJsonAsync("/api/paycon/settings/scheme-management/schemes", createBody);
        createResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        var newId = (await createResponse.Content.ReadFromJsonAsync<Guid>());

        var getResponse = await _client.GetAsync($"/api/paycon/settings/scheme-management/schemes/{newId}");
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        using (var getDoc = JsonDocument.Parse(await getResponse.Content.ReadAsStringAsync()))
        {
            getDoc.RootElement.GetProperty("code").GetString().Should().Be(uniqueCode);
        }

        var updateBody = new
        {
            name = "Integration Test Scheme (Updated)",
            currency = "AED",
            operatingBank = "Test Bank",
            description = "Updated by an integration test.",
            state = 0,
            toleranceLimit = 75m,
            exchangeRate = 3.6725m
        };
        var updateResponse = await _client.PutAsJsonAsync($"/api/paycon/settings/scheme-management/schemes/{newId}", updateBody);
        updateResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);

        var deleteResponse = await _client.DeleteAsync($"/api/paycon/settings/scheme-management/schemes/{newId}");
        deleteResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);

        var getAfterDelete = await _client.GetAsync($"/api/paycon/settings/scheme-management/schemes/{newId}");
        getAfterDelete.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreateScheme_WithDuplicateCode_ShouldReturnBadRequest()
    {
        var body = new { code = "DEWS", name = "Duplicate", currency = "AED", operatingBank = (string?)null, description = (string?)null, state = 0, toleranceLimit = (decimal?)null, exchangeRate = (decimal?)null };

        var response = await _client.PostAsJsonAsync("/api/paycon/settings/scheme-management/schemes", body);

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
}
