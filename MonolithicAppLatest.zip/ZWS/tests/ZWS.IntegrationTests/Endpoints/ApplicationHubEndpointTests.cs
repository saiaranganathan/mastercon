using System.Net;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

public class ApplicationHubEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetApplications_ShouldReturnAllFourSeededCards()
    {
        var response = await _client.GetAsync("/api/applications");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var codes = doc.RootElement.EnumerateArray().Select(e => e.GetProperty("code").GetString()).ToList();

        codes.Should().BeEquivalentTo(["PAYCON", "COMPLIANCE", "TRADEINSIGHTS", "PARTNERHUB"]);
    }

    [Fact]
    public async Task GetApplications_PayconCard_ShouldBeNativeAndActive()
    {
        var response = await _client.GetAsync("/api/applications");
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());

        var paycon = doc.RootElement.EnumerateArray().Single(e => e.GetProperty("code").GetString() == "PAYCON");

        paycon.GetProperty("isExternal").GetBoolean().Should().BeFalse();
        paycon.GetProperty("isActive").GetBoolean().Should().BeTrue();
        paycon.GetProperty("route").GetString().Should().Be("/paycon/dashboard");
    }
}
