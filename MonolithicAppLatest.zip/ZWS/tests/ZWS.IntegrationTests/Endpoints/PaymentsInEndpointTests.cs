using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

public class PaymentsInEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetBatches_ShouldReturnTheTwoSeededBatches()
    {
        var response = await _client.GetAsync("/api/paycon/reconciliation/payments-in/batches?pageSize=50");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var fileNames = doc.RootElement.GetProperty("items").EnumerateArray().Select(e => e.GetProperty("fileName").GetString()).ToList();

        fileNames.Should().Contain(f => f != null && f.Contains("DEWS"));
        fileNames.Should().Contain(f => f != null && f.Contains("DAMAN"));
    }

    [Fact]
    public async Task UploadFile_ShouldCreateACompletedBatchWithTransactions()
    {
        var referenceResponse = await _client.GetAsync("/api/paycon/settings/scheme-management/schemes/reference");
        using var referenceDoc = JsonDocument.Parse(await referenceResponse.Content.ReadAsStringAsync());
        var firstScheme = referenceDoc.RootElement.EnumerateArray().First();
        var schemeId = firstScheme.GetProperty("id").GetGuid();
        var schemeName = firstScheme.GetProperty("name").GetString();

        var uploadBody = new { fileName = "IT_Upload.csv", schemeId, schemeName };
        var uploadResponse = await _client.PostAsJsonAsync("/api/paycon/reconciliation/payments-in/upload", uploadBody);
        uploadResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        var batchId = await uploadResponse.Content.ReadFromJsonAsync<Guid>();

        var transactionsResponse = await _client.GetAsync($"/api/paycon/reconciliation/payments-in/transactions?batchId={batchId}&pageSize=50");
        transactionsResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await transactionsResponse.Content.ReadAsStringAsync());
        doc.RootElement.GetProperty("totalCount").GetInt32().Should().Be(10);
    }

    [Fact]
    public async Task AddComment_ForUnknownTransaction_ShouldReturnNotFound()
    {
        var response = await _client.PostAsJsonAsync(
            $"/api/paycon/reconciliation/payments-in/transactions/{Guid.NewGuid()}/comment",
            new { comment = "Looks fine." });

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
}
