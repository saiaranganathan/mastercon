using System.Net;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

public class DashboardEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetSnapshot_ShouldReturnMetricsQuickActionsAndProgressBreakdown()
    {
        var response = await _client.GetAsync("/api/paycon/dashboard");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());

        doc.RootElement.GetProperty("metrics").GetArrayLength().Should().BeGreaterThan(0);
        doc.RootElement.GetProperty("quickActions").GetArrayLength().Should().BeGreaterThan(0);
        doc.RootElement.GetProperty("progressBreakdown").GetArrayLength().Should().BeGreaterThan(0);
    }
}
