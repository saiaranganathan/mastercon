using System.Net;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

public class PayconNavigationEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetNavigation_ShouldReturnTopLevelSectionsInDisplayOrder()
    {
        var response = await _client.GetAsync("/api/paycon/navigation");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var names = doc.RootElement.EnumerateArray().Select(e => e.GetProperty("name").GetString()).ToList();

        names.Should().Equal("Dashboard", "Reconciliation", "Insights", "Statements", "Settings");
    }

    [Fact]
    public async Task GetNavigation_Settings_ShouldContainUserAndSchemeAndInsightManagement()
    {
        var response = await _client.GetAsync("/api/paycon/navigation");
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());

        var settings = doc.RootElement.EnumerateArray().Single(e => e.GetProperty("name").GetString() == "Settings");
        var childNames = settings.GetProperty("children").EnumerateArray().Select(c => c.GetProperty("name").GetString()).ToList();

        childNames.Should().BeEquivalentTo(["User Management", "Scheme Management", "Insight Management"]);
    }

    [Fact]
    public async Task GetNavigation_Reconciliation_ShouldContainPaymentsInAndOutWithRoutes()
    {
        var response = await _client.GetAsync("/api/paycon/navigation");
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());

        var reconciliation = doc.RootElement.EnumerateArray().Single(e => e.GetProperty("name").GetString() == "Reconciliation");
        var routes = reconciliation.GetProperty("children").EnumerateArray().Select(c => c.GetProperty("route").GetString()).ToList();

        routes.Should().BeEquivalentTo(["/paycon/reconciliation/payments-in", "/paycon/reconciliation/payments-out"]);
    }
}
