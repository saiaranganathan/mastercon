using System.Net;
using System.Text.Json;
using FluentAssertions;
using Xunit;

namespace ZWS.IntegrationTests.Endpoints;

/// <summary>Covers the BRD-driven Groups / Roles / Users / Permissions surface (PR_UM 1-3).</summary>
public class UserManagementEndpointTests(ZwsWebApplicationFactory factory) : IClassFixture<ZwsWebApplicationFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetGroups_ShouldReturnSeededFinanceGroup()
    {
        var response = await _client.GetAsync("/api/paycon/settings/user-management/groups?pageSize=50");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var names = doc.RootElement.GetProperty("items").EnumerateArray().Select(e => e.GetProperty("name").GetString()).ToList();

        names.Should().Contain("Finance");
    }

    [Fact]
    public async Task GetRoles_ShouldReturnSeededFinanceAnalystRole()
    {
        var response = await _client.GetAsync("/api/paycon/settings/user-management/roles?pageSize=50");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var names = doc.RootElement.GetProperty("items").EnumerateArray().Select(e => e.GetProperty("name").GetString()).ToList();

        names.Should().Contain("FinanceAnalyst");
    }

    [Fact]
    public async Task GetUsers_ShouldReturnSeededUsersWithExpectedStates()
    {
        var response = await _client.GetAsync("/api/paycon/settings/user-management/users?pageSize=50");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var users = doc.RootElement.GetProperty("items").EnumerateArray()
            .ToDictionary(e => e.GetProperty("fullName").GetString()!, e => e.GetProperty("state").GetString());

        users.Should().ContainKey("John Deo").WhoseValue.Should().Be("Inactive");
        users.Should().ContainKey("Priya Sharma").WhoseValue.Should().Be("Terminated");
    }

    [Fact]
    public async Task GetPermissions_ShouldReturnTheFixedEightPermissionCatalog()
    {
        var response = await _client.GetAsync("/api/paycon/settings/user-management/permissions");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());

        doc.RootElement.GetArrayLength().Should().Be(8);
    }

    [Fact]
    public async Task GetUserById_ForUnknownId_ShouldReturnNotFound()
    {
        var response = await _client.GetAsync($"/api/paycon/settings/user-management/users/{Guid.NewGuid()}");

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
}
