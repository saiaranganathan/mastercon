using FluentAssertions;
using Moq;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Groups.Commands;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

public class CreateGroupCommandHandlerTests
{
    private readonly Mock<IGroupRepository> _groupRepository = new();
    private readonly Mock<ISchemeReferenceService> _schemeReferenceService = new();
    private readonly Mock<IUserManagementDbContext> _dbContext = new();

    [Fact]
    public async Task Handle_ShouldCreateGroupWithOnlySelectedSchemes()
    {
        var selectedSchemeId = Guid.NewGuid();
        var otherSchemeId = Guid.NewGuid();

        _schemeReferenceService.Setup(s => s.GetActiveSchemesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([
                new SchemeRefDto(selectedSchemeId, "DEWS"),
                new SchemeRefDto(otherSchemeId, "DAMAN")
            ]);

        Group? capturedGroup = null;
        _groupRepository.Setup(r => r.Add(It.IsAny<Group>())).Callback<Group>(g => capturedGroup = g);
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = new CreateGroupCommandHandler(_groupRepository.Object, _schemeReferenceService.Object, _dbContext.Object);
        var command = new CreateGroupCommand("Finance", GroupState.Active, false, [selectedSchemeId]);

        var result = await handler.Handle(command, CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        capturedGroup.Should().NotBeNull();
        capturedGroup!.Name.Should().Be("Finance");
        capturedGroup.SchemeAssignments.Should().ContainSingle(a => a.SchemeId == selectedSchemeId);
        _dbContext.Verify(d => d.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }
}
