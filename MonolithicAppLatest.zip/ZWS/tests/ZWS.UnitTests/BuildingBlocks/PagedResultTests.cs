using FluentAssertions;
using ZWS.BuildingBlocks.Application.Common;
using Xunit;

namespace ZWS.UnitTests.BuildingBlocks;

public class PagedResultTests
{
    [Fact]
    public void TotalPages_ShouldRoundUp()
    {
        var result = new PagedResult<int>([1, 2, 3], totalCount: 25, page: 1, pageSize: 10);

        result.TotalPages.Should().Be(3);
    }

    [Fact]
    public void HasPreviousPage_ShouldBeFalseOnFirstPage()
    {
        var result = new PagedResult<int>([], totalCount: 25, page: 1, pageSize: 10);

        result.HasPreviousPage.Should().BeFalse();
        result.HasNextPage.Should().BeTrue();
    }

    [Fact]
    public void HasNextPage_ShouldBeFalseOnLastPage()
    {
        var result = new PagedResult<int>([], totalCount: 25, page: 3, pageSize: 10);

        result.HasNextPage.Should().BeFalse();
        result.HasPreviousPage.Should().BeTrue();
    }

    [Fact]
    public void Empty_ShouldHaveNoItemsAndNoPages()
    {
        var result = PagedResult<int>.Empty(1, 10);

        result.Items.Should().BeEmpty();
        result.TotalCount.Should().Be(0);
        result.TotalPages.Should().Be(0);
    }

    [Fact]
    public void PageSize_ShouldBeClampedToMaximum()
    {
        var request = new PagedRequest { PageSize = 999 };

        request.PageSize.Should().Be(200);
    }

    [Fact]
    public void PageSize_ShouldFallBackToDefaultWhenNonPositive()
    {
        var request = new PagedRequest { PageSize = 0 };

        request.PageSize.Should().Be(10);
    }
}
