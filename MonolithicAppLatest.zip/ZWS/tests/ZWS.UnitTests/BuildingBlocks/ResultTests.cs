using FluentAssertions;
using ZWS.BuildingBlocks.Application.Common;
using Xunit;

namespace ZWS.UnitTests.BuildingBlocks;

public class ResultTests
{
    [Fact]
    public void Success_ShouldHaveNoError()
    {
        var result = Result.Success();

        result.IsSuccess.Should().BeTrue();
        result.IsFailure.Should().BeFalse();
        result.Error.Should().Be(Error.None);
    }

    [Fact]
    public void Failure_ShouldCarryTheGivenError()
    {
        var error = Error.NotFound("Thing.NotFound", "Thing was not found.");

        var result = Result.Failure(error);

        result.IsSuccess.Should().BeFalse();
        result.IsFailure.Should().BeTrue();
        result.Error.Should().Be(error);
    }

    [Fact]
    public void GenericSuccess_ShouldExposeValue()
    {
        var result = Result.Success(42);

        result.IsSuccess.Should().BeTrue();
        result.Value.Should().Be(42);
    }

    [Fact]
    public void GenericFailure_AccessingValue_ShouldThrow()
    {
        var result = Result.Failure<int>(Error.Validation("Thing.Invalid", "Invalid."));

        var act = () => result.Value;

        act.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void ImplicitConversion_FromValue_ShouldProduceSuccess()
    {
        Result<string> result = "hello";

        result.IsSuccess.Should().BeTrue();
        result.Value.Should().Be("hello");
    }

    [Theory]
    [InlineData(ErrorType.NotFound)]
    [InlineData(ErrorType.Validation)]
    [InlineData(ErrorType.Conflict)]
    [InlineData(ErrorType.Forbidden)]
    [InlineData(ErrorType.Failure)]
    public void ErrorFactories_ShouldSetCorrectErrorType(ErrorType expected)
    {
        var error = expected switch
        {
            ErrorType.NotFound => Error.NotFound("code", "message"),
            ErrorType.Validation => Error.Validation("code", "message"),
            ErrorType.Conflict => Error.Conflict("code", "message"),
            ErrorType.Forbidden => Error.Forbidden("code", "message"),
            _ => new Error("code", "message")
        };

        error.Type.Should().Be(expected);
    }
}
