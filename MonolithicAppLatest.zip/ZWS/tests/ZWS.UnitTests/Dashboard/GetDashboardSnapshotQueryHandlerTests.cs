using FluentAssertions;
using Moq;
using ZWS.Modules.Paycon.Dashboard.Application.Dtos;
using ZWS.Modules.Paycon.Dashboard.Application.Queries;
using ZWS.Modules.Paycon.Dashboard.Application.Repositories;
using ZWS.Modules.Paycon.Dashboard.Domain;
using Xunit;

namespace ZWS.UnitTests.Dashboard;

public class GetDashboardSnapshotQueryHandlerTests
{
    private readonly Mock<IDashboardRepository> _repository = new();
    private readonly Mock<IDashboardNotificationsReader> _notificationsReader = new();

    [Fact]
    public async Task Handle_ShouldComposeASnapshotFromAllFourWidgetSources()
    {
        _repository.Setup(r => r.GetMetricsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([DashboardMetric.Create("Today's Contributions", "vs last month", "$23M", "$69M", 1)]);
        _repository.Setup(r => r.GetQuickActionsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([DashboardQuickAction.Create("Upload file", "📥", "/paycon/reconciliation/payments-in", 1)]);
        _repository.Setup(r => r.GetRecentActivitiesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([DashboardRecentActivity.Create("Batch reconciled", DateTime.UtcNow, "🔄")]);
        _repository.Setup(r => r.GetProgressBreakdownAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([DashboardProgressSegment.Create("Matched", 52.1m, "#1FA97E", 1)]);
        _notificationsReader.Setup(n => n.GetRecentNotificationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync([new DashboardNotificationDto("New user created", "Shelby Goode", "Info", DateTime.UtcNow, false)]);

        var handler = new GetDashboardSnapshotQueryHandler(_repository.Object, _notificationsReader.Object);

        var result = await handler.Handle(new GetDashboardSnapshotQuery("demo-user"), CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        result.Value.Metrics.Should().ContainSingle();
        result.Value.QuickActions.Should().ContainSingle();
        result.Value.RecentActivities.Should().ContainSingle();
        result.Value.ProgressBreakdown.Should().ContainSingle();
        result.Value.Notifications.Should().ContainSingle();
    }

    [Fact]
    public async Task Handle_WhenNoData_ShouldReturnEmptyCollectionsNotFailure()
    {
        _repository.Setup(r => r.GetMetricsAsync(It.IsAny<CancellationToken>())).ReturnsAsync([]);
        _repository.Setup(r => r.GetQuickActionsAsync(It.IsAny<CancellationToken>())).ReturnsAsync([]);
        _repository.Setup(r => r.GetRecentActivitiesAsync(It.IsAny<CancellationToken>())).ReturnsAsync([]);
        _repository.Setup(r => r.GetProgressBreakdownAsync(It.IsAny<CancellationToken>())).ReturnsAsync([]);
        _notificationsReader.Setup(n => n.GetRecentNotificationsAsync(It.IsAny<CancellationToken>())).ReturnsAsync([]);

        var handler = new GetDashboardSnapshotQueryHandler(_repository.Object, _notificationsReader.Object);

        var result = await handler.Handle(new GetDashboardSnapshotQuery("demo-user"), CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        result.Value.Metrics.Should().BeEmpty();
    }
}
