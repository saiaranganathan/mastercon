using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.SchemeManagement;

public class DeleteSchemeCommandHandlerTests
{
    private readonly Mock<ISchemeRepository> _repository = new();
    private readonly Mock<ISchemeManagementDbContext> _dbContext = new();
    private readonly Mock<ICacheService> _cache = new();

    [Fact]
    public async Task Handle_WhenSchemeNotFound_ShouldReturnNotFound()
    {
        _repository.Setup(r => r.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>())).ReturnsAsync((Scheme?)null);
        var handler = new DeleteSchemeCommandHandler(_repository.Object, _dbContext.Object, _cache.Object);

        var result = await handler.Handle(new DeleteSchemeCommand(Guid.NewGuid()), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.NotFound);
    }

    [Fact]
    public async Task Handle_WhenSchemeExists_ShouldRemoveAndInvalidateReferenceCache()
    {
        var scheme = Scheme.Create("DEWS", "DEWS", "AED", null, null, SchemeState.Active, null, null);
        _repository.Setup(r => r.GetByIdAsync(scheme.Id, It.IsAny<CancellationToken>())).ReturnsAsync(scheme);
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = new DeleteSchemeCommandHandler(_repository.Object, _dbContext.Object, _cache.Object);

        var result = await handler.Handle(new DeleteSchemeCommand(scheme.Id), CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        _repository.Verify(r => r.Remove(scheme), Times.Once);
        _cache.Verify(c => c.RemoveAsync(CacheKeys.SchemeReferenceData, It.IsAny<CancellationToken>()), Times.Once);
    }
}
