using FluentAssertions;
using Moq;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.SchemeManagement;

public class CreateSchemeCommandValidatorTests
{
    private readonly Mock<ISchemeRepository> _repository = new();

    private static CreateSchemeCommand ValidCommand(string code = "DEWS") =>
        new(code, "DEWS Retirement Scheme", "AED", "Emirates NBD", "Description", SchemeState.Active, 100m, 3.6725m);

    [Fact]
    public async Task Validate_WithValidCommand_ShouldSucceed()
    {
        _repository.Setup(r => r.ExistsByCodeAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateSchemeCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand());

        result.IsValid.Should().BeTrue();
    }

    [Fact]
    public async Task Validate_WithDuplicateCode_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByCodeAsync("DEWS", null, It.IsAny<CancellationToken>())).ReturnsAsync(true);
        var validator = new CreateSchemeCommandValidator(_repository.Object);

        var result = await validator.ValidateAsync(ValidCommand());

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateSchemeCommand.Code));
    }

    [Fact]
    public async Task Validate_WithNegativeToleranceLimit_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByCodeAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateSchemeCommandValidator(_repository.Object);
        var command = ValidCommand() with { ToleranceLimit = -5m };

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateSchemeCommand.ToleranceLimit));
    }

    [Fact]
    public async Task Validate_WithZeroExchangeRate_ShouldFail()
    {
        _repository.Setup(r => r.ExistsByCodeAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var validator = new CreateSchemeCommandValidator(_repository.Object);
        var command = ValidCommand() with { ExchangeRate = 0m };

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateSchemeCommand.ExchangeRate));
    }
}
