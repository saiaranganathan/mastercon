using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Abstractions;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;
using Xunit;

namespace ZWS.UnitTests.PaymentsIn;

public class UploadPaymentFileCommandHandlerTests
{
    private readonly Mock<IPaymentBatchRepository> _repository = new();
    private readonly Mock<IPaymentsInDbContext> _dbContext = new();
    private readonly Mock<IEventBus> _eventBus = new();

    [Fact]
    public async Task Handle_ShouldCreateACompletedBatchWithTenReconciledTransactions()
    {
        PaymentBatch? captured = null;
        _repository.Setup(r => r.Add(It.IsAny<PaymentBatch>())).Callback<PaymentBatch>(b => captured = b);
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = new UploadPaymentFileCommandHandler(_repository.Object, _dbContext.Object, _eventBus.Object);
        var command = new UploadPaymentFileCommand("SCB_DEWS_Aug2026.csv", Guid.NewGuid(), "DEWS");

        var result = await handler.Handle(command, CancellationToken.None);

        result.IsSuccess.Should().BeTrue();
        captured.Should().NotBeNull();
        captured!.Status.Should().Be(PaymentBatchStatus.Completed);
        captured.Transactions.Should().HaveCount(10);
        (captured.MatchedCount + captured.MismatchedCount).Should().Be(10);
    }

    [Fact]
    public async Task Handle_ShouldPublishAPaymentBatchReconciledIntegrationEvent()
    {
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);
        var handler = new UploadPaymentFileCommandHandler(_repository.Object, _dbContext.Object, _eventBus.Object);
        var command = new UploadPaymentFileCommand("SCB_DAMAN_Aug2026.csv", Guid.NewGuid(), "DAMAN");

        await handler.Handle(command, CancellationToken.None);

        _eventBus.Verify(b => b.PublishAsync(
            It.Is<PaymentBatchReconciledIntegrationEvent>(e => e.FileName == "SCB_DAMAN_Aug2026.csv"),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Handle_IsDeterministic_ForTheSameBatchId()
    {
        // The handler seeds its Random from the batch's own Guid, so re-running reconciliation
        // logic for a given batch always produces the same match/mismatch split (requirement 30).
        _dbContext.Setup(d => d.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);
        var handler = new UploadPaymentFileCommandHandler(_repository.Object, _dbContext.Object, _eventBus.Object);

        PaymentBatch? first = null;
        _repository.Setup(r => r.Add(It.IsAny<PaymentBatch>())).Callback<PaymentBatch>(b => first = b);
        await handler.Handle(new UploadPaymentFileCommand("a.csv", Guid.NewGuid(), "DEWS"), CancellationToken.None);

        first!.Transactions.Select(t => t.Status).Should().OnlyContain(s => s == PaymentTransactionStatus.Matched || s == PaymentTransactionStatus.Mismatched);
    }
}
