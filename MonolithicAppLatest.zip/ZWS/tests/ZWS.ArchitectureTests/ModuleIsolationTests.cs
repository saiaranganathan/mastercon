using FluentAssertions;
using NetArchTest.Rules;
using ZWS.Modules.Paycon.Dashboard;
using ZWS.Modules.Paycon.Notifications;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn;
using ZWS.Modules.Paycon.Settings.SchemeManagement;
using ZWS.Modules.Paycon.Settings.UserManagement;
using Xunit;

namespace ZWS.ArchitectureTests;

/// <summary>
/// Turns the modular-monolith cross-module rules (requirement 3, 9) from
/// prose into a build-breaking check: the Notifications module stays fully
/// isolated, and the one sanctioned UserManagement -> SchemeManagement
/// reference never runs in reverse.
/// </summary>
public class ModuleIsolationTests
{
    [Fact]
    public void NotificationsModule_ShouldNotDependOnAnyOtherPayconModule()
    {
        var result = Types.InAssembly(typeof(NotificationsModule).Assembly)
            .ShouldNot()
            .HaveDependencyOnAny(
                "ZWS.Modules.Paycon.Settings.UserManagement",
                "ZWS.Modules.Paycon.Settings.SchemeManagement",
                "ZWS.Modules.Paycon.Dashboard",
                "ZWS.Modules.Paycon.Reconciliation.PaymentsIn")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FailureSummary(result));
    }

    [Fact]
    public void UserManagementModule_ShouldNotDependOnNotifications()
    {
        var result = Types.InAssembly(typeof(UserManagementModule).Assembly)
            .ShouldNot()
            .HaveDependencyOn("ZWS.Modules.Paycon.Notifications")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FailureSummary(result));
    }

    [Fact]
    public void PaymentsInModule_ShouldNotDependOnNotifications()
    {
        // PaymentsIn only talks to Notifications through a RabbitMQ integration event
        // (PaymentBatchReconciledIntegrationEvent) - zero project reference expected.
        var result = Types.InAssembly(typeof(PaymentsInModule).Assembly)
            .ShouldNot()
            .HaveDependencyOn("ZWS.Modules.Paycon.Notifications")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FailureSummary(result));
    }

    [Fact]
    public void SchemeManagementModule_ShouldNotDependOnUserManagement()
    {
        // The reference is sanctioned in one direction only: UserManagement reads
        // SchemeManagement's public query, never the other way around.
        var result = Types.InAssembly(typeof(SchemeManagementModule).Assembly)
            .ShouldNot()
            .HaveDependencyOn("ZWS.Modules.Paycon.Settings.UserManagement")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FailureSummary(result));
    }

    [Fact]
    public void NotificationsModule_ShouldNotDependOnDashboard()
    {
        // Dashboard is allowed to read Notifications (IDashboardNotificationsReader);
        // the reverse dependency would break the module's isolation.
        var result = Types.InAssembly(typeof(NotificationsModule).Assembly)
            .ShouldNot()
            .HaveDependencyOn("ZWS.Modules.Paycon.Dashboard")
            .GetResult();

        result.IsSuccessful.Should().BeTrue(FailureSummary(result));
    }

    [Fact]
    public void DashboardModule_IsAllowedToDependOnNotifications()
    {
        // Documents the one sanctioned Dashboard -> Notifications reference
        // (DashboardNotificationsReader) so a future refactor that removes it
        // is a deliberate, visible change rather than a silent regression.
        // Asserting the negative rule here is *expected* to fail - that failure
        // is the proof the dependency exists exactly where the comments say it does.
        var result = Types.InAssembly(typeof(DashboardModule).Assembly)
            .That().ResideInNamespace("ZWS.Modules.Paycon.Dashboard.Infrastructure")
            .ShouldNot()
            .HaveDependencyOn("ZWS.Modules.Paycon.Notifications")
            .GetResult();

        result.IsSuccessful.Should().BeFalse("DashboardNotificationsReader in Infrastructure is expected to reference Notifications' public query");
    }

    private static string FailureSummary(TestResult result) =>
        result.FailingTypeNames is null
            ? "no further detail available"
            : string.Join(", ", result.FailingTypeNames);
}
