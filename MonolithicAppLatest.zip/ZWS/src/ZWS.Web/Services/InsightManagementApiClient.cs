using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class InsightManagementApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/settings/insight-management";

    public Task<ApiResult<IReadOnlyCollection<InsightConfigurationDto>>> GetConfigurationsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<InsightConfigurationDto>>(BaseRoute, cancellationToken);

    public Task<ApiResult> ToggleAsync(Guid id, bool isEnabled, CancellationToken cancellationToken = default) =>
        PostAsync($"{BaseRoute}/{id}/toggle", isEnabled, cancellationToken);
}
