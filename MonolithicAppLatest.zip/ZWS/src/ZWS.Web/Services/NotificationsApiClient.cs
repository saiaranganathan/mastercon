using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class NotificationsApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/notifications";

    public Task<ApiResult<IReadOnlyCollection<NotificationDto>>> GetRecentAsync(int take = 10, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("take", take);
        return GetAsync<IReadOnlyCollection<NotificationDto>>($"{BaseRoute}{qs}", cancellationToken);
    }

    public Task<ApiResult> MarkReadAsync(Guid id, CancellationToken cancellationToken = default) =>
        PostAsync($"{BaseRoute}/{id}/mark-read", new { }, cancellationToken);
}
