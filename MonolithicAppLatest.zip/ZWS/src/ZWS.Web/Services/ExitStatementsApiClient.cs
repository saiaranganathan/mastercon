using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class ExitStatementsApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/statements/exit-statements";

    public Task<ApiResult<PagedResult<ExitStatementDto>>> GetAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<ExitStatementDto>>($"{BaseRoute}{qs}", cancellationToken);
    }

    public Task<ApiResult> GenerateAsync(Guid id, CancellationToken cancellationToken = default) =>
        PostAsync($"{BaseRoute}/{id}/generate", new { }, cancellationToken);
}
