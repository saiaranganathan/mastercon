using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class AnnualStatementsApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<PagedResult<AnnualStatementDto>>> GetAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<AnnualStatementDto>>($"api/paycon/statements/annual-statements{qs}", cancellationToken);
    }
}
