using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class PayconNavigationApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<NavigationItemDto>>> GetNavigationAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<NavigationItemDto>>("api/paycon/navigation", cancellationToken);
}
