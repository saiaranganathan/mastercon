using System.Text;

namespace ZWS.Web.Services;

/// <summary>
/// Minimal dependency-free query-string builder (deliberately avoids
/// System.Web.HttpUtility, which pulls in more of the BCL than a trimmed
/// Blazor WebAssembly build needs for something this small).
/// </summary>
public sealed class QueryStringBuilder
{
    private readonly StringBuilder _sb = new();
    private bool _hasAny;

    public QueryStringBuilder Add(string key, object? value)
    {
        if (value is null) return this;
        var text = value switch
        {
            bool b => b ? "true" : "false",
            _ => value.ToString()
        };
        if (string.IsNullOrWhiteSpace(text)) return this;

        _sb.Append(_hasAny ? '&' : '?');
        _sb.Append(Uri.EscapeDataString(key)).Append('=').Append(Uri.EscapeDataString(text));
        _hasAny = true;
        return this;
    }

    public override string ToString() => _sb.ToString();
}
