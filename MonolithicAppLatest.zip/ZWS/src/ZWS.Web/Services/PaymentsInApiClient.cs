using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class PaymentsInApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/reconciliation/payments-in";

    public Task<ApiResult<PagedResult<PaymentBatchListItemDto>>> GetBatchesAsync(
        int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder()
            .Add("page", page)
            .Add("pageSize", pageSize)
            .Add("search", search);
        return GetAsync<PagedResult<PaymentBatchListItemDto>>($"{BaseRoute}/batches{qs}", cancellationToken);
    }

    public Task<ApiResult<PagedResult<PaymentTransactionDto>>> GetTransactionsAsync(
        Guid? batchId, string? status, int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder()
            .Add("batchId", batchId)
            .Add("status", status)
            .Add("page", page)
            .Add("pageSize", pageSize)
            .Add("search", search);
        return GetAsync<PagedResult<PaymentTransactionDto>>($"{BaseRoute}/transactions{qs}", cancellationToken);
    }

    public Task<ApiResult<Guid>> UploadFileAsync(UploadPaymentFileRequest request, CancellationToken cancellationToken = default) =>
        PostAsync<UploadPaymentFileRequest, Guid>($"{BaseRoute}/upload", request, cancellationToken);

    public Task<ApiResult> AddCommentAsync(Guid transactionId, string comment, CancellationToken cancellationToken = default) =>
        PostAsync($"{BaseRoute}/transactions/{transactionId}/comment", new AddCommentRequest(comment), cancellationToken);
}
