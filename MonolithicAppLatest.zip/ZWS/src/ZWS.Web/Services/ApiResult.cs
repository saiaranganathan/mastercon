namespace ZWS.Web.Services;

/// <summary>
/// Uniform client-side result envelope so pages never need try/catch around
/// every HttpClient call - they check IsSuccess and read either Value or Error,
/// mirroring the server-side Result&lt;T&gt; pattern (requirement 22, 32).
/// </summary>
public sealed class ApiResult<T>
{
    public bool IsSuccess { get; }
    public T? Value { get; }
    public string? ErrorMessage { get; }

    private ApiResult(bool isSuccess, T? value, string? errorMessage)
    {
        IsSuccess = isSuccess;
        Value = value;
        ErrorMessage = errorMessage;
    }

    public static ApiResult<T> Success(T value) => new(true, value, null);
    public static ApiResult<T> Failure(string message) => new(false, default, message);
}

public sealed class ApiResult
{
    public bool IsSuccess { get; }
    public string? ErrorMessage { get; }

    private ApiResult(bool isSuccess, string? errorMessage)
    {
        IsSuccess = isSuccess;
        ErrorMessage = errorMessage;
    }

    public static ApiResult Success() => new(true, null);
    public static ApiResult Failure(string message) => new(false, message);
}
