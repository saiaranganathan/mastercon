using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class SchemeManagementApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/settings/scheme-management/schemes";

    public Task<ApiResult<PagedResult<SchemeListItemDto>>> GetSchemesAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<SchemeListItemDto>>($"{BaseRoute}{qs}", cancellationToken);
    }

    public Task<ApiResult<SchemeDetailDto>> GetSchemeAsync(Guid id, CancellationToken cancellationToken = default) =>
        GetAsync<SchemeDetailDto>($"{BaseRoute}/{id}", cancellationToken);

    public Task<ApiResult<IReadOnlyCollection<SchemeReferenceItemDto>>> GetActiveForReferenceAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<SchemeReferenceItemDto>>($"{BaseRoute}/reference", cancellationToken);

    public Task<ApiResult<Guid>> CreateSchemeAsync(CreateSchemeRequest request, CancellationToken cancellationToken = default) =>
        PostAsync<CreateSchemeRequest, Guid>(BaseRoute, request, cancellationToken);

    public Task<ApiResult> UpdateSchemeAsync(Guid id, UpdateSchemeRequest request, CancellationToken cancellationToken = default) =>
        PutAsync($"{BaseRoute}/{id}", request, cancellationToken);

    public Task<ApiResult> DeleteSchemeAsync(Guid id, CancellationToken cancellationToken = default) =>
        DeleteAsync($"{BaseRoute}/{id}", cancellationToken);
}
