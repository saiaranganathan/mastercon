using Microsoft.AspNetCore.SignalR.Client;

namespace ZWS.Web.Services;

/// <summary>
/// Thin wrapper around a single shared HubConnection to /payconHub
/// (requirement 24). Registered as a singleton so every page/component
/// subscribes to the same live connection instead of opening its own.
/// Client event names match ZWS.BuildingBlocks.Realtime.PayconHub's
/// documented contract: PaymentStatusUpdated, ReconciliationUpdated,
/// DashboardMetricUpdated, NotificationReceived.
/// </summary>
public sealed class PayconRealtimeService : IAsyncDisposable
{
    private readonly HubConnection _connection;
    private Task? _startTask;

    public event Action<string>? PaymentStatusUpdated;
    public event Action<string>? ReconciliationUpdated;
    public event Action<string>? DashboardMetricUpdated;
    public event Action<string>? NotificationReceived;

    public HubConnectionState State => _connection.State;

    public PayconRealtimeService(string apiBaseAddress)
    {
        _connection = new HubConnectionBuilder()
            .WithUrl($"{apiBaseAddress.TrimEnd('/')}/payconHub")
            .WithAutomaticReconnect()
            .Build();

        _connection.On<string>("PaymentStatusUpdated", payload => PaymentStatusUpdated?.Invoke(payload));
        _connection.On<string>("ReconciliationUpdated", payload => ReconciliationUpdated?.Invoke(payload));
        _connection.On<string>("DashboardMetricUpdated", payload => DashboardMetricUpdated?.Invoke(payload));
        _connection.On<string>("NotificationReceived", payload => NotificationReceived?.Invoke(payload));
    }

    /// <summary>Idempotent, concurrency-safe start - safe to call from every page's OnInitializedAsync.</summary>
    public Task EnsureConnectedAsync()
    {
        if (_connection.State == HubConnectionState.Disconnected)
        {
            _startTask = _connection.StartAsync();
        }
        return _startTask ?? Task.CompletedTask;
    }

    public async ValueTask DisposeAsync() => await _connection.DisposeAsync();
}
