using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class DashboardApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<DashboardSnapshotDto>> GetSnapshotAsync(CancellationToken cancellationToken = default) =>
        GetAsync<DashboardSnapshotDto>("api/paycon/dashboard", cancellationToken);
}
