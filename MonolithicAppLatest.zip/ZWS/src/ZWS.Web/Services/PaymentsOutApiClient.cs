using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class PaymentsOutApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/reconciliation/payments-out";

    public Task<ApiResult<PagedResult<PaymentOutDto>>> GetPaymentsOutAsync(int page = 1, int pageSize = 20, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize);
        return GetAsync<PagedResult<PaymentOutDto>>($"{BaseRoute}{qs}", cancellationToken);
    }

    public Task<ApiResult> CreateAsync(CreatePaymentOutRequest request, CancellationToken cancellationToken = default) =>
        PostAsync(BaseRoute, request, cancellationToken);
}
