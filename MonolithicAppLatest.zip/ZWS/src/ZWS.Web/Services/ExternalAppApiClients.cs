using ZWS.Web.Models;

namespace ZWS.Web.Services;

/// <summary>
/// Compliance, Trade Insights and PartnerHub are external applications
/// (requirement 17) - ZWS.Web only shows a lightweight preview backed by
/// their public summary endpoint; the full experience lives outside ZWS.
/// </summary>
public sealed class ComplianceApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<ComplianceCaseDto>>> GetSummaryAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<ComplianceCaseDto>>("api/compliance/summary", cancellationToken);
}

public sealed class TradeInsightsApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<TradePositionDto>>> GetPositionsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<TradePositionDto>>("api/trade-insights/positions", cancellationToken);
}

public sealed class PartnerHubApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<PartnerDto>>> GetPartnersAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<PartnerDto>>("api/partner-hub/partners", cancellationToken);
}
