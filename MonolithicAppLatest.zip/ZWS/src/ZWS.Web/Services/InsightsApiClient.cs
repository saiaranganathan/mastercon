using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class InsightsApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<IReadOnlyCollection<InsightDto>>> GetInsightsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<InsightDto>>("api/paycon/insights", cancellationToken);
}
