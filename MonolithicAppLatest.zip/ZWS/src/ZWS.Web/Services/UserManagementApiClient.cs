using ZWS.Web.Models;

namespace ZWS.Web.Services;

/// <summary>Backs the Settings > User Management screen (Groups / Roles / Users / Permission Matrix tabs, per the BRD).</summary>
public sealed class UserManagementApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/settings/user-management";

    // ---- Groups (PR_UM-1.x) ------------------------------------------------
    public Task<ApiResult<PagedResult<GroupListItemDto>>> GetGroupsAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<GroupListItemDto>>($"{BaseRoute}/groups{qs}", cancellationToken);
    }

    public Task<ApiResult<GroupDetailDto>> GetGroupAsync(Guid id, CancellationToken cancellationToken = default) =>
        GetAsync<GroupDetailDto>($"{BaseRoute}/groups/{id}", cancellationToken);

    public Task<ApiResult<Guid>> CreateGroupAsync(CreateGroupRequest request, CancellationToken cancellationToken = default) =>
        PostAsync<CreateGroupRequest, Guid>($"{BaseRoute}/groups", request, cancellationToken);

    public Task<ApiResult> UpdateGroupAsync(Guid id, UpdateGroupRequest request, CancellationToken cancellationToken = default) =>
        PutAsync($"{BaseRoute}/groups/{id}", request, cancellationToken);

    public Task<ApiResult> DeleteGroupAsync(Guid id, CancellationToken cancellationToken = default) =>
        DeleteAsync($"{BaseRoute}/groups/{id}", cancellationToken);

    // ---- Roles (PR_UM 2.x) --------------------------------------------------
    public Task<ApiResult<PagedResult<RoleListItemDto>>> GetRolesAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<RoleListItemDto>>($"{BaseRoute}/roles{qs}", cancellationToken);
    }

    public Task<ApiResult<RoleDetailDto>> GetRoleAsync(Guid id, CancellationToken cancellationToken = default) =>
        GetAsync<RoleDetailDto>($"{BaseRoute}/roles/{id}", cancellationToken);

    public Task<ApiResult<Guid>> CreateRoleAsync(CreateRoleRequest request, CancellationToken cancellationToken = default) =>
        PostAsync<CreateRoleRequest, Guid>($"{BaseRoute}/roles", request, cancellationToken);

    public Task<ApiResult> UpdateRoleAsync(Guid id, UpdateRoleRequest request, CancellationToken cancellationToken = default) =>
        PutAsync($"{BaseRoute}/roles/{id}", request, cancellationToken);

    public Task<ApiResult> DeleteRoleAsync(Guid id, CancellationToken cancellationToken = default) =>
        DeleteAsync($"{BaseRoute}/roles/{id}", cancellationToken);

    // ---- Users (PR_UM 3.x) --------------------------------------------------
    public Task<ApiResult<PagedResult<UserListItemDto>>> GetUsersAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<UserListItemDto>>($"{BaseRoute}/users{qs}", cancellationToken);
    }

    public Task<ApiResult<UserDetailDto>> GetUserAsync(Guid id, CancellationToken cancellationToken = default) =>
        GetAsync<UserDetailDto>($"{BaseRoute}/users/{id}", cancellationToken);

    public Task<ApiResult<IReadOnlyCollection<SupervisorOptionDto>>> GetSupervisorCandidatesAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<SupervisorOptionDto>>($"{BaseRoute}/users/supervisors", cancellationToken);

    public Task<ApiResult<Guid>> CreateUserAsync(CreateUserRequest request, CancellationToken cancellationToken = default) =>
        PostAsync<CreateUserRequest, Guid>($"{BaseRoute}/users", request, cancellationToken);

    public Task<ApiResult> UpdateUserAsync(Guid id, UpdateUserRequest request, CancellationToken cancellationToken = default) =>
        PutAsync($"{BaseRoute}/users/{id}", request, cancellationToken);

    public Task<ApiResult> DeleteUserAsync(Guid id, CancellationToken cancellationToken = default) =>
        DeleteAsync($"{BaseRoute}/users/{id}", cancellationToken);

    // ---- Permission matrix catalog ------------------------------------------
    public Task<ApiResult<IReadOnlyCollection<PermissionOptionDto>>> GetPermissionsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<IReadOnlyCollection<PermissionOptionDto>>($"{BaseRoute}/permissions", cancellationToken);
}
