namespace ZWS.Web.Models;

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.SchemeManagement.Domain.SchemeState.</summary>
public enum SchemeState { Active, Inactive }

public sealed record SchemeListItemDto(
    Guid Id, string Code, string Name, string Currency, string? OperatingBank, string State,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record SchemeDetailDto(
    Guid Id, string Code, string Name, string Currency, string? OperatingBank, string? Description, string State,
    decimal? ToleranceLimit, decimal? ExchangeRate,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record SchemeReferenceItemDto(Guid Id, string Name);

public sealed record CreateSchemeRequest(string Code, string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
public sealed record UpdateSchemeRequest(string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
