namespace ZWS.Web.Models;

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.GroupState.</summary>
public enum GroupState { Active, Inactive }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.RoleState.</summary>
public enum RoleState { Active, Inactive }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.UserState.</summary>
public enum UserState { Active, Inactive, Terminated }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.PermissionCode - the fixed catalog
/// behind every Permission Matrix checkbox list (PR_UM 2.1).</summary>
public enum PermissionCode { View, Create, Edit, Delete, TransactionApproval, ManageGroup, ManageRole, ManageUsers }

public sealed record SchemeRefDto(Guid SchemeId, string SchemeName);

public sealed record GroupListItemDto(
    Guid Id, string Name, string AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record GroupDetailDto(
    Guid Id, string Name, IReadOnlyCollection<SchemeRefDto> AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);
public sealed record UpdateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);

public sealed record RoleListItemDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record RoleDetailDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    IReadOnlyCollection<string> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateRoleRequest(string Name, Guid GroupId, string? Description, RoleState State, IReadOnlyCollection<PermissionCode> Permissions);
public sealed record UpdateRoleRequest(string Name, string? Description, RoleState State, IReadOnlyCollection<PermissionCode> Permissions);

public sealed record GroupRefDto(Guid GroupId, string GroupName);
public sealed record RoleRefDto(Guid RoleId, string RoleName);
public sealed record SupervisorOptionDto(Guid Id, string FullName);

public sealed record UserListItemDto(
    Guid Id, string FullName, string Email, string AssignedPlans, string? SupervisorName, string State, bool IsSupervisor,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record UserDetailDto(
    Guid Id, string FullName, string Email,
    IReadOnlyCollection<SchemeRefDto> AssignedPlans,
    Guid? SupervisorId, string? SupervisorName, bool IsSupervisor, string State,
    IReadOnlyCollection<GroupRefDto> Groups,
    IReadOnlyCollection<RoleRefDto> Roles,
    IReadOnlyCollection<string> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateUserRequest(
    string FullName, string Email, Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PermissionCode> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);

public sealed record UpdateUserRequest(
    Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PermissionCode> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);

public sealed record PermissionOptionDto(string Code, string Label);
