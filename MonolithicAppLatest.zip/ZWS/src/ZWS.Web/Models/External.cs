namespace ZWS.Web.Models;

public sealed record ComplianceCaseDto(Guid Id, string Title, string Category, string Status, DateTime RaisedAt);
public sealed record TradePositionDto(Guid Id, string Instrument, string Fund, decimal MarketValue, decimal DayChangePercentage);
public sealed record PartnerDto(Guid Id, string Name, string Region, string Status);
