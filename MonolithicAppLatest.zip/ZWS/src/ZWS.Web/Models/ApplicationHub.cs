namespace ZWS.Web.Models;

public sealed record ApplicationCardDto(
    Guid Id, string Code, string Name, string Description, string Icon, string? ImageUri,
    string BaseColor, string Route, int DisplayOrder, bool IsActive, bool IsExternal, string Status);
