namespace ZWS.Web.Models;

public sealed record NavigationItemDto(
    Guid Id, string Name, string? Route, string Icon, int DisplayOrder, IReadOnlyCollection<NavigationItemDto> Children);
