namespace ZWS.Web.Models;

public sealed record InsightDto(Guid Id, string Title, string Category, string ValueDisplay, decimal TrendPercentage);

public sealed record ExitStatementDto(Guid Id, string EmployeeName, string SchemeName, DateTime ExitDate, decimal FinalAmount, string Currency, string Status);
public sealed record AnnualStatementDto(Guid Id, string EmployeeName, string SchemeName, int Year, decimal TotalContribution, string Currency);

public sealed record InsightConfigurationDto(Guid Id, string Name, string? Description, bool IsEnabled);

public sealed record NotificationDto(Guid Id, string Title, string Description, string Severity, DateTime OccurredAt, bool IsRead);
