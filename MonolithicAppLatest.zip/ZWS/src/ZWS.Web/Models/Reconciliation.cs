namespace ZWS.Web.Models;

public sealed record PaymentBatchListItemDto(
    Guid Id, string FileName, string SchemeName, string Status, DateTime UploadedAt,
    int TotalRecords, int MatchedCount, int MismatchedCount);

public sealed record PaymentTransactionDto(
    Guid Id, Guid BatchId, string EmployeeName, string EmployeeId, decimal Amount, string Currency,
    string PayPeriod, string Status, bool IsProcessed, string? Comments);

public sealed record UploadPaymentFileRequest(string FileName, Guid SchemeId, string SchemeName);
public sealed record AddCommentRequest(string Comment);

public sealed record PaymentOutDto(Guid Id, string BeneficiaryName, string SchemeName, decimal Amount, string Currency, string Status, DateTime RequestedAt);
public sealed record CreatePaymentOutRequest(string BeneficiaryName, string SchemeName, decimal Amount, string Currency);
