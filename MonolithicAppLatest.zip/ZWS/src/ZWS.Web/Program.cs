using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ZWS.Web;
using ZWS.Web.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// The API base address is provided by wwwroot/appsettings*.json ("ApiBaseAddress").
// It defaults to the ZWS.Host dev port (see src/ZWS.Host/Properties/launchSettings.json)
// so `dotnet run` works out of the box against a locally running Host.
var apiBaseAddress = builder.Configuration["ApiBaseAddress"] ?? "https://localhost:5201";

builder.Services.AddScoped(_ => new HttpClient { BaseAddress = new Uri(apiBaseAddress) });

builder.Services.AddScoped<ApplicationHubApiClient>();
builder.Services.AddScoped<PayconNavigationApiClient>();
builder.Services.AddScoped<DashboardApiClient>();
builder.Services.AddScoped<PaymentsInApiClient>();
builder.Services.AddScoped<PaymentsOutApiClient>();
builder.Services.AddScoped<InsightsApiClient>();
builder.Services.AddScoped<ExitStatementsApiClient>();
builder.Services.AddScoped<AnnualStatementsApiClient>();
builder.Services.AddScoped<UserManagementApiClient>();
builder.Services.AddScoped<SchemeManagementApiClient>();
builder.Services.AddScoped<InsightManagementApiClient>();
builder.Services.AddScoped<NotificationsApiClient>();
builder.Services.AddScoped<ComplianceApiClient>();
builder.Services.AddScoped<TradeInsightsApiClient>();
builder.Services.AddScoped<PartnerHubApiClient>();

// Single shared SignalR connection to /payconHub (requirement 24), consumed by
// any page/component that needs live PaymentStatusUpdated / ReconciliationUpdated /
// DashboardMetricUpdated / NotificationReceived events.
builder.Services.AddSingleton(sp => new PayconRealtimeService(apiBaseAddress));

await builder.Build().RunAsync();
