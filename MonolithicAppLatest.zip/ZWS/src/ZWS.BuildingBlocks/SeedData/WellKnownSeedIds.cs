namespace ZWS.BuildingBlocks.SeedData;

/// <summary>
/// Fixed, deterministic GUIDs shared by more than one module's dummy-data
/// seeder (requirement 30). Because each module owns its own DbContext there
/// is no real foreign key across them - these constants are simply how the
/// UserManagement seed and the SchemeManagement seed agree on "Scheme #3 is
/// called DEWS" without either module touching the other's database.
/// </summary>
public static class WellKnownSeedIds
{
    public static readonly Guid SchemeDews = Guid.Parse("10000000-0000-0000-0000-000000000001");
    public static readonly Guid SchemeDubaiGovernment = Guid.Parse("10000000-0000-0000-0000-000000000002");
    public static readonly Guid SchemeDaman = Guid.Parse("10000000-0000-0000-0000-000000000003");
    public static readonly Guid SchemeDubaiGovernmentAed = Guid.Parse("10000000-0000-0000-0000-000000000004");
    public static readonly Guid SchemeAdnoc = Guid.Parse("10000000-0000-0000-0000-000000000005");
}
