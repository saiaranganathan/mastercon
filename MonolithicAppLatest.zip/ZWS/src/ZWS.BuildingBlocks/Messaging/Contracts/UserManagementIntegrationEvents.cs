namespace ZWS.BuildingBlocks.Messaging.Contracts;

/// <summary>
/// Cross-module integration event contracts. Living here (in the shared
/// kernel) rather than inside the UserManagement module itself is what lets
/// the Notifications module subscribe to them without ever project-referencing
/// UserManagement, and vice versa (requirement 9: Notifications integrates
/// exclusively via MediatR/RabbitMQ).
/// </summary>
public sealed record UserCreatedIntegrationEvent(Guid UserId, string FullName, string Email, string CreatedBy) : IntegrationEvent;

public sealed record UserStateChangedIntegrationEvent(Guid UserId, string FullName, string PreviousState, string NewState, string ChangedBy) : IntegrationEvent;

public sealed record GroupDeletedIntegrationEvent(Guid GroupId, string GroupName, string DeletedBy) : IntegrationEvent;

public sealed record RoleDeletedIntegrationEvent(Guid RoleId, string RoleName, string DeletedBy) : IntegrationEvent;

/// <summary>Published by Reconciliation.PaymentsIn when a batch finishes reconciling (requirement 24).</summary>
public sealed record PaymentBatchReconciledIntegrationEvent(Guid BatchId, string FileName, int MatchedCount, int MismatchedCount) : IntegrationEvent;
