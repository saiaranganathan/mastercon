namespace ZWS.BuildingBlocks.Messaging;

public sealed class RabbitMqOptions
{
    public const string SectionName = "RabbitMQ";

    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string Username { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string VirtualHost { get; set; } = "/";
    public string ExchangeName { get; set; } = "zws.integration-events";
    public string DeadLetterExchangeName { get; set; } = "zws.integration-events.dlx";
    public int RetryCount { get; set; } = 3;
    public bool Enabled { get; set; } = true;
}
