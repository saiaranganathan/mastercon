namespace ZWS.BuildingBlocks.Messaging;

/// <summary>
/// A fact published across module/application boundaries over RabbitMQ.
/// Unlike a DomainEvent (in-process, MediatR only), an IntegrationEvent is
/// serialized and may be consumed by a different module - or, per requirement
/// 9, always by the Notifications module.
/// </summary>
public abstract record IntegrationEvent
{
    public Guid EventId { get; init; } = Guid.NewGuid();
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;

    /// <summary>Routing key / event type name used for the RabbitMQ topic exchange. Defaults to the CLR type name.</summary>
    public virtual string EventType => GetType().Name;
}
