using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace ZWS.BuildingBlocks.Messaging;

/// <summary>
/// Generic background consumer: declares a durable queue bound to the shared
/// topic exchange for one event type, dead-letters poison messages after the
/// configured retry count, and resolves a fresh, scoped
/// <see cref="IIntegrationEventHandler{TEvent}"/> per message.
/// </summary>
public sealed class RabbitMqIntegrationEventConsumer<TEvent>(
    RabbitMqConnection connection,
    IServiceScopeFactory scopeFactory,
    IOptions<RabbitMqOptions> options,
    ILogger<RabbitMqIntegrationEventConsumer<TEvent>> logger,
    string queueName) : BackgroundService
    where TEvent : IntegrationEvent
{
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);
    private readonly RabbitMqOptions _options = options.Value;
    private readonly string _routingKey = typeof(TEvent).Name;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var conn = await connection.GetConnectionAsync(stoppingToken);
        if (conn is null)
        {
            logger.LogWarning("RabbitMQ unavailable - consumer for {Queue} will not start", queueName);
            return;
        }

        var channel = await conn.CreateChannelAsync(cancellationToken: stoppingToken);

        await channel.ExchangeDeclareAsync(_options.ExchangeName, ExchangeType.Topic, durable: true, autoDelete: false, cancellationToken: stoppingToken);
        await channel.ExchangeDeclareAsync(_options.DeadLetterExchangeName, ExchangeType.Fanout, durable: true, autoDelete: false, cancellationToken: stoppingToken);

        var dlq = $"{queueName}.dlq";
        await channel.QueueDeclareAsync(dlq, durable: true, exclusive: false, autoDelete: false, cancellationToken: stoppingToken);
        await channel.QueueBindAsync(dlq, _options.DeadLetterExchangeName, routingKey: string.Empty, cancellationToken: stoppingToken);

        var queueArgs = new Dictionary<string, object?>
        {
            ["x-dead-letter-exchange"] = _options.DeadLetterExchangeName
        };
        await channel.QueueDeclareAsync(queueName, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs, cancellationToken: stoppingToken);
        await channel.QueueBindAsync(queueName, _options.ExchangeName, routingKey: _routingKey, cancellationToken: stoppingToken);
        await channel.BasicQosAsync(0, prefetchCount: 10, global: false, cancellationToken: stoppingToken);

        var consumer = new AsyncEventingBasicConsumer(channel);
        consumer.ReceivedAsync += async (_, ea) =>
        {
            try
            {
                var json = Encoding.UTF8.GetString(ea.Body.Span);
                var @event = JsonSerializer.Deserialize<TEvent>(json, SerializerOptions);
                if (@event is null)
                {
                    await channel.BasicNackAsync(ea.DeliveryTag, multiple: false, requeue: false, cancellationToken: stoppingToken);
                    return;
                }

                using var scope = scopeFactory.CreateScope();
                var handler = scope.ServiceProvider.GetRequiredService<IIntegrationEventHandler<TEvent>>();
                await handler.HandleAsync(@event, stoppingToken);

                await channel.BasicAckAsync(ea.DeliveryTag, multiple: false, cancellationToken: stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Failed to process message from {Queue}; dead-lettering", queueName);
                await channel.BasicNackAsync(ea.DeliveryTag, multiple: false, requeue: false, cancellationToken: stoppingToken);
            }
        };

        await channel.BasicConsumeAsync(queueName, autoAck: false, consumer, cancellationToken: stoppingToken);
        logger.LogInformation("Consumer listening on {Queue} (routing key {RoutingKey})", queueName, _routingKey);

        // Keep the background service alive for the process lifetime; the channel/consumer above do the work.
        await Task.Delay(Timeout.Infinite, stoppingToken).ContinueWith(_ => { }, TaskScheduler.Default);
    }
}
