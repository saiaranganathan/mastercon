using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ZWS.BuildingBlocks.Messaging;

public static class ServiceCollectionExtensions
{
    /// <summary>Registers the shared RabbitMQ connection + publisher. Call once from ZWS.Host.</summary>
    public static IServiceCollection AddZwsRabbitMq(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<RabbitMqOptions>(configuration.GetSection(RabbitMqOptions.SectionName));
        services.AddSingleton<RabbitMqConnection>();
        services.AddSingleton<IEventBus, RabbitMqEventBus>();
        return services;
    }

    /// <summary>
    /// Registers a background consumer for <typeparamref name="TEvent"/> handled by
    /// <typeparamref name="THandler"/>. Called by a module's own Infrastructure
    /// registration (e.g. the Notifications module subscribing to Paycon events).
    /// </summary>
    public static IServiceCollection AddZwsIntegrationEventConsumer<TEvent, THandler>(
        this IServiceCollection services, string queueName)
        where TEvent : IntegrationEvent
        where THandler : class, IIntegrationEventHandler<TEvent>
    {
        services.AddScoped<IIntegrationEventHandler<TEvent>, THandler>();
        services.AddSingleton<IHostedService>(sp => new RabbitMqIntegrationEventConsumer<TEvent>(
            sp.GetRequiredService<RabbitMqConnection>(),
            sp.GetRequiredService<IServiceScopeFactory>(),
            sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<RabbitMqOptions>>(),
            sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<RabbitMqIntegrationEventConsumer<TEvent>>>(),
            queueName));
        return services;
    }
}
