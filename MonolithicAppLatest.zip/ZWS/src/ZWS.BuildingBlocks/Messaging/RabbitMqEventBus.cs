using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;

namespace ZWS.BuildingBlocks.Messaging;

/// <summary>
/// Publishes integration events to a durable topic exchange. Every module's
/// composition root registers this as the IEventBus implementation - modules
/// never open their own RabbitMQ connection.
/// </summary>
public sealed class RabbitMqEventBus(
    RabbitMqConnection connection,
    IOptions<RabbitMqOptions> options,
    ILogger<RabbitMqEventBus> logger) : IEventBus
{
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);
    private readonly RabbitMqOptions _options = options.Value;

    public async Task PublishAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default)
        where TEvent : IntegrationEvent
    {
        var conn = await connection.GetConnectionAsync(cancellationToken);
        if (conn is null)
        {
            logger.LogWarning("RabbitMQ unavailable - dropping integration event {EventType} ({EventId})", @event.EventType, @event.EventId);
            return;
        }

        for (var attempt = 1; attempt <= _options.RetryCount; attempt++)
        {
            try
            {
                await using var channel = await conn.CreateChannelAsync(cancellationToken: cancellationToken);

                await channel.ExchangeDeclareAsync(
                    exchange: _options.ExchangeName,
                    type: ExchangeType.Topic,
                    durable: true,
                    autoDelete: false,
                    cancellationToken: cancellationToken);

                var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(@event, @event.GetType(), SerializerOptions));

                var properties = new BasicProperties
                {
                    Persistent = true,
                    Type = @event.EventType,
                    MessageId = @event.EventId.ToString(),
                    Timestamp = new AmqpTimestamp(DateTimeOffset.UtcNow.ToUnixTimeSeconds())
                };

                await channel.BasicPublishAsync(
                    exchange: _options.ExchangeName,
                    routingKey: @event.EventType,
                    mandatory: false,
                    basicProperties: properties,
                    body: body,
                    cancellationToken: cancellationToken);

                logger.LogInformation("Published integration event {EventType} ({EventId})", @event.EventType, @event.EventId);
                return;
            }
            catch (Exception ex) when (attempt < _options.RetryCount)
            {
                logger.LogWarning(ex, "Publish attempt {Attempt}/{Max} failed for {EventType}; retrying", attempt, _options.RetryCount, @event.EventType);
                await Task.Delay(TimeSpan.FromMilliseconds(200 * attempt), cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Giving up publishing {EventType} ({EventId}) after {Attempts} attempts", @event.EventType, @event.EventId, _options.RetryCount);
            }
        }
    }
}
