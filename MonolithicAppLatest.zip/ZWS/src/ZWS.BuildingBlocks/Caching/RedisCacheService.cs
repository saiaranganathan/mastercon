using System.Text.Json;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace ZWS.BuildingBlocks.Caching;

/// <summary>
/// Redis-backed cache. Every member gracefully degrades to a "no cache" outcome
/// (returning default/executing the factory) whenever the Redis connection is
/// unavailable, per requirement 25: "If Redis is unavailable, gracefully fall
/// back to SQL."
/// </summary>
public sealed class RedisCacheService(
    IConnectionMultiplexer? connectionMultiplexer,
    ILogger<RedisCacheService> logger) : ICacheService
{
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);

    public async Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default)
    {
        if (connectionMultiplexer is null || !connectionMultiplexer.IsConnected) return default;

        try
        {
            var db = connectionMultiplexer.GetDatabase();
            var value = await db.StringGetAsync(key);
            if (value.IsNullOrEmpty) return default;
            return JsonSerializer.Deserialize<T>(value!, SerializerOptions);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis GET failed for {Key}; falling back to source", key);
            return default;
        }
    }

    public async Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default)
    {
        if (connectionMultiplexer is null || !connectionMultiplexer.IsConnected || value is null) return;

        try
        {
            var db = connectionMultiplexer.GetDatabase();
            var json = JsonSerializer.Serialize(value, SerializerOptions);
            await db.StringSetAsync(key, json, expiration ?? TimeSpan.FromMinutes(10));
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis SET failed for {Key}; continuing without caching", key);
        }
    }

    public async Task RemoveAsync(string key, CancellationToken cancellationToken = default)
    {
        if (connectionMultiplexer is null || !connectionMultiplexer.IsConnected) return;

        try
        {
            var db = connectionMultiplexer.GetDatabase();
            await db.KeyDeleteAsync(key);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis DEL failed for {Key}", key);
        }
    }

    public async Task RemoveByPrefixAsync(string prefix, CancellationToken cancellationToken = default)
    {
        if (connectionMultiplexer is null || !connectionMultiplexer.IsConnected) return;

        try
        {
            foreach (var endpoint in connectionMultiplexer.GetEndPoints())
            {
                var server = connectionMultiplexer.GetServer(endpoint);
                var db = connectionMultiplexer.GetDatabase();
                await foreach (var key in server.KeysAsync(pattern: $"{prefix}*"))
                {
                    await db.KeyDeleteAsync(key);
                }
            }
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis prefix removal failed for {Prefix}", prefix);
        }
    }

    public async Task<T> GetOrCreateAsync<T>(
        string key,
        Func<CancellationToken, Task<T>> factory,
        TimeSpan? expiration = null,
        CancellationToken cancellationToken = default)
    {
        var cached = await GetAsync<T>(key, cancellationToken);
        if (cached is not null) return cached;

        var value = await factory(cancellationToken);
        await SetAsync(key, value, expiration, cancellationToken);
        return value;
    }
}
