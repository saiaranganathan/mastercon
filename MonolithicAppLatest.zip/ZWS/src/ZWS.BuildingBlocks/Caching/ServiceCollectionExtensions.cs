using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace ZWS.BuildingBlocks.Caching;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers the shared IConnectionMultiplexer + ICacheService. The
    /// multiplexer is created eagerly-but-safely: a connection failure is
    /// logged and the app continues without caching rather than crashing.
    /// </summary>
    public static IServiceCollection AddZwsRedisCache(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration["Redis:ConnectionString"];

        services.AddSingleton<IConnectionMultiplexer?>(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger("ZWS.Redis");
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                logger.LogWarning("Redis:ConnectionString not configured - caching disabled, all reads fall back to SQL");
                return null;
            }

            try
            {
                var options = ConfigurationOptions.Parse(connectionString);
                options.AbortOnConnectFail = false;
                options.ConnectRetry = 3;
                options.ConnectTimeout = 3000;
                return ConnectionMultiplexer.Connect(options);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Could not connect to Redis at startup - caching disabled, all reads fall back to SQL");
                return null;
            }
        });

        services.AddSingleton<ICacheService, RedisCacheService>();
        return services;
    }
}
