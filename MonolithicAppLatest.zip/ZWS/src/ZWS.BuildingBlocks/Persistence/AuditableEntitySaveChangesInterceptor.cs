using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Domain;

namespace ZWS.BuildingBlocks.Persistence;

/// <summary>
/// Registered by every module's DbContext (see each module's
/// AddXxxModule extension). Automatically stamps CreatedAt/CreatedBy on insert
/// and UpdatedAt/UpdatedBy on update, and turns hard deletes of an
/// AuditableEntity into a logical delete, so audit history is never lost -
/// exactly what PR_UM-1.4 / PR_UM 2.4 / PR_UM 3.2 require.
/// </summary>
public sealed class AuditableEntitySaveChangesInterceptor(ICurrentUserService currentUser) : SaveChangesInterceptor
{
    public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
    {
        UpdateAuditFields(eventData.Context);
        return base.SavingChanges(eventData, result);
    }

    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
        DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken = default)
    {
        UpdateAuditFields(eventData.Context);
        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    private void UpdateAuditFields(DbContext? context)
    {
        if (context is null) return;

        var userId = currentUser.IsAuthenticated ? currentUser.UserId : "system";

        foreach (EntityEntry<AuditableEntity> entry in context.ChangeTracker.Entries<AuditableEntity>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedAt = DateTime.UtcNow;
                    entry.Entity.CreatedBy = userId;
                    break;

                case EntityState.Modified:
                    entry.Entity.UpdatedAt = DateTime.UtcNow;
                    entry.Entity.UpdatedBy = userId;
                    break;

                case EntityState.Deleted:
                    // Never physically delete an auditable row - convert to a logical delete instead.
                    entry.State = EntityState.Modified;
                    entry.Entity.IsDeleted = true;
                    entry.Entity.DeletedAt = DateTime.UtcNow;
                    entry.Entity.DeletedBy = userId;
                    break;
            }
        }
    }
}
