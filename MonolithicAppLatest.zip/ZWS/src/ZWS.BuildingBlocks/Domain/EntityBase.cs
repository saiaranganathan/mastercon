using System.ComponentModel.DataAnnotations.Schema;

namespace ZWS.BuildingBlocks.Domain;

/// <summary>
/// Base class for every entity owned by a module. Modules must not derive their
/// entities from anything outside this shared kernel, and must never reference
/// another module's entities directly.
/// </summary>
public abstract class EntityBase<TId>
{
    public TId Id { get; protected set; } = default!;

    private readonly List<DomainEvent> _domainEvents = new();

    // EF Core auto-discovers every public property as a column or navigation.
    // DomainEvent has no key, so without [NotMapped] the model builder tries to
    // map it as an entity and throws "requires a primary key to be defined."
    // This collection is in-memory only (dispatched then cleared by the
    // SaveChanges interceptor) and must never be part of the persistence model.
    [NotMapped]
    public IReadOnlyCollection<DomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    protected void AddDomainEvent(DomainEvent domainEvent) => _domainEvents.Add(domainEvent);
    public void ClearDomainEvents() => _domainEvents.Clear();

    public override bool Equals(object? obj)
    {
        if (obj is not EntityBase<TId> other) return false;
        if (ReferenceEquals(this, other)) return true;
        return EqualityComparer<TId>.Default.Equals(Id, other.Id);
    }

    public override int GetHashCode() => EqualityComparer<TId>.Default.GetHashCode(Id!);
}

/// <summary>Convenience base for the very common case of a Guid-keyed entity.</summary>
public abstract class EntityBase : EntityBase<Guid>
{
    protected EntityBase() => Id = Guid.NewGuid();
}
