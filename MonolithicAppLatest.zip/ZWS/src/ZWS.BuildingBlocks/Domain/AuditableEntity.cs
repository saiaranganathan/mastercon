namespace ZWS.BuildingBlocks.Domain;

/// <summary>
/// Adds the Created/Updated audit trail columns that almost every screen in the
/// business requirements document surfaces (Created At/By, Updated At/By).
/// Values are stamped automatically by <see cref="ZWS.BuildingBlocks.Persistence.AuditableEntitySaveChangesInterceptor"/>.
/// </summary>
public abstract class AuditableEntity : EntityBase
{
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = "system";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    /// <summary>Logical delete flag - rows are never physically removed so audit history is preserved.</summary>
    public bool IsDeleted { get; set; }
    public DateTime? DeletedAt { get; set; }
    public string? DeletedBy { get; set; }
}
