using MediatR;

namespace ZWS.BuildingBlocks.Domain;

/// <summary>
/// A fact that happened inside a module's domain. In-module reactions are
/// dispatched in-process via MediatR (INotification); anything another module
/// or the Notifications module needs to know about is additionally published
/// as an <see cref="ZWS.BuildingBlocks.Messaging.IntegrationEvent"/> on RabbitMQ.
/// </summary>
public abstract record DomainEvent : INotification
{
    public DateTime OccurredOn { get; } = DateTime.UtcNow;
}
