using Microsoft.AspNetCore.SignalR;

namespace ZWS.BuildingBlocks.Realtime;

/// <summary>
/// The single SignalR hub for the Paycon application (requirement 24), mapped
/// at /payconHub. Lives in BuildingBlocks (not inside any one module) because
/// several modules push events through it: Notifications, Reconciliation,
/// Dashboard. Client event names: PaymentStatusUpdated, ReconciliationUpdated,
/// DashboardMetricUpdated, NotificationReceived.
/// </summary>
public sealed class PayconHub : Hub
{
    public override async Task OnConnectedAsync()
    {
        // Every connected client joins a shared "paycon-users" group so server-side
        // code can broadcast without tracking connection ids itself.
        await Groups.AddToGroupAsync(Context.ConnectionId, "paycon-users");
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, "paycon-users");
        await base.OnDisconnectedAsync(exception);
    }
}
