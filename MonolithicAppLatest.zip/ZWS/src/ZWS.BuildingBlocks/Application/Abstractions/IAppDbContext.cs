namespace ZWS.BuildingBlocks.Application.Abstractions;

/// <summary>
/// Every module's DbContext implements this so shared infrastructure (the audit
/// interceptor, the base repository) can call SaveChangesAsync without any
/// module needing to reference another module's concrete DbContext type.
/// </summary>
public interface IAppDbContext
{
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
