namespace ZWS.BuildingBlocks.Application.Abstractions;

/// <summary>
/// Every module depends on this abstraction instead of ClaimsPrincipal/HttpContext
/// directly, so Application-layer code stays testable and Infrastructure-agnostic.
/// The concrete implementation (reading the authenticated OKTA/JWT principal) is
/// registered once in ZWS.Host and shared by every module.
/// </summary>
public interface ICurrentUserService
{
    string UserId { get; }
    string UserName { get; }
    string? Email { get; }
    bool IsAuthenticated { get; }
    IReadOnlyCollection<string> Permissions { get; }
    bool HasPermission(string permission);
}
