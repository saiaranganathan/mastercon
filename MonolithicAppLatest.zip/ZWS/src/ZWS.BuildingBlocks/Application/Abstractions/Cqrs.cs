using MediatR;
using ZWS.BuildingBlocks.Application.Common;

namespace ZWS.BuildingBlocks.Application.Abstractions;

/// <summary>Marker for a write operation that returns no data.</summary>
public interface ICommand : IRequest<Result>;

/// <summary>Marker for a write operation that returns data (e.g. the created entity's id).</summary>
public interface ICommand<TResponse> : IRequest<Result<TResponse>>;

/// <summary>Marker for a read operation. Queries never mutate state.</summary>
public interface IQuery<TResponse> : IRequest<Result<TResponse>>;

/// <summary>Opt a query into the Redis-backed caching pipeline behavior.</summary>
public interface ICacheableQuery
{
    string CacheKey { get; }
    TimeSpan? Expiration => null;
}

public interface ICommandHandler<in TCommand> : IRequestHandler<TCommand, Result>
    where TCommand : ICommand;

public interface ICommandHandler<in TCommand, TResponse> : IRequestHandler<TCommand, Result<TResponse>>
    where TCommand : ICommand<TResponse>;

public interface IQueryHandler<in TQuery, TResponse> : IRequestHandler<TQuery, Result<TResponse>>
    where TQuery : IQuery<TResponse>;
