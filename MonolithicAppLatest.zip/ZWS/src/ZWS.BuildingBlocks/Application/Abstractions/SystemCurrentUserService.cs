namespace ZWS.BuildingBlocks.Application.Abstractions;

/// <summary>Fallback ICurrentUserService for background jobs, seeding and tests where there is no HTTP request.</summary>
public sealed class SystemCurrentUserService : ICurrentUserService
{
    public string UserId => "system";
    public string UserName => "System";
    public string? Email => null;
    public bool IsAuthenticated => false;
    public IReadOnlyCollection<string> Permissions => [];
    public bool HasPermission(string permission) => true;
}
