using MediatR;
using Microsoft.Extensions.Logging;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;

namespace ZWS.BuildingBlocks.Application.Behaviors;

/// <summary>
/// Transparently caches the result of any query that implements
/// <see cref="ICacheableQuery"/> in Redis (see requirement 25 - dashboard
/// metrics, hub application cards and Paycon navigation are all cached this
/// way). Falls back straight to the handler if Redis is unavailable.
/// </summary>
public sealed class CachingBehavior<TRequest, TResponse>(
    ICacheService cacheService,
    ILogger<CachingBehavior<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        if (request is not ICacheableQuery cacheable)
            return await next();

        var cached = await cacheService.GetAsync<TResponse>(cacheable.CacheKey, cancellationToken);
        if (cached is not null)
        {
            logger.LogDebug("Cache hit for {CacheKey}", cacheable.CacheKey);
            return cached;
        }

        logger.LogDebug("Cache miss for {CacheKey}", cacheable.CacheKey);
        var response = await next();

        await cacheService.SetAsync(cacheable.CacheKey, response, cacheable.Expiration, cancellationToken);
        return response;
    }
}
