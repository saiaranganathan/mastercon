using System.Reflection;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Application.Behaviors;

namespace ZWS.BuildingBlocks.Application;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers MediatR handlers + FluentValidation validators for every
    /// supplied module assembly, and wires the shared pipeline behaviors in
    /// the order: Logging -> Validation -> Caching -> Handler.
    /// Called once from ZWS.Host with every module's Application assembly.
    /// </summary>
    public static IServiceCollection AddZwsApplicationLayer(this IServiceCollection services, params Assembly[] moduleAssemblies)
    {
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssemblies(moduleAssemblies);
            cfg.AddOpenBehavior(typeof(LoggingBehavior<,>));
            cfg.AddOpenBehavior(typeof(ValidationBehavior<,>));
            cfg.AddOpenBehavior(typeof(CachingBehavior<,>));
        });

        services.AddValidatorsFromAssemblies(moduleAssemblies, includeInternalTypes: true);

        return services;
    }
}
