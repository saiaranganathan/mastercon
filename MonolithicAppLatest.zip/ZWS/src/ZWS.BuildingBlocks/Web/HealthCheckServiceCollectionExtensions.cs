using HealthChecks.Rabbitmq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RabbitMQ.Client;

namespace ZWS.BuildingBlocks.Web;

public static class HealthCheckServiceCollectionExtensions
{
    /// <summary>Requirement 33: /health and /health/ready, checking SQL, Redis, RabbitMQ and app availability.</summary>
    public static IServiceCollection AddZwsHealthChecks(this IServiceCollection services, IConfiguration configuration, string primaryConnectionStringName)
    {
        var builder = services.AddHealthChecks()
            .AddCheck("self", () => Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy(), tags: ["ready"]);

        var sqlConnectionString = configuration.GetConnectionString(primaryConnectionStringName);
        if (!string.IsNullOrWhiteSpace(sqlConnectionString))
        {
            builder.AddSqlServer(sqlConnectionString, name: "sql-server", tags: ["ready"]);
        }

        var redisConnectionString = configuration["Redis:ConnectionString"];
        if (!string.IsNullOrWhiteSpace(redisConnectionString))
        {
            builder.AddRedis(redisConnectionString, name: "redis", tags: ["ready"]);
        }

        var rabbitHost = configuration["RabbitMQ:Host"];
        if (!string.IsNullOrWhiteSpace(rabbitHost))
        {
            var user = configuration["RabbitMQ:Username"] ?? "guest";
            var pass = configuration["RabbitMQ:Password"] ?? "guest";
            var vhost = configuration["RabbitMQ:VirtualHost"] ?? "/";
            var port = int.TryParse(configuration["RabbitMQ:Port"], out var parsedPort) ? parsedPort : 5672;

            // AspNetCore.HealthChecks.Rabbitmq 9.x takes a connection factory delegate
            // rather than a connection string, matching RabbitMQ.Client 7's async-only
            // connection API (see RabbitMqConnection for the same pattern).
            builder.AddRabbitMQ(
                factory: async _ =>
                {
                    var connectionFactory = new ConnectionFactory
                    {
                        HostName = rabbitHost,
                        Port = port,
                        UserName = user,
                        Password = pass,
                        VirtualHost = vhost
                    };
                    return await connectionFactory.CreateConnectionAsync("zws-health-check");
                },
                name: "rabbitmq",
                tags: ["ready"]);
        }

        return services;
    }
}
