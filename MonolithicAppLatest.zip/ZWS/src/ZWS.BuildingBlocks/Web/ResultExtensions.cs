using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;

namespace ZWS.BuildingBlocks.Web;

/// <summary>Maps an application-layer Result/Result&lt;T&gt; onto the appropriate HTTP response.</summary>
public static class ResultExtensions
{
    public static IActionResult ToActionResult(this Result result)
    {
        if (result.IsSuccess) return new NoContentResult();
        return MapError(result.Error);
    }

    public static IActionResult ToActionResult<T>(this Result<T> result)
    {
        if (result.IsSuccess) return new OkObjectResult(result.Value);
        return MapError(result.Error);
    }

    public static IActionResult ToCreatedResult<T>(this Result<T> result, string actionName, object routeValues)
    {
        if (result.IsSuccess) return new OkObjectResult(result.Value);
        return MapError(result.Error);
    }

    private static IActionResult MapError(Error error)
    {
        var status = error.Type switch
        {
            ErrorType.NotFound => StatusCodes.Status404NotFound,
            ErrorType.Validation => StatusCodes.Status400BadRequest,
            ErrorType.Conflict => StatusCodes.Status409Conflict,
            ErrorType.Forbidden => StatusCodes.Status403Forbidden,
            _ => StatusCodes.Status500InternalServerError
        };

        var apiError = new ApiError { Status = status, Message = error.Message };
        return new ObjectResult(apiError) { StatusCode = status };
    }
}
