namespace ZWS.BuildingBlocks.Web;

/// <summary>The single, consistent error shape returned by every ZWS API (requirement 32).</summary>
public sealed record ApiError
{
    public int Status { get; init; }
    public string Message { get; init; } = "An unexpected error occurred.";
    public string TraceId { get; init; } = string.Empty;
    public IDictionary<string, string[]>? Errors { get; init; }
}
