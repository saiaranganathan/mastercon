using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.PartnerHub.Domain;

namespace ZWS.Modules.PartnerHub.Infrastructure.Persistence;

public sealed class PartnerHubDbContext(DbContextOptions<PartnerHubDbContext> options) : DbContext(options), IAppDbContext
{
    public DbSet<Partner> Partners => Set<Partner>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("partner_hub");
        modelBuilder.Entity<Partner>(b =>
        {
            b.ToTable("Partners");
            b.HasKey(x => x.Id);
            b.Property(x => x.Name).HasMaxLength(200);
            b.Property(x => x.Region).HasMaxLength(100);
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
