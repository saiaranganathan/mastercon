using Microsoft.EntityFrameworkCore;
using ZWS.Modules.PartnerHub.Domain;

namespace ZWS.Modules.PartnerHub.Infrastructure.Persistence;

public static class PartnerHubDbContextSeed
{
    public static async Task SeedAsync(PartnerHubDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Partners.AnyAsync(cancellationToken)) return;

        context.Partners.AddRange(
            Partner.Create("Emirates NBD Correspondent Network", "UAE", PartnerStatus.Active),
            Partner.Create("Standard Chartered MEA", "UAE", PartnerStatus.Active),
            Partner.Create("HSBC Trade Finance", "UK", PartnerStatus.Active),
            Partner.Create("First Abu Dhabi Bank Alliance", "UAE", PartnerStatus.Pending),
            Partner.Create("Barclays Settlement Partner", "UK", PartnerStatus.Suspended));

        await context.SaveChangesAsync(cancellationToken);
    }
}
