using Microsoft.EntityFrameworkCore;
using ZWS.Modules.PartnerHub.Application.Repositories;
using ZWS.Modules.PartnerHub.Domain;
using ZWS.Modules.PartnerHub.Infrastructure.Persistence;

namespace ZWS.Modules.PartnerHub.Infrastructure.Repositories;

public sealed class PartnerRepository(PartnerHubDbContext context) : IPartnerRepository
{
    public async Task<IReadOnlyCollection<Partner>> GetAllAsync(CancellationToken cancellationToken) =>
        await context.Partners.AsNoTracking().OrderBy(p => p.Name).ToListAsync(cancellationToken);
}
