using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.PartnerHub.Application.Repositories;
using ZWS.Modules.PartnerHub.Infrastructure.Persistence;
using ZWS.Modules.PartnerHub.Infrastructure.Repositories;

namespace ZWS.Modules.PartnerHub;

public static class PartnerHubModule
{
    public static IServiceCollection AddPartnerHubModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("PartnerHub");

        services.AddDbContext<PartnerHubDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=partner_hub.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "partner_hub"));
        });

        services.AddScoped<IPartnerRepository, PartnerRepository>();
        return services;
    }

    public static async Task SeedPartnerHubModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PartnerHubDbContext>();
        await PartnerHubDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
