using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.PartnerHub.Domain;

public enum PartnerStatus { Active, Pending, Suspended }

/// <summary>PartnerHub is an external application (requirement 5/17) - see ComplianceCase for the pattern rationale.</summary>
public sealed class Partner : AuditableEntity
{
    public string Name { get; private set; } = default!;
    public string Region { get; private set; } = default!;
    public PartnerStatus Status { get; private set; } = PartnerStatus.Pending;

    private Partner() { }

    public static Partner Create(string name, string region, PartnerStatus status) => new()
    {
        Name = name, Region = region, Status = status
    };
}
