using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.PartnerHub.Application.Queries;

namespace ZWS.Modules.PartnerHub.Presentation.Controllers;

/// <summary>Route: /partner-hub - basic landing summary; the full app is external (requirement 17).</summary>
[ApiController]
[Route("api/partner-hub/partners")]
public sealed class PartnersController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetPartners(CancellationToken cancellationToken) =>
        (await sender.Send(new GetPartnersQuery(), cancellationToken)).ToActionResult();
}
