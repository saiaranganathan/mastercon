using ZWS.Modules.PartnerHub.Domain;

namespace ZWS.Modules.PartnerHub.Application.Repositories;

public interface IPartnerRepository
{
    Task<IReadOnlyCollection<Partner>> GetAllAsync(CancellationToken cancellationToken);
}
