namespace ZWS.Modules.PartnerHub.Application.Dtos;

public sealed record PartnerDto(Guid Id, string Name, string Region, string Status);
