using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.PartnerHub.Application.Dtos;

namespace ZWS.Modules.PartnerHub.Application.Queries;

public sealed record GetPartnersQuery : IQuery<IReadOnlyCollection<PartnerDto>>;
