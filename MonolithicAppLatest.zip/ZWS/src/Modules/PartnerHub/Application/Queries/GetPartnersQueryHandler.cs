using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.PartnerHub.Application.Dtos;
using ZWS.Modules.PartnerHub.Application.Repositories;

namespace ZWS.Modules.PartnerHub.Application.Queries;

public sealed class GetPartnersQueryHandler(IPartnerRepository repository) : IQueryHandler<GetPartnersQuery, IReadOnlyCollection<PartnerDto>>
{
    public async Task<Result<IReadOnlyCollection<PartnerDto>>> Handle(GetPartnersQuery request, CancellationToken cancellationToken)
    {
        var partners = await repository.GetAllAsync(cancellationToken);
        var dtos = partners.Select(p => new PartnerDto(p.Id, p.Name, p.Region, p.Status.ToString())).ToList();
        return Result.Success<IReadOnlyCollection<PartnerDto>>(dtos);
    }
}
