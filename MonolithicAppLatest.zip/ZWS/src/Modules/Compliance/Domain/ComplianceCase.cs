using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Compliance.Domain;

public enum ComplianceCaseStatus { Open, UnderReview, Resolved }

/// <summary>
/// Compliance is an external application in production (requirement 5/17):
/// clicking its Hub card renders the external app inside the ZWS master
/// layout via an iframe/remote view. This module still owns a small local
/// dataset (its own landing/summary dashboard) so the shell has something
/// real to show before the external app takes over.
/// </summary>
public sealed class ComplianceCase : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public string Category { get; private set; } = default!;
    public ComplianceCaseStatus Status { get; private set; } = ComplianceCaseStatus.Open;
    public DateTime RaisedAt { get; private set; }

    private ComplianceCase() { }

    public static ComplianceCase Create(string title, string category, ComplianceCaseStatus status, DateTime raisedAt) => new()
    {
        Title = title, Category = category, Status = status, RaisedAt = raisedAt
    };
}
