using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Compliance.Application.Queries;

namespace ZWS.Modules.Compliance.Presentation.Controllers;

/// <summary>Route: /compliance - basic landing summary; the full app is external (requirement 17).</summary>
[ApiController]
[Route("api/compliance/summary")]
public sealed class ComplianceController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetSummary(CancellationToken cancellationToken) =>
        (await sender.Send(new GetComplianceSummaryQuery(), cancellationToken)).ToActionResult();
}
