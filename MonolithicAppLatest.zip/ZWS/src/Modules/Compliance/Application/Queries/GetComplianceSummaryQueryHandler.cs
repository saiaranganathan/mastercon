using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Compliance.Application.Dtos;
using ZWS.Modules.Compliance.Application.Repositories;

namespace ZWS.Modules.Compliance.Application.Queries;

public sealed class GetComplianceSummaryQueryHandler(IComplianceCaseRepository repository)
    : IQueryHandler<GetComplianceSummaryQuery, IReadOnlyCollection<ComplianceCaseDto>>
{
    public async Task<Result<IReadOnlyCollection<ComplianceCaseDto>>> Handle(GetComplianceSummaryQuery request, CancellationToken cancellationToken)
    {
        var cases = await repository.GetRecentAsync(cancellationToken);
        var dtos = cases.Select(c => new ComplianceCaseDto(c.Id, c.Title, c.Category, c.Status.ToString(), c.RaisedAt)).ToList();
        return Result.Success<IReadOnlyCollection<ComplianceCaseDto>>(dtos);
    }
}
