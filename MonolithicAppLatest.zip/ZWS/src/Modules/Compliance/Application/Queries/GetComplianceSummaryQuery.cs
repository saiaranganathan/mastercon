using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Compliance.Application.Dtos;

namespace ZWS.Modules.Compliance.Application.Queries;

public sealed record GetComplianceSummaryQuery : IQuery<IReadOnlyCollection<ComplianceCaseDto>>;
