namespace ZWS.Modules.Compliance.Application.Dtos;

public sealed record ComplianceCaseDto(Guid Id, string Title, string Category, string Status, DateTime RaisedAt);
