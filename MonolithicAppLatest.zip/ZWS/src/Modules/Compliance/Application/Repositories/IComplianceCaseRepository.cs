using ZWS.Modules.Compliance.Domain;

namespace ZWS.Modules.Compliance.Application.Repositories;

public interface IComplianceCaseRepository
{
    Task<IReadOnlyCollection<ComplianceCase>> GetRecentAsync(CancellationToken cancellationToken);
}
