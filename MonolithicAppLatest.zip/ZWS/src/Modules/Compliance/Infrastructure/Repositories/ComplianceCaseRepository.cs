using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Compliance.Application.Repositories;
using ZWS.Modules.Compliance.Domain;
using ZWS.Modules.Compliance.Infrastructure.Persistence;

namespace ZWS.Modules.Compliance.Infrastructure.Repositories;

public sealed class ComplianceCaseRepository(ComplianceDbContext context) : IComplianceCaseRepository
{
    public async Task<IReadOnlyCollection<ComplianceCase>> GetRecentAsync(CancellationToken cancellationToken) =>
        await context.Cases.AsNoTracking().OrderByDescending(c => c.RaisedAt).Take(10).ToListAsync(cancellationToken);
}
