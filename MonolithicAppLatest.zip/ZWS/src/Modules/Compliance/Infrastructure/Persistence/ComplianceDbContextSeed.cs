using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Compliance.Domain;

namespace ZWS.Modules.Compliance.Infrastructure.Persistence;

public static class ComplianceDbContextSeed
{
    public static async Task SeedAsync(ComplianceDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Cases.AnyAsync(cancellationToken)) return;

        context.Cases.AddRange(
            ComplianceCase.Create("KYC refresh overdue - DAMAN scheme", "KYC", ComplianceCaseStatus.Open, DateTime.UtcNow.AddDays(-2)),
            ComplianceCase.Create("Suspicious transaction flagged", "AML", ComplianceCaseStatus.UnderReview, DateTime.UtcNow.AddDays(-5)),
            ComplianceCase.Create("Annual regulatory filing", "Regulatory", ComplianceCaseStatus.Resolved, DateTime.UtcNow.AddDays(-14)));

        await context.SaveChangesAsync(cancellationToken);
    }
}
