using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Compliance.Domain;

namespace ZWS.Modules.Compliance.Infrastructure.Persistence;

public sealed class ComplianceDbContext(DbContextOptions<ComplianceDbContext> options) : DbContext(options), IAppDbContext
{
    public DbSet<ComplianceCase> Cases => Set<ComplianceCase>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("compliance");
        modelBuilder.Entity<ComplianceCase>(b =>
        {
            b.ToTable("ComplianceCases");
            b.HasKey(x => x.Id);
            b.Property(x => x.Title).HasMaxLength(200);
            b.Property(x => x.Category).HasMaxLength(100);
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
