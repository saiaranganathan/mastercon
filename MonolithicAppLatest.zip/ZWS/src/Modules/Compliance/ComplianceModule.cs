using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Compliance.Application.Repositories;
using ZWS.Modules.Compliance.Infrastructure.Persistence;
using ZWS.Modules.Compliance.Infrastructure.Repositories;

namespace ZWS.Modules.Compliance;

public static class ComplianceModule
{
    public static IServiceCollection AddComplianceModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Compliance");

        services.AddDbContext<ComplianceDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=compliance.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "compliance"));
        });

        services.AddScoped<IComplianceCaseRepository, ComplianceCaseRepository>();
        return services;
    }

    public static async Task SeedComplianceModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ComplianceDbContext>();
        await ComplianceDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
