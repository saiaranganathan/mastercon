using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement;

public static class SchemeManagementModule
{
    public static IServiceCollection AddSchemeManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<SchemeManagementDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_scheme_management.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_scheme_management"));
        });

        services.AddScoped<ISchemeRepository, SchemeRepository>();
        services.AddScoped<ISchemeManagementDbContext>(sp => sp.GetRequiredService<SchemeManagementDbContext>());
        return services;
    }

    public static async Task SeedSchemeManagementModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<SchemeManagementDbContext>();
        await SchemeManagementDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
