using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Presentation.Controllers;

/// <summary>/paycon/settings/scheme-management (requirement 15).</summary>
[ApiController]
[Route("api/paycon/settings/scheme-management/schemes")]
public sealed class SchemesController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetSchemes([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetSchemesQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetScheme(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GetSchemeByIdQuery(id), cancellationToken)).ToActionResult();

    [HttpGet("reference")]
    public async Task<IActionResult> GetActiveSchemesForReference(CancellationToken cancellationToken) =>
        (await sender.Send(new GetActiveSchemesForReferenceQuery(), cancellationToken)).ToActionResult();

    [HttpPost]
    public async Task<IActionResult> CreateScheme([FromBody] CreateSchemeRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreateSchemeCommand(request.Code, request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> UpdateScheme(Guid id, [FromBody] UpdateSchemeRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateSchemeCommand(id, request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> DeleteScheme(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteSchemeCommand(id), cancellationToken)).ToActionResult();
}

public sealed record CreateSchemeRequest(string Code, string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
public sealed record UpdateSchemeRequest(string Name, string Currency, string? OperatingBank, string? Description, SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate);
