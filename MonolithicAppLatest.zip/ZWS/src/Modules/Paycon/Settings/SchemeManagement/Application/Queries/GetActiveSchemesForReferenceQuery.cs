using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;

/// <summary>
/// SchemeManagement's public cross-module contract: every other module that
/// needs "which plans exist" (UserManagement's Group/User pickers today)
/// calls this query instead of touching SchemeManagementDbContext.
/// </summary>
public sealed record GetActiveSchemesForReferenceQuery : IQuery<IReadOnlyCollection<SchemeReferenceItemDto>>, ICacheableQuery
{
    public string CacheKey => CacheKeys.SchemeReferenceData;
    public TimeSpan? Expiration => TimeSpan.FromMinutes(30);
}
