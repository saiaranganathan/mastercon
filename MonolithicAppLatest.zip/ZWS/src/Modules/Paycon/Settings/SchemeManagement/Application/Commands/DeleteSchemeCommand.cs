using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed record DeleteSchemeCommand(Guid Id) : ICommand;
