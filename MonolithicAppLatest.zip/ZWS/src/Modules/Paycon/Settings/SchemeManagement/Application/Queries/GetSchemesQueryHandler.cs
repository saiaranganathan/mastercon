using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;

public sealed class GetSchemesQueryHandler(ISchemeRepository repository) : IQueryHandler<GetSchemesQuery, PagedResult<SchemeListItemDto>>
{
    public async Task<Result<PagedResult<SchemeListItemDto>>> Handle(GetSchemesQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchAsync(request.Paging, cancellationToken);
        var dtos = items.Select(s => new SchemeListItemDto(s.Id, s.Code, s.Name, s.Currency, s.OperatingBank, s.State.ToString(), s.CreatedAt, s.CreatedBy, s.UpdatedAt, s.UpdatedBy)).ToList();
        return Result.Success(new PagedResult<SchemeListItemDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
