using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed class CreateSchemeCommandHandler(ISchemeRepository repository, ISchemeManagementDbContext dbContext, ICacheService cache)
    : ICommandHandler<CreateSchemeCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreateSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = Scheme.Create(request.Code, request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate);
        repository.Add(scheme);
        await dbContext.SaveChangesAsync(cancellationToken);
        await cache.RemoveAsync(CacheKeys.SchemeReferenceData, cancellationToken);
        return Result.Success(scheme.Id);
    }
}
