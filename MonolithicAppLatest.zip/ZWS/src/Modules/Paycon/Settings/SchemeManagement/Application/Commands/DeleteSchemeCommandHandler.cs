using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed class DeleteSchemeCommandHandler(ISchemeRepository repository, ISchemeManagementDbContext dbContext, ICacheService cache)
    : ICommandHandler<DeleteSchemeCommand>
{
    public async Task<Result> Handle(DeleteSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (scheme is null) return Result.Failure(Error.NotFound("Scheme.NotFound", $"Scheme '{request.Id}' was not found."));

        repository.Remove(scheme);
        await dbContext.SaveChangesAsync(cancellationToken);
        await cache.RemoveAsync(CacheKeys.SchemeReferenceData, cancellationToken);
        return Result.Success();
    }
}
