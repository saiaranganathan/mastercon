using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

public interface ISchemeRepository
{
    Task<(IReadOnlyCollection<Scheme> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<Scheme?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<Scheme>> GetActiveAsync(CancellationToken cancellationToken);
    Task<bool> ExistsByCodeAsync(string code, Guid? excludeId, CancellationToken cancellationToken);
    void Add(Scheme scheme);
    void Remove(Scheme scheme);
}
