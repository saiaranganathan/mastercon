using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;

public sealed record GetSchemeByIdQuery(Guid Id) : IQuery<SchemeDetailDto>;
