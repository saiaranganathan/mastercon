using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed class UpdateSchemeCommandHandler(ISchemeRepository repository, ISchemeManagementDbContext dbContext, ICacheService cache)
    : ICommandHandler<UpdateSchemeCommand>
{
    public async Task<Result> Handle(UpdateSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (scheme is null) return Result.Failure(Error.NotFound("Scheme.NotFound", $"Scheme '{request.Id}' was not found."));

        scheme.UpdateDetails(request.Name, request.Currency, request.OperatingBank, request.Description, request.State, request.ToleranceLimit, request.ExchangeRate);
        await dbContext.SaveChangesAsync(cancellationToken);
        await cache.RemoveAsync(CacheKeys.SchemeReferenceData, cancellationToken);
        return Result.Success();
    }
}
