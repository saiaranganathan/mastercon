using FluentValidation;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed class UpdateSchemeCommandValidator : AbstractValidator<UpdateSchemeCommand>
{
    public UpdateSchemeCommandValidator()
    {
        RuleFor(x => x.Name).NotEmpty().Length(2, 150);
        RuleFor(x => x.Currency).NotEmpty().Length(3, 10);
        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.State).IsInEnum();
    }
}
