using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed record CreateSchemeCommand(
    string Code, string Name, string Currency, string? OperatingBank, string? Description,
    SchemeState State, decimal? ToleranceLimit, decimal? ExchangeRate) : ICommand<Guid>;
