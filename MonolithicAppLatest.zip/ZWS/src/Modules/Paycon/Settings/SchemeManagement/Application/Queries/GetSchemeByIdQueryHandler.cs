using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;

public sealed class GetSchemeByIdQueryHandler(ISchemeRepository repository) : IQueryHandler<GetSchemeByIdQuery, SchemeDetailDto>
{
    public async Task<Result<SchemeDetailDto>> Handle(GetSchemeByIdQuery request, CancellationToken cancellationToken)
    {
        var scheme = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (scheme is null) return Result.Failure<SchemeDetailDto>(Error.NotFound("Scheme.NotFound", $"Scheme '{request.Id}' was not found."));

        return Result.Success(new SchemeDetailDto(
            scheme.Id, scheme.Code, scheme.Name, scheme.Currency, scheme.OperatingBank, scheme.Description, scheme.State.ToString(),
            scheme.ToleranceLimit, scheme.ExchangeRate, scheme.CreatedAt, scheme.CreatedBy, scheme.UpdatedAt, scheme.UpdatedBy));
    }
}
