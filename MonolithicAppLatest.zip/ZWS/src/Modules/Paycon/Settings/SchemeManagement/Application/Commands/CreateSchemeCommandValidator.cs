using FluentValidation;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Commands;

public sealed class CreateSchemeCommandValidator : AbstractValidator<CreateSchemeCommand>
{
    public CreateSchemeCommandValidator(ISchemeRepository repository)
    {
        RuleFor(x => x.Code)
            .NotEmpty().Length(2, 20).Matches("^[A-Za-z0-9_-]+$")
            .MustAsync(async (code, ct) => !await repository.ExistsByCodeAsync(code, null, ct))
            .WithMessage("Scheme Code must be unique.");

        RuleFor(x => x.Name).NotEmpty().Length(2, 150);
        RuleFor(x => x.Currency).NotEmpty().Length(3, 10);
        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.State).IsInEnum();
        RuleFor(x => x.ToleranceLimit).GreaterThanOrEqualTo(0).When(x => x.ToleranceLimit.HasValue);
        RuleFor(x => x.ExchangeRate).GreaterThan(0).When(x => x.ExchangeRate.HasValue);
    }
}
