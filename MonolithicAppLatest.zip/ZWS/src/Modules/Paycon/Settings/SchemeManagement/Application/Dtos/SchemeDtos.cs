namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;

public sealed record SchemeListItemDto(
    Guid Id, string Code, string Name, string Currency, string? OperatingBank, string State,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record SchemeDetailDto(
    Guid Id, string Code, string Name, string Currency, string? OperatingBank, string? Description, string State,
    decimal? ToleranceLimit, decimal? ExchangeRate,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

/// <summary>The public, cross-module contract UserManagement consumes for its "Assigned Plans" pickers.</summary>
public sealed record SchemeReferenceItemDto(Guid Id, string Name);
