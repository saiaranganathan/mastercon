using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;

public sealed class GetActiveSchemesForReferenceQueryHandler(ISchemeRepository repository)
    : IQueryHandler<GetActiveSchemesForReferenceQuery, IReadOnlyCollection<SchemeReferenceItemDto>>
{
    public async Task<Result<IReadOnlyCollection<SchemeReferenceItemDto>>> Handle(GetActiveSchemesForReferenceQuery request, CancellationToken cancellationToken)
    {
        var schemes = await repository.GetActiveAsync(cancellationToken);
        var dtos = schemes.Select(s => new SchemeReferenceItemDto(s.Id, s.Name)).ToList();
        return Result.Success<IReadOnlyCollection<SchemeReferenceItemDto>>(dtos);
    }
}
