using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;

public interface ISchemeManagementDbContext : IAppDbContext;
