using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

public enum SchemeState { Active, Inactive }

/// <summary>
/// A pension/benefits scheme (plan) - "Scheme Master" in the Figma design.
/// Referenced by name+id (never by shared FK) from the UserManagement module's
/// Group/User "Assigned Plans" pickers.
/// </summary>
public sealed class Scheme : AuditableEntity
{
    public string Code { get; private set; } = default!;
    public string Name { get; private set; } = default!;
    public string Currency { get; private set; } = "AED";
    public string? OperatingBank { get; private set; }
    public string? Description { get; private set; }
    public SchemeState State { get; private set; } = SchemeState.Active;
    public decimal? ToleranceLimit { get; private set; }
    public decimal? ExchangeRate { get; private set; }

    private Scheme() { }

    public static Scheme Create(string code, string name, string currency, string? operatingBank, string? description, SchemeState state, decimal? toleranceLimit, decimal? exchangeRate)
        => new()
        {
            Code = code,
            Name = name,
            Currency = currency,
            OperatingBank = operatingBank,
            Description = description,
            State = state,
            ToleranceLimit = toleranceLimit,
            ExchangeRate = exchangeRate
        };

    public void UpdateDetails(string name, string currency, string? operatingBank, string? description, SchemeState state, decimal? toleranceLimit, decimal? exchangeRate)
    {
        Name = name;
        Currency = currency;
        OperatingBank = operatingBank;
        Description = description;
        State = state;
        ToleranceLimit = toleranceLimit;
        ExchangeRate = exchangeRate;
    }
}
