using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.SeedData;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Persistence;

public static class SchemeManagementDbContextSeed
{
    public static async Task SeedAsync(SchemeManagementDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Schemes.AnyAsync(cancellationToken)) return;

        // NOTE: ids intentionally match ZWS.BuildingBlocks.SeedData.WellKnownSeedIds so the
        // UserManagement module's dummy Group/User plan assignments render sensible names.
        context.Schemes.AddRange(
            WithId(WellKnownSeedIds.SchemeDews, Scheme.Create("DEWS", "DEWS", "AED", "Emirates NBD", "Dubai Employee Workplace Savings scheme.", SchemeState.Active, 500m, 1m)),
            WithId(WellKnownSeedIds.SchemeDubaiGovernment, Scheme.Create("DUBGOV", "Dubai Government", "AED", "Emirates NBD", "Dubai Government workplace savings plan.", SchemeState.Active, 250m, 1m)),
            WithId(WellKnownSeedIds.SchemeDaman, Scheme.Create("DAMAN", "DAMAN", "AED", "ADCB", "DAMAN health & benefits scheme.", SchemeState.Active, 300m, 1m)),
            WithId(WellKnownSeedIds.SchemeDubaiGovernmentAed, Scheme.Create("DUBGOVAED", "Dubai Government AED", "AED", "ADCB", "Dubai Government AED-denominated plan.", SchemeState.Active, 250m, 1m)),
            WithId(WellKnownSeedIds.SchemeAdnoc, Scheme.Create("ADNOC", "ADNOC", "USD", "FAB", "ADNOC workplace savings scheme.", SchemeState.Active, 400m, 3.6725m))
        );

        await context.SaveChangesAsync(cancellationToken);
    }

    private static Scheme WithId(Guid id, Scheme scheme)
    {
        // Id normally comes from EntityBase's constructor (Guid.NewGuid()); here we pin it to a
        // well-known value purely so the UserManagement module's dummy data references the same
        // scheme ids/names without either module sharing a DbContext (requirement 4).
        typeof(Scheme).GetProperty(nameof(Scheme.Id))!.SetValue(scheme, id);
        return scheme;
    }
}
