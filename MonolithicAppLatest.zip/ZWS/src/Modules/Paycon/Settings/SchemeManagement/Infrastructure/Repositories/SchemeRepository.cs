using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Repositories;

public sealed class SchemeRepository(SchemeManagementDbContext context) : ISchemeRepository
{
    public async Task<(IReadOnlyCollection<Scheme> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.Schemes.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(s => EF.Functions.Like(s.Name, $"%{term}%") || EF.Functions.Like(s.Code, $"%{term}%"));
        }

        query = request.SortDescending ? query.OrderByDescending(s => s.Name) : query.OrderBy(s => s.Name);

        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public Task<Scheme?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.Schemes.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    public async Task<IReadOnlyCollection<Scheme>> GetActiveAsync(CancellationToken cancellationToken) =>
        await context.Schemes.Where(s => s.State == SchemeState.Active).AsNoTracking().ToListAsync(cancellationToken);

    public Task<bool> ExistsByCodeAsync(string code, Guid? excludeId, CancellationToken cancellationToken) =>
        context.Schemes.AnyAsync(s => s.Code == code && (excludeId == null || s.Id != excludeId), cancellationToken);

    public void Add(Scheme scheme) => context.Schemes.Add(scheme);
    public void Remove(Scheme scheme) => context.Schemes.Remove(scheme);
}
