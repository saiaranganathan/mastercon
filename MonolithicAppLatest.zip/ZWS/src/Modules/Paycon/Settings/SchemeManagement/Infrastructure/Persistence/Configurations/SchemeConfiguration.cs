using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Persistence.Configurations;

public sealed class SchemeConfiguration : IEntityTypeConfiguration<Scheme>
{
    public void Configure(EntityTypeBuilder<Scheme> builder)
    {
        builder.ToTable("Schemes");
        builder.HasKey(s => s.Id);
        builder.Property(s => s.Code).HasMaxLength(20).IsRequired();
        builder.HasIndex(s => s.Code).IsUnique().HasFilter("[IsDeleted] = 0");
        builder.Property(s => s.Name).HasMaxLength(150).IsRequired();
        builder.Property(s => s.Currency).HasMaxLength(10);
        builder.Property(s => s.OperatingBank).HasMaxLength(150);
        builder.Property(s => s.Description).HasMaxLength(500);
        builder.Property(s => s.State).HasConversion<string>().HasMaxLength(20);
        builder.Property(s => s.ToleranceLimit).HasColumnType("decimal(18,4)");
        builder.Property(s => s.ExchangeRate).HasColumnType("decimal(18,6)");
        builder.Property(s => s.CreatedBy).HasMaxLength(100);
        builder.Property(s => s.UpdatedBy).HasMaxLength(100);
        builder.Property(s => s.DeletedBy).HasMaxLength(100);
    }
}
