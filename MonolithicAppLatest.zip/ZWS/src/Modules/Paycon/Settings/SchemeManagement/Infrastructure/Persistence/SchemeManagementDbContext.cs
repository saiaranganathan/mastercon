using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.SchemeManagement.Infrastructure.Persistence;

public sealed class SchemeManagementDbContext(DbContextOptions<SchemeManagementDbContext> options)
    : DbContext(options), ISchemeManagementDbContext
{
    public DbSet<Scheme> Schemes => Set<Scheme>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_scheme_management");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(SchemeManagementDbContext).Assembly);
        modelBuilder.Entity<Scheme>().HasQueryFilter(s => !s.IsDeleted);
    }
}
