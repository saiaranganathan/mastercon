using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Settings.InsightManagement;

public static class InsightManagementModule
{
    public static IServiceCollection AddInsightManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<InsightManagementDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_insight_management.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_insight_management"));
        });

        services.AddScoped<IInsightManagementDbContext>(sp => sp.GetRequiredService<InsightManagementDbContext>());
        services.AddScoped<IInsightConfigurationRepository, InsightConfigurationRepository>();
        return services;
    }

    public static async Task SeedInsightManagementModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<InsightManagementDbContext>();
        await InsightManagementDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
