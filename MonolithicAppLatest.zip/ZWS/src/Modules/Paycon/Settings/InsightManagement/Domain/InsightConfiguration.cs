using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Domain;

/// <summary>
/// Route: /paycon/settings/insight-management. Placeholder (requirement 16) -
/// architecturally complete and ready to be replaced with the real Figma
/// implementation. Today it configures which Insights module tiles are enabled.
/// </summary>
public sealed class InsightConfiguration : AuditableEntity
{
    public string Name { get; private set; } = default!;
    public string? Description { get; private set; }
    public bool IsEnabled { get; private set; } = true;

    private InsightConfiguration() { }

    public static InsightConfiguration Create(string name, string? description, bool isEnabled) => new()
    {
        Name = name, Description = description, IsEnabled = isEnabled
    };

    public void SetEnabled(bool isEnabled) => IsEnabled = isEnabled;
}
