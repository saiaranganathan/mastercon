using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.InsightManagement.Domain;
using ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Repositories;

public sealed class InsightConfigurationRepository(InsightManagementDbContext context) : IInsightConfigurationRepository
{
    public async Task<IReadOnlyCollection<InsightConfiguration>> GetAllAsync(CancellationToken cancellationToken) =>
        await context.InsightConfigurations.AsNoTracking().OrderBy(c => c.Name).ToListAsync(cancellationToken);

    public Task<InsightConfiguration?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.InsightConfigurations.FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
}
