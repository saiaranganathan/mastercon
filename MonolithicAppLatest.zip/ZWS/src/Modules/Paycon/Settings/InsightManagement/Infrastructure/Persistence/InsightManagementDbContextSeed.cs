using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Settings.InsightManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Persistence;

public static class InsightManagementDbContextSeed
{
    public static async Task SeedAsync(InsightManagementDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.InsightConfigurations.AnyAsync(cancellationToken)) return;

        context.InsightConfigurations.AddRange(
            InsightConfiguration.Create("Average Reconciliation Time", "Shows the rolling average time to reconcile a batch.", true),
            InsightConfiguration.Create("Contribution Growth (MoM)", "Month-over-month contribution growth trend.", true),
            InsightConfiguration.Create("Mismatch Rate", "Percentage of transactions requiring manual review.", true),
            InsightConfiguration.Create("Fund Provider Payout Insights", "Detailed fund provider payout breakdowns (pending Figma design).", false));

        await context.SaveChangesAsync(cancellationToken);
    }
}
