using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.InsightManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Infrastructure.Persistence;

public sealed class InsightManagementDbContext(DbContextOptions<InsightManagementDbContext> options)
    : DbContext(options), IInsightManagementDbContext
{
    public DbSet<InsightConfiguration> InsightConfigurations => Set<InsightConfiguration>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_insight_management");
        modelBuilder.Entity<InsightConfiguration>(b =>
        {
            b.ToTable("InsightConfigurations");
            b.HasKey(x => x.Id);
            b.Property(x => x.Name).HasMaxLength(150);
            b.Property(x => x.Description).HasMaxLength(500);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
