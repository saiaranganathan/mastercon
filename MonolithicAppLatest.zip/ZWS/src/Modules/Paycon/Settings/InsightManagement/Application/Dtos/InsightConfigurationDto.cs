namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Dtos;

public sealed record InsightConfigurationDto(Guid Id, string Name, string? Description, bool IsEnabled);
