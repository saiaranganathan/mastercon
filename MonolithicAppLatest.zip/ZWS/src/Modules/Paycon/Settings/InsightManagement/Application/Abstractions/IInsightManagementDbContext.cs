using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Abstractions;

public interface IInsightManagementDbContext : IAppDbContext;
