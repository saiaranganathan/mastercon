using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Commands;

public sealed record ToggleInsightConfigurationCommand(Guid Id, bool IsEnabled) : ICommand;
