using ZWS.Modules.Paycon.Settings.InsightManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Repositories;

public interface IInsightConfigurationRepository
{
    Task<IReadOnlyCollection<InsightConfiguration>> GetAllAsync(CancellationToken cancellationToken);
    Task<InsightConfiguration?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
}
