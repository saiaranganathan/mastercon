using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Commands;

public sealed class ToggleInsightConfigurationCommandHandler(IInsightConfigurationRepository repository, IInsightManagementDbContext dbContext)
    : ICommandHandler<ToggleInsightConfigurationCommand>
{
    public async Task<Result> Handle(ToggleInsightConfigurationCommand request, CancellationToken cancellationToken)
    {
        var config = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (config is null) return Result.Failure(Error.NotFound("InsightConfiguration.NotFound", "Configuration not found."));

        config.SetEnabled(request.IsEnabled);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
