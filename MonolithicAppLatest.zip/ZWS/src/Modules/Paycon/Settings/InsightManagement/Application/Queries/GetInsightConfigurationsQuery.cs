using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Queries;

public sealed record GetInsightConfigurationsQuery : IQuery<IReadOnlyCollection<InsightConfigurationDto>>;
