using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.InsightManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.InsightManagement.Application.Queries;

public sealed class GetInsightConfigurationsQueryHandler(IInsightConfigurationRepository repository)
    : IQueryHandler<GetInsightConfigurationsQuery, IReadOnlyCollection<InsightConfigurationDto>>
{
    public async Task<Result<IReadOnlyCollection<InsightConfigurationDto>>> Handle(GetInsightConfigurationsQuery request, CancellationToken cancellationToken)
    {
        var configs = await repository.GetAllAsync(cancellationToken);
        var dtos = configs.Select(c => new InsightConfigurationDto(c.Id, c.Name, c.Description, c.IsEnabled)).ToList();
        return Result.Success<IReadOnlyCollection<InsightConfigurationDto>>(dtos);
    }
}
