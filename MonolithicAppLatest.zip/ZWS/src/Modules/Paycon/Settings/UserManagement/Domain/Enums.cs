namespace ZWS.Modules.Paycon.Settings.UserManagement.Domain;

public enum GroupState { Active, Inactive }

public enum RoleState { Active, Inactive }

public enum UserState { Active, Inactive, Terminated }

/// <summary>Fixed permission catalog from PR_UM 2.1's Permission Matrix checkbox list.</summary>
public enum PermissionCode
{
    View,
    Create,
    Edit,
    Delete,
    TransactionApproval,
    ManageGroup,
    ManageRole,
    ManageUsers
}
