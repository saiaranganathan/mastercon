using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Domain;

/// <summary>PR_UM 2.x: a named set of permissions belonging to exactly one Group.</summary>
public sealed class Role : AuditableEntity
{
    public string Name { get; private set; } = default!;
    public Guid GroupId { get; private set; }
    public string? Description { get; private set; }
    public RoleState State { get; private set; } = RoleState.Active;

    private readonly List<RolePermission> _permissions = [];
    public IReadOnlyCollection<RolePermission> Permissions => _permissions.AsReadOnly();

    private Role() { }

    public static Role Create(string name, Guid groupId, string? description, RoleState state, IEnumerable<PermissionCode> permissions)
    {
        var role = new Role { Name = name, GroupId = groupId, Description = description, State = state };
        foreach (var permission in permissions.Distinct())
            role._permissions.Add(RolePermission.Create(role.Id, permission));
        return role;
    }

    public void UpdateDetails(string name, string? description, IEnumerable<PermissionCode> permissions)
    {
        // PR_UM 2.2: Group cannot change once the role has active users - enforced in the command handler,
        // which has visibility into the User aggregate; the domain model here just applies the edit.
        Name = name;
        Description = description;
        _permissions.Clear();
        foreach (var permission in permissions.Distinct())
            _permissions.Add(RolePermission.Create(Id, permission));
    }

    public void ChangeState(RoleState state) => State = state;
}

public sealed class RolePermission
{
    public Guid Id { get; private set; }
    public Guid RoleId { get; private set; }
    public PermissionCode Permission { get; private set; }

    private RolePermission() { }

    public static RolePermission Create(Guid roleId, PermissionCode permission) => new()
    {
        Id = Guid.NewGuid(),
        RoleId = roleId,
        Permission = permission
    };
}
