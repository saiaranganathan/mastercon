using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;

/// <summary>PR_UM 3.0: paginated/searchable/sortable User list (search by full name, email, group, role).</summary>
public sealed record GetUsersQuery(PagedRequest Paging) : IQuery<PagedResult<UserListItemDto>>;
