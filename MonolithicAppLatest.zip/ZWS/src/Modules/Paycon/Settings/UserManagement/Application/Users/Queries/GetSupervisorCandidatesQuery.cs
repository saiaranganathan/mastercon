using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;

/// <summary>Powers the Supervisor drop-down (PR_UM 3.0/3.1) - every user tagged IsSupervisor = Yes.</summary>
public sealed record GetSupervisorCandidatesQuery : IQuery<IReadOnlyCollection<SupervisorOptionDto>>;
