using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;

public sealed class GetUsersQueryHandler(IUserRepository userRepository, IGroupRepository groupRepository)
    : IQueryHandler<GetUsersQuery, PagedResult<UserListItemDto>>
{
    public async Task<Result<PagedResult<UserListItemDto>>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
    {
        var (users, totalCount) = await userRepository.SearchAsync(request.Paging, cancellationToken);

        var items = new List<UserListItemDto>();
        foreach (var user in users)
        {
            var planNames = new List<string>();
            foreach (var membership in user.Groups)
            {
                var group = await groupRepository.GetByIdAsync(membership.GroupId, cancellationToken);
                if (group is not null) planNames.AddRange(group.SchemeAssignments.Select(s => s.SchemeName));
            }
            planNames.AddRange(user.SchemeOverrides.Select(s => s.SchemeName));
            var plans = planNames.Distinct().DefaultIfEmpty("-");

            items.Add(new UserListItemDto(
                user.Id, user.FullName, user.Email, string.Join(", ", plans),
                user.SupervisorName, user.State.ToString(), user.IsSupervisor,
                user.CreatedAt, user.CreatedBy, user.UpdatedAt, user.UpdatedBy));
        }

        return Result.Success(new PagedResult<UserListItemDto>(items, totalCount, request.Paging.Page, request.Paging.PageSize));
    }
}
