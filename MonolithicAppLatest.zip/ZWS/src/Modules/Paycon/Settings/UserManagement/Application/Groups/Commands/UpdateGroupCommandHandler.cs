using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Groups.Commands;

public sealed class UpdateGroupCommandHandler(
    IGroupRepository groupRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext) : ICommandHandler<UpdateGroupCommand>
{
    public async Task<Result> Handle(UpdateGroupCommand request, CancellationToken cancellationToken)
    {
        var group = await groupRepository.GetByIdAsync(request.Id, cancellationToken);
        if (group is null)
            return Result.Failure(Error.NotFound("Group.NotFound", $"Group '{request.Id}' was not found."));

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var selectedSchemes = allSchemes
            .Where(s => request.SchemeIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        // PR_UM-1.3: plans removed from a group automatically remove access from users who
        // inherit that plan, unless they hold an explicit user-level override - the User
        // aggregate's own inherited-plan projection (see GetUserByIdQueryHandler) recalculates
        // this live from the group's current scheme assignments, so nothing further to cascade here.
        group.UpdateDetails(request.Name, request.State, request.OverridePlanPermissionAtUserLevel, selectedSchemes);

        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
