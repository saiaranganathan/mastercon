using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Commands;

public sealed class UpdateUserCommandHandler(
    IUserRepository userRepository,
    IGroupRepository groupRepository,
    IRoleRepository roleRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext,
    IEventBus eventBus,
    ICurrentUserService currentUser) : ICommandHandler<UpdateUserCommand>
{
    public async Task<Result> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByIdAsync(request.Id, cancellationToken);
        if (user is null)
            return Result.Failure(Error.NotFound("User.NotFound", $"User '{request.Id}' was not found."));

        if (request.SupervisorId == request.Id)
            return Result.Failure(Error.Validation("User.InvalidSupervisor", "A user cannot be their own supervisor."));

        var previousState = user.State.ToString();

        var groups = new List<(Guid, string)>();
        foreach (var groupId in request.GroupIds)
        {
            var group = await groupRepository.GetByIdAsync(groupId, cancellationToken);
            if (group is not null) groups.Add((group.Id, group.Name));
        }

        var roles = new List<(Guid, string)>();
        foreach (var roleId in request.RoleIds)
        {
            var role = await roleRepository.GetByIdAsync(roleId, cancellationToken);
            if (role is not null) roles.Add((role.Id, role.Name));
        }

        string? supervisorName = null;
        if (request.SupervisorId is { } supervisorId)
        {
            var supervisor = await userRepository.GetByIdAsync(supervisorId, cancellationToken);
            supervisorName = supervisor?.FullName;
        }

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var schemeOverrides = allSchemes
            .Where(s => request.SchemeOverrideIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        user.UpdateDetails(request.SupervisorId, supervisorName, request.IsSupervisor, request.State, groups, roles, request.Permissions, schemeOverrides);
        await dbContext.SaveChangesAsync(cancellationToken);

        if (previousState != request.State.ToString())
        {
            await eventBus.PublishAsync(
                new UserStateChangedIntegrationEvent(user.Id, user.FullName, previousState, request.State.ToString(), currentUser.IsAuthenticated ? currentUser.UserId : "system"),
                cancellationToken);
        }

        return Result.Success();
    }
}
