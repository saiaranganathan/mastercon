using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Groups.Queries;

/// <summary>PR_UM-1.1/1.2: paginated, searchable, sortable Group list.</summary>
public sealed record GetGroupsQuery(PagedRequest Paging) : IQuery<PagedResult<GroupListItemDto>>;
