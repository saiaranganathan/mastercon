using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

public interface IRoleRepository
{
    Task<(IReadOnlyCollection<Role> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<Role?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<bool> ExistsByNameAsync(string groupQualifiedName, Guid? excludeId, CancellationToken cancellationToken);
    Task<int> CountActiveUsersAsync(Guid roleId, CancellationToken cancellationToken);
    void Add(Role role);
    void Remove(Role role);
}
