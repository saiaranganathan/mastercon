using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Roles.Commands;

public sealed class UpdateRoleCommandHandler(IRoleRepository roleRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<UpdateRoleCommand>
{
    public async Task<Result> Handle(UpdateRoleCommand request, CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.Id, cancellationToken);
        if (role is null)
            return Result.Failure(Error.NotFound("Role.NotFound", $"Role '{request.Id}' was not found."));

        var activeUsers = await roleRepository.CountActiveUsersAsync(role.Id, cancellationToken);

        // PR_UM 2.2: state changes are blocked (with a warning, surfaced by the API as a Conflict)
        // once the role has active users - only permission changes remain possible, and those
        // must propagate to every user currently holding the role.
        if (activeUsers > 0 && role.State != request.State)
            return Result.Failure(Error.Conflict("Role.HasActiveUsers", "This role has active users - its state cannot be changed while users are assigned."));

        role.UpdateDetails(request.Name, request.Description, request.Permissions);
        if (activeUsers == 0) role.ChangeState(request.State);

        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
