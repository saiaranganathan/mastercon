using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Commands;

/// <summary>Delete is only allowed for Inactive or Terminated users; an Active user cannot be deleted.</summary>
public sealed record DeleteUserCommand(Guid Id) : ICommand;
