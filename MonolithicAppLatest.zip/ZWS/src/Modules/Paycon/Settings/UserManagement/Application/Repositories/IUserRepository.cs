using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

public interface IUserRepository
{
    Task<(IReadOnlyCollection<User> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<bool> ExistsByEmailAsync(string email, Guid? excludeId, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<User>> GetSupervisorCandidatesAsync(CancellationToken cancellationToken);
    void Add(User user);
    void Remove(User user);
}
