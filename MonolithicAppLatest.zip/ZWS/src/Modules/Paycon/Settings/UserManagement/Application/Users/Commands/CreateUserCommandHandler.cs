using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Commands;

public sealed class CreateUserCommandHandler(
    IUserRepository userRepository,
    IGroupRepository groupRepository,
    IRoleRepository roleRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext,
    IEventBus eventBus,
    ICurrentUserService currentUser) : ICommandHandler<CreateUserCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        var groups = new List<(Guid, string)>();
        foreach (var groupId in request.GroupIds)
        {
            var group = await groupRepository.GetByIdAsync(groupId, cancellationToken);
            if (group is not null) groups.Add((group.Id, group.Name));
        }

        var roles = new List<(Guid, string)>();
        foreach (var roleId in request.RoleIds)
        {
            var role = await roleRepository.GetByIdAsync(roleId, cancellationToken);
            if (role is not null) roles.Add((role.Id, role.Name));
        }

        string? supervisorName = null;
        if (request.SupervisorId is { } supervisorId)
        {
            var supervisor = await userRepository.GetByIdAsync(supervisorId, cancellationToken);
            supervisorName = supervisor?.FullName;
        }

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var schemeOverrides = allSchemes
            .Where(s => request.SchemeOverrideIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        var user = User.Create(
            request.FullName, request.Email, request.SupervisorId, supervisorName, request.IsSupervisor, request.State,
            groups, roles, request.Permissions, schemeOverrides);

        userRepository.Add(user);
        await dbContext.SaveChangesAsync(cancellationToken);

        await eventBus.PublishAsync(
            new UserCreatedIntegrationEvent(user.Id, user.FullName, user.Email, currentUser.IsAuthenticated ? currentUser.UserId : "system"),
            cancellationToken);

        return Result.Success(user.Id);
    }
}
