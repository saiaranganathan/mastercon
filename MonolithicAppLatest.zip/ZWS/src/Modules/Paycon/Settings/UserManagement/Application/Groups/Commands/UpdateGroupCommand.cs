using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Groups.Commands;

/// <summary>PR_UM-1.3: Edit Group.</summary>
public sealed record UpdateGroupCommand(
    Guid Id,
    string Name,
    GroupState State,
    bool OverridePlanPermissionAtUserLevel,
    IReadOnlyCollection<Guid> SchemeIds) : ICommand;
