using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Commands;

/// <summary>PR_UM 3.2: Edit User. Full Name and Email are non-editable, per the BRD.</summary>
public sealed record UpdateUserCommand(
    Guid Id,
    Guid? SupervisorId,
    bool IsSupervisor,
    UserState State,
    IReadOnlyCollection<Guid> GroupIds,
    IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PermissionCode> Permissions,
    IReadOnlyCollection<Guid> SchemeOverrideIds) : ICommand;
