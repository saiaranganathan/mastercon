using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

/// <summary>
/// UserManagement's window into the SchemeManagement module. Implemented in
/// Infrastructure by sending SchemeManagement's own public MediatR query -
/// this is cross-module communication through an Application-layer contract,
/// never through SchemeManagementDbContext (requirement 4).
/// </summary>
public interface ISchemeReferenceService
{
    Task<IReadOnlyCollection<SchemeRefDto>> GetActiveSchemesAsync(CancellationToken cancellationToken);
}
