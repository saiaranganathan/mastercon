using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Groups.Queries;

public sealed class GetGroupByIdQueryHandler(IGroupRepository groupRepository)
    : IQueryHandler<GetGroupByIdQuery, GroupDetailDto>
{
    public async Task<Result<GroupDetailDto>> Handle(GetGroupByIdQuery request, CancellationToken cancellationToken)
    {
        var group = await groupRepository.GetByIdAsync(request.Id, cancellationToken);
        if (group is null)
            return Result.Failure<GroupDetailDto>(Error.NotFound("Group.NotFound", $"Group '{request.Id}' was not found."));

        var activeUsers = await groupRepository.CountActiveUsersAsync(group.Id, cancellationToken);
        var plans = group.SchemeAssignments.Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName)).ToList();

        return Result.Success(new GroupDetailDto(
            group.Id, group.Name, plans, activeUsers, group.State.ToString(), group.OverridePlanPermissionAtUserLevel,
            group.CreatedAt, group.CreatedBy, group.UpdatedAt, group.UpdatedBy));
    }
}
