using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Permissions;

public sealed record PermissionOptionDto(string Code, string Label);

/// <summary>The fixed catalog behind every "Permission Matrix" multi-select in the Groups/Roles/Users screens.</summary>
public sealed record GetPermissionsQuery : IQuery<IReadOnlyCollection<PermissionOptionDto>>;
