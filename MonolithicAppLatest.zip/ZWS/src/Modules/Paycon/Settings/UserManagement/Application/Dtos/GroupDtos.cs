namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

public sealed record GroupListItemDto(
    Guid Id, string Name, string AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record GroupDetailDto(
    Guid Id, string Name, IReadOnlyCollection<SchemeRefDto> AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record SchemeRefDto(Guid SchemeId, string SchemeName);
