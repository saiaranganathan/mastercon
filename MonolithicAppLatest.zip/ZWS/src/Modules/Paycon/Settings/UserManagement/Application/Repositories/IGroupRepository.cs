using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

public interface IGroupRepository
{
    Task<(IReadOnlyCollection<Group> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<Group?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<bool> ExistsByNameAsync(string name, Guid? excludeId, CancellationToken cancellationToken);
    Task<int> CountActiveUsersAsync(Guid groupId, CancellationToken cancellationToken);
    void Add(Group group);
    void Remove(Group group);
}
