using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Roles.Queries;

/// <summary>PR_UM 2.0: paginated, searchable Role list (search by Role Name, Group Name or Description).</summary>
public sealed record GetRolesQuery(PagedRequest Paging) : IQuery<PagedResult<RoleListItemDto>>;
