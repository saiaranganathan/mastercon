using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Permissions;

public sealed class GetPermissionsQueryHandler : IQueryHandler<GetPermissionsQuery, IReadOnlyCollection<PermissionOptionDto>>
{
    public Task<Result<IReadOnlyCollection<PermissionOptionDto>>> Handle(GetPermissionsQuery request, CancellationToken cancellationToken)
    {
        var options = Enum.GetValues<PermissionCode>()
            .Select(p => new PermissionOptionDto(p.ToString(), Humanize(p)))
            .ToList();

        return Task.FromResult(Result.Success<IReadOnlyCollection<PermissionOptionDto>>(options));
    }

    private static string Humanize(PermissionCode code) => code switch
    {
        PermissionCode.View => "View",
        PermissionCode.Create => "Create",
        PermissionCode.Edit => "Edit",
        PermissionCode.Delete => "Delete",
        PermissionCode.TransactionApproval => "Transaction Approval",
        PermissionCode.ManageGroup => "Manage Group",
        PermissionCode.ManageRole => "Manage Role",
        PermissionCode.ManageUsers => "Manage Users",
        _ => code.ToString()
    };
}
