using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;

/// <summary>PR_UM 3.4: full user detail view (the tabbed Details/Groups/Roles/Permissions modal).</summary>
public sealed record GetUserByIdQuery(Guid Id) : IQuery<UserDetailDto>;
