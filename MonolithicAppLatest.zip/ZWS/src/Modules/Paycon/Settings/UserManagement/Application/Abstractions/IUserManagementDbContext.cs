using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;

/// <summary>
/// Module-specific SaveChanges abstraction. Each module declares its own
/// (rather than every handler depending on the shared IAppDbContext), because
/// IAppDbContext is implemented by every module's DbContext - resolving the
/// bare shared interface from the single composite DI container would be
/// ambiguous. This keeps Application-layer handlers decoupled from EF Core
/// while still resolving unambiguously per module.
/// </summary>
public interface IUserManagementDbContext : IAppDbContext;
