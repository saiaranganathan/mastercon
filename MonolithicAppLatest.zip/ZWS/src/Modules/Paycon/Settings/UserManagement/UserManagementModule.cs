using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.ExternalServices;
using ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement;

public static class UserManagementModule
{
    public static IServiceCollection AddUserManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<UserManagementDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_user_management.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_user_management"));
        });

        services.AddScoped<IUserManagementDbContext>(sp => sp.GetRequiredService<UserManagementDbContext>());
        services.AddScoped<IGroupRepository, GroupRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<ISchemeReferenceService, SchemeReferenceService>();

        return services;
    }

    public static async Task SeedUserManagementModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<UserManagementDbContext>();
        await UserManagementDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
