using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.Persistence.Configurations;

public sealed class GroupConfiguration : IEntityTypeConfiguration<Group>
{
    public void Configure(EntityTypeBuilder<Group> builder)
    {
        builder.ToTable("Groups");
        builder.HasKey(g => g.Id);
        builder.Property(g => g.Name).HasMaxLength(150).IsRequired();
        builder.HasIndex(g => g.Name).IsUnique().HasFilter("[IsDeleted] = 0");
        builder.Property(g => g.State).HasConversion<string>().HasMaxLength(20);
        builder.Property(g => g.CreatedBy).HasMaxLength(100);
        builder.Property(g => g.UpdatedBy).HasMaxLength(100);
        builder.Property(g => g.DeletedBy).HasMaxLength(100);

        builder.HasMany(g => g.SchemeAssignments).WithOne().HasForeignKey(s => s.GroupId).OnDelete(DeleteBehavior.Cascade);
        builder.Metadata.FindNavigation(nameof(Group.SchemeAssignments))!.SetPropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class GroupSchemeAssignmentConfiguration : IEntityTypeConfiguration<GroupSchemeAssignment>
{
    public void Configure(EntityTypeBuilder<GroupSchemeAssignment> builder)
    {
        builder.ToTable("GroupSchemeAssignments");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.SchemeName).HasMaxLength(150);
    }
}
