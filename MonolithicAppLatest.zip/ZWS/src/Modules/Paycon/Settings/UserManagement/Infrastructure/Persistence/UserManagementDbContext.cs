using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Abstractions;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.Persistence;

/// <summary>
/// The ONLY DbContext for the UserManagement module - covers Groups, Roles,
/// Users and their assignment tables. No other module may reference this type.
/// </summary>
public sealed class UserManagementDbContext(DbContextOptions<UserManagementDbContext> options)
    : DbContext(options), IUserManagementDbContext
{
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<GroupSchemeAssignment> GroupSchemeAssignments => Set<GroupSchemeAssignment>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<User> Users => Set<User>();
    public DbSet<UserGroupAssignment> UserGroupAssignments => Set<UserGroupAssignment>();
    public DbSet<UserRoleAssignment> UserRoleAssignments => Set<UserRoleAssignment>();
    public DbSet<UserPermissionAssignment> UserPermissionAssignments => Set<UserPermissionAssignment>();
    public DbSet<UserSchemeOverride> UserSchemeOverrides => Set<UserSchemeOverride>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_user_management");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(UserManagementDbContext).Assembly);
        modelBuilder.Entity<Group>().HasQueryFilter(g => !g.IsDeleted);
        modelBuilder.Entity<Role>().HasQueryFilter(r => !r.IsDeleted);
        modelBuilder.Entity<User>().HasQueryFilter(u => !u.IsDeleted);
    }
}
