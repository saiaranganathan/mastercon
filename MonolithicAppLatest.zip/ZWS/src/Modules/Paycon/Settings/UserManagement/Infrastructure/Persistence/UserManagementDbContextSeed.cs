using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.SeedData;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.Persistence;

/// <summary>Realistic dummy data mirroring the Figma Users/Groups/Roles screens (requirement 30).</summary>
public static class UserManagementDbContextSeed
{
    public static async Task SeedAsync(UserManagementDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Groups.AnyAsync(cancellationToken)) return;

        (Guid Id, string Name)[] schemes =
        [
            (WellKnownSeedIds.SchemeDews, "DEWS"),
            (WellKnownSeedIds.SchemeDubaiGovernment, "Dubai Government"),
            (WellKnownSeedIds.SchemeDaman, "DAMAN"),
            (WellKnownSeedIds.SchemeDubaiGovernmentAed, "Dubai Government AED"),
            (WellKnownSeedIds.SchemeAdnoc, "ADNOC")
        ];

        var finance = Group.Create("Finance", GroupState.Active, true, [schemes[0], schemes[1], schemes[2], schemes[3]]);
        var operations = Group.Create("Operations", GroupState.Active, true, [schemes[0], schemes[1]]);
        var compliance = Group.Create("Compliance", GroupState.Active, false, [schemes[0]]);
        var crm = Group.Create("CRM", GroupState.Active, true, [schemes[1], schemes[2]]);
        var it = Group.Create("IT", GroupState.Active, false, [schemes[0], schemes[1], schemes[2], schemes[3], schemes[4]]);
        var system = Group.Create("System", GroupState.Inactive, false, [schemes[4]]);

        context.Groups.AddRange(finance, operations, compliance, crm, it, system);
        await context.SaveChangesAsync(cancellationToken);

        var financeRole = Role.Create("FinanceAnalyst", finance.Id, "Reconciliation and payments analyst.", RoleState.Active,
            [PermissionCode.View, PermissionCode.Create, PermissionCode.Edit, PermissionCode.TransactionApproval]);
        var opsRole = Role.Create("OperationsLead", operations.Id, "Operations team lead.", RoleState.Active,
            [PermissionCode.View, PermissionCode.Create, PermissionCode.Edit, PermissionCode.Delete, PermissionCode.ManageUsers]);
        var itAdminRole = Role.Create("ITAdministrator", it.Id, "Full system administration.", RoleState.Active,
            [PermissionCode.View, PermissionCode.Create, PermissionCode.Edit, PermissionCode.Delete, PermissionCode.ManageGroup, PermissionCode.ManageRole, PermissionCode.ManageUsers, PermissionCode.TransactionApproval]);
        var crmViewerRole = Role.Create("CRMViewer", crm.Id, "Read-only access to CRM data.", RoleState.Active, [PermissionCode.View]);

        context.Roles.AddRange(financeRole, opsRole, itAdminRole, crmViewerRole);
        await context.SaveChangesAsync(cancellationToken);

        var shelby = User.Create("Shelby Goode", "userfour@zurich.com", null, null, true, UserState.Active,
            [(operations.Id, operations.Name)], [(opsRole.Id, opsRole.Name)], [PermissionCode.View, PermissionCode.Create, PermissionCode.Edit], []);
        var robert = User.Create("Robert Bacins", "userthree@zurich.com", null, null, true, UserState.Active,
            [(it.Id, it.Name)], [(itAdminRole.Id, itAdminRole.Name)], [PermissionCode.View, PermissionCode.ManageUsers], []);
        var john = User.Create("John Carilo", "usertwo@zurich.com", robert.Id, robert.FullName, true, UserState.Active,
            [(crm.Id, crm.Name)], [(crmViewerRole.Id, crmViewerRole.Name)], [PermissionCode.View], []);

        context.Users.AddRange(shelby, robert, john);
        await context.SaveChangesAsync(cancellationToken);

        var adriene = User.Create("Adriene Watson", "userone@zurich.com", shelby.Id, shelby.FullName, false, UserState.Active,
            [(finance.Id, finance.Name)], [(financeRole.Id, financeRole.Name)], [PermissionCode.View, PermissionCode.Create], [(schemes[4].Id, schemes[4].Name)]);
        var johnDeo = User.Create("John Deo", "userfive@zurich.com", shelby.Id, shelby.FullName, false, UserState.Inactive,
            [(finance.Id, finance.Name)], [(financeRole.Id, financeRole.Name)], [PermissionCode.View], []);
        var terminatedUser = User.Create("Priya Sharma", "usersix@zurich.com", robert.Id, robert.FullName, false, UserState.Terminated,
            [(compliance.Id, compliance.Name)], [(crmViewerRole.Id, crmViewerRole.Name)], [PermissionCode.View], []);

        context.Users.AddRange(adriene, johnDeo, terminatedUser);
        await context.SaveChangesAsync(cancellationToken);
    }
}
