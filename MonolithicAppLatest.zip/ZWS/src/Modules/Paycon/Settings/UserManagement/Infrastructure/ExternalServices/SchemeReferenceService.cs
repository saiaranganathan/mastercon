using MediatR;
using ZWS.Modules.Paycon.Settings.SchemeManagement.Application.Queries;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Infrastructure.ExternalServices;

/// <summary>
/// Cross-module call into SchemeManagement's own public MediatR query. This is
/// the sanctioned way modules talk to each other in this codebase: through
/// the other module's Application-layer contract, never through its DbContext.
/// </summary>
public sealed class SchemeReferenceService(ISender sender) : ISchemeReferenceService
{
    public async Task<IReadOnlyCollection<SchemeRefDto>> GetActiveSchemesAsync(CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetActiveSchemesForReferenceQuery(), cancellationToken);
        if (result.IsFailure) return [];

        return result.Value.Select(s => new SchemeRefDto(s.Id, s.Name)).ToList();
    }
}
