using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Notifications.Domain;

public enum NotificationSeverity { Info, Success, Warning, Error }

/// <summary>
/// A single notification, created exclusively in reaction to integration
/// events published by other Paycon modules over RabbitMQ (requirement 9) -
/// this module never receives synchronous calls that write data.
/// </summary>
public sealed class Notification : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public string Description { get; private set; } = default!;
    public NotificationSeverity Severity { get; private set; } = NotificationSeverity.Info;
    public DateTime OccurredAt { get; private set; }
    public bool IsRead { get; private set; }
    public string? TargetUserId { get; private set; } // null = broadcast to every Paycon user

    private Notification() { }

    public static Notification Create(string title, string description, NotificationSeverity severity, string? targetUserId = null) => new()
    {
        Title = title,
        Description = description,
        Severity = severity,
        OccurredAt = DateTime.UtcNow,
        TargetUserId = targetUserId
    };

    public void MarkRead() => IsRead = true;
}
