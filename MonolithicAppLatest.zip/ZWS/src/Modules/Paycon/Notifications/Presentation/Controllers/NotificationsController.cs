using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Notifications.Application.Commands;
using ZWS.Modules.Paycon.Notifications.Application.Queries;

namespace ZWS.Modules.Paycon.Notifications.Presentation.Controllers;

[ApiController]
[Route("api/paycon/notifications")]
public sealed class NotificationsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetRecent([FromQuery] int take = 10, CancellationToken cancellationToken = default) =>
        (await sender.Send(new GetRecentNotificationsQuery(take), cancellationToken)).ToActionResult();

    [HttpPost("{id:guid}/mark-read")]
    public async Task<IActionResult> MarkRead(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new MarkNotificationReadCommand(id), cancellationToken)).ToActionResult();
}
