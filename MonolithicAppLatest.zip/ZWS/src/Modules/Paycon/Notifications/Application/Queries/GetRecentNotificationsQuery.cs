using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;

namespace ZWS.Modules.Paycon.Notifications.Application.Queries;

/// <summary>Public cross-module contract - consumed today by the Dashboard module's Notifications panel.</summary>
public sealed record GetRecentNotificationsQuery(int Take = 10) : IQuery<IReadOnlyCollection<NotificationDto>>;
