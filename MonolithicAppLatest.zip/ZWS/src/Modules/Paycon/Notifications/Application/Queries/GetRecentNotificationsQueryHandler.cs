using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;

namespace ZWS.Modules.Paycon.Notifications.Application.Queries;

public sealed class GetRecentNotificationsQueryHandler(INotificationRepository repository)
    : IQueryHandler<GetRecentNotificationsQuery, IReadOnlyCollection<NotificationDto>>
{
    public async Task<Result<IReadOnlyCollection<NotificationDto>>> Handle(GetRecentNotificationsQuery request, CancellationToken cancellationToken)
    {
        var notifications = await repository.GetRecentAsync(request.Take, cancellationToken);
        var dtos = notifications.Select(n => new NotificationDto(n.Id, n.Title, n.Description, n.Severity.ToString(), n.OccurredAt, n.IsRead)).ToList();
        return Result.Success<IReadOnlyCollection<NotificationDto>>(dtos);
    }
}
