namespace ZWS.Modules.Paycon.Notifications.Application.Dtos;

public sealed record NotificationDto(Guid Id, string Title, string Description, string Severity, DateTime OccurredAt, bool IsRead);
