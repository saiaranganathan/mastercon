using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Notifications.Application.Commands;

public sealed record MarkNotificationReadCommand(Guid Id) : ICommand;
