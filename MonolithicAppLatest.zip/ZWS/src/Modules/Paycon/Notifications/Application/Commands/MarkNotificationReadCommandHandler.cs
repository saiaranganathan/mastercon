using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;

namespace ZWS.Modules.Paycon.Notifications.Application.Commands;

public sealed class MarkNotificationReadCommandHandler(INotificationRepository repository, INotificationsDbContext dbContext)
    : ICommandHandler<MarkNotificationReadCommand>
{
    public async Task<Result> Handle(MarkNotificationReadCommand request, CancellationToken cancellationToken)
    {
        var notification = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (notification is null) return Result.Failure(Error.NotFound("Notification.NotFound", "Notification not found."));

        notification.MarkRead();
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
