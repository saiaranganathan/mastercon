using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Application.Repositories;

public interface INotificationRepository
{
    Task<IReadOnlyCollection<Notification>> GetRecentAsync(int take, CancellationToken cancellationToken);
    Task<Notification?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    void Add(Notification notification);
}
