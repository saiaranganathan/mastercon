using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Application.EventHandlers;

public sealed class UserStateChangedIntegrationEventHandler(
    INotificationRepository repository,
    INotificationsDbContext dbContext,
    IPayconRealtimeNotifier realtimeNotifier) : IIntegrationEventHandler<UserStateChangedIntegrationEvent>
{
    public async Task HandleAsync(UserStateChangedIntegrationEvent @event, CancellationToken cancellationToken)
    {
        var notification = Notification.Create(
            "User State Changed",
            $"{@event.FullName} moved from {@event.PreviousState} to {@event.NewState} (by {@event.ChangedBy}).",
            NotificationSeverity.Warning);

        repository.Add(notification);
        await dbContext.SaveChangesAsync(cancellationToken);

        var dto = new NotificationDto(notification.Id, notification.Title, notification.Description, notification.Severity.ToString(), notification.OccurredAt, notification.IsRead);
        await realtimeNotifier.NotificationReceivedAsync(dto, cancellationToken);
    }
}
