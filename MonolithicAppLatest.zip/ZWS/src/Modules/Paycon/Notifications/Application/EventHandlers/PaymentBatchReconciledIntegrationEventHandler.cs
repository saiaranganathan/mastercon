using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Application.EventHandlers;

public sealed class PaymentBatchReconciledIntegrationEventHandler(
    INotificationRepository repository,
    INotificationsDbContext dbContext,
    IPayconRealtimeNotifier realtimeNotifier) : IIntegrationEventHandler<PaymentBatchReconciledIntegrationEvent>
{
    public async Task HandleAsync(PaymentBatchReconciledIntegrationEvent @event, CancellationToken cancellationToken)
    {
        var severity = @event.MismatchedCount > 0 ? NotificationSeverity.Warning : NotificationSeverity.Success;
        var notification = Notification.Create(
            "Reconciliation Completed",
            $"{@event.FileName}: {@event.MatchedCount} matched, {@event.MismatchedCount} mismatched.",
            severity);

        repository.Add(notification);
        await dbContext.SaveChangesAsync(cancellationToken);

        var dto = new NotificationDto(notification.Id, notification.Title, notification.Description, notification.Severity.ToString(), notification.OccurredAt, notification.IsRead);
        await realtimeNotifier.NotificationReceivedAsync(dto, cancellationToken);
        await realtimeNotifier.ReconciliationUpdatedAsync(@event.BatchId, "Completed", cancellationToken);
    }
}
