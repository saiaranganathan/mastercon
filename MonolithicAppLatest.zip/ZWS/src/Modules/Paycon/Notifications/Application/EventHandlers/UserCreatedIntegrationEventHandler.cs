using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Application.EventHandlers;

/// <summary>
/// Reacts to UserManagement's UserCreatedIntegrationEvent over RabbitMQ
/// (requirement 9) - this is the ONLY way Notifications learns a user was
/// created; it never calls UserManagement synchronously.
/// </summary>
public sealed class UserCreatedIntegrationEventHandler(
    INotificationRepository repository,
    INotificationsDbContext dbContext,
    IPayconRealtimeNotifier realtimeNotifier) : IIntegrationEventHandler<UserCreatedIntegrationEvent>
{
    public async Task HandleAsync(UserCreatedIntegrationEvent @event, CancellationToken cancellationToken)
    {
        var notification = Notification.Create(
            "User Created",
            $"{@event.FullName} ({@event.Email}) was created by {@event.CreatedBy}.",
            NotificationSeverity.Success);

        repository.Add(notification);
        await dbContext.SaveChangesAsync(cancellationToken);

        var dto = new NotificationDto(notification.Id, notification.Title, notification.Description, notification.Severity.ToString(), notification.OccurredAt, notification.IsRead);
        await realtimeNotifier.NotificationReceivedAsync(dto, cancellationToken);
    }
}
