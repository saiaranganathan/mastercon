using ZWS.Modules.Paycon.Notifications.Application.Dtos;

namespace ZWS.Modules.Paycon.Notifications.Application.Abstractions;

/// <summary>Application-layer abstraction over SignalR so handlers never reference IHubContext directly.</summary>
public interface IPayconRealtimeNotifier
{
    Task NotificationReceivedAsync(NotificationDto notification, CancellationToken cancellationToken);
    Task DashboardMetricUpdatedAsync(CancellationToken cancellationToken);
    Task PaymentStatusUpdatedAsync(Guid paymentId, string status, CancellationToken cancellationToken);
    Task ReconciliationUpdatedAsync(Guid batchId, string status, CancellationToken cancellationToken);
}
