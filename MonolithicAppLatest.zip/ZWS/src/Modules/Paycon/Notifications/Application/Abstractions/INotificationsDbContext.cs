using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Notifications.Application.Abstractions;

public interface INotificationsDbContext : IAppDbContext;
