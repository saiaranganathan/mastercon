using Microsoft.AspNetCore.SignalR;
using ZWS.BuildingBlocks.Realtime;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.Dtos;

namespace ZWS.Modules.Paycon.Notifications.Infrastructure.Hubs;

public sealed class PayconRealtimeNotifier(IHubContext<PayconHub> hubContext) : IPayconRealtimeNotifier
{
    public Task NotificationReceivedAsync(NotificationDto notification, CancellationToken cancellationToken) =>
        hubContext.Clients.Group("paycon-users").SendAsync("NotificationReceived", notification, cancellationToken);

    public Task DashboardMetricUpdatedAsync(CancellationToken cancellationToken) =>
        hubContext.Clients.Group("paycon-users").SendAsync("DashboardMetricUpdated", cancellationToken);

    public Task PaymentStatusUpdatedAsync(Guid paymentId, string status, CancellationToken cancellationToken) =>
        hubContext.Clients.Group("paycon-users").SendAsync("PaymentStatusUpdated", paymentId, status, cancellationToken);

    public Task ReconciliationUpdatedAsync(Guid batchId, string status, CancellationToken cancellationToken) =>
        hubContext.Clients.Group("paycon-users").SendAsync("ReconciliationUpdated", batchId, status, cancellationToken);
}
