using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Domain;
using ZWS.Modules.Paycon.Notifications.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Notifications.Infrastructure.Repositories;

public sealed class NotificationRepository(NotificationsDbContext context) : INotificationRepository
{
    public async Task<IReadOnlyCollection<Notification>> GetRecentAsync(int take, CancellationToken cancellationToken) =>
        await context.Notifications.AsNoTracking().OrderByDescending(n => n.OccurredAt).Take(take).ToListAsync(cancellationToken);

    public Task<Notification?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.Notifications.FirstOrDefaultAsync(n => n.Id == id, cancellationToken);

    public void Add(Notification notification) => context.Notifications.Add(notification);
}
