using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Infrastructure.Persistence;

public sealed class NotificationsDbContext(DbContextOptions<NotificationsDbContext> options)
    : DbContext(options), INotificationsDbContext
{
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_notifications");
        modelBuilder.Entity<Notification>(b =>
        {
            b.ToTable("Notifications");
            b.HasKey(n => n.Id);
            b.Property(n => n.Title).HasMaxLength(200).IsRequired();
            b.Property(n => n.Description).HasMaxLength(1000).IsRequired();
            b.Property(n => n.Severity).HasConversion<string>().HasMaxLength(20);
            b.Property(n => n.TargetUserId).HasMaxLength(100);
            b.Property(n => n.CreatedBy).HasMaxLength(100);
            b.Property(n => n.UpdatedBy).HasMaxLength(100);
            b.Property(n => n.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(n => !n.IsDeleted);
        });
    }
}
