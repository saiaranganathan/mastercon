using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Notifications.Domain;

namespace ZWS.Modules.Paycon.Notifications.Infrastructure.Persistence;

public static class NotificationsDbContextSeed
{
    public static async Task SeedAsync(NotificationsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Notifications.AnyAsync(cancellationToken)) return;

        context.Notifications.AddRange(
            Notification.Create("Reconciliation Completed", "The December DEWS reconciliation batch completed successfully.", NotificationSeverity.Success),
            Notification.Create("Workflow Failed", "The DAMAN payments-in workflow failed validation - see error log.", NotificationSeverity.Error),
            Notification.Create("Month-End Close Reminder", "Month-end close for December starts in 3 days.", NotificationSeverity.Info));

        await context.SaveChangesAsync(cancellationToken);
    }
}
