using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Notifications.Application.Abstractions;
using ZWS.Modules.Paycon.Notifications.Application.EventHandlers;
using ZWS.Modules.Paycon.Notifications.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Infrastructure.Hubs;
using ZWS.Modules.Paycon.Notifications.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Notifications.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Notifications;

/// <summary>
/// The Notifications module is deliberately isolated (requirement 9): it has
/// no project reference to, and is never referenced by, UserManagement or any
/// other Paycon module. It hears about the rest of the system exclusively
/// through RabbitMQ integration events, and is reached back only via its own
/// public MediatR query (GetRecentNotificationsQuery) or the shared SignalR hub.
/// </summary>
public static class NotificationsModule
{
    public static IServiceCollection AddNotificationsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<NotificationsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_notifications.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_notifications"));
        });

        services.AddScoped<INotificationsDbContext>(sp => sp.GetRequiredService<NotificationsDbContext>());
        services.AddScoped<INotificationRepository, NotificationRepository>();
        services.AddScoped<IPayconRealtimeNotifier, PayconRealtimeNotifier>();

        services.AddZwsIntegrationEventConsumer<UserCreatedIntegrationEvent, UserCreatedIntegrationEventHandler>("paycon.notifications.user-created");
        services.AddZwsIntegrationEventConsumer<UserStateChangedIntegrationEvent, UserStateChangedIntegrationEventHandler>("paycon.notifications.user-state-changed");
        services.AddZwsIntegrationEventConsumer<PaymentBatchReconciledIntegrationEvent, PaymentBatchReconciledIntegrationEventHandler>("paycon.notifications.payment-batch-reconciled");

        return services;
    }

    public static async Task SeedNotificationsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<NotificationsDbContext>();
        await NotificationsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
