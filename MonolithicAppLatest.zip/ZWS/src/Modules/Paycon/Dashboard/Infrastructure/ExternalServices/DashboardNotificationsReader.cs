using MediatR;
using ZWS.Modules.Paycon.Dashboard.Application.Dtos;
using ZWS.Modules.Paycon.Dashboard.Application.Repositories;
using ZWS.Modules.Paycon.Notifications.Application.Queries;

namespace ZWS.Modules.Paycon.Dashboard.Infrastructure.ExternalServices;

public sealed class DashboardNotificationsReader(ISender sender) : IDashboardNotificationsReader
{
    public async Task<IReadOnlyCollection<DashboardNotificationDto>> GetRecentNotificationsAsync(CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetRecentNotificationsQuery(5), cancellationToken);
        if (result.IsFailure) return [];

        return result.Value.Select(n => new DashboardNotificationDto(n.Title, n.Description, n.Severity, n.OccurredAt, n.IsRead)).ToList();
    }
}
