using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Dashboard.Application.Repositories;
using ZWS.Modules.Paycon.Dashboard.Domain;
using ZWS.Modules.Paycon.Dashboard.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Dashboard.Infrastructure.Repositories;

public sealed class DashboardRepository(PayconDashboardDbContext context) : IDashboardRepository
{
    public Task<IReadOnlyCollection<DashboardMetric>> GetMetricsAsync(CancellationToken cancellationToken) =>
        Materialize(context.Metrics.OrderBy(m => m.DisplayOrder), cancellationToken);

    public Task<IReadOnlyCollection<DashboardQuickAction>> GetQuickActionsAsync(CancellationToken cancellationToken) =>
        Materialize(context.QuickActions.OrderBy(a => a.DisplayOrder), cancellationToken);

    public Task<IReadOnlyCollection<DashboardRecentActivity>> GetRecentActivitiesAsync(CancellationToken cancellationToken) =>
        Materialize(context.RecentActivities.OrderByDescending(a => a.OccurredAt).Take(5), cancellationToken);

    public Task<IReadOnlyCollection<DashboardProgressSegment>> GetProgressBreakdownAsync(CancellationToken cancellationToken) =>
        Materialize(context.ProgressSegments.OrderBy(p => p.DisplayOrder), cancellationToken);

    private static async Task<IReadOnlyCollection<T>> Materialize<T>(IQueryable<T> query, CancellationToken cancellationToken) =>
        await query.AsNoTracking().ToListAsync(cancellationToken);
}
