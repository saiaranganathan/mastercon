using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Dashboard.Domain;

namespace ZWS.Modules.Paycon.Dashboard.Infrastructure.Persistence;

/// <summary>Dummy data matching the Figma "My Dashboard" screen (requirement 30).</summary>
public static class PayconDashboardDbContextSeed
{
    public static async Task SeedAsync(PayconDashboardDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Metrics.AnyAsync(cancellationToken)) return;

        context.Metrics.AddRange(
            DashboardMetric.Create("Today's Contributions", "DEC '23", "$23M", "$69M", 1),
            DashboardMetric.Create("Mismatches", "DEC '23", "4", "16", 2),
            DashboardMetric.Create("Trades", "DEC '23", "$21M", "$42M", 3));

        context.QuickActions.AddRange(
            DashboardQuickAction.Create("SCB File - DEWS", "tabler-icon-file-text", "/paycon/reconciliation/payments-in?template=scb-dews", 1),
            DashboardQuickAction.Create("SCB File - DAMAN", "tabler-icon-file-text", "/paycon/reconciliation/payments-in?template=scb-daman", 2),
            DashboardQuickAction.Create("Bank Upload", "tabler-icon-building-bank", "/paycon/reconciliation/payments-in", 3),
            DashboardQuickAction.Create("Contribution File Upload", "tabler-icon-upload", "/paycon/reconciliation/payments-in", 4));

        var now = DateTime.UtcNow;
        context.RecentActivities.AddRange(
            DashboardRecentActivity.Create("July Bank Statement", now.AddHours(-2), "tabler-icon-file-text"),
            DashboardRecentActivity.Create("Bank File Uploaded", now.AddHours(-5), "tabler-icon-upload"),
            DashboardRecentActivity.Create("Contribution File Uploaded", now.AddDays(-1), "tabler-icon-upload"));

        context.ProgressSegments.AddRange(
            DashboardProgressSegment.Create("Payments In", 52.1m, "#1B2A63", 1),
            DashboardProgressSegment.Create("Payments Out", 22.8m, "#4B6FE0", 2),
            DashboardProgressSegment.Create("Mismatches", 13.9m, "#8FB2F6", 3),
            DashboardProgressSegment.Create("Reconciliations", 11.2m, "#C9DBF5", 4));

        await context.SaveChangesAsync(cancellationToken);
    }
}
