using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Dashboard.Application.Abstractions;
using ZWS.Modules.Paycon.Dashboard.Domain;

namespace ZWS.Modules.Paycon.Dashboard.Infrastructure.Persistence;

public sealed class PayconDashboardDbContext(DbContextOptions<PayconDashboardDbContext> options)
    : DbContext(options), IDashboardDbContext
{
    public DbSet<DashboardMetric> Metrics => Set<DashboardMetric>();
    public DbSet<DashboardQuickAction> QuickActions => Set<DashboardQuickAction>();
    public DbSet<DashboardRecentActivity> RecentActivities => Set<DashboardRecentActivity>();
    public DbSet<DashboardProgressSegment> ProgressSegments => Set<DashboardProgressSegment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_dashboard");
        foreach (var entity in new[] { typeof(DashboardMetric), typeof(DashboardQuickAction), typeof(DashboardRecentActivity), typeof(DashboardProgressSegment) })
            modelBuilder.Entity(entity).Property("Title").HasMaxLength(200);

        modelBuilder.Entity<DashboardMetric>(b =>
        {
            b.ToTable("DashboardMetrics");
            b.Property(m => m.PeriodLabel).HasMaxLength(50);
            b.Property(m => m.FromValueDisplay).HasMaxLength(50);
            b.Property(m => m.ToValueDisplay).HasMaxLength(50);
        });
        modelBuilder.Entity<DashboardQuickAction>(b =>
        {
            b.ToTable("DashboardQuickActions");
            b.Property(a => a.Icon).HasMaxLength(100);
            b.Property(a => a.Route).HasMaxLength(200);
        });
        modelBuilder.Entity<DashboardRecentActivity>(b =>
        {
            b.ToTable("DashboardRecentActivities");
            b.Property(a => a.Icon).HasMaxLength(100);
        });
        modelBuilder.Entity<DashboardProgressSegment>(b =>
        {
            b.ToTable("DashboardProgressSegments");
            b.Property(p => p.ColorHex).HasMaxLength(20);
        });
    }
}
