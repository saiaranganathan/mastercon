using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Dashboard.Application.Abstractions;
using ZWS.Modules.Paycon.Dashboard.Application.Repositories;
using ZWS.Modules.Paycon.Dashboard.Infrastructure.ExternalServices;
using ZWS.Modules.Paycon.Dashboard.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Dashboard.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Dashboard;

public static class DashboardModule
{
    public static IServiceCollection AddDashboardModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<PayconDashboardDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_dashboard.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_dashboard"));
        });

        services.AddScoped<IDashboardDbContext>(sp => sp.GetRequiredService<PayconDashboardDbContext>());
        services.AddScoped<IDashboardRepository, DashboardRepository>();
        services.AddScoped<IDashboardNotificationsReader, DashboardNotificationsReader>();

        return services;
    }

    public static async Task SeedDashboardModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PayconDashboardDbContext>();
        await PayconDashboardDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
