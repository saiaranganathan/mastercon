using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Dashboard.Application.Abstractions;

public interface IDashboardDbContext : IAppDbContext;
