using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Dashboard.Application.Dtos;

namespace ZWS.Modules.Paycon.Dashboard.Application.Queries;

/// <summary>Powers /paycon/dashboard end to end (requirement 9.1). Cached per requirement 25.</summary>
public sealed record GetDashboardSnapshotQuery(string UserId) : IQuery<DashboardSnapshotDto>, ICacheableQuery
{
    public string CacheKey => CacheKeys.PayconDashboard(UserId);
    public TimeSpan? Expiration => TimeSpan.FromMinutes(2);
}
