using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Dashboard.Application.Dtos;
using ZWS.Modules.Paycon.Dashboard.Application.Repositories;

namespace ZWS.Modules.Paycon.Dashboard.Application.Queries;

public sealed class GetDashboardSnapshotQueryHandler(
    IDashboardRepository repository,
    IDashboardNotificationsReader notificationsReader) : IQueryHandler<GetDashboardSnapshotQuery, DashboardSnapshotDto>
{
    public async Task<Result<DashboardSnapshotDto>> Handle(GetDashboardSnapshotQuery request, CancellationToken cancellationToken)
    {
        var metrics = (await repository.GetMetricsAsync(cancellationToken))
            .Select(m => new DashboardMetricDto(m.Title, m.PeriodLabel, m.FromValueDisplay, m.ToValueDisplay)).ToList();

        var quickActions = (await repository.GetQuickActionsAsync(cancellationToken))
            .Select(a => new DashboardQuickActionDto(a.Label, a.Icon, a.Route)).ToList();

        var activities = (await repository.GetRecentActivitiesAsync(cancellationToken))
            .Select(a => new DashboardRecentActivityDto(a.Title, a.OccurredAt, a.Icon)).ToList();

        var progress = (await repository.GetProgressBreakdownAsync(cancellationToken))
            .Select(p => new DashboardProgressSegmentDto(p.Label, p.Percentage, p.ColorHex)).ToList();

        var notifications = await notificationsReader.GetRecentNotificationsAsync(cancellationToken);

        var snapshot = new DashboardSnapshotDto(metrics, quickActions, activities, progress, notifications, DateTime.UtcNow);
        return Result.Success(snapshot);
    }
}
