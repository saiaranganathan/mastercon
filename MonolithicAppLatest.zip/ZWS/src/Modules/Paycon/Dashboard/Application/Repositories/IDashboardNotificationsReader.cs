using ZWS.Modules.Paycon.Dashboard.Application.Dtos;

namespace ZWS.Modules.Paycon.Dashboard.Application.Repositories;

/// <summary>Cross-module read into the Notifications module's own public query (never its DbContext).</summary>
public interface IDashboardNotificationsReader
{
    Task<IReadOnlyCollection<DashboardNotificationDto>> GetRecentNotificationsAsync(CancellationToken cancellationToken);
}
