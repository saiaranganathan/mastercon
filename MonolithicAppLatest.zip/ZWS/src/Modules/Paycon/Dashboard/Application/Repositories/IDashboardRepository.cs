using ZWS.Modules.Paycon.Dashboard.Domain;

namespace ZWS.Modules.Paycon.Dashboard.Application.Repositories;

public interface IDashboardRepository
{
    Task<IReadOnlyCollection<DashboardMetric>> GetMetricsAsync(CancellationToken cancellationToken);
    Task<IReadOnlyCollection<DashboardQuickAction>> GetQuickActionsAsync(CancellationToken cancellationToken);
    Task<IReadOnlyCollection<DashboardRecentActivity>> GetRecentActivitiesAsync(CancellationToken cancellationToken);
    Task<IReadOnlyCollection<DashboardProgressSegment>> GetProgressBreakdownAsync(CancellationToken cancellationToken);
}
