using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Commands;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Queries;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Presentation.Controllers;

/// <summary>Route: /paycon/statements/exit-statements (requirement 12).</summary>
[ApiController]
[Route("api/paycon/statements/exit-statements")]
public sealed class ExitStatementsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetExitStatements([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetExitStatementsQuery(paging), cancellationToken)).ToActionResult();

    [HttpPost("{id:guid}/generate")]
    public async Task<IActionResult> Generate(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GenerateExitStatementCommand(id), cancellationToken)).ToActionResult();
}
