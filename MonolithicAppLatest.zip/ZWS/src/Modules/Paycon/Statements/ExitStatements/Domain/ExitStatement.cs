using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Domain;

public enum ExitStatementStatus { Draft, Generated, Sent }

/// <summary>Route: /paycon/statements/exit-statements (requirement 12).</summary>
public sealed class ExitStatement : AuditableEntity
{
    public string EmployeeName { get; private set; } = default!;
    public string SchemeName { get; private set; } = default!;
    public DateTime ExitDate { get; private set; }
    public decimal FinalAmount { get; private set; }
    public string Currency { get; private set; } = "AED";
    public ExitStatementStatus Status { get; private set; } = ExitStatementStatus.Draft;

    private ExitStatement() { }

    public static ExitStatement Create(string employeeName, string schemeName, DateTime exitDate, decimal finalAmount, string currency) => new()
    {
        EmployeeName = employeeName, SchemeName = schemeName, ExitDate = exitDate, FinalAmount = finalAmount, Currency = currency, Status = ExitStatementStatus.Draft
    };

    public void Generate() => Status = ExitStatementStatus.Generated;
    public void MarkSent() => Status = ExitStatementStatus.Sent;
}
