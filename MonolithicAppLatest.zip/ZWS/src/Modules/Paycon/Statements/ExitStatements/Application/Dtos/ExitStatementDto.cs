namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Dtos;

public sealed record ExitStatementDto(Guid Id, string EmployeeName, string SchemeName, DateTime ExitDate, decimal FinalAmount, string Currency, string Status);
