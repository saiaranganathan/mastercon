using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Commands;

public sealed class GenerateExitStatementCommandHandler(IExitStatementRepository repository, IExitStatementsDbContext dbContext)
    : ICommandHandler<GenerateExitStatementCommand>
{
    public async Task<Result> Handle(GenerateExitStatementCommand request, CancellationToken cancellationToken)
    {
        var statement = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (statement is null) return Result.Failure(Error.NotFound("ExitStatement.NotFound", "Exit statement not found."));

        statement.Generate();
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
