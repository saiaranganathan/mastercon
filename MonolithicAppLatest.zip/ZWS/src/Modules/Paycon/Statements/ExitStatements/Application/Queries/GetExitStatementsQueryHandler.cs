using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Queries;

public sealed class GetExitStatementsQueryHandler(IExitStatementRepository repository) : IQueryHandler<GetExitStatementsQuery, PagedResult<ExitStatementDto>>
{
    public async Task<Result<PagedResult<ExitStatementDto>>> Handle(GetExitStatementsQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchAsync(request.Paging, cancellationToken);
        var dtos = items.Select(s => new ExitStatementDto(s.Id, s.EmployeeName, s.SchemeName, s.ExitDate, s.FinalAmount, s.Currency, s.Status.ToString())).ToList();
        return Result.Success(new PagedResult<ExitStatementDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
