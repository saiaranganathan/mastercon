using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Dtos;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Queries;

public sealed record GetExitStatementsQuery(PagedRequest Paging) : IQuery<PagedResult<ExitStatementDto>>;
