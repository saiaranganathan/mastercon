using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Commands;

public sealed record GenerateExitStatementCommand(Guid Id) : ICommand;
