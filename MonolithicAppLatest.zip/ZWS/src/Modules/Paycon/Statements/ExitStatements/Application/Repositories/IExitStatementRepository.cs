using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.ExitStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Repositories;

public interface IExitStatementRepository
{
    Task<(IReadOnlyCollection<ExitStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<ExitStatement?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    void Add(ExitStatement statement);
}
