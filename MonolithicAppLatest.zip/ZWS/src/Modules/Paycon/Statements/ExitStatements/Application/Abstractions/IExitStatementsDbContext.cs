using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Application.Abstractions;

public interface IExitStatementsDbContext : IAppDbContext;
