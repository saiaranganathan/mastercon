using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.ExitStatements.Domain;
using ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Repositories;

public sealed class ExitStatementRepository(ExitStatementsDbContext context) : IExitStatementRepository
{
    public async Task<(IReadOnlyCollection<ExitStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.ExitStatements.AsNoTracking().OrderByDescending(s => s.ExitDate).AsQueryable();
        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public Task<ExitStatement?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.ExitStatements.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    public void Add(ExitStatement statement) => context.ExitStatements.Add(statement);
}
