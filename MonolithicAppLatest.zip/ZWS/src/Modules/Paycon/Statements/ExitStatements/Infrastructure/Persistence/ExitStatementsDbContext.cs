using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.ExitStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Persistence;

public sealed class ExitStatementsDbContext(DbContextOptions<ExitStatementsDbContext> options)
    : DbContext(options), IExitStatementsDbContext
{
    public DbSet<ExitStatement> ExitStatements => Set<ExitStatement>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_exit_statements");
        modelBuilder.Entity<ExitStatement>(b =>
        {
            b.ToTable("ExitStatements");
            b.HasKey(x => x.Id);
            b.Property(x => x.EmployeeName).HasMaxLength(150);
            b.Property(x => x.SchemeName).HasMaxLength(150);
            b.Property(x => x.FinalAmount).HasColumnType("decimal(18,2)");
            b.Property(x => x.Currency).HasMaxLength(10);
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
