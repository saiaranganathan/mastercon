using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.ExitStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Persistence;

public static class ExitStatementsDbContextSeed
{
    public static async Task SeedAsync(ExitStatementsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.ExitStatements.AnyAsync(cancellationToken)) return;

        var s1 = ExitStatement.Create("Priya Sharma", "DEWS", DateTime.UtcNow.AddDays(-20), 45200m, "AED"); s1.Generate(); s1.MarkSent();
        var s2 = ExitStatement.Create("John Deo", "DAMAN", DateTime.UtcNow.AddDays(-5), 18750m, "AED"); s2.Generate();
        var s3 = ExitStatement.Create("Ahmed Al Farsi", "Dubai Government", DateTime.UtcNow.AddDays(-1), 62300m, "AED");

        context.ExitStatements.AddRange(s1, s2, s3);
        await context.SaveChangesAsync(cancellationToken);
    }
}
