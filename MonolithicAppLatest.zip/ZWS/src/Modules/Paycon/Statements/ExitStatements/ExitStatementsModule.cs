using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.ExitStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Statements.ExitStatements.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Statements.ExitStatements;

public static class ExitStatementsModule
{
    public static IServiceCollection AddExitStatementsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<ExitStatementsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_exit_statements.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_exit_statements"));
        });

        services.AddScoped<IExitStatementsDbContext>(sp => sp.GetRequiredService<ExitStatementsDbContext>());
        services.AddScoped<IExitStatementRepository, ExitStatementRepository>();
        return services;
    }

    public static async Task SeedExitStatementsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ExitStatementsDbContext>();
        await ExitStatementsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
