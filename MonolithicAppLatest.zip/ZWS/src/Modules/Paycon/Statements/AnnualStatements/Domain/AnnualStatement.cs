using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

/// <summary>
/// Route: /paycon/statements/annual-statements. Clean placeholder using the
/// same design system as Exit Statements (requirement 12) - no Figma design
/// exists for this screen yet.
/// </summary>
public sealed class AnnualStatement : AuditableEntity
{
    public string EmployeeName { get; private set; } = default!;
    public string SchemeName { get; private set; } = default!;
    public int Year { get; private set; }
    public decimal TotalContribution { get; private set; }
    public string Currency { get; private set; } = "AED";

    private AnnualStatement() { }

    public static AnnualStatement Create(string employeeName, string schemeName, int year, decimal totalContribution, string currency) => new()
    {
        EmployeeName = employeeName, SchemeName = schemeName, Year = year, TotalContribution = totalContribution, Currency = currency
    };
}
