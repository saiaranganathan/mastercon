using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

public sealed class AnnualStatementsDbContext(DbContextOptions<AnnualStatementsDbContext> options)
    : DbContext(options), IAnnualStatementsDbContext
{
    public DbSet<AnnualStatement> AnnualStatements => Set<AnnualStatement>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_annual_statements");
        modelBuilder.Entity<AnnualStatement>(b =>
        {
            b.ToTable("AnnualStatements");
            b.HasKey(x => x.Id);
            b.Property(x => x.EmployeeName).HasMaxLength(150);
            b.Property(x => x.SchemeName).HasMaxLength(150);
            b.Property(x => x.TotalContribution).HasColumnType("decimal(18,2)");
            b.Property(x => x.Currency).HasMaxLength(10);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
