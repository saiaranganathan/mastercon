using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

public static class AnnualStatementsDbContextSeed
{
    public static async Task SeedAsync(AnnualStatementsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.AnnualStatements.AnyAsync(cancellationToken)) return;

        context.AnnualStatements.AddRange(
            AnnualStatement.Create("Adriene Watson", "DEWS", 2023, 58200m, "AED"),
            AnnualStatement.Create("John Carilo", "DAMAN", 2023, 41750m, "AED"),
            AnnualStatement.Create("Robert Bacins", "Dubai Government", 2023, 63400m, "AED"));

        await context.SaveChangesAsync(cancellationToken);
    }
}
