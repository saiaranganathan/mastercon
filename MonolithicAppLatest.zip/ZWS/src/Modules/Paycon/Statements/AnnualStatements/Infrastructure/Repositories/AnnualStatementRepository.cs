using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

public sealed class AnnualStatementRepository(AnnualStatementsDbContext context) : IAnnualStatementRepository
{
    public async Task<(IReadOnlyCollection<AnnualStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.AnnualStatements.AsNoTracking().OrderByDescending(s => s.Year).AsQueryable();
        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }
}
