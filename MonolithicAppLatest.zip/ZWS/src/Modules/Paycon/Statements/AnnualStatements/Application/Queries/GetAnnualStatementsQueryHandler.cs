using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

public sealed class GetAnnualStatementsQueryHandler(IAnnualStatementRepository repository)
    : IQueryHandler<GetAnnualStatementsQuery, PagedResult<AnnualStatementDto>>
{
    public async Task<Result<PagedResult<AnnualStatementDto>>> Handle(GetAnnualStatementsQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchAsync(request.Paging, cancellationToken);
        var dtos = items.Select(s => new AnnualStatementDto(s.Id, s.EmployeeName, s.SchemeName, s.Year, s.TotalContribution, s.Currency)).ToList();
        return Result.Success(new PagedResult<AnnualStatementDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
