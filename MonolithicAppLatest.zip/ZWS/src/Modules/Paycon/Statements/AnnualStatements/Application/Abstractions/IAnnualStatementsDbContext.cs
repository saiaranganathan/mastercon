using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;

public interface IAnnualStatementsDbContext : IAppDbContext;
