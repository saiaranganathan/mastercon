namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

public sealed record AnnualStatementDto(Guid Id, string EmployeeName, string SchemeName, int Year, decimal TotalContribution, string Currency);
