using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

public interface IAnnualStatementRepository
{
    Task<(IReadOnlyCollection<AnnualStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
}
