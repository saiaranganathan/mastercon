using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Presentation.Controllers;

/// <summary>Route: /paycon/statements/annual-statements (requirement 12 - placeholder).</summary>
[ApiController]
[Route("api/paycon/statements/annual-statements")]
public sealed class AnnualStatementsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAnnualStatements([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetAnnualStatementsQuery(paging), cancellationToken)).ToActionResult();
}
