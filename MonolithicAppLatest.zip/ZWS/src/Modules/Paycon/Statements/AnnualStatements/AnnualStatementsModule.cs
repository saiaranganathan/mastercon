using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements;

public static class AnnualStatementsModule
{
    public static IServiceCollection AddAnnualStatementsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<AnnualStatementsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_annual_statements.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_annual_statements"));
        });

        services.AddScoped<IAnnualStatementRepository, AnnualStatementRepository>();
        return services;
    }

    public static async Task SeedAnnualStatementsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<AnnualStatementsDbContext>();
        await AnnualStatementsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
