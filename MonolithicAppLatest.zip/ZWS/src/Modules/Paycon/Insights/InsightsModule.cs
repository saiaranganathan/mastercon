using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Insights.Application.Repositories;
using ZWS.Modules.Paycon.Insights.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Insights.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Insights;

public static class InsightsModule
{
    public static IServiceCollection AddInsightsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<InsightsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_insights.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_insights"));
        });

        services.AddScoped<IInsightRepository, InsightRepository>();
        return services;
    }

    public static async Task SeedInsightsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<InsightsDbContext>();
        await InsightsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
