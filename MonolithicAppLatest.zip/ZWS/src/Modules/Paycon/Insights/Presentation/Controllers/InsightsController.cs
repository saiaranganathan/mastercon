using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Insights.Application.Queries;

namespace ZWS.Modules.Paycon.Insights.Presentation.Controllers;

/// <summary>Route: /paycon/insights (requirement 11).</summary>
[ApiController]
[Route("api/paycon/insights")]
public sealed class InsightsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetInsights(CancellationToken cancellationToken) =>
        (await sender.Send(new GetInsightsQuery(), cancellationToken)).ToActionResult();
}
