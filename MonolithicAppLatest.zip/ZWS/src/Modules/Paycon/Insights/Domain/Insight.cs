using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Insights.Domain;

/// <summary>Route: /paycon/insights (requirement 11). Modular so more insight types can be added later.</summary>
public sealed class Insight : AuditableEntity
{
    public string Title { get; private set; } = default!;
    public string Category { get; private set; } = default!;
    public string ValueDisplay { get; private set; } = default!;
    public decimal TrendPercentage { get; private set; }
    public int DisplayOrder { get; private set; }

    private Insight() { }

    public static Insight Create(string title, string category, string valueDisplay, decimal trendPercentage, int displayOrder) => new()
    {
        Title = title, Category = category, ValueDisplay = valueDisplay, TrendPercentage = trendPercentage, DisplayOrder = displayOrder
    };
}
