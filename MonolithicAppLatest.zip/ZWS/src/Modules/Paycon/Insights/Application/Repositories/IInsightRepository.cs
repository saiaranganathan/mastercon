using ZWS.Modules.Paycon.Insights.Domain;

namespace ZWS.Modules.Paycon.Insights.Application.Repositories;

public interface IInsightRepository
{
    Task<IReadOnlyCollection<Insight>> GetAllAsync(CancellationToken cancellationToken);
}
