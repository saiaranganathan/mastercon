using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Insights.Application.Abstractions;

public interface IInsightsDbContext : IAppDbContext;
