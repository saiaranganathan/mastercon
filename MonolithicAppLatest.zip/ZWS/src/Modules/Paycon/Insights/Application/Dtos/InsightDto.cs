namespace ZWS.Modules.Paycon.Insights.Application.Dtos;

public sealed record InsightDto(Guid Id, string Title, string Category, string ValueDisplay, decimal TrendPercentage);
