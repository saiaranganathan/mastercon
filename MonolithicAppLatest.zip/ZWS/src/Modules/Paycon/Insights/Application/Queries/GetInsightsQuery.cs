using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Insights.Application.Dtos;

namespace ZWS.Modules.Paycon.Insights.Application.Queries;

public sealed record GetInsightsQuery : IQuery<IReadOnlyCollection<InsightDto>>;
