using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Insights.Application.Dtos;
using ZWS.Modules.Paycon.Insights.Application.Repositories;

namespace ZWS.Modules.Paycon.Insights.Application.Queries;

public sealed class GetInsightsQueryHandler(IInsightRepository repository) : IQueryHandler<GetInsightsQuery, IReadOnlyCollection<InsightDto>>
{
    public async Task<Result<IReadOnlyCollection<InsightDto>>> Handle(GetInsightsQuery request, CancellationToken cancellationToken)
    {
        var insights = await repository.GetAllAsync(cancellationToken);
        var dtos = insights.Select(i => new InsightDto(i.Id, i.Title, i.Category, i.ValueDisplay, i.TrendPercentage)).ToList();
        return Result.Success<IReadOnlyCollection<InsightDto>>(dtos);
    }
}
