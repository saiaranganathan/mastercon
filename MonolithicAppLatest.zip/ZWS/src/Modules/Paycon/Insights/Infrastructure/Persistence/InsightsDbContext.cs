using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Insights.Application.Abstractions;
using ZWS.Modules.Paycon.Insights.Domain;

namespace ZWS.Modules.Paycon.Insights.Infrastructure.Persistence;

public sealed class InsightsDbContext(DbContextOptions<InsightsDbContext> options) : DbContext(options), IInsightsDbContext
{
    public DbSet<Insight> Insights => Set<Insight>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_insights");
        modelBuilder.Entity<Insight>(b =>
        {
            b.ToTable("Insights");
            b.HasKey(x => x.Id);
            b.Property(x => x.Title).HasMaxLength(200);
            b.Property(x => x.Category).HasMaxLength(100);
            b.Property(x => x.ValueDisplay).HasMaxLength(50);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
