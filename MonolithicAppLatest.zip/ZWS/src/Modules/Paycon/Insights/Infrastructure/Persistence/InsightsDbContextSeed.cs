using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Insights.Domain;

namespace ZWS.Modules.Paycon.Insights.Infrastructure.Persistence;

public static class InsightsDbContextSeed
{
    public static async Task SeedAsync(InsightsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Insights.AnyAsync(cancellationToken)) return;

        context.Insights.AddRange(
            Insight.Create("Average Reconciliation Time", "Performance", "1.8 days", -12.4m, 1),
            Insight.Create("Contribution Growth (MoM)", "Contributions", "+6.2%", 6.2m, 2),
            Insight.Create("Mismatch Rate", "Quality", "3.4%", -1.1m, 3),
            Insight.Create("Active Schemes", "Coverage", "5", 0m, 4));

        await context.SaveChangesAsync(cancellationToken);
    }
}
