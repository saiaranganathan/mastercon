using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Insights.Application.Repositories;
using ZWS.Modules.Paycon.Insights.Domain;
using ZWS.Modules.Paycon.Insights.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Insights.Infrastructure.Repositories;

public sealed class InsightRepository(InsightsDbContext context) : IInsightRepository
{
    public async Task<IReadOnlyCollection<Insight>> GetAllAsync(CancellationToken cancellationToken) =>
        await context.Insights.AsNoTracking().OrderBy(i => i.DisplayOrder).ToListAsync(cancellationToken);
}
