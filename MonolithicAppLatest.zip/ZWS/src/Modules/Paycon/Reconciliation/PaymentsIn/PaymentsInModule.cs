using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Abstractions;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn;

public static class PaymentsInModule
{
    public static IServiceCollection AddPaymentsInModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<PaymentsInDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_payments_in.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_payments_in"));
        });

        services.AddScoped<IPaymentsInDbContext>(sp => sp.GetRequiredService<PaymentsInDbContext>());
        services.AddScoped<IPaymentBatchRepository, PaymentBatchRepository>();
        return services;
    }

    public static async Task SeedPaymentsInModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PaymentsInDbContext>();
        await PaymentsInDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
