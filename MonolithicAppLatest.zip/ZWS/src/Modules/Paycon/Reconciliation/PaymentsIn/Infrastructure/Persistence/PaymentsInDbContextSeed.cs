using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.SeedData;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Persistence;

public static class PaymentsInDbContextSeed
{
    private static readonly (string Name, string EmpId)[] Employees =
    [
        ("Adriene Watson", "EMP1223"), ("John Carilo", "EMP5462"), ("Robert Bacins", "EMP2425"),
        ("Shelby Goode", "EMP2565"), ("John Deo", "EMP5609")
    ];

    public static async Task SeedAsync(PaymentsInDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.PaymentBatches.AnyAsync(cancellationToken)) return;

        var random = new Random(42);
        var batch1 = PaymentBatch.Create("SCB_DEWS_Dec2023.csv", WellKnownSeedIds.SchemeDews, "DEWS");
        var batch2 = PaymentBatch.Create("SCB_DAMAN_Dec2023.csv", WellKnownSeedIds.SchemeDaman, "DAMAN");

        foreach (var batch in new[] { batch1, batch2 })
        {
            foreach (var (name, empId) in Employees)
            {
                var status = random.NextDouble() < 0.7 ? PaymentTransactionStatus.Matched : PaymentTransactionStatus.Mismatched;
                batch.AddTransaction(PaymentTransaction.Create(batch.Id, name, empId, Math.Round((decimal)(random.NextDouble() * 4000 + 800), 2), "AED", "Dec 2023", status));
            }
            batch.CompleteReconciliation();
        }

        context.PaymentBatches.AddRange(batch1, batch2);
        await context.SaveChangesAsync(cancellationToken);
    }
}
