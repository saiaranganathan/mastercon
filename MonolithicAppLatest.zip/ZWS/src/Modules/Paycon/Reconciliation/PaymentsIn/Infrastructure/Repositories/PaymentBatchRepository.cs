using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Repositories;

public sealed class PaymentBatchRepository(PaymentsInDbContext context) : IPaymentBatchRepository
{
    public async Task<(IReadOnlyCollection<PaymentBatch> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.PaymentBatches.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(b => EF.Functions.Like(b.FileName, $"%{term}%") || EF.Functions.Like(b.SchemeName, $"%{term}%"));
        }

        query = query.OrderByDescending(b => b.UploadedAt);
        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public Task<PaymentBatch?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.PaymentBatches.Include(b => b.Transactions).FirstOrDefaultAsync(b => b.Id == id, cancellationToken);

    public async Task<(IReadOnlyCollection<PaymentTransaction> Items, int TotalCount)> SearchTransactionsAsync(
        Guid? batchId, PaymentTransactionStatus? status, PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.PaymentTransactions.AsNoTracking().AsQueryable();

        if (batchId.HasValue) query = query.Where(t => t.BatchId == batchId.Value);
        if (status.HasValue) query = query.Where(t => t.Status == status.Value);

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(t => EF.Functions.Like(t.EmployeeName, $"%{term}%") || EF.Functions.Like(t.EmployeeId, $"%{term}%"));
        }

        query = query.OrderBy(t => t.EmployeeName);
        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public Task<PaymentTransaction?> GetTransactionByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.PaymentTransactions.FirstOrDefaultAsync(t => t.Id == id, cancellationToken);

    public void Add(PaymentBatch batch) => context.PaymentBatches.Add(batch);
}
