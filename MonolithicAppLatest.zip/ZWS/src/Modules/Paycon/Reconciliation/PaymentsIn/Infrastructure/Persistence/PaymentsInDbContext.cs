using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Abstractions;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Infrastructure.Persistence;

public sealed class PaymentsInDbContext(DbContextOptions<PaymentsInDbContext> options)
    : DbContext(options), IPaymentsInDbContext
{
    public DbSet<PaymentBatch> PaymentBatches => Set<PaymentBatch>();
    public DbSet<PaymentTransaction> PaymentTransactions => Set<PaymentTransaction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_payments_in");

        modelBuilder.Entity<PaymentBatch>(b =>
        {
            b.ToTable("PaymentBatches");
            b.HasKey(x => x.Id);
            b.Property(x => x.FileName).HasMaxLength(260).IsRequired();
            b.Property(x => x.SchemeName).HasMaxLength(150);
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
            b.HasMany(x => x.Transactions).WithOne().HasForeignKey(t => t.BatchId).OnDelete(DeleteBehavior.Cascade);
            b.Metadata.FindNavigation(nameof(PaymentBatch.Transactions))!.SetPropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<PaymentTransaction>(t =>
        {
            t.ToTable("PaymentTransactions");
            t.HasKey(x => x.Id);
            t.Property(x => x.EmployeeName).HasMaxLength(150);
            t.Property(x => x.EmployeeId).HasMaxLength(50);
            t.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            t.Property(x => x.Currency).HasMaxLength(10);
            t.Property(x => x.PayPeriod).HasMaxLength(20);
            t.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            t.Property(x => x.Comments).HasMaxLength(1000);
            t.Property(x => x.CreatedBy).HasMaxLength(100);
            t.Property(x => x.UpdatedBy).HasMaxLength(100);
            t.Property(x => x.DeletedBy).HasMaxLength(100);
            t.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
