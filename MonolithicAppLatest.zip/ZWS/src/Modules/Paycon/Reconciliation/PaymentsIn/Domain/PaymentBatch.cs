using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

public enum PaymentBatchStatus { Uploaded, Reconciling, Completed, Failed }
public enum PaymentTransactionStatus { Pending, Matched, Mismatched }

/// <summary>PaymentIn - one uploaded reconciliation file and its outcome (Figma "Payments In" screen).</summary>
public sealed class PaymentBatch : AuditableEntity
{
    public string FileName { get; private set; } = default!;
    public Guid SchemeId { get; private set; }
    public string SchemeName { get; private set; } = default!;
    public PaymentBatchStatus Status { get; private set; } = PaymentBatchStatus.Uploaded;
    public DateTime UploadedAt { get; private set; }
    public int TotalRecords { get; private set; }
    public int MatchedCount { get; private set; }
    public int MismatchedCount { get; private set; }

    private readonly List<PaymentTransaction> _transactions = [];
    public IReadOnlyCollection<PaymentTransaction> Transactions => _transactions.AsReadOnly();

    private PaymentBatch() { }

    public static PaymentBatch Create(string fileName, Guid schemeId, string schemeName) => new()
    {
        FileName = fileName,
        SchemeId = schemeId,
        SchemeName = schemeName,
        Status = PaymentBatchStatus.Uploaded,
        UploadedAt = DateTime.UtcNow
    };

    public void AddTransaction(PaymentTransaction transaction) => _transactions.Add(transaction);

    public void CompleteReconciliation()
    {
        TotalRecords = _transactions.Count;
        MatchedCount = _transactions.Count(t => t.Status == PaymentTransactionStatus.Matched);
        MismatchedCount = _transactions.Count(t => t.Status == PaymentTransactionStatus.Mismatched);
        Status = PaymentBatchStatus.Completed;
    }
}

public sealed class PaymentTransaction : AuditableEntity
{
    public Guid BatchId { get; private set; }
    public string EmployeeName { get; private set; } = default!;
    public string EmployeeId { get; private set; } = default!;
    public decimal Amount { get; private set; }
    public string Currency { get; private set; } = "AED";
    public string PayPeriod { get; private set; } = default!;
    public PaymentTransactionStatus Status { get; private set; } = PaymentTransactionStatus.Pending;
    public bool IsProcessed { get; private set; }
    public string? Comments { get; private set; }

    private PaymentTransaction() { }

    public static PaymentTransaction Create(Guid batchId, string employeeName, string employeeId, decimal amount, string currency, string payPeriod, PaymentTransactionStatus status) => new()
    {
        BatchId = batchId,
        EmployeeName = employeeName,
        EmployeeId = employeeId,
        Amount = amount,
        Currency = currency,
        PayPeriod = payPeriod,
        Status = status,
        IsProcessed = status == PaymentTransactionStatus.Matched
    };

    public void AddComment(string comment) => Comments = comment;
    public void MarkProcessed() => IsProcessed = true;
}
