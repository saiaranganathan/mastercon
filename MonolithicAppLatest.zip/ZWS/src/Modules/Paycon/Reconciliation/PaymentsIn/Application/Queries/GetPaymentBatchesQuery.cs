using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Dtos;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Queries;

public sealed record GetPaymentBatchesQuery(PagedRequest Paging) : IQuery<PagedResult<PaymentBatchListItemDto>>;
