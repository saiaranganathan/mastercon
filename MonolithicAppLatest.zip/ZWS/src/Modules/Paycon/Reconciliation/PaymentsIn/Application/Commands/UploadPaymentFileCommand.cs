using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;

/// <summary>
/// Simulates the Figma "File Upload" wizard (upload -> uploading animation ->
/// reconciliating animation -> complete) as a single synchronous command for
/// this demo build; a production version would raise PaymentFileUploaded and
/// let a background worker reconcile asynchronously.
/// </summary>
public sealed record UploadPaymentFileCommand(string FileName, Guid SchemeId, string SchemeName) : ICommand<Guid>;
