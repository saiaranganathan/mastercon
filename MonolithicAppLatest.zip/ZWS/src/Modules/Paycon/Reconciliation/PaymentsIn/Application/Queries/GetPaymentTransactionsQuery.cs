using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Dtos;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Queries;

/// <summary>Backs both the "Matches" and "Mismatches" tabs in the Figma design via the Status filter.</summary>
public sealed record GetPaymentTransactionsQuery(Guid? BatchId, PaymentTransactionStatus? Status, PagedRequest Paging)
    : IQuery<PagedResult<PaymentTransactionDto>>;
