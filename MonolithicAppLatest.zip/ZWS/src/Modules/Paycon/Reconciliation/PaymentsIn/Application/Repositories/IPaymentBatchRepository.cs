using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;

public interface IPaymentBatchRepository
{
    Task<(IReadOnlyCollection<PaymentBatch> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<PaymentBatch?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<(IReadOnlyCollection<PaymentTransaction> Items, int TotalCount)> SearchTransactionsAsync(Guid? batchId, PaymentTransactionStatus? status, PagedRequest request, CancellationToken cancellationToken);
    Task<PaymentTransaction?> GetTransactionByIdAsync(Guid id, CancellationToken cancellationToken);
    void Add(PaymentBatch batch);
}
