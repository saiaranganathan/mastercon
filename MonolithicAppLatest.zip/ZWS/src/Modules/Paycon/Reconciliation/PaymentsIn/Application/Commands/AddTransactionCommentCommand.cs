using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;

public sealed record AddTransactionCommentCommand(Guid TransactionId, string Comment) : ICommand;
