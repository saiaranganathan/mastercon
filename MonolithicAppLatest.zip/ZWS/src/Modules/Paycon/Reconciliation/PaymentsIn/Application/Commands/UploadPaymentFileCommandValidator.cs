using FluentValidation;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;

public sealed class UploadPaymentFileCommandValidator : AbstractValidator<UploadPaymentFileCommand>
{
    public UploadPaymentFileCommandValidator()
    {
        RuleFor(x => x.FileName).NotEmpty().MaximumLength(260);
        RuleFor(x => x.SchemeId).NotEmpty();
        RuleFor(x => x.SchemeName).NotEmpty();
    }
}
