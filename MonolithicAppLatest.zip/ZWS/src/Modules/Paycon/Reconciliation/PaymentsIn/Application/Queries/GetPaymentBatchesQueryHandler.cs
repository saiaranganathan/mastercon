using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Dtos;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Queries;

public sealed class GetPaymentBatchesQueryHandler(IPaymentBatchRepository repository)
    : IQueryHandler<GetPaymentBatchesQuery, PagedResult<PaymentBatchListItemDto>>
{
    public async Task<Result<PagedResult<PaymentBatchListItemDto>>> Handle(GetPaymentBatchesQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchAsync(request.Paging, cancellationToken);
        var dtos = items.Select(b => new PaymentBatchListItemDto(b.Id, b.FileName, b.SchemeName, b.Status.ToString(), b.UploadedAt, b.TotalRecords, b.MatchedCount, b.MismatchedCount)).ToList();
        return Result.Success(new PagedResult<PaymentBatchListItemDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
