using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;

public sealed class AddTransactionCommentCommandHandler(IPaymentBatchRepository repository, IPaymentsInDbContext dbContext)
    : ICommandHandler<AddTransactionCommentCommand>
{
    public async Task<Result> Handle(AddTransactionCommentCommand request, CancellationToken cancellationToken)
    {
        var transaction = await repository.GetTransactionByIdAsync(request.TransactionId, cancellationToken);
        if (transaction is null) return Result.Failure(Error.NotFound("Transaction.NotFound", "Transaction not found."));

        transaction.AddComment(request.Comment);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
