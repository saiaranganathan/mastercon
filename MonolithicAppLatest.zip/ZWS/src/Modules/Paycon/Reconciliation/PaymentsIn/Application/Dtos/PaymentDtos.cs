namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Dtos;

public sealed record PaymentBatchListItemDto(
    Guid Id, string FileName, string SchemeName, string Status, DateTime UploadedAt,
    int TotalRecords, int MatchedCount, int MismatchedCount);

public sealed record PaymentTransactionDto(
    Guid Id, Guid BatchId, string EmployeeName, string EmployeeId, decimal Amount, string Currency,
    string PayPeriod, string Status, bool IsProcessed, string? Comments);
