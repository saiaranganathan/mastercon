using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Dtos;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Queries;

public sealed class GetPaymentTransactionsQueryHandler(IPaymentBatchRepository repository)
    : IQueryHandler<GetPaymentTransactionsQuery, PagedResult<PaymentTransactionDto>>
{
    public async Task<Result<PagedResult<PaymentTransactionDto>>> Handle(GetPaymentTransactionsQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchTransactionsAsync(request.BatchId, request.Status, request.Paging, cancellationToken);
        var dtos = items.Select(t => new PaymentTransactionDto(t.Id, t.BatchId, t.EmployeeName, t.EmployeeId, t.Amount, t.Currency, t.PayPeriod, t.Status.ToString(), t.IsProcessed, t.Comments)).ToList();
        return Result.Success(new PagedResult<PaymentTransactionDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
