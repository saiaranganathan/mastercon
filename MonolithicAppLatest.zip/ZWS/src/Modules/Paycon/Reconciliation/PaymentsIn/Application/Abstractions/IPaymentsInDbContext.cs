using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Abstractions;

public interface IPaymentsInDbContext : IAppDbContext;
