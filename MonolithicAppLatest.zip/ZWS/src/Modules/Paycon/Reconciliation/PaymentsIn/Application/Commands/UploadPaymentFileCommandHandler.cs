using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Application.Commands;

public sealed class UploadPaymentFileCommandHandler(
    IPaymentBatchRepository repository, IPaymentsInDbContext dbContext, IEventBus eventBus)
    : ICommandHandler<UploadPaymentFileCommand, Guid>
{
    private static readonly string[] SampleEmployees = ["Adriene Watson", "John Carilo", "Robert Bacins", "Shelby Goode", "John Deo", "Priya Sharma"];

    public async Task<Result<Guid>> Handle(UploadPaymentFileCommand request, CancellationToken cancellationToken)
    {
        var batch = PaymentBatch.Create(request.FileName, request.SchemeId, request.SchemeName);

        var random = new Random(batch.Id.GetHashCode());
        for (var i = 0; i < 10; i++)
        {
            var status = random.NextDouble() < 0.75 ? PaymentTransactionStatus.Matched : PaymentTransactionStatus.Mismatched;
            var transaction = PaymentTransaction.Create(
                batch.Id,
                SampleEmployees[i % SampleEmployees.Length],
                $"EMP{1000 + i}",
                Math.Round((decimal)(random.NextDouble() * 5000 + 500), 2),
                "AED",
                DateTime.UtcNow.ToString("MMM yyyy"),
                status);
            batch.AddTransaction(transaction);
        }

        batch.CompleteReconciliation();
        repository.Add(batch);
        await dbContext.SaveChangesAsync(cancellationToken);

        await eventBus.PublishAsync(
            new PaymentBatchReconciledIntegrationEvent(batch.Id, batch.FileName, batch.MatchedCount, batch.MismatchedCount),
            cancellationToken);

        return Result.Success(batch.Id);
    }
}
