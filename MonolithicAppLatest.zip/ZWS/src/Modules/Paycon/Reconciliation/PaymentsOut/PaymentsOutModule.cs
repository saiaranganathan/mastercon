using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Abstractions;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut;

public static class PaymentsOutModule
{
    public static IServiceCollection AddPaymentsOutModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<PaymentsOutDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_payments_out.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_payments_out"));
        });

        services.AddScoped<IPaymentsOutDbContext>(sp => sp.GetRequiredService<PaymentsOutDbContext>());
        services.AddScoped<IPaymentOutRepository, PaymentOutRepository>();
        return services;
    }

    public static async Task SeedPaymentsOutModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PaymentsOutDbContext>();
        await PaymentsOutDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
