using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Abstractions;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Persistence;

public sealed class PaymentsOutDbContext(DbContextOptions<PaymentsOutDbContext> options)
    : DbContext(options), IPaymentsOutDbContext
{
    public DbSet<PaymentOut> PaymentsOut => Set<PaymentOut>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_payments_out");
        modelBuilder.Entity<PaymentOut>(b =>
        {
            b.ToTable("PaymentsOut");
            b.HasKey(x => x.Id);
            b.Property(x => x.BeneficiaryName).HasMaxLength(150);
            b.Property(x => x.SchemeName).HasMaxLength(150);
            b.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            b.Property(x => x.Currency).HasMaxLength(10);
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
