using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Repositories;

public sealed class PaymentOutRepository(PaymentsOutDbContext context) : IPaymentOutRepository
{
    public async Task<(IReadOnlyCollection<PaymentOut> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = context.PaymentsOut.AsNoTracking().OrderByDescending(p => p.RequestedAt).AsQueryable();
        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public void Add(PaymentOut paymentOut) => context.PaymentsOut.Add(paymentOut);
}
