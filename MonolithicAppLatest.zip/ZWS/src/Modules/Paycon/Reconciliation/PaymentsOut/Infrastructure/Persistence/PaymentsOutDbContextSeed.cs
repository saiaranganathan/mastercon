using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Infrastructure.Persistence;

public static class PaymentsOutDbContextSeed
{
    public static async Task SeedAsync(PaymentsOutDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.PaymentsOut.AnyAsync(cancellationToken)) return;

        var p1 = PaymentOut.Create("Adriene Watson", "DEWS", 12500m, "AED"); p1.Approve();
        var p2 = PaymentOut.Create("John Carilo", "DAMAN", 8300m, "AED");
        var p3 = PaymentOut.Create("Robert Bacins", "Dubai Government", 15200m, "AED"); p3.Approve(); p3.MarkPaid();

        context.PaymentsOut.AddRange(p1, p2, p3);
        await context.SaveChangesAsync(cancellationToken);
    }
}
