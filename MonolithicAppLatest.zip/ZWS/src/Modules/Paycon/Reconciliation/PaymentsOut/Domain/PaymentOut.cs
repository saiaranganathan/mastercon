using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;

public enum PaymentOutStatus { Pending, Approved, Paid, Rejected }

/// <summary>
/// PaymentOut - placeholder module (requirement 10): no Figma design exists
/// yet, so this follows the Payments In design language and data shape at a
/// smaller scope, ready to be replaced once the design is delivered.
/// </summary>
public sealed class PaymentOut : AuditableEntity
{
    public string BeneficiaryName { get; private set; } = default!;
    public string SchemeName { get; private set; } = default!;
    public decimal Amount { get; private set; }
    public string Currency { get; private set; } = "AED";
    public PaymentOutStatus Status { get; private set; } = PaymentOutStatus.Pending;
    public DateTime RequestedAt { get; private set; }

    private PaymentOut() { }

    public static PaymentOut Create(string beneficiaryName, string schemeName, decimal amount, string currency) => new()
    {
        BeneficiaryName = beneficiaryName,
        SchemeName = schemeName,
        Amount = amount,
        Currency = currency,
        Status = PaymentOutStatus.Pending,
        RequestedAt = DateTime.UtcNow
    };

    public void Approve() => Status = PaymentOutStatus.Approved;
    public void MarkPaid() => Status = PaymentOutStatus.Paid;
    public void Reject() => Status = PaymentOutStatus.Rejected;
}
