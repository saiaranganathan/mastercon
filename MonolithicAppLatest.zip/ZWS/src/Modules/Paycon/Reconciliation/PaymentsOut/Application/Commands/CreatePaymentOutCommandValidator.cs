using FluentValidation;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Commands;

public sealed class CreatePaymentOutCommandValidator : AbstractValidator<CreatePaymentOutCommand>
{
    public CreatePaymentOutCommandValidator()
    {
        RuleFor(x => x.BeneficiaryName).NotEmpty().MaximumLength(150);
        RuleFor(x => x.SchemeName).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Amount).GreaterThan(0);
        RuleFor(x => x.Currency).NotEmpty().MaximumLength(10);
    }
}
