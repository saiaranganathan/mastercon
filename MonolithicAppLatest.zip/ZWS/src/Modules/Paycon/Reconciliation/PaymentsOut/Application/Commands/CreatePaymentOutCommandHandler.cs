using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Repositories;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Commands;

public sealed class CreatePaymentOutCommandHandler(IPaymentOutRepository repository, IPaymentsOutDbContext dbContext)
    : ICommandHandler<CreatePaymentOutCommand, Guid>
{
    public async Task<Result<Guid>> Handle(CreatePaymentOutCommand request, CancellationToken cancellationToken)
    {
        var payment = PaymentOut.Create(request.BeneficiaryName, request.SchemeName, request.Amount, request.Currency);
        repository.Add(payment);
        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success(payment.Id);
    }
}
