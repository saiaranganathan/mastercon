using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Dtos;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Queries;

public sealed record GetPaymentsOutQuery(PagedRequest Paging) : IQuery<PagedResult<PaymentOutDto>>;
