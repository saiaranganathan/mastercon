using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Commands;

public sealed record CreatePaymentOutCommand(string BeneficiaryName, string SchemeName, decimal Amount, string Currency) : ICommand<Guid>;
