using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Abstractions;

public interface IPaymentsOutDbContext : IAppDbContext;
