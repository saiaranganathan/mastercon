namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Dtos;

public sealed record PaymentOutDto(Guid Id, string BeneficiaryName, string SchemeName, decimal Amount, string Currency, string Status, DateTime RequestedAt);
