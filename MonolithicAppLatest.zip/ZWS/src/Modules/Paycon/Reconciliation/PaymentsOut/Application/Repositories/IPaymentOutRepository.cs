using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Domain;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Repositories;

public interface IPaymentOutRepository
{
    Task<(IReadOnlyCollection<PaymentOut> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    void Add(PaymentOut paymentOut);
}
