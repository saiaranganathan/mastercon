using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Dtos;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Repositories;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Queries;

public sealed class GetPaymentsOutQueryHandler(IPaymentOutRepository repository) : IQueryHandler<GetPaymentsOutQuery, PagedResult<PaymentOutDto>>
{
    public async Task<Result<PagedResult<PaymentOutDto>>> Handle(GetPaymentsOutQuery request, CancellationToken cancellationToken)
    {
        var (items, total) = await repository.SearchAsync(request.Paging, cancellationToken);
        var dtos = items.Select(p => new PaymentOutDto(p.Id, p.BeneficiaryName, p.SchemeName, p.Amount, p.Currency, p.Status.ToString(), p.RequestedAt)).ToList();
        return Result.Success(new PagedResult<PaymentOutDto>(dtos, total, request.Paging.Page, request.Paging.PageSize));
    }
}
