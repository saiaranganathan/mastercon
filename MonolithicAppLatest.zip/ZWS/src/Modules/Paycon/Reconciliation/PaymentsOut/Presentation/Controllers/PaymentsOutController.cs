using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Commands;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Application.Queries;

namespace ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Presentation.Controllers;

/// <summary>Route: /paycon/reconciliation/payments-out (requirement 10 - placeholder, no Figma yet).</summary>
[ApiController]
[Route("api/paycon/reconciliation/payments-out")]
public sealed class PaymentsOutController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetPaymentsOut([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetPaymentsOutQuery(paging), cancellationToken)).ToActionResult();

    [HttpPost]
    public async Task<IActionResult> CreatePaymentOut([FromBody] CreatePaymentOutRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreatePaymentOutCommand(request.BeneficiaryName, request.SchemeName, request.Amount, request.Currency), cancellationToken)).ToActionResult();
}

public sealed record CreatePaymentOutRequest(string BeneficiaryName, string SchemeName, decimal Amount, string Currency);
