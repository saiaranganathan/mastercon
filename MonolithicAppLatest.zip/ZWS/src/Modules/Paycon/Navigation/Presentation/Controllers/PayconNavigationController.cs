using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Navigation.Application.Queries;

namespace ZWS.Modules.Paycon.Navigation.Presentation.Controllers;

[ApiController]
[Route("api/paycon/navigation")]
public sealed class PayconNavigationController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetNavigation(CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetPayconNavigationQuery(), cancellationToken);
        return result.ToActionResult();
    }
}
