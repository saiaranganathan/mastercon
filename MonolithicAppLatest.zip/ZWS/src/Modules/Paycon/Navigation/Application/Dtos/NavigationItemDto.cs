namespace ZWS.Modules.Paycon.Navigation.Application.Dtos;

public sealed record NavigationItemDto(
    Guid Id,
    string Name,
    string? Route,
    string Icon,
    int DisplayOrder,
    IReadOnlyCollection<NavigationItemDto> Children);
