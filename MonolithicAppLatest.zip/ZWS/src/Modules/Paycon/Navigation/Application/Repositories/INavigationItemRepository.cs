using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Application.Repositories;

public interface INavigationItemRepository
{
    Task<IReadOnlyCollection<NavigationItem>> GetTreeAsync(string applicationCode, CancellationToken cancellationToken);
    void Add(NavigationItem item);
}
