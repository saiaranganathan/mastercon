using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Navigation.Application.Dtos;
using ZWS.Modules.Paycon.Navigation.Application.Repositories;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Application.Queries;

public sealed class GetPayconNavigationQueryHandler(INavigationItemRepository repository)
    : IQueryHandler<GetPayconNavigationQuery, IReadOnlyCollection<NavigationItemDto>>
{
    public async Task<Result<IReadOnlyCollection<NavigationItemDto>>> Handle(GetPayconNavigationQuery request, CancellationToken cancellationToken)
    {
        var flat = await repository.GetTreeAsync("PAYCON", cancellationToken);
        var tree = BuildTree(flat, null);
        return Result.Success<IReadOnlyCollection<NavigationItemDto>>(tree);
    }

    private static List<NavigationItemDto> BuildTree(IReadOnlyCollection<NavigationItem> all, Guid? parentId) =>
        all.Where(i => i.ParentId == parentId)
           .OrderBy(i => i.DisplayOrder)
           .Select(i => new NavigationItemDto(i.Id, i.Name, i.Route, i.Icon, i.DisplayOrder, BuildTree(all, i.Id)))
           .ToList();
}
