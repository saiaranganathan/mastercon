using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Navigation.Application.Dtos;

namespace ZWS.Modules.Paycon.Navigation.Application.Queries;

/// <summary>GET /api/paycon/navigation - builds the sidebar tree straight from the database (requirement 7).</summary>
public sealed record GetPayconNavigationQuery : IQuery<IReadOnlyCollection<NavigationItemDto>>, ICacheableQuery
{
    public string CacheKey => CacheKeys.PayconNavigation();
    public TimeSpan? Expiration => TimeSpan.FromMinutes(30);
}
