using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Navigation.Application.Repositories;
using ZWS.Modules.Paycon.Navigation.Domain;
using ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Navigation.Infrastructure.Repositories;

public sealed class NavigationItemRepository(PayconNavigationDbContext context) : INavigationItemRepository
{
    public async Task<IReadOnlyCollection<NavigationItem>> GetTreeAsync(string applicationCode, CancellationToken cancellationToken) =>
        await context.NavigationItems
            .AsNoTracking()
            .Where(n => n.ApplicationCode == applicationCode && n.IsActive && n.IsVisible)
            .ToListAsync(cancellationToken);

    public void Add(NavigationItem item) => context.NavigationItems.Add(item);
}
