using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence.Configurations;

public sealed class NavigationItemConfiguration : IEntityTypeConfiguration<NavigationItem>
{
    public void Configure(EntityTypeBuilder<NavigationItem> builder)
    {
        builder.ToTable("NavigationItems");
        builder.HasKey(n => n.Id);
        builder.Property(n => n.ApplicationCode).HasMaxLength(50).IsRequired();
        builder.Property(n => n.Name).HasMaxLength(150).IsRequired();
        builder.Property(n => n.Route).HasMaxLength(200);
        builder.Property(n => n.Icon).HasMaxLength(100);
        builder.HasIndex(n => new { n.ApplicationCode, n.ParentId, n.DisplayOrder });
    }
}
