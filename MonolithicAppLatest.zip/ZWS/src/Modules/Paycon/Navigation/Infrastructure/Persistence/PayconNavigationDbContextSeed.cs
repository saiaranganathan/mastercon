using Microsoft.EntityFrameworkCore;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence;

/// <summary>Seeds the exact navigation tree specified in section 8 of the requirements.</summary>
public static class PayconNavigationDbContextSeed
{
    public static async Task SeedAsync(PayconNavigationDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);

        if (await context.NavigationItems.AnyAsync(cancellationToken)) return;

        var dashboard = NavigationItem.Create("Dashboard", "/paycon/dashboard", "tabler-icon-smart-home", null, 1);
        var reconciliation = NavigationItem.Create("Reconciliation", null, "tabler-icon-refresh", null, 2);
        var insights = NavigationItem.Create("Insights", "/paycon/insights", "tabler-icon-chart-bar", null, 3);
        var statements = NavigationItem.Create("Statements", null, "tabler-icon-file-text", null, 4);
        var settings = NavigationItem.Create("Settings", null, "tabler-icon-settings", null, 5);

        context.NavigationItems.AddRange(dashboard, reconciliation, insights, statements, settings);
        await context.SaveChangesAsync(cancellationToken);

        var paymentsIn = NavigationItem.Create("Payments In", "/paycon/reconciliation/payments-in", "tabler-icon-arrow-down-circle", reconciliation.Id, 1);
        var paymentsOut = NavigationItem.Create("Payments Out", "/paycon/reconciliation/payments-out", "tabler-icon-arrow-up-circle", reconciliation.Id, 2);
        var exitStatements = NavigationItem.Create("Exit Statements", "/paycon/statements/exit-statements", "tabler-icon-file-minus", statements.Id, 1);
        var annualStatements = NavigationItem.Create("Annual Statements", "/paycon/statements/annual-statements", "tabler-icon-calendar-stats", statements.Id, 2);
        var userManagement = NavigationItem.Create("User Management", "/paycon/settings/user-management", "tabler-icon-users", settings.Id, 1, requiredPermission: "Settings.UserManagement.View");
        var schemeManagement = NavigationItem.Create("Scheme Management", "/paycon/settings/scheme-management", "tabler-icon-building-bank", settings.Id, 2, requiredPermission: "Settings.SchemeManagement.View");
        var insightManagement = NavigationItem.Create("Insight Management", "/paycon/settings/insight-management", "tabler-icon-bulb", settings.Id, 3, requiredPermission: "Settings.InsightManagement.View");

        context.NavigationItems.AddRange(paymentsIn, paymentsOut, exitStatements, annualStatements, userManagement, schemeManagement, insightManagement);
        await context.SaveChangesAsync(cancellationToken);
    }
}
