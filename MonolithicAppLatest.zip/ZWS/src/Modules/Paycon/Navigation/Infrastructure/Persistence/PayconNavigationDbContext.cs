using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence;

public sealed class PayconNavigationDbContext(DbContextOptions<PayconNavigationDbContext> options)
    : DbContext(options), IAppDbContext
{
    public DbSet<NavigationItem> NavigationItems => Set<NavigationItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("paycon_navigation");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(PayconNavigationDbContext).Assembly);
        modelBuilder.Entity<NavigationItem>().HasQueryFilter(n => !n.IsDeleted);
    }
}
