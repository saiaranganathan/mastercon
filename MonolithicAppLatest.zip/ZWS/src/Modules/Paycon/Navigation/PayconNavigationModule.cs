using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.Paycon.Navigation.Application.Repositories;
using ZWS.Modules.Paycon.Navigation.Infrastructure.Persistence;
using ZWS.Modules.Paycon.Navigation.Infrastructure.Repositories;

namespace ZWS.Modules.Paycon.Navigation;

public static class PayconNavigationModule
{
    public static IServiceCollection AddPayconNavigationModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Paycon");

        services.AddDbContext<PayconNavigationDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=paycon_navigation.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "paycon_navigation"));
        });

        services.AddScoped<INavigationItemRepository, NavigationItemRepository>();
        return services;
    }

    public static async Task SeedPayconNavigationModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PayconNavigationDbContext>();
        await PayconNavigationDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
