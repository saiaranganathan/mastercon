using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Navigation.Domain;

/// <summary>
/// One entry in the Paycon sidebar. Self-referencing parent/child so the
/// Blazor sidebar can be built as a tree purely from database rows
/// (requirements 7, 8, 21) - nothing about the menu is hard-coded in Razor.
/// </summary>
public sealed class NavigationItem : AuditableEntity
{
    public string ApplicationCode { get; private set; } = "PAYCON";
    public string Name { get; private set; } = default!;
    public string? Route { get; private set; }
    public string Icon { get; private set; } = string.Empty;
    public Guid? ParentId { get; private set; }
    public int DisplayOrder { get; private set; }
    public bool IsActive { get; private set; } = true;
    public bool IsVisible { get; private set; } = true;
    public string? RequiredPermission { get; private set; }

    private NavigationItem() { } // EF Core

    public static NavigationItem Create(
        string name, string? route, string icon, Guid? parentId, int displayOrder,
        string? requiredPermission = null, string applicationCode = "PAYCON")
        => new()
        {
            ApplicationCode = applicationCode,
            Name = name,
            Route = route,
            Icon = icon,
            ParentId = parentId,
            DisplayOrder = displayOrder,
            RequiredPermission = requiredPermission,
            IsActive = true,
            IsVisible = true
        };
}
