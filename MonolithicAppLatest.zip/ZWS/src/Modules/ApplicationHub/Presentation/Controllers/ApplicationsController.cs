using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.ApplicationHub.Application.Queries;

namespace ZWS.Modules.ApplicationHub.Presentation.Controllers;

/// <summary>
/// Flow: Blazor -> GET /api/applications -> MediatR query -> ApplicationHubDbContext -> SQL/Redis (requirement 6).
/// </summary>
[ApiController]
[Route("api/applications")]
[Produces("application/json")]
public sealed class ApplicationsController(ISender sender) : ControllerBase
{
    /// <summary>Returns the ZWS Application Hub landing page cards.</summary>
    [HttpGet]
    public async Task<IActionResult> GetApplications([FromQuery] bool includeInactive, CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetApplicationCardsQuery(includeInactive), cancellationToken);
        return result.ToActionResult();
    }
}
