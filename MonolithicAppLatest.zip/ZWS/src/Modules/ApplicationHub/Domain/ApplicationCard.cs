using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.ApplicationHub.Domain;

public enum ApplicationCardStatus
{
    Active,
    ComingSoon,
    Maintenance,
    Retired
}

/// <summary>
/// One tile on the ZWS Application Hub landing page. Owned exclusively by the
/// ApplicationHub module - the Blazor landing page is populated entirely from
/// this table via GET /api/applications (requirement 6); nothing is hard-coded.
/// </summary>
public sealed class ApplicationCard : AuditableEntity
{
    public string Code { get; private set; } = default!;
    public string Name { get; private set; } = default!;
    public string Description { get; private set; } = string.Empty;
    public string Icon { get; private set; } = string.Empty;
    public string? ImageUri { get; private set; }
    public string BaseColor { get; private set; } = "#1B2A63";
    public string Route { get; private set; } = default!;
    public int DisplayOrder { get; private set; }
    public bool IsActive { get; private set; } = true;
    public bool IsExternal { get; private set; }
    public ApplicationCardStatus Status { get; private set; } = ApplicationCardStatus.Active;

    private ApplicationCard() { } // EF Core

    public static ApplicationCard Create(
        string code, string name, string description, string icon, string? imageUri,
        string baseColor, string route, int displayOrder, bool isExternal, ApplicationCardStatus status)
        => new()
        {
            Code = code,
            Name = name,
            Description = description,
            Icon = icon,
            ImageUri = imageUri,
            BaseColor = baseColor,
            Route = route,
            DisplayOrder = displayOrder,
            IsExternal = isExternal,
            Status = status,
            IsActive = true
        };

    public void UpdateDetails(string name, string description, string icon, string? imageUri, string baseColor, int displayOrder, ApplicationCardStatus status)
    {
        Name = name;
        Description = description;
        Icon = icon;
        ImageUri = imageUri;
        BaseColor = baseColor;
        DisplayOrder = displayOrder;
        Status = status;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
