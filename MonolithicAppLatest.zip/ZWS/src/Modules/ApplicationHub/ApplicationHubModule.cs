using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.ApplicationHub.Application.Repositories;
using ZWS.Modules.ApplicationHub.Infrastructure.Persistence;
using ZWS.Modules.ApplicationHub.Infrastructure.Repositories;

namespace ZWS.Modules.ApplicationHub;

/// <summary>
/// Single composition-root entry point for the ApplicationHub module.
/// ZWS.Host calls AddApplicationHubModule + (later) UseApplicationHubModule -
/// it never touches this module's internals directly.
/// </summary>
public static class ApplicationHubModule
{
    public static IServiceCollection AddApplicationHubModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("ApplicationHub");

        services.AddDbContext<ApplicationHubDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=applicationhub.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "hub"));
        });

        services.AddScoped<IApplicationCardRepository, ApplicationCardRepository>();

        return services;
    }

    /// <summary>Applies migrations and seeds dummy data. Called once at startup from ZWS.Host.</summary>
    public static async Task SeedApplicationHubModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationHubDbContext>();
        await ApplicationHubDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
