using Microsoft.EntityFrameworkCore;
using ZWS.Modules.ApplicationHub.Application.Repositories;
using ZWS.Modules.ApplicationHub.Domain;
using ZWS.Modules.ApplicationHub.Infrastructure.Persistence;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Repositories;

public sealed class ApplicationCardRepository(ApplicationHubDbContext context) : IApplicationCardRepository
{
    public async Task<IReadOnlyCollection<ApplicationCard>> GetAllAsync(bool includeInactive, CancellationToken cancellationToken)
    {
        var query = context.ApplicationCards.AsNoTracking();
        if (!includeInactive) query = query.Where(a => a.IsActive);
        return await query.ToListAsync(cancellationToken);
    }

    public Task<ApplicationCard?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        context.ApplicationCards.FirstOrDefaultAsync(a => a.Id == id, cancellationToken);

    public Task<ApplicationCard?> GetByCodeAsync(string code, CancellationToken cancellationToken) =>
        context.ApplicationCards.FirstOrDefaultAsync(a => a.Code == code, cancellationToken);

    public void Add(ApplicationCard applicationCard) => context.ApplicationCards.Add(applicationCard);
}
