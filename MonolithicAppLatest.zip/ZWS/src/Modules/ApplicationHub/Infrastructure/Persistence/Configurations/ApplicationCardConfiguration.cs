using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ZWS.Modules.ApplicationHub.Domain;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence.Configurations;

public sealed class ApplicationCardConfiguration : IEntityTypeConfiguration<ApplicationCard>
{
    public void Configure(EntityTypeBuilder<ApplicationCard> builder)
    {
        builder.ToTable("ApplicationCards");
        builder.HasKey(a => a.Id);

        builder.Property(a => a.Code).HasMaxLength(50).IsRequired();
        builder.HasIndex(a => a.Code).IsUnique();
        builder.Property(a => a.Name).HasMaxLength(150).IsRequired();
        builder.Property(a => a.Description).HasMaxLength(500);
        builder.Property(a => a.Icon).HasMaxLength(100);
        builder.Property(a => a.ImageUri).HasMaxLength(500);
        builder.Property(a => a.BaseColor).HasMaxLength(20);
        builder.Property(a => a.Route).HasMaxLength(200).IsRequired();
        builder.Property(a => a.Status).HasConversion<string>().HasMaxLength(30);
        builder.Property(a => a.CreatedBy).HasMaxLength(100);
        builder.Property(a => a.UpdatedBy).HasMaxLength(100);
        builder.Property(a => a.DeletedBy).HasMaxLength(100);
    }
}
