using Microsoft.EntityFrameworkCore;
using ZWS.Modules.ApplicationHub.Domain;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence;

/// <summary>
/// Deterministic dummy data (requirement 30) so the Hub landing page looks
/// realistic immediately after `dotnet run` - no manual seeding step needed.
/// </summary>
public static class ApplicationHubDbContextSeed
{
    public static async Task SeedAsync(ApplicationHubDbContext context, CancellationToken cancellationToken = default)
    {
        // Dev/demo bootstrap: creates the schema from the current model with no migration
        // step required, so the app has realistic data immediately after `dotnet run`
        // (requirement 30). Switch to context.Database.MigrateAsync() once versioned
        // EF Core migrations have been generated for production (see README "Migrations").
        await context.Database.EnsureCreatedAsync(cancellationToken);

        if (await context.ApplicationCards.AnyAsync(cancellationToken)) return;

        context.ApplicationCards.AddRange(
            ApplicationCard.Create("PAYCON", "PayCon", "Reconciliation, payments and scheme management for Zurich Workplace Solutions.", "tabler-icon-building-bank", null, "#1B2A63", "/paycon/dashboard", 1, false, ApplicationCardStatus.Active),
            ApplicationCard.Create("COMPLIANCE", "Compliance", "Regulatory compliance monitoring and reporting.", "tabler-icon-shield-check", null, "#0F9D58", "/compliance", 2, true, ApplicationCardStatus.Active),
            ApplicationCard.Create("TRADEINSIGHTS", "Trade Insights", "Trade performance analytics and insights.", "tabler-icon-chart-candle", null, "#6B4EFF", "/trade-insights", 3, false, ApplicationCardStatus.Active),
            ApplicationCard.Create("PARTNERHUB", "PartnerHub", "Partner and distributor collaboration portal.", "tabler-icon-users-group", null, "#EA9B2D", "/partner-hub", 4, true, ApplicationCardStatus.ComingSoon)
        );

        await context.SaveChangesAsync(cancellationToken);
    }
}
