using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.ApplicationHub.Domain;

namespace ZWS.Modules.ApplicationHub.Infrastructure.Persistence;

/// <summary>
/// The ONLY DbContext for the ApplicationHub module. No other module may
/// reference this type (enforced by ZWS.ArchitectureTests).
/// </summary>
public sealed class ApplicationHubDbContext(DbContextOptions<ApplicationHubDbContext> options)
    : DbContext(options), IAppDbContext
{
    public DbSet<ApplicationCard> ApplicationCards => Set<ApplicationCard>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("hub");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationHubDbContext).Assembly);
        modelBuilder.Entity<ApplicationCard>().HasQueryFilter(a => !a.IsDeleted);
    }
}
