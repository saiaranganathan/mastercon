using ZWS.Modules.ApplicationHub.Domain;

namespace ZWS.Modules.ApplicationHub.Application.Repositories;

public interface IApplicationCardRepository
{
    Task<IReadOnlyCollection<ApplicationCard>> GetAllAsync(bool includeInactive, CancellationToken cancellationToken);
    Task<ApplicationCard?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<ApplicationCard?> GetByCodeAsync(string code, CancellationToken cancellationToken);
    void Add(ApplicationCard applicationCard);
}
