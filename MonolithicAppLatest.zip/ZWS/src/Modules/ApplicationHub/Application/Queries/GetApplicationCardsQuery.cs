using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.ApplicationHub.Application.Dtos;

namespace ZWS.Modules.ApplicationHub.Application.Queries;

/// <summary>GET /api/applications. Cached in Redis (requirement 25); falls back to SQL on a cache miss.</summary>
public sealed record GetApplicationCardsQuery(bool IncludeInactive = false)
    : IQuery<IReadOnlyCollection<ApplicationCardDto>>, ICacheableQuery
{
    public string CacheKey => CacheKeys.ApplicationHubCards + (IncludeInactive ? ":all" : ":active");
    public TimeSpan? Expiration => TimeSpan.FromMinutes(15);
}
