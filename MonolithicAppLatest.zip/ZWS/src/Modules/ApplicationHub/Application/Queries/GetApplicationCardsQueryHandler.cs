using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.ApplicationHub.Application.Dtos;
using ZWS.Modules.ApplicationHub.Application.Repositories;

namespace ZWS.Modules.ApplicationHub.Application.Queries;

public sealed class GetApplicationCardsQueryHandler(IApplicationCardRepository repository)
    : IQueryHandler<GetApplicationCardsQuery, IReadOnlyCollection<ApplicationCardDto>>
{
    public async Task<Result<IReadOnlyCollection<ApplicationCardDto>>> Handle(GetApplicationCardsQuery request, CancellationToken cancellationToken)
    {
        var cards = await repository.GetAllAsync(request.IncludeInactive, cancellationToken);

        var dtos = cards
            .OrderBy(c => c.DisplayOrder)
            .Select(c => new ApplicationCardDto(
                c.Id, c.Code, c.Name, c.Description, c.Icon, c.ImageUri, c.BaseColor,
                c.Route, c.DisplayOrder, c.IsActive, c.IsExternal, c.Status.ToString()))
            .ToList();

        return Result.Success<IReadOnlyCollection<ApplicationCardDto>>(dtos);
    }
}
