namespace ZWS.Modules.ApplicationHub.Application.Dtos;

/// <summary>API/UI shape - EF Core entities are never exposed directly (requirement 27).</summary>
public sealed record ApplicationCardDto(
    Guid Id,
    string Code,
    string Name,
    string Description,
    string Icon,
    string? ImageUri,
    string BaseColor,
    string Route,
    int DisplayOrder,
    bool IsActive,
    bool IsExternal,
    string Status);
