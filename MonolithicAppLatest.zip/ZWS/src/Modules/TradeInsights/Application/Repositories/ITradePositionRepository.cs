using ZWS.Modules.TradeInsights.Domain;

namespace ZWS.Modules.TradeInsights.Application.Repositories;

public interface ITradePositionRepository
{
    Task<IReadOnlyCollection<TradePosition>> GetAllAsync(CancellationToken cancellationToken);
}
