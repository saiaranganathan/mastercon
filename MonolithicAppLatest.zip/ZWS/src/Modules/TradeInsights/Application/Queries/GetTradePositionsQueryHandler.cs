using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.TradeInsights.Application.Dtos;
using ZWS.Modules.TradeInsights.Application.Repositories;

namespace ZWS.Modules.TradeInsights.Application.Queries;

public sealed class GetTradePositionsQueryHandler(ITradePositionRepository repository)
    : IQueryHandler<GetTradePositionsQuery, IReadOnlyCollection<TradePositionDto>>
{
    public async Task<Result<IReadOnlyCollection<TradePositionDto>>> Handle(GetTradePositionsQuery request, CancellationToken cancellationToken)
    {
        var positions = await repository.GetAllAsync(cancellationToken);
        var dtos = positions.Select(p => new TradePositionDto(p.Id, p.Instrument, p.Fund, p.MarketValue, p.DayChangePercentage)).ToList();
        return Result.Success<IReadOnlyCollection<TradePositionDto>>(dtos);
    }
}
