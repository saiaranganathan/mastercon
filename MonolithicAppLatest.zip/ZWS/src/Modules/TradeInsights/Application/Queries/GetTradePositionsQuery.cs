using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.TradeInsights.Application.Dtos;

namespace ZWS.Modules.TradeInsights.Application.Queries;

public sealed record GetTradePositionsQuery : IQuery<IReadOnlyCollection<TradePositionDto>>;
