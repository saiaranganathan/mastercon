namespace ZWS.Modules.TradeInsights.Application.Dtos;

public sealed record TradePositionDto(Guid Id, string Instrument, string Fund, decimal MarketValue, decimal DayChangePercentage);
