using Microsoft.EntityFrameworkCore;
using ZWS.Modules.TradeInsights.Application.Repositories;
using ZWS.Modules.TradeInsights.Domain;
using ZWS.Modules.TradeInsights.Infrastructure.Persistence;

namespace ZWS.Modules.TradeInsights.Infrastructure.Repositories;

public sealed class TradePositionRepository(TradeInsightsDbContext context) : ITradePositionRepository
{
    public async Task<IReadOnlyCollection<TradePosition>> GetAllAsync(CancellationToken cancellationToken) =>
        await context.Positions.AsNoTracking().OrderByDescending(p => p.MarketValue).ToListAsync(cancellationToken);
}
