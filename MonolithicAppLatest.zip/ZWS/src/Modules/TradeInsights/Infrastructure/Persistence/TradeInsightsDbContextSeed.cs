using Microsoft.EntityFrameworkCore;
using ZWS.Modules.TradeInsights.Domain;

namespace ZWS.Modules.TradeInsights.Infrastructure.Persistence;

public static class TradeInsightsDbContextSeed
{
    public static async Task SeedAsync(TradeInsightsDbContext context, CancellationToken cancellationToken = default)
    {
        await context.Database.EnsureCreatedAsync(cancellationToken);
        if (await context.Positions.AnyAsync(cancellationToken)) return;

        context.Positions.AddRange(
            TradePosition.Create("Global Equity Fund", "DEWS", 12_400_000m, 1.8m),
            TradePosition.Create("Emerging Markets Bond", "DAMAN", 6_150_000m, -0.6m),
            TradePosition.Create("Sukuk Income Fund", "Dubai Government", 8_900_000m, 0.3m));

        await context.SaveChangesAsync(cancellationToken);
    }
}
