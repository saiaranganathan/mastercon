using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.TradeInsights.Domain;

namespace ZWS.Modules.TradeInsights.Infrastructure.Persistence;

public sealed class TradeInsightsDbContext(DbContextOptions<TradeInsightsDbContext> options) : DbContext(options), IAppDbContext
{
    public DbSet<TradePosition> Positions => Set<TradePosition>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("trade_insights");
        modelBuilder.Entity<TradePosition>(b =>
        {
            b.ToTable("TradePositions");
            b.HasKey(x => x.Id);
            b.Property(x => x.Instrument).HasMaxLength(150);
            b.Property(x => x.Fund).HasMaxLength(150);
            b.Property(x => x.MarketValue).HasColumnType("decimal(18,2)");
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
            b.Property(x => x.DeletedBy).HasMaxLength(100);
            b.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
