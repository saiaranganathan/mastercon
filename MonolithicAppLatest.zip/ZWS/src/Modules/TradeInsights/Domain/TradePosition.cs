using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.TradeInsights.Domain;

/// <summary>Trade Insights - native ZWS application (requirement 17), basic landing dashboard.</summary>
public sealed class TradePosition : AuditableEntity
{
    public string Instrument { get; private set; } = default!;
    public string Fund { get; private set; } = default!;
    public decimal MarketValue { get; private set; }
    public decimal DayChangePercentage { get; private set; }

    private TradePosition() { }

    public static TradePosition Create(string instrument, string fund, decimal marketValue, decimal dayChangePercentage) => new()
    {
        Instrument = instrument, Fund = fund, MarketValue = marketValue, DayChangePercentage = dayChangePercentage
    };
}
