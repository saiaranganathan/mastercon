using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.TradeInsights.Application.Repositories;
using ZWS.Modules.TradeInsights.Infrastructure.Persistence;
using ZWS.Modules.TradeInsights.Infrastructure.Repositories;

namespace ZWS.Modules.TradeInsights;

public static class TradeInsightsModule
{
    public static IServiceCollection AddTradeInsightsModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("TradeInsights");

        services.AddDbContext<TradeInsightsDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=trade_insights.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "trade_insights"));
        });

        services.AddScoped<ITradePositionRepository, TradePositionRepository>();
        return services;
    }

    public static async Task SeedTradeInsightsModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<TradeInsightsDbContext>();
        await TradeInsightsDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
