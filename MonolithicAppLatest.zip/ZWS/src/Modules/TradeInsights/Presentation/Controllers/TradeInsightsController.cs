using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.TradeInsights.Application.Queries;

namespace ZWS.Modules.TradeInsights.Presentation.Controllers;

/// <summary>Route: /trade-insights (requirement 17).</summary>
[ApiController]
[Route("api/trade-insights/positions")]
public sealed class TradeInsightsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetPositions(CancellationToken cancellationToken) =>
        (await sender.Send(new GetTradePositionsQuery(), cancellationToken)).ToActionResult();
}
