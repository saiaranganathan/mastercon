using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Presentation.Controllers;

/// <summary>Route: /paycon/statements/annual-statements.</summary>
[ApiController]
[Route("api/paycon/statements/annual-statements")]
[RequirePermission("statements.annual-statements")]
public sealed class AnnualStatementsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAnnualStatements([FromQuery] PagedRequest paging, [FromQuery] AnnualStatementFilter filter, CancellationToken cancellationToken) =>
        (await sender.Send(new GetAnnualStatementsQuery(paging, filter), cancellationToken)).ToActionResult();

    /// <summary>Distinct employer ids - fills the Employer ID dropdown of the "Add Filter" panel.</summary>
    [HttpGet("employer-ids")]
    public async Task<IActionResult> GetEmployerIds(CancellationToken cancellationToken) =>
        (await sender.Send(new GetAnnualStatementEmployerIdsQuery(), cancellationToken)).ToActionResult();

    /// <summary>Backs the "Download As CSV" button: every row matching the search/filters (all
    /// pages, not just the visible one). View-level permission is enough - it never changes
    /// anything. Returned as a real file response, like Download.</summary>
    [HttpGet("export")]
    public async Task<IActionResult> Export([FromQuery] string? search, [FromQuery] AnnualStatementFilter filter, CancellationToken cancellationToken)
    {
        var result = await sender.Send(new ExportAnnualStatementsQuery(search, filter), cancellationToken);
        return result.IsSuccess
            ? File(result.Value.Content, "text/csv", result.Value.FileName)
            : result.ToActionResult();
    }

    /// <summary>Backs the per-row "Send" button (one id in the body, Force: false), the toolbar
    /// "Bulk trigger" button (every checked id, Force: false), and the per-row "Resend" button
    /// (one id in the body, Force: true) - see SendAnnualStatementsCommand.</summary>
    [HttpPost("send")]
    [RequirePermission("statements.annual-statements", PermissionAccess.Edit)]
    public async Task<IActionResult> Send([FromBody] SendAnnualStatementsCommand command, CancellationToken cancellationToken) =>
        (await sender.Send(command, cancellationToken)).ToActionResult();

    /// <summary>Backs the per-row "Resend" button. Always forces the send, whatever the row's
    /// current status (Sent, Failed or Pending) - per the BRD, Resend must work for both
    /// successful and failed statements. Separate from <see cref="Send"/> so the force behavior
    /// can never depend on a flag in the request body.</summary>
    [HttpPost("resend")]
    [RequirePermission("statements.annual-statements", PermissionAccess.Edit)]
    public async Task<IActionResult> Resend([FromBody] ResendAnnualStatementsRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new SendAnnualStatementsCommand(request.StatementIds ?? [], Force: true), cancellationToken)).ToActionResult();

    /// <summary>Backs the per-row "Download" button - View-level permission (the class-level
    /// attribute) is enough, since this never changes anything, unlike Send. Bypasses
    /// ResultExtensions.ToActionResult on success (that would JSON-serialize the byte[] as base64
    /// inside an object) and returns the PDF as a real file response instead.</summary>
    [HttpGet("{id:guid}/download")]
    public async Task<IActionResult> Download(Guid id, CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetAnnualStatementPdfQuery(id), cancellationToken);
        return result.IsSuccess
            ? File(result.Value.Content, "application/pdf", result.Value.FileName)
            : result.ToActionResult();
    }
}

public sealed record ResendAnnualStatementsRequest(IReadOnlyCollection<Guid> StatementIds);
