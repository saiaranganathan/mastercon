using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

/// <summary>Distinct employer ids present in the annual statements table - fills the Employer ID
/// dropdown of the "Add Filter" panel.</summary>
public sealed record GetAnnualStatementEmployerIdsQuery : IQuery<IReadOnlyCollection<long>>;

public sealed class GetAnnualStatementEmployerIdsQueryHandler(IAnnualStatementRepository repository)
    : IQueryHandler<GetAnnualStatementEmployerIdsQuery, IReadOnlyCollection<long>>
{
    public async Task<Result<IReadOnlyCollection<long>>> Handle(GetAnnualStatementEmployerIdsQuery request, CancellationToken cancellationToken) =>
        Result.Success(await repository.GetEmployerIdsAsync(cancellationToken));
}
