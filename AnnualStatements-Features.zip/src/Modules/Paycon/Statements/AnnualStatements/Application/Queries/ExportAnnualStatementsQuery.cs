using System.Globalization;
using System.Text;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

/// <summary>Backs the "Download As CSV" button: every row matching the current search/filters
/// (NOT just the current page). With no search and no filters that is the entire table.</summary>
public sealed record ExportAnnualStatementsQuery(string? Search, AnnualStatementFilter? Filter = null) : IQuery<AnnualStatementCsvDto>;

public sealed class ExportAnnualStatementsQueryHandler(IAnnualStatementRepository repository)
    : IQueryHandler<ExportAnnualStatementsQuery, AnnualStatementCsvDto>
{
    public async Task<Result<AnnualStatementCsvDto>> Handle(ExportAnnualStatementsQuery request, CancellationToken cancellationToken)
    {
        var rows = await repository.ListAsync(request.Search, request.Filter, cancellationToken);

        var sb = new StringBuilder();
        sb.AppendLine("Employee ID,Employer ID,Employee Full Name,Statement Due Date,Statement Sent Date,Statement Sent Status");
        foreach (var s in rows)
        {
            sb.Append(s.EmployeeId.ToString(CultureInfo.InvariantCulture)).Append(',')
              .Append(s.EmployerId.ToString(CultureInfo.InvariantCulture)).Append(',')
              .Append(Escape(s.EmployeeFullName)).Append(',')
              .Append(s.StatementDueDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)).Append(',')
              .Append(s.StatementSentDate?.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) ?? string.Empty).Append(',')
              .Append(s.StatementSentStatus).AppendLine();
        }

        // UTF-8 with BOM so Excel opens names with accents correctly.
        var bytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true).GetPreamble()
            .Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
        var fileName = $"annual-statements-{DateTime.UtcNow:yyyyMMdd-HHmmss}.csv";
        return Result.Success(new AnnualStatementCsvDto(fileName, bytes));
    }

    /// <summary>RFC 4180 quoting, plus a leading apostrophe on values starting with = + - @ so a
    /// name can never be interpreted as a spreadsheet formula (CSV injection).</summary>
    private static string Escape(string? value)
    {
        value ??= string.Empty;
        if (value.Length > 0 && "=+-@".Contains(value[0])) value = "'" + value;
        return value.IndexOfAny([',', '"', '\r', '\n']) >= 0 ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
    }
}
