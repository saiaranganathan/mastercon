using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

public sealed record GetAnnualStatementsQuery(PagedRequest Paging, AnnualStatementFilter? Filter = null) : IQuery<PagedResult<AnnualStatementDto>>;
