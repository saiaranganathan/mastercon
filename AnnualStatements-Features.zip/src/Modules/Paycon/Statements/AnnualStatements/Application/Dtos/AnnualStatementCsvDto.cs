namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

/// <summary>The CSV export of the annual statements list, ready to stream back as a file
/// response (see AnnualStatementsController.Export).</summary>
public sealed record AnnualStatementCsvDto(string FileName, byte[] Content);
