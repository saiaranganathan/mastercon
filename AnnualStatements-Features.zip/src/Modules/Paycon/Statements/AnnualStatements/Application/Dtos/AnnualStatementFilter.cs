namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

/// <summary>
/// The "Add Filter" panel on the Annual Statements page. Bound straight from the query string
/// ([FromQuery]) on the list and CSV-export endpoints, so it's a plain class with settable
/// properties. Every property is optional - null/blank means "don't filter on this".
/// Dates are inclusive on both ends and compare on the calendar day only.
/// </summary>
public sealed class AnnualStatementFilter
{
    /// <summary>Partial match on the employee id (e.g. "10" matches 1001 and 2103).</summary>
    public string? EmployeeId { get; set; }
    public long? EmployerId { get; set; }
    /// <summary>Pending, Sent or Failed (case-insensitive). Anything else is ignored.</summary>
    public string? Status { get; set; }
    public DateTime? DueDateFrom { get; set; }
    public DateTime? DueDateTo { get; set; }
    public DateTime? SentDateFrom { get; set; }
    public DateTime? SentDateTo { get; set; }
}
