using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Persistence;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Infrastructure.Repositories;

public sealed class AnnualStatementRepository(AnnualStatementsDbContext context) : IAnnualStatementRepository
{
    public async Task<(IReadOnlyCollection<AnnualStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, AnnualStatementFilter? filter, CancellationToken cancellationToken)
    {
        var query = Filtered(request.Search, filter);

        var total = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, total);
    }

    public async Task<IReadOnlyCollection<AnnualStatement>> ListAsync(string? search, AnnualStatementFilter? filter, CancellationToken cancellationToken) =>
        await Filtered(search, filter).ToListAsync(cancellationToken);

    public async Task<IReadOnlyCollection<long>> GetEmployerIdsAsync(CancellationToken cancellationToken) =>
        await context.AnnualStatements.AsNoTracking().Select(s => s.EmployerId).Distinct().OrderBy(id => id).ToListAsync(cancellationToken);

    public async Task<IReadOnlyCollection<AnnualStatement>> GetByIdsAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken) =>
        await context.AnnualStatements.Where(s => ids.Contains(s.Id)).ToListAsync(cancellationToken);

    public async Task<AnnualStatement?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        await context.AnnualStatements.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    /// <summary>Shared by the paged list and the CSV export so both always agree on what "matches".
    /// Ordered newest due date first (then by name, so paging is stable).</summary>
    private IQueryable<AnnualStatement> Filtered(string? search, AnnualStatementFilter? filter)
    {
        var query = context.AnnualStatements.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(s => s.EmployeeFullName.Contains(term) || s.EmployeeId.ToString().Contains(term));
        }

        if (filter is not null)
        {
            if (!string.IsNullOrWhiteSpace(filter.EmployeeId))
            {
                var id = filter.EmployeeId.Trim();
                query = query.Where(s => s.EmployeeId.ToString().Contains(id));
            }

            if (filter.EmployerId is { } employerId)
                query = query.Where(s => s.EmployerId == employerId);

            if (!string.IsNullOrWhiteSpace(filter.Status) && Enum.TryParse<AnnualStatementSentStatus>(filter.Status.Trim(), ignoreCase: true, out var status))
                query = query.Where(s => s.StatementSentStatus == status);

            if (filter.DueDateFrom is { } dueFrom)
            {
                var from = dueFrom.Date;
                query = query.Where(s => s.StatementDueDate >= from);
            }

            if (filter.DueDateTo is { } dueTo)
            {
                var before = dueTo.Date.AddDays(1);
                query = query.Where(s => s.StatementDueDate < before);
            }

            if (filter.SentDateFrom is { } sentFrom)
            {
                var from = sentFrom.Date;
                query = query.Where(s => s.StatementSentDate != null && s.StatementSentDate >= from);
            }

            if (filter.SentDateTo is { } sentTo)
            {
                var before = sentTo.Date.AddDays(1);
                query = query.Where(s => s.StatementSentDate != null && s.StatementSentDate < before);
            }
        }

        return query.OrderByDescending(s => s.StatementDueDate).ThenBy(s => s.EmployeeFullName);
    }
}
