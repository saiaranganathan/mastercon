namespace ZWS.Web.Models;

public sealed record InsightDto(Guid Id, string Title, string Category, string ValueDisplay, decimal TrendPercentage);

public sealed record ExitStatementDto(Guid Id, string EmployeeName, string SchemeName, DateTime ExitDate, decimal FinalAmount, string Currency, string Status);

public sealed record AnnualStatementDto(
    Guid Id,
    long EmployeeId,
    long EmployerId,
    string EmployeeFullName,
    DateTime StatementDueDate,
    DateTime? StatementSentDate,
    string StatementSentStatus);

/// <summary>Values of the "Add Filter" panel on the Annual Statements page. Dates are the raw
/// date-picker values (null when empty). Mirrors the server-side AnnualStatementFilter.</summary>
public sealed class AnnualStatementFilter
{
    public string? EmployeeId { get; set; }
    public long? EmployerId { get; set; }
    public string? Status { get; set; }
    public DateTime? DueDateFrom { get; set; }
    public DateTime? DueDateTo { get; set; }
    public DateTime? SentDateFrom { get; set; }
    public DateTime? SentDateTo { get; set; }

    /// <summary>How many filters are currently set - shown as the "Add Filter (n)" badge.</summary>
    public int ActiveCount =>
        (string.IsNullOrWhiteSpace(EmployeeId) ? 0 : 1) + (EmployerId is null ? 0 : 1) + (string.IsNullOrWhiteSpace(Status) ? 0 : 1) +
        (DueDateFrom is null ? 0 : 1) + (DueDateTo is null ? 0 : 1) + (SentDateFrom is null ? 0 : 1) + (SentDateTo is null ? 0 : 1);

    public void Clear()
    {
        EmployeeId = null; EmployerId = null; Status = null;
        DueDateFrom = DueDateTo = SentDateFrom = SentDateTo = null;
    }
}

public sealed record AnnualStatementSendOutcomeDto(Guid StatementId, long EmployeeId, string EmployeeFullName, string Status, string? ErrorMessage);

public sealed record SendAnnualStatementsResultDto(int SentCount, int SkippedCount, int FailedCount, IReadOnlyCollection<AnnualStatementSendOutcomeDto> Outcomes);

public sealed record InsightConfigurationDto(Guid Id, string Name, string? Description, bool IsEnabled);

public sealed record NotificationDto(Guid Id, string Title, string Description, string Severity, DateTime OccurredAt, bool IsRead);
