using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class AnnualStatementsApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseUrl = "api/paycon/statements/annual-statements";

    public Task<ApiResult<PagedResult<AnnualStatementDto>>> GetAsync(int page = 1, int pageSize = 20, string? search = null, AnnualStatementFilter? filter = null, CancellationToken cancellationToken = default)
    {
        var qs = AddFilter(new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search), filter);
        return GetAsync<PagedResult<AnnualStatementDto>>($"{BaseUrl}{qs}", cancellationToken);
    }

    /// <summary>Distinct employer ids for the Employer ID dropdown of the "Add Filter" panel.</summary>
    public Task<ApiResult<List<long>>> GetEmployerIdsAsync(CancellationToken cancellationToken = default) =>
        GetAsync<List<long>>($"{BaseUrl}/employer-ids", cancellationToken);

    /// <summary>Backs the "Download As CSV" button - the whole list (every page) matching the
    /// current search/filters, as raw bytes for the caller to hand to JS interop.</summary>
    public Task<ApiResult<byte[]>> ExportCsvAsync(string? search = null, AnnualStatementFilter? filter = null, CancellationToken cancellationToken = default)
    {
        var qs = AddFilter(new QueryStringBuilder().Add("search", search), filter);
        return GetBytesAsync($"{BaseUrl}/export{qs}", cancellationToken);
    }

    /// <summary>Backs the per-row "Send" button (a single id) and the toolbar "Bulk trigger"
    /// button (every checked id). Rows already marked Sent are skipped - use
    /// <see cref="ResendAsync"/> to send those again.</summary>
    public Task<ApiResult<SendAnnualStatementsResultDto>> SendAsync(IReadOnlyCollection<Guid> statementIds, CancellationToken cancellationToken = default) =>
        PostAsync<object, SendAnnualStatementsResultDto>($"{BaseUrl}/send", new { StatementIds = statementIds, Force = false }, cancellationToken);

    /// <summary>Backs the per-row "Resend" button: always sends, even when the row is already
    /// Sent (or Failed) - nothing is skipped.</summary>
    public Task<ApiResult<SendAnnualStatementsResultDto>> ResendAsync(IReadOnlyCollection<Guid> statementIds, CancellationToken cancellationToken = default) =>
        PostAsync<object, SendAnnualStatementsResultDto>($"{BaseUrl}/resend", new { StatementIds = statementIds }, cancellationToken);

    /// <summary>Backs the per-row "Download" button - returns the raw PDF bytes for the caller to
    /// hand to JS interop (see AnnualStatements.razor.DownloadAsync).</summary>
    public Task<ApiResult<byte[]>> DownloadPdfAsync(Guid statementId, CancellationToken cancellationToken = default) =>
        GetBytesAsync($"{BaseUrl}/{statementId}/download", cancellationToken);

    private static QueryStringBuilder AddFilter(QueryStringBuilder qs, AnnualStatementFilter? f)
    {
        if (f is null) return qs;
        const string dateFormat = "yyyy-MM-dd";
        return qs.Add("employeeId", f.EmployeeId?.Trim())
                 .Add("employerId", f.EmployerId)
                 .Add("status", f.Status)
                 .Add("dueDateFrom", f.DueDateFrom?.ToString(dateFormat))
                 .Add("dueDateTo", f.DueDateTo?.ToString(dateFormat))
                 .Add("sentDateFrom", f.SentDateFrom?.ToString(dateFormat))
                 .Add("sentDateTo", f.SentDateTo?.ToString(dateFormat));
    }
}
