using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

public sealed class UpdateRoleCommandHandler(IRoleRepository roleRepository, IGroupRepository groupRepository, IUserManagementDbContext dbContext)
    : ICommandHandler<UpdateRoleCommand>
{
    public async Task<Result> Handle(UpdateRoleCommand request, CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.Id, cancellationToken);
        if (role is null)
            return Result.Failure(Error.NotFound("Role.NotFound", $"Role '{request.Id}' was not found."));

        var activeUsers = await roleRepository.CountActiveUsersAsync(role.Id, cancellationToken);

        // PR_UM 2.2: state changes are blocked (with a warning, surfaced by the API as a Conflict)
        // once the role has active users - only permission changes remain possible, and those
        // must propagate to every user currently holding the role.
        if (activeUsers > 0 && role.State != request.State)
            return Result.Failure(Error.Conflict("Role.HasActiveUsers", "The state of Role cannot be changed because there are active users assigned to it."));

        // BUS-4538: the Name must stay unique within the (possibly unchanged) Group - previously this
        // was only checked when the Group itself changed, so renaming a role to an existing
        // Name+Group combination was accepted.
        if ((request.GroupId != role.GroupId || !string.Equals(request.Name, role.Name, StringComparison.Ordinal))
            && await roleRepository.ExistsByNameAsync($"{request.GroupId}::{request.Name}", role.Id, cancellationToken))
            return Result.Failure(Error.Conflict("Role.NameNotUnique", "Role Name must be unique within the selected Group."));

        // BUS-4537: the Group can be changed only while the role has no active users (PR_UM 2.2),
        // and only to an existing, Active Group (BUS-4542) where the role name is still unique.
        if (request.GroupId != role.GroupId)
        {
            if (activeUsers > 0)
                return Result.Failure(Error.Conflict("Role.GroupLocked", "This role has active users - its Group cannot be changed while users are assigned."));

            var newGroup = await groupRepository.GetByIdAsync(request.GroupId, cancellationToken);
            if (newGroup is null)
                return Result.Failure(Error.NotFound("Group.NotFound", "Selected Group does not exist."));
            if (newGroup.State != GroupState.Active)
                return Result.Failure(Error.Validation("Role.GroupInactive", "Selected Group is inactive. Choose an active Group."));

            role.ChangeGroup(request.GroupId);
        }

        // Snapshot the permissions being replaced BEFORE UpdateDetails clears them from the
        // navigation - needed below only to detach the change tracker's now-stale copies once
        // their rows have been deleted directly via SQL (see IUserManagementDbContext.
        // DeleteChildRowsAsync/DetachRange).
        var oldPermissions = role.Permissions.ToList();

        role.UpdateDetails(request.Name, request.Description, request.Permissions);
        if (activeUsers == 0) role.ChangeState(request.State);

        // See IUserManagementDbContext.AddRange - these freshly-created replacement rows must be
        // explicitly marked Added, or EF's IsKeySet heuristic (seeing their already-set,
        // client-generated Guid key) tracks them as Modified instead, since they're only
        // discovered via graph-fixup from the already-tracked `role`, not an explicit Add call.
        var newPermissions = role.Permissions.ToList();

        await dbContext.DeleteChildRowsAsync<RolePagePermission>(x => x.RoleId == role.Id, cancellationToken);
        dbContext.DetachRange(oldPermissions);
        dbContext.AddRange(newPermissions);

        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
