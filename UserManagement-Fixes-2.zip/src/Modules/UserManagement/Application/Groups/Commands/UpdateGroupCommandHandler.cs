using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Groups.Commands;

public sealed class UpdateGroupCommandHandler(
    IGroupRepository groupRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext) : ICommandHandler<UpdateGroupCommand>
{
    public async Task<Result> Handle(UpdateGroupCommand request, CancellationToken cancellationToken)
    {
        var group = await groupRepository.GetByIdAsync(request.Id, cancellationToken);
        if (group is null)
            return Result.Failure(Error.NotFound("Group.NotFound", $"Group '{request.Id}' was not found."));

        // BUS-4546: a Group with active users cannot be made Inactive.
        if (group.State != request.State && request.State == GroupState.Inactive)
        {
            var activeUsers = await groupRepository.CountActiveUsersAsync(group.Id, cancellationToken);
            if (activeUsers > 0)
                return Result.Failure(Error.Conflict("Group.HasActiveUsers", "The state of Group cannot be changed because there are active users assigned to it."));
        }

        // BUS-4550: when "Override Plan Permission at user level" is switched off, the plan
        // overrides previously granted to this Group's users are revoked straight away (unless
        // another of the user's Groups still allows overrides) - rather than lingering until each
        // user is next saved. Computed BEFORE the flag is changed so the "other groups" check
        // reads the persisted state of the user's remaining Groups.
        IReadOnlyCollection<Guid> usersToClear = [];
        if (group.OverridePlanPermissionAtUserLevel && !request.OverridePlanPermissionAtUserLevel)
            usersToClear = await groupRepository.GetUserIdsLosingPlanOverrideAsync(group.Id, cancellationToken);

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var selectedSchemes = allSchemes
            .Where(s => request.SchemeIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        // Snapshot the scheme assignments being replaced BEFORE UpdateDetails clears them from
        // the navigation - needed below only to detach the change tracker's now-stale copies once
        // their rows have been deleted directly via SQL (see IUserManagementDbContext.
        // DeleteChildRowsAsync/DetachRange).
        var oldSchemeAssignments = group.SchemeAssignments.ToList();

        // PR_UM-1.3: plans removed from a group automatically remove access from users who
        // inherit that plan, unless they hold an explicit user-level override - the User
        // aggregate's own inherited-plan projection (see GetUserByIdQueryHandler) recalculates
        // this live from the group's current scheme assignments, so nothing further to cascade here.
        group.UpdateDetails(request.Name, request.State, request.OverridePlanPermissionAtUserLevel, selectedSchemes);

        // See IUserManagementDbContext.AddRange - these freshly-created replacement rows must be
        // explicitly marked Added, or EF's IsKeySet heuristic (seeing their already-set,
        // client-generated Guid key) tracks them as Modified instead, since they're only
        // discovered via graph-fixup from the already-tracked `group`, not an explicit Add call.
        var newSchemeAssignments = group.SchemeAssignments.ToList();

        if (usersToClear.Count > 0)
        {
            var ids = usersToClear.ToList();
            await dbContext.DeleteChildRowsAsync<UserSchemeOverride>(x => ids.Contains(x.UserId), cancellationToken);
        }

        await dbContext.DeleteChildRowsAsync<GroupSchemeAssignment>(x => x.GroupId == group.Id, cancellationToken);
        dbContext.DetachRange(oldSchemeAssignments);
        dbContext.AddRange(newSchemeAssignments);

        await dbContext.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}
