using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Queries;

public sealed class GetUserByIdQueryHandler(IUserRepository userRepository, IGroupRepository groupRepository)
    : IQueryHandler<GetUserByIdQuery, UserDetailDto>
{
    public async Task<Result<UserDetailDto>> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByIdAsync(request.Id, cancellationToken);
        if (user is null)
            return Result.Failure<UserDetailDto>(Error.NotFound("User.NotFound", $"User '{request.Id}' was not found."));

        // Assigned Plans = inherited (from every group the user belongs to) + explicit user-level overrides.
        var inherited = new List<SchemeRefDto>();
        var anyGroupAllowsOverride = false;
        foreach (var membership in user.Groups)
        {
            var group = await groupRepository.GetByIdAsync(membership.GroupId, cancellationToken);
            if (group is null) continue;
            anyGroupAllowsOverride |= group.OverridePlanPermissionAtUserLevel;
            inherited.AddRange(group.SchemeAssignments.Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName)));
        }
        inherited = inherited.DistinctBy(s => s.SchemeId).ToList();

        // BUS-4550: user-level overrides only count while at least one of the user's Groups still
        // allows them - revoking the Group's override right takes effect immediately.
        var overrides = anyGroupAllowsOverride
            ? user.SchemeOverrides.Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName)).ToList()
            : new List<SchemeRefDto>();
        var assignedPlans = inherited.Concat(overrides).DistinctBy(s => s.SchemeId).ToList();

        var dto = new UserDetailDto(
            user.Id, user.FullName, user.Email, assignedPlans, inherited, overrides,
            user.SupervisorId, user.SupervisorName, user.IsSupervisor, user.State.ToString(),
            user.Groups.Select(g => new GroupRefDto(g.GroupId, g.GroupName)).ToList(),
            user.Roles.Select(r => new RoleRefDto(r.RoleId, r.RoleName)).ToList(),
            user.Permissions.Select(p => new PagePermissionDto(p.PageKey, PermissionPageCatalog.LabelFor(p.PageKey), p.Access.ToString())).ToList(),
            user.CreatedAt, user.CreatedBy, user.UpdatedAt, user.UpdatedBy);

        return Result.Success(dto);
    }
}
