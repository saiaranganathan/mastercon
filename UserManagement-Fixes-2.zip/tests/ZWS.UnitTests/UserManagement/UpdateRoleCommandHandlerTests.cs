using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Application.Roles.Commands;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>BUS-4538 (unique Name + Group on edit) and BUS-4543 (state-change message).</summary>
public class UpdateRoleCommandHandlerTests
{
    private readonly Mock<IRoleRepository> _roleRepository = new();
    private readonly Mock<IGroupRepository> _groupRepository = new();
    private readonly Mock<IUserManagementDbContext> _dbContext = new();

    private static readonly PagePermissionAssignment[] Permissions = [new("statements.annual-statements", AccessLevel.View)];

    private UpdateRoleCommandHandler CreateHandler() => new(_roleRepository.Object, _groupRepository.Object, _dbContext.Object);

    [Fact]
    public async Task Handle_WhenRenamedToExistingNameInSameGroup_ShouldReturnConflict()
    {
        var groupId = Guid.NewGuid();
        var role = Role.Create("FinanceAnalyst", groupId, null, RoleState.Active, Permissions);
        _roleRepository.Setup(r => r.GetByIdAsync(role.Id, It.IsAny<CancellationToken>())).ReturnsAsync(role);
        _roleRepository.Setup(r => r.CountActiveUsersAsync(role.Id, It.IsAny<CancellationToken>())).ReturnsAsync(0);
        _roleRepository.Setup(r => r.ExistsByNameAsync($"{groupId}::FinanceManager", role.Id, It.IsAny<CancellationToken>())).ReturnsAsync(true);

        var result = await CreateHandler().Handle(
            new UpdateRoleCommand(role.Id, "FinanceManager", groupId, null, RoleState.Active, Permissions), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.Conflict);
        result.Error.Code.Should().Be("Role.NameNotUnique");
        _dbContext.Verify(d => d.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenStateChangedWithActiveUsers_ShouldReturnUserStoryMessage()
    {
        var groupId = Guid.NewGuid();
        var role = Role.Create("FinanceAnalyst", groupId, null, RoleState.Active, Permissions);
        _roleRepository.Setup(r => r.GetByIdAsync(role.Id, It.IsAny<CancellationToken>())).ReturnsAsync(role);
        _roleRepository.Setup(r => r.CountActiveUsersAsync(role.Id, It.IsAny<CancellationToken>())).ReturnsAsync(2);

        var result = await CreateHandler().Handle(
            new UpdateRoleCommand(role.Id, "FinanceAnalyst", groupId, null, RoleState.Inactive, Permissions), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.Conflict);
        result.Error.Message.Should().Be("The state of Role cannot be changed because there are active users assigned to it.");
    }
}
