using FluentAssertions;
using Moq;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Groups.Commands;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>BUS-4546: a Group with active users cannot be made Inactive.</summary>
public class UpdateGroupCommandHandlerTests
{
    private readonly Mock<IGroupRepository> _groupRepository = new();
    private readonly Mock<ISchemeReferenceService> _schemes = new();
    private readonly Mock<IUserManagementDbContext> _dbContext = new();

    [Fact]
    public async Task Handle_WhenInactivatingGroupWithActiveUsers_ShouldReturnConflict()
    {
        var group = Group.Create("Finance", GroupState.Active, false, []);
        _groupRepository.Setup(r => r.GetByIdAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(group);
        _groupRepository.Setup(r => r.CountActiveUsersAsync(group.Id, It.IsAny<CancellationToken>())).ReturnsAsync(3);

        var handler = new UpdateGroupCommandHandler(_groupRepository.Object, _schemes.Object, _dbContext.Object);
        var result = await handler.Handle(
            new UpdateGroupCommand(group.Id, "Finance", GroupState.Inactive, false, [Guid.NewGuid()]), CancellationToken.None);

        result.IsFailure.Should().BeTrue();
        result.Error.Type.Should().Be(ErrorType.Conflict);
        result.Error.Message.Should().Be("The state of Group cannot be changed because there are active users assigned to it.");
        group.State.Should().Be(GroupState.Active);
        _dbContext.Verify(d => d.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }
}
