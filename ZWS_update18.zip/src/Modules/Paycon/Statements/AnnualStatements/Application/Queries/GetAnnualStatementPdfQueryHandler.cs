using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

/// <summary>
/// Same PDF rendering step Send/Bulk trigger uses (AnnualStatement_Data.PdfContent through
/// IPdfGeneratorService.ConvertToPdfBytesAsync) - this query just stops short of emailing it, and
/// hands the bytes back for the browser to save instead. Read-only: never touches
/// StatementSentStatus/StatementSentDate, so downloading a statement has no effect on whether
/// it's still due to be sent.
/// </summary>
public sealed class GetAnnualStatementPdfQueryHandler(
    IAnnualStatementRepository repository,
    IAnnualStatementDataRepository dataRepository,
    IPdfGeneratorService pdfGenerator)
    : IQueryHandler<GetAnnualStatementPdfQuery, AnnualStatementPdfDto>
{
    public async Task<Result<AnnualStatementPdfDto>> Handle(GetAnnualStatementPdfQuery request, CancellationToken cancellationToken)
    {
        var statement = await repository.GetByIdAsync(request.StatementId, cancellationToken);
        if (statement is null)
            return Result.Failure<AnnualStatementPdfDto>(Error.NotFound("AnnualStatements.NotFound", "Statement not found."));

        var data = (await dataRepository.GetByEmployeeIdsAsync([statement.EmployeeId], cancellationToken)).FirstOrDefault();
        if (data is null)
            return Result.Failure<AnnualStatementPdfDto>(Error.NotFound("AnnualStatements.DataNotFound",
                "No annual statement data found for this employee yet."));

        var fileName = $"{statement.EmployeeFullName}-annual-statement-{statement.StatementDueDate:yyyy}.pdf";
        var pdfBytes = await pdfGenerator.ConvertToPdfBytesAsync(fileName, data.PdfContent ?? string.Empty, cancellationToken);

        return Result.Success(new AnnualStatementPdfDto(fileName, pdfBytes));
    }
}
