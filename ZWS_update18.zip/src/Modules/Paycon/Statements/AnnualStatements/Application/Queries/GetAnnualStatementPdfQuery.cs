using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

/// <summary>Backs the per-row "Download" button - renders the same PDF Send/Bulk trigger would
/// email, but hands it back to the browser instead of sending it anywhere.</summary>
public sealed record GetAnnualStatementPdfQuery(Guid StatementId) : IQuery<AnnualStatementPdfDto>;
