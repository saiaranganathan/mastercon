namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Dtos;

/// <summary>The rendered PDF for one employee's annual statement, ready to stream straight back
/// as the download response (see AnnualStatementsController.Download) - not a JSON DTO, just a
/// name/bytes pair.</summary>
public sealed record AnnualStatementPdfDto(string FileName, byte[] Content);
