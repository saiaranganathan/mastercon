using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Domain;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Repositories;

public interface IAnnualStatementRepository
{
    Task<(IReadOnlyCollection<AnnualStatement> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);

    /// <summary>
    /// Loads the selected rows TRACKED (not AsNoTracking, unlike SearchAsync) - Send/Bulk trigger
    /// mutates each returned AnnualStatement (MarkSent/MarkFailed) and relies on the change
    /// tracker to pick those changes up on SaveChangesAsync. IDs that don't match an existing,
    /// non-deleted row are simply absent from the result rather than causing an error - the
    /// handler treats "found fewer than requested" as normal (e.g. a row deleted between the grid
    /// load and the click).
    /// </summary>
    Task<IReadOnlyCollection<AnnualStatement>> GetByIdsAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken);

    /// <summary>Single-row, AsNoTracking lookup - backs the "Download" button
    /// (GetAnnualStatementPdfQueryHandler), which only reads the row, never mutates it.</summary>
    Task<AnnualStatement?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
}
