using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Commands;
using ZWS.Modules.Paycon.Statements.AnnualStatements.Application.Queries;

namespace ZWS.Modules.Paycon.Statements.AnnualStatements.Presentation.Controllers;

/// <summary>Route: /paycon/statements/annual-statements.</summary>
[ApiController]
[Route("api/paycon/statements/annual-statements")]
[RequirePermission("statements.annual-statements")]
public sealed class AnnualStatementsController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAnnualStatements([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetAnnualStatementsQuery(paging), cancellationToken)).ToActionResult();

    /// <summary>Backs both the per-row "Send" button (one id in the body) and the toolbar "Bulk
    /// trigger" button (every checked id) - see SendAnnualStatementsCommand.</summary>
    [HttpPost("send")]
    [RequirePermission("statements.annual-statements", PermissionAccess.Edit)]
    public async Task<IActionResult> Send([FromBody] SendAnnualStatementsCommand command, CancellationToken cancellationToken) =>
        (await sender.Send(command, cancellationToken)).ToActionResult();

    /// <summary>Backs the per-row "Download" button - View-level permission (the class-level
    /// attribute) is enough, since this never changes anything, unlike Send. Bypasses
    /// ResultExtensions.ToActionResult on success (that would JSON-serialize the byte[] as base64
    /// inside an object) and returns the PDF as a real file response instead.</summary>
    [HttpGet("{id:guid}/download")]
    public async Task<IActionResult> Download(Guid id, CancellationToken cancellationToken)
    {
        var result = await sender.Send(new GetAnnualStatementPdfQuery(id), cancellationToken);
        return result.IsSuccess
            ? File(result.Value.Content, "application/pdf", result.Value.FileName)
            : result.ToActionResult();
    }
}
