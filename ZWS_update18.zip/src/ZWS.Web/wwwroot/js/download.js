// Triggers a browser "Save As" for bytes already fetched through an authenticated HttpClient
// call (see ApiClientBase.GetBytesAsync). A plain <a href="{api-url}"> can't be used for this -
// the download API requires the "Authorization: Bearer {token}" header AuthMessageHandler
// attaches to typed HttpClient calls, and a normal anchor-click browser navigation never sends
// that header. Blazor's JS interop marshals a C# byte[] argument as a Uint8Array here directly,
// no base64 round-trip needed.
window.zwsDownloadFile = (fileName, contentType, bytes) => {
    const blob = new Blob([bytes], { type: contentType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
};
