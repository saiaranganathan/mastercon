using ZWS.Web.Models;

namespace ZWS.Web.Services;

public sealed class AnnualStatementsApiClient(HttpClient http) : ApiClientBase(http)
{
    public Task<ApiResult<PagedResult<AnnualStatementDto>>> GetAsync(int page = 1, int pageSize = 20, string? search = null, CancellationToken cancellationToken = default)
    {
        var qs = new QueryStringBuilder().Add("page", page).Add("pageSize", pageSize).Add("search", search);
        return GetAsync<PagedResult<AnnualStatementDto>>($"api/paycon/statements/annual-statements{qs}", cancellationToken);
    }

    /// <summary>Backs both the per-row "Send" button (a single id) and the toolbar "Bulk trigger"
    /// button (every checked id).</summary>
    public Task<ApiResult<SendAnnualStatementsResultDto>> SendAsync(IReadOnlyCollection<Guid> statementIds, CancellationToken cancellationToken = default) =>
        PostAsync<object, SendAnnualStatementsResultDto>("api/paycon/statements/annual-statements/send", new { StatementIds = statementIds }, cancellationToken);

    /// <summary>Backs the per-row "Download" button - returns the raw PDF bytes for the caller to
    /// hand to JS interop (see AnnualStatements.razor.DownloadAsync).</summary>
    public Task<ApiResult<byte[]>> DownloadPdfAsync(Guid statementId, CancellationToken cancellationToken = default) =>
        GetBytesAsync($"api/paycon/statements/annual-statements/{statementId}/download", cancellationToken);
}
