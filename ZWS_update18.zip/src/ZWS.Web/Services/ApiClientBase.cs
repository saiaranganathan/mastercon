using System.Net.Http.Json;
using System.Text.Json;
using ZWS.Web.Models;

namespace ZWS.Web.Services;

/// <summary>
/// Shared HTTP plumbing for every typed API client below. Every ZWS API
/// returns the same ApiError shape on failure (requirement 32), so the
/// unwrapping logic lives here exactly once.
/// </summary>
public abstract class ApiClientBase(HttpClient http)
{
    protected readonly HttpClient Http = http;

    /// <summary>
    /// ASP.NET Core's MVC JSON formatter serializes with "web" defaults
    /// (camelCase, case-insensitive) - System.Net.Http.Json's parameterless
    /// ReadFromJsonAsync/PostAsJsonAsync overloads do NOT use those defaults,
    /// they use plain case-sensitive JsonSerializerOptions. Without this,
    /// every server "items"/"page"/"pageSize" property would silently fail
    /// to bind onto our PascalCase C# models. Shared once here so every
    /// typed client automatically speaks the same JSON dialect as the API.
    /// </summary>
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    protected async Task<ApiResult<T>> GetAsync<T>(string uri, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.GetAsync(uri, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                var value = await response.Content.ReadFromJsonAsync<T>(JsonOptions, cancellationToken);
                return value is null ? ApiResult<T>.Failure("The server returned an empty response.") : ApiResult<T>.Success(value);
            }
            return ApiResult<T>.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult<T>.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    /// <summary>Like GetAsync&lt;T&gt;, but for an endpoint that returns a raw file body (e.g. a
    /// PDF) instead of JSON - reads the response as bytes rather than deserializing it. Used for
    /// downloads: the response still needs the "Authorization: Bearer" header AuthMessageHandler
    /// attaches to this HttpClient, which is exactly why this goes through the typed client
    /// rather than a plain browser &lt;a href&gt; navigation (that would hit the API with no
    /// token and get a 401) - the caller then hands the bytes to JS interop to actually trigger
    /// the browser's save-file dialog.</summary>
    protected async Task<ApiResult<byte[]>> GetBytesAsync(string uri, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.GetAsync(uri, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                var bytes = await response.Content.ReadAsByteArrayAsync(cancellationToken);
                return ApiResult<byte[]>.Success(bytes);
            }
            return ApiResult<byte[]>.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult<byte[]>.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    protected async Task<ApiResult<TResponse>> PostAsync<TRequest, TResponse>(string uri, TRequest body, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.PostAsJsonAsync(uri, body, JsonOptions, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                var value = await response.Content.ReadFromJsonAsync<TResponse>(JsonOptions, cancellationToken);
                return value is null ? ApiResult<TResponse>.Failure("The server returned an empty response.") : ApiResult<TResponse>.Success(value);
            }
            return ApiResult<TResponse>.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult<TResponse>.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    protected async Task<ApiResult> PostAsync<TRequest>(string uri, TRequest body, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.PostAsJsonAsync(uri, body, JsonOptions, cancellationToken);
            return response.IsSuccessStatusCode ? ApiResult.Success() : ApiResult.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    protected async Task<ApiResult> PutAsync<TRequest>(string uri, TRequest body, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.PutAsJsonAsync(uri, body, JsonOptions, cancellationToken);
            return response.IsSuccessStatusCode ? ApiResult.Success() : ApiResult.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    protected async Task<ApiResult> DeleteAsync(string uri, CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.DeleteAsync(uri, cancellationToken);
            return response.IsSuccessStatusCode ? ApiResult.Success() : ApiResult.Failure(await ReadErrorAsync(response, cancellationToken));
        }
        catch (Exception ex)
        {
            return ApiResult.Failure($"Could not reach the ZWS API: {ex.Message}");
        }
    }

    private static async Task<string> ReadErrorAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        try
        {
            var apiError = await response.Content.ReadFromJsonAsync<ApiError>(JsonOptions, cancellationToken);
            if (apiError is not null && !string.IsNullOrWhiteSpace(apiError.Message)) return apiError.Message;
        }
        catch
        {
            // Body wasn't a well-formed ApiError - fall through to the generic status-based message.
        }
        return $"Request failed ({(int)response.StatusCode} {response.ReasonPhrase}).";
    }
}
