namespace ZWS.Web.Models;

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.GroupState.</summary>
public enum GroupState { Active, Inactive }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.RoleState.</summary>
public enum RoleState { Active, Inactive }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.UserState.</summary>
public enum UserState { Active, Inactive, Terminated }

/// <summary>Mirrors ZWS.Modules.Paycon.Settings.UserManagement.Domain.AccessLevel - the level of
/// access a Role or User is granted against one page in the Permissions matrix (PR_UM 2.1).
/// Edit implies View; a page absent from the list means no access.</summary>
public enum AccessLevel { View, Edit }

/// <summary>One row submitted back to a Create/Update Role or User request: the page being
/// granted access to (a key from <see cref="PermissionPageDto"/>) and the access level.</summary>
public sealed record PagePermissionAssignment(string PageKey, AccessLevel Access);

/// <summary>One entry in the fixed page/sub-page catalog returned by GET .../permissions -
/// mirrors the real Paycon navigation tree one level deeper, since pages like User Management
/// render their own Users/Groups/Roles/Permissions tabs instead of separate nav items.
/// ParentKey is null for a top-level page.</summary>
public sealed record PermissionPageDto(string Key, string Label, string? ParentKey);

/// <summary>One row of a Role's or User's Permissions matrix as returned by the API - the page
/// being granted access to (with its display label already resolved) and the access level.</summary>
public sealed record PagePermissionDto(string PageKey, string PageLabel, string Access);

public sealed record SchemeRefDto(Guid SchemeId, string SchemeName);

public sealed record GroupListItemDto(
    Guid Id, string Name, string AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record GroupDetailDto(
    Guid Id, string Name, IReadOnlyCollection<SchemeRefDto> AssignedPlans, int AssignedUsers, string State,
    bool OverridePlanPermissionAtUserLevel, DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);
public sealed record UpdateGroupRequest(string Name, GroupState State, bool OverridePlanPermissionAtUserLevel, IReadOnlyCollection<Guid> SchemeIds);

public sealed record RoleListItemDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record RoleDetailDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    IReadOnlyCollection<PagePermissionDto> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateRoleRequest(string Name, Guid GroupId, string? Description, RoleState State, IReadOnlyCollection<PagePermissionAssignment> Permissions);
public sealed record UpdateRoleRequest(string Name, string? Description, RoleState State, IReadOnlyCollection<PagePermissionAssignment> Permissions);

public sealed record GroupRefDto(Guid GroupId, string GroupName);
public sealed record RoleRefDto(Guid RoleId, string RoleName);
public sealed record SupervisorOptionDto(Guid Id, string FullName);

public sealed record UserListItemDto(
    Guid Id, string FullName, string Email, string AssignedPlans, string? SupervisorName, string State, bool IsSupervisor,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record UserDetailDto(
    Guid Id, string FullName, string Email,
    IReadOnlyCollection<SchemeRefDto> AssignedPlans,
    Guid? SupervisorId, string? SupervisorName, bool IsSupervisor, string State,
    IReadOnlyCollection<GroupRefDto> Groups,
    IReadOnlyCollection<RoleRefDto> Roles,
    IReadOnlyCollection<PagePermissionDto> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record CreateUserRequest(
    string FullName, string Email, Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);

public sealed record UpdateUserRequest(
    Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);
