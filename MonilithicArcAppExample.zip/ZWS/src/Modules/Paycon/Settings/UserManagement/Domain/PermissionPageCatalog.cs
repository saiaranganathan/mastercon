namespace ZWS.Modules.Paycon.Settings.UserManagement.Domain;

/// <summary>
/// PR_UM 2.1: the fixed catalog of navigable pages and sub-pages that a Role's or User's
/// Permissions matrix assigns View/Edit access against. Mirrors the actual Paycon
/// navigation tree (see PayconNavigationDbContextSeed in the Navigation module) one level
/// deeper - it also lists the internal tabs of pages that render their own tab strip
/// instead of being modelled as separate navigation items (e.g. User Management's
/// Users/Groups/Roles/Permissions tabs), since an admin still needs to grant or withhold
/// access to each of those individually.
/// </summary>
public static class PermissionPageCatalog
{
    public sealed record Page(string Key, string Label, string? ParentKey);

    public static readonly IReadOnlyList<Page> Pages =
    [
        new("dashboard", "Dashboard", null),

        new("reconciliation", "Reconciliation", null),
        new("reconciliation.payments-in", "Payments In", "reconciliation"),
        new("reconciliation.payments-out", "Payments Out", "reconciliation"),

        new("insights", "Insights", null),

        new("statements", "Statements", null),
        new("statements.exit-statements", "Exit Statements", "statements"),
        new("statements.annual-statements", "Annual Statements", "statements"),

        new("settings", "Settings", null),
        new("settings.user-management", "User Management", "settings"),
        new("settings.user-management.users", "Users", "settings.user-management"),
        new("settings.user-management.groups", "Groups", "settings.user-management"),
        new("settings.user-management.roles", "Roles", "settings.user-management"),
        new("settings.user-management.permissions", "Permissions", "settings.user-management"),
        new("settings.scheme-management", "Scheme Management", "settings"),
        new("settings.insight-management", "Insight Management", "settings"),
    ];

    private static readonly HashSet<string> ValidKeys = Pages.Select(p => p.Key).ToHashSet();

    public static bool IsValidKey(string key) => ValidKeys.Contains(key);

    public static string LabelFor(string key) => Pages.FirstOrDefault(p => p.Key == key)?.Label ?? key;
}
