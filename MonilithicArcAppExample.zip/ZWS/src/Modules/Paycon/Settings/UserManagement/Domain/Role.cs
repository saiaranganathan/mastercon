using ZWS.BuildingBlocks.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Domain;

/// <summary>PR_UM 2.x: a named set of page permissions belonging to exactly one Group.</summary>
public sealed class Role : AuditableEntity
{
    public string Name { get; private set; } = default!;
    public Guid GroupId { get; private set; }
    public string? Description { get; private set; }
    public RoleState State { get; private set; } = RoleState.Active;

    private readonly List<RolePagePermission> _permissions = [];
    public IReadOnlyCollection<RolePagePermission> Permissions => _permissions.AsReadOnly();

    private Role() { }

    public static Role Create(string name, Guid groupId, string? description, RoleState state, IEnumerable<PagePermissionAssignment> permissions)
    {
        var role = new Role { Name = name, GroupId = groupId, Description = description, State = state };
        foreach (var permission in permissions.DistinctBy(p => p.PageKey))
            role._permissions.Add(RolePagePermission.Create(role.Id, permission.PageKey, permission.Access));
        return role;
    }

    public void UpdateDetails(string name, string? description, IEnumerable<PagePermissionAssignment> permissions)
    {
        // PR_UM 2.2: Group cannot change once the role has active users - enforced in the command handler,
        // which has visibility into the User aggregate; the domain model here just applies the edit.
        Name = name;
        Description = description;
        _permissions.Clear();
        foreach (var permission in permissions.DistinctBy(p => p.PageKey))
            _permissions.Add(RolePagePermission.Create(Id, permission.PageKey, permission.Access));
    }

    public void ChangeState(RoleState state) => State = state;
}

/// <summary>Grants one Role View or Edit access to one page/sub-page from the <see cref="PermissionPageCatalog"/>.</summary>
public sealed class RolePagePermission
{
    public Guid Id { get; private set; }
    public Guid RoleId { get; private set; }
    public string PageKey { get; private set; } = default!;
    public AccessLevel Access { get; private set; }

    private RolePagePermission() { }

    public static RolePagePermission Create(Guid roleId, string pageKey, AccessLevel access) => new()
    {
        Id = Guid.NewGuid(),
        RoleId = roleId,
        PageKey = pageKey,
        Access = access
    };
}
