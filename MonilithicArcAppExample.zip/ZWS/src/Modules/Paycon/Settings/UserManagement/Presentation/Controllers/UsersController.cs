using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Commands;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Presentation.Controllers;

/// <summary>/paycon/settings/user-management -> Users tab (PR_UM 3.x).</summary>
[ApiController]
[Route("api/paycon/settings/user-management/users")]
public sealed class UsersController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetUsers([FromQuery] PagedRequest paging, CancellationToken cancellationToken) =>
        (await sender.Send(new GetUsersQuery(paging), cancellationToken)).ToActionResult();

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetUser(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new GetUserByIdQuery(id), cancellationToken)).ToActionResult();

    [HttpGet("supervisors")]
    public async Task<IActionResult> GetSupervisorCandidates(CancellationToken cancellationToken) =>
        (await sender.Send(new GetSupervisorCandidatesQuery(), cancellationToken)).ToActionResult();

    [HttpPost]
    public async Task<IActionResult> CreateUser([FromBody] CreateUserRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new CreateUserCommand(
            request.FullName, request.Email, request.SupervisorId, request.IsSupervisor, request.State,
            request.GroupIds, request.RoleIds, request.Permissions, request.SchemeOverrideIds), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> UpdateUser(Guid id, [FromBody] UpdateUserRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateUserCommand(
            id, request.SupervisorId, request.IsSupervisor, request.State,
            request.GroupIds, request.RoleIds, request.Permissions, request.SchemeOverrideIds), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> DeleteUser(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteUserCommand(id), cancellationToken)).ToActionResult();
}

public sealed record CreateUserRequest(
    string FullName, string Email, Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);

public sealed record UpdateUserRequest(
    Guid? SupervisorId, bool IsSupervisor, UserState State,
    IReadOnlyCollection<Guid> GroupIds, IReadOnlyCollection<Guid> RoleIds,
    IReadOnlyCollection<PagePermissionAssignment> Permissions, IReadOnlyCollection<Guid> SchemeOverrideIds);
