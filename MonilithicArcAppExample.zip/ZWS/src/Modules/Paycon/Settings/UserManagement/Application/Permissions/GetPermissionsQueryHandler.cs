using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Permissions;

public sealed class GetPermissionsQueryHandler : IQueryHandler<GetPermissionsQuery, IReadOnlyCollection<PermissionPageDto>>
{
    public Task<Result<IReadOnlyCollection<PermissionPageDto>>> Handle(GetPermissionsQuery request, CancellationToken cancellationToken)
    {
        var pages = PermissionPageCatalog.Pages
            .Select(p => new PermissionPageDto(p.Key, p.Label, p.ParentKey))
            .ToList();

        return Task.FromResult(Result.Success<IReadOnlyCollection<PermissionPageDto>>(pages));
    }
}
