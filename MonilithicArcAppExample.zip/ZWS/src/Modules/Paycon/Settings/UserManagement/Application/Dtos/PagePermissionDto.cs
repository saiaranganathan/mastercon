namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

/// <summary>One row of a Role's or User's Permissions matrix as returned to the client - the
/// page being granted access to (with its display label resolved) and the access level.</summary>
public sealed record PagePermissionDto(string PageKey, string PageLabel, string Access);
