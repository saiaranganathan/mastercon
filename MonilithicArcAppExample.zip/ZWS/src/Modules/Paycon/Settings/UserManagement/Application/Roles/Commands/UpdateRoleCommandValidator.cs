using FluentValidation;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Roles.Commands;

public sealed class UpdateRoleCommandValidator : AbstractValidator<UpdateRoleCommand>
{
    public UpdateRoleCommandValidator()
    {
        RuleFor(x => x.Name).NotEmpty().Matches("^[A-Za-z0-9]+$").Length(4, 150);
        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.State).IsInEnum();
        RuleFor(x => x.Permissions).NotEmpty().WithMessage("At least one page permission must be selected.");
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
    }
}
