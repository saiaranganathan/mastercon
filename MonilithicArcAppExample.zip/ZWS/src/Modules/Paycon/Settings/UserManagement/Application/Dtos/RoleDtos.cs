namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;

public sealed record RoleListItemDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);

public sealed record RoleDetailDto(
    Guid Id, string Name, Guid GroupId, string GroupName, string? Description, int AssignedUsers, string State,
    IReadOnlyCollection<PagePermissionDto> Permissions,
    DateTime CreatedAt, string CreatedBy, DateTime? UpdatedAt, string? UpdatedBy);
