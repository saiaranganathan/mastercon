using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Permissions;

public sealed record PermissionPageDto(string Key, string Label, string? ParentKey);

/// <summary>The fixed catalog of navigable pages/sub-pages behind every "Permissions" matrix
/// in the Groups/Roles/Users screens (PR_UM 2.1) - see <see cref="Domain.PermissionPageCatalog"/>.</summary>
public sealed record GetPermissionsQuery : IQuery<IReadOnlyCollection<PermissionPageDto>>;
