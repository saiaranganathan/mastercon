using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Roles.Queries;

public sealed class GetRoleByIdQueryHandler(IRoleRepository roleRepository, IGroupRepository groupRepository)
    : IQueryHandler<GetRoleByIdQuery, RoleDetailDto>
{
    public async Task<Result<RoleDetailDto>> Handle(GetRoleByIdQuery request, CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.Id, cancellationToken);
        if (role is null)
            return Result.Failure<RoleDetailDto>(Error.NotFound("Role.NotFound", $"Role '{request.Id}' was not found."));

        var group = await groupRepository.GetByIdAsync(role.GroupId, cancellationToken);
        var activeUsers = await roleRepository.CountActiveUsersAsync(role.Id, cancellationToken);
        var permissions = role.Permissions
            .Select(p => new PagePermissionDto(p.PageKey, PermissionPageCatalog.LabelFor(p.PageKey), p.Access.ToString()))
            .ToList();

        return Result.Success(new RoleDetailDto(
            role.Id, role.Name, role.GroupId, group?.Name ?? "-", role.Description, activeUsers, role.State.ToString(),
            permissions, role.CreatedAt, role.CreatedBy, role.UpdatedAt, role.UpdatedBy));
    }
}
