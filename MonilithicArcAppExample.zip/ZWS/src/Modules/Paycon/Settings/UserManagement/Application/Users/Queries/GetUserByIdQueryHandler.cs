using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Dtos;
using ZWS.Modules.Paycon.Settings.UserManagement.Application.Repositories;
using ZWS.Modules.Paycon.Settings.UserManagement.Domain;

namespace ZWS.Modules.Paycon.Settings.UserManagement.Application.Users.Queries;

public sealed class GetUserByIdQueryHandler(IUserRepository userRepository, IGroupRepository groupRepository)
    : IQueryHandler<GetUserByIdQuery, UserDetailDto>
{
    public async Task<Result<UserDetailDto>> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByIdAsync(request.Id, cancellationToken);
        if (user is null)
            return Result.Failure<UserDetailDto>(Error.NotFound("User.NotFound", $"User '{request.Id}' was not found."));

        // Assigned Plans = inherited (from every group the user belongs to) + explicit user-level overrides.
        var inherited = new List<SchemeRefDto>();
        foreach (var membership in user.Groups)
        {
            var group = await groupRepository.GetByIdAsync(membership.GroupId, cancellationToken);
            if (group is not null)
                inherited.AddRange(group.SchemeAssignments.Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName)));
        }
        var overrides = user.SchemeOverrides.Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName));
        var assignedPlans = inherited.Concat(overrides).DistinctBy(s => s.SchemeId).ToList();

        var dto = new UserDetailDto(
            user.Id, user.FullName, user.Email, assignedPlans,
            user.SupervisorId, user.SupervisorName, user.IsSupervisor, user.State.ToString(),
            user.Groups.Select(g => new GroupRefDto(g.GroupId, g.GroupName)).ToList(),
            user.Roles.Select(r => new RoleRefDto(r.RoleId, r.RoleName)).ToList(),
            user.Permissions.Select(p => new PagePermissionDto(p.PageKey, PermissionPageCatalog.LabelFor(p.PageKey), p.Access.ToString())).ToList(),
            user.CreatedAt, user.CreatedBy, user.UpdatedAt, user.UpdatedBy);

        return Result.Success(dto);
    }
}
