using System.Text.Json;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using ZWS.BuildingBlocks.Application;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Caching;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Persistence;
using ZWS.BuildingBlocks.Realtime;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Compliance;
using ZWS.Modules.PartnerHub;
using ZWS.Modules.Paycon.Dashboard;
using ZWS.Modules.Paycon.Insights;
using ZWS.Modules.Paycon.Navigation;
using ZWS.Modules.Paycon.Notifications;
using ZWS.Modules.Paycon.Reconciliation.PaymentsIn;
using ZWS.Modules.Paycon.Reconciliation.PaymentsOut;
using ZWS.Modules.Paycon.Settings.InsightManagement;
using ZWS.Modules.Paycon.Settings.SchemeManagement;
using ZWS.Modules.Paycon.Statements.AnnualStatements;
using ZWS.Modules.Paycon.Statements.ExitStatements;
using ZWS.Modules.TradeInsights;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------
// Cross-cutting / shared kernel (requirement 6, 24, 25, 32, 33)
// ---------------------------------------------------------------------
// Validates the JWT Master issues at login and registers the real, claims-based
// ICurrentUserService - Paycon only validates (AddZwsJwtAuthentication), it never issues
// tokens itself (that's Master-only, via AddZwsJwtIssuer). This replaces the old
// `AddScoped<ICurrentUserService, SystemCurrentUserService>()` + TODO(auth) stub.
builder.Services.AddZwsJwtAuthentication(builder.Configuration);
builder.Services.AddScoped<AuditableEntitySaveChangesInterceptor>();

builder.Services.AddZwsRedisCache(builder.Configuration);
builder.Services.AddZwsRabbitMq(builder.Configuration);

builder.Services.AddSignalR();

builder.Services.AddControllers()
    // Every module's Presentation/Controllers live in that module's own
    // assembly (never in ZWS.Host), so each one is registered explicitly as
    // an MVC application part.
    .AddApplicationPart(typeof(ZWS.Modules.Compliance.Presentation.Controllers.ComplianceController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.PartnerHub.Presentation.Controllers.PartnersController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.TradeInsights.Presentation.Controllers.TradeInsightsController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Navigation.Presentation.Controllers.PayconNavigationController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Dashboard.Presentation.Controllers.DashboardController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Reconciliation.PaymentsIn.Presentation.Controllers.PaymentsInController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Reconciliation.PaymentsOut.Presentation.Controllers.PaymentsOutController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Insights.Presentation.Controllers.InsightsController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Statements.ExitStatements.Presentation.Controllers.ExitStatementsController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Statements.AnnualStatements.Presentation.Controllers.AnnualStatementsController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Settings.SchemeManagement.Presentation.Controllers.SchemesController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Settings.InsightManagement.Presentation.Controllers.InsightManagementController).Assembly)
    .AddApplicationPart(typeof(ZWS.Modules.Paycon.Notifications.Presentation.Controllers.NotificationsController).Assembly);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "ZWS API",
        Version = "v1",
        Description = "ZWS modular monolith - Paycon, ZWS Application Hub, Compliance, Trade Insights and PartnerHub APIs (requirement 34)."
    });

    // Same reasoning as ZWS.Master.Host's Program.cs: AddZwsJwtAuthentication's fallback policy
    // now requires a valid Bearer token on every endpoint here too, so Swagger needs a way to
    // attach one. Log in via Master (POST api/auth/login there), then paste that token into
    // "Authorize" below (no "Bearer " prefix needed) to exercise Paycon's own endpoints here.
    var securityScheme = new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Paste the token returned by Master's POST api/auth/login."
    };
    options.AddSecurityDefinition("Bearer", securityScheme);
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            []
        }
    });
});

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
    ?? ["https://localhost:5101", "http://localhost:5100"];

builder.Services.AddCors(options =>
{
    options.AddPolicy("ZwsWebClient", policy => policy
        .WithOrigins(allowedOrigins)
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowCredentials());
});

// ---------------------------------------------------------------------
// MediatR + FluentValidation across every module's assembly (requirement 20)
// ---------------------------------------------------------------------
builder.Services.AddZwsApplicationLayer(
    typeof(ComplianceModule).Assembly,
    typeof(PartnerHubModule).Assembly,
    typeof(TradeInsightsModule).Assembly,
    typeof(PayconNavigationModule).Assembly,
    typeof(DashboardModule).Assembly,
    typeof(PaymentsInModule).Assembly,
    typeof(PaymentsOutModule).Assembly,
    typeof(InsightsModule).Assembly,
    typeof(ExitStatementsModule).Assembly,
    typeof(AnnualStatementsModule).Assembly,
    typeof(SchemeManagementModule).Assembly,
    typeof(InsightManagementModule).Assembly,
    typeof(NotificationsModule).Assembly);

// ---------------------------------------------------------------------
// Modules (requirement 3, 5, 6 - one DbContext per module, wired here only)
// ---------------------------------------------------------------------
// ApplicationHub is no longer wired up here - Master.Host is now the sole owner of the Hub
// landing page (and ZWS.Web's own Hub.razor/ApplicationHubApiClient have been removed to match,
// since Paycon's frontend no longer shows the Hub or calls api/applications at all).
builder.Services.AddComplianceModule(builder.Configuration);
builder.Services.AddPartnerHubModule(builder.Configuration);
builder.Services.AddTradeInsightsModule(builder.Configuration);

builder.Services.AddPayconNavigationModule(builder.Configuration);
builder.Services.AddDashboardModule(builder.Configuration);
builder.Services.AddPaymentsInModule(builder.Configuration);
builder.Services.AddPaymentsOutModule(builder.Configuration);
builder.Services.AddInsightsModule(builder.Configuration);
builder.Services.AddExitStatementsModule(builder.Configuration);
builder.Services.AddAnnualStatementsModule(builder.Configuration);

// UserManagement moved to the Master app (it now lives in Modules/UserManagement, wired up by
// ZWS.Master.Host). SchemeManagement stays here and is called by Master's UserManagement over
// HTTP (see ZWS.Modules.UserManagement.Infrastructure.ExternalServices.SchemeReferenceService) -
// that's exactly the endpoint SchemesController exposes below.
builder.Services.AddSchemeManagementModule(builder.Configuration);
builder.Services.AddInsightManagementModule(builder.Configuration);

// Notifications is deliberately last among Paycon modules: it has no project
// reference to any of them and hears about the system only via RabbitMQ.
builder.Services.AddNotificationsModule(builder.Configuration);

builder.Services.AddZwsHealthChecks(builder.Configuration, primaryConnectionStringName: "Paycon");

var app = builder.Build();

// ---------------------------------------------------------------------
// Pipeline (requirement 32)
// ---------------------------------------------------------------------
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v1/swagger.json", "ZWS API v1"));
}

app.UseCors("ZwsWebClient");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
// Anonymous for now, deliberately scoped out of this pass: PayconRealtimeService's
// HubConnection (ZWS.Web) doesn't attach the JWT as an AccessTokenProvider yet, so requiring
// auth here would silently break the live dashboard/notification updates instead of actually
// securing anything meaningful - every payload this hub pushes is just a "something changed,
// go re-fetch" ping, and the re-fetch itself goes through the now-protected REST endpoints
// below. Wiring a real AccessTokenProvider here is follow-up work, not bundled into this fix.
app.MapHub<PayconHub>("/payconHub").AllowAnonymous();

var healthResponseWriter = new Func<HttpContext, HealthReport, Task>((context, report) =>
{
    context.Response.ContentType = "application/json";
    var payload = new
    {
        status = report.Status.ToString(),
        totalDurationMs = report.TotalDuration.TotalMilliseconds,
        checks = report.Entries.Select(e => new
        {
            name = e.Key,
            status = e.Value.Status.ToString(),
            description = e.Value.Description,
            durationMs = e.Value.Duration.TotalMilliseconds
        })
    };
    return context.Response.WriteAsync(JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }));
});

// Liveness: is the process up at all. Anonymous on purpose - an orchestrator probing this
// never carries a JWT, and AddZwsJwtAuthentication's fallback policy now requires one by default
// on every other endpoint.
app.MapHealthChecks("/health", new HealthCheckOptions
{
    Predicate = _ => false,
    ResponseWriter = healthResponseWriter
}).AllowAnonymous();

// Readiness: SQL / Redis / RabbitMQ actually reachable (requirement 33). Anonymous for the same
// reason as /health above.
app.MapHealthChecks("/health/ready", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = healthResponseWriter
}).AllowAnonymous();

// ---------------------------------------------------------------------
// Deterministic dummy/seed data (requirement 31) - one DbContext at a time,
// each module owning and seeding only its own schema.
// ---------------------------------------------------------------------
// Each Seed{X}ModuleAsync extension opens its own short-lived scope
// internally, so these are called directly against the root provider.
await app.Services.SeedComplianceModuleAsync();
await app.Services.SeedPartnerHubModuleAsync();
await app.Services.SeedTradeInsightsModuleAsync();

await app.Services.SeedPayconNavigationModuleAsync();
await app.Services.SeedSchemeManagementModuleAsync();
await app.Services.SeedDashboardModuleAsync();
await app.Services.SeedPaymentsInModuleAsync();
await app.Services.SeedPaymentsOutModuleAsync();
await app.Services.SeedInsightsModuleAsync();
await app.Services.SeedExitStatementsModuleAsync();
await app.Services.SeedAnnualStatementsModuleAsync();
await app.Services.SeedInsightManagementModuleAsync();
await app.Services.SeedNotificationsModuleAsync();

app.Run();

// Exposed for WebApplicationFactory<Program> in ZWS.IntegrationTests.
public partial class Program;
