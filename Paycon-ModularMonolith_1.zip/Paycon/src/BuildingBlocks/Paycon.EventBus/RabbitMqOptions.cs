namespace Paycon.EventBus;

public class RabbitMqOptions
{
    public const string SectionName = "RabbitMQ";

    public string HostName { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string UserName { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string VirtualHost { get; set; } = "/";
    /// <summary>Single topic exchange shared by every module; routing keys (e.g.
    /// "reconciliation.match.completed") decide which module queues receive an event.</summary>
    public string ExchangeName { get; set; } = "paycon.event-bus";
    /// <summary>Queue name for THIS module, e.g. "paycon.queue.notifications". Each module
    /// process/host instance binds its own durable queue to the routing keys it cares about.</summary>
    public string QueueName { get; set; } = "paycon.queue.default";
    public int RetryCount { get; set; } = 5;
}
