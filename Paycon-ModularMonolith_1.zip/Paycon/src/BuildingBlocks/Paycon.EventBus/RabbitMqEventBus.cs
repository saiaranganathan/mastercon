using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Paycon.EventBus;

/// <summary>
/// Topic-exchange based event bus. One exchange ("paycon.event-bus") is shared by the
/// whole monolith; each module declares its own durable queue and binds only the
/// routing keys it subscribes to, so modules stay decoupled even though they currently
/// run in the same process. This is intentionally the ONLY way modules communicate
/// with each other at runtime (besides going through the Host's HTTP API).
/// </summary>
public sealed class RabbitMqEventBus : IEventBus, IDisposable
{
    private readonly IConnection _connection;
    private readonly IModel _channel;
    private readonly RabbitMqOptions _options;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<RabbitMqEventBus> _logger;
    private readonly ConcurrentDictionary<string, Type> _routingKeyToEventType = new();
    private readonly ConcurrentDictionary<Type, List<Type>> _eventTypeToHandlerTypes = new();

    public RabbitMqEventBus(
        IOptions<RabbitMqOptions> options,
        IServiceProvider serviceProvider,
        ILogger<RabbitMqEventBus> logger)
    {
        _options = options.Value;
        _serviceProvider = serviceProvider;
        _logger = logger;

        var factory = new ConnectionFactory
        {
            HostName = _options.HostName,
            Port = _options.Port,
            UserName = _options.UserName,
            Password = _options.Password,
            VirtualHost = _options.VirtualHost,
            DispatchConsumersAsync = true
        };

        _connection = factory.CreateConnection($"paycon-{_options.QueueName}");
        _channel = _connection.CreateModel();

        _channel.ExchangeDeclare(_options.ExchangeName, ExchangeType.Topic, durable: true);
        _channel.QueueDeclare(_options.QueueName, durable: true, exclusive: false, autoDelete: false);

        var consumer = new AsyncEventingBasicConsumer(_channel);
        consumer.Received += OnMessageReceivedAsync;
        _channel.BasicConsume(_options.QueueName, autoAck: false, consumer);
    }

    public Task PublishAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default) where TEvent : IntegrationEvent
    {
        var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(@event, @event.GetType()));

        var properties = _channel.CreateBasicProperties();
        properties.DeliveryMode = 2; // persistent
        properties.ContentType = "application/json";
        properties.Type = @event.GetType().AssemblyQualifiedName;

        _channel.BasicPublish(_options.ExchangeName, @event.RoutingKey, properties, body);

        _logger.LogInformation("Published integration event {EventType} with routing key {RoutingKey}",
            @event.GetType().Name, @event.RoutingKey);

        return Task.CompletedTask;
    }

    public void Subscribe<TEvent, THandler>()
        where TEvent : IntegrationEvent
        where THandler : IIntegrationEventHandler<TEvent>
    {
        var routingKey = ((TEvent)System.Runtime.Serialization.FormatterServices.GetUninitializedObject(typeof(TEvent))).RoutingKey;

        _channel.QueueBind(_options.QueueName, _options.ExchangeName, routingKey);
        _routingKeyToEventType[routingKey] = typeof(TEvent);

        var handlers = _eventTypeToHandlerTypes.GetOrAdd(typeof(TEvent), _ => new List<Type>());
        handlers.Add(typeof(THandler));

        _logger.LogInformation("Module queue {Queue} subscribed to {RoutingKey} -> {Handler}",
            _options.QueueName, routingKey, typeof(THandler).Name);
    }

    private async Task OnMessageReceivedAsync(object sender, BasicDeliverEventArgs eventArgs)
    {
        var routingKey = eventArgs.RoutingKey;
        try
        {
            if (!_routingKeyToEventType.TryGetValue(routingKey, out var eventType))
            {
                _channel.BasicAck(eventArgs.DeliveryTag, multiple: false);
                return;
            }

            var message = Encoding.UTF8.GetString(eventArgs.Body.Span);
            var @event = JsonSerializer.Deserialize(message, eventType);
            if (@event is null) { _channel.BasicNack(eventArgs.DeliveryTag, false, false); return; }

            using var scope = _serviceProvider.CreateScope();
            if (_eventTypeToHandlerTypes.TryGetValue(eventType, out var handlerTypes))
            {
                foreach (var handlerType in handlerTypes)
                {
                    var handler = scope.ServiceProvider.GetService(handlerType);
                    if (handler is null) continue;
                    var handleMethod = handlerType.GetMethod("Handle");
                    await (Task)handleMethod!.Invoke(handler, new[] { @event, CancellationToken.None })!;
                }
            }

            _channel.BasicAck(eventArgs.DeliveryTag, multiple: false);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing integration event with routing key {RoutingKey}", routingKey);
            _channel.BasicNack(eventArgs.DeliveryTag, multiple: false, requeue: true);
        }
    }

    public void Dispose()
    {
        _channel?.Close();
        _connection?.Close();
    }
}
