namespace Paycon.EventBus;

public interface IEventBus
{
    Task PublishAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default) where TEvent : IntegrationEvent;

    /// <summary>Registers a handler for a routing key on this module's queue. Called once per
    /// module at startup for every integration event the module subscribes to.</summary>
    void Subscribe<TEvent, THandler>()
        where TEvent : IntegrationEvent
        where THandler : IIntegrationEventHandler<TEvent>;
}
