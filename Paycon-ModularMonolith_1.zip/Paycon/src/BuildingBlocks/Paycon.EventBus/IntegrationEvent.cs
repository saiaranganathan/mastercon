namespace Paycon.EventBus;

/// <summary>
/// Base type for events that cross module boundaries over RabbitMQ. Unlike an
/// IDomainEvent (in-process, MediatR, single module), an IntegrationEvent is
/// serialized and published on the bus so other modules (or other services in the
/// future, if a module is ever split out of the monolith) can subscribe independently.
/// </summary>
public abstract record IntegrationEvent
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
    /// <summary>RabbitMQ routing key, e.g. "reconciliation.match.completed".</summary>
    public abstract string RoutingKey { get; }
}
