namespace Paycon.SharedKernel;

/// <summary>
/// Marker for the root entity of an aggregate. Only aggregate roots may be referenced
/// across module boundaries - and even then only via an integration event or a read
/// model, never a direct foreign key into another module's schema/DbContext.
/// </summary>
public abstract class AggregateRoot<TId> : Entity<TId> where TId : notnull
{
}
