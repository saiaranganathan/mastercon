using MediatR;

namespace Paycon.SharedKernel;

/// <summary>
/// Raised and handled INSIDE a single module, in-process, via MediatR's INotification
/// pipeline. If another module needs to react, publish an IntegrationEvent
/// (see Paycon.EventBus) over RabbitMQ instead - domain events never cross modules.
/// </summary>
public interface IDomainEvent : INotification
{
    DateTime OccurredOnUtc { get; }
}
