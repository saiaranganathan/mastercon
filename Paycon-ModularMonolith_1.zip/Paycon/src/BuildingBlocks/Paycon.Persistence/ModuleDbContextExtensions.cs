using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Paycon.Persistence;

/// <summary>
/// Single place every module's Api project goes through to register its own DbContext.
/// Reads one flag - "Infrastructure:UseInMemory" - and switches the WHOLE monolith (all six
/// module schemas at once) between:
///
///   - Azure SQL / SQL Server (production, and any local run against a real database)
///   - EF Core's InMemory provider (zero external dependencies - no Docker, no SQL
///     Server, no connection string needed at all; every module's schema, as defined
///     by its own OnModelCreating, still applies - only relational-only concerns like
///     HasDefaultSchema and column types are silently ignored by the InMemory provider)
///
/// This keeps the DbContext-per-module rule intact: each module still owns exactly one
/// DbContext and calls this once, with its own connection-string key and schema name.
/// </summary>
public static class ModuleDbContextExtensions
{
    public static IServiceCollection AddModuleDbContext<TContext>(
        this IServiceCollection services,
        IConfiguration configuration,
        string connectionStringKey,
        string schemaName)
        where TContext : DbContext
    {
        var useInMemory = configuration.GetValue<bool>("Infrastructure:UseInMemory");

        services.AddDbContext<TContext>(options =>
        {
            if (useInMemory)
            {
                // One named in-memory database per module keeps their data isolated from
                // each other, mirroring the schema isolation used against real SQL Server.
                options.UseInMemoryDatabase($"paycon-{schemaName}");
            }
            else
            {
                var connectionString = configuration.GetConnectionString(connectionStringKey)
                    ?? configuration.GetConnectionString("DefaultConnection")
                    ?? throw new InvalidOperationException(
                        $"No connection string configured for '{connectionStringKey}' (and no ConnectionStrings:DefaultConnection fallback). " +
                        "Either provide one, or set Infrastructure:UseInMemory = true to run without a real database.");

                options.UseSqlServer(connectionString, sql =>
                    sql.MigrationsHistoryTable("__EFMigrationsHistory", schemaName));
            }
        });

        return services;
    }
}
