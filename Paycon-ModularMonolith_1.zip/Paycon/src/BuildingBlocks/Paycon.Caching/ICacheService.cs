namespace Paycon.Caching;

/// <summary>
/// Thin abstraction over Azure Cache for Redis so modules never take a dependency
/// on StackExchange.Redis directly. Every module shares the same Redis instance but
/// MUST prefix keys with its own module name (see CacheKeyPrefix) to avoid collisions -
/// this is a convention, not a hard partition, so discipline matters here.
/// </summary>
public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
    Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
}
