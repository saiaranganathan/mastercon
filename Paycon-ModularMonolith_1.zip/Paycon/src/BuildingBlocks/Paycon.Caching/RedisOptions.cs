namespace Paycon.Caching;

public class RedisOptions
{
    public const string SectionName = "Redis";

    /// <summary>Azure Cache for Redis connection string, e.g.
    /// "paycon-cache.redis.cache.windows.net:6380,password=...,ssl=True,abortConnect=False".</summary>
    public string ConnectionString { get; set; } = "localhost:6379";
    public int DefaultAbsoluteExpirationMinutes { get; set; } = 30;
}
