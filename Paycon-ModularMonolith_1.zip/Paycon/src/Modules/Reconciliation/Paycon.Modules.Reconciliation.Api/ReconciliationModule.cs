using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Domain.Entities;
using Paycon.Modules.Reconciliation.Domain.Enums;
using Paycon.Modules.Reconciliation.Infrastructure.Persistence;
using Paycon.Modules.Reconciliation.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Api;

public class ReconciliationModule : IModule
{
    public string Name => "Reconciliation";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<ReconciliationDbContext>(configuration, "ReconciliationDb", ReconciliationDbContext.Schema);

        services.AddScoped<IReconciliationRepository, ReconciliationRepository>();

        // IReconciliationNotifier is implemented in the Host (it owns the SignalR hub) and
        // registered there; this module only depends on the abstraction.

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(
            typeof(Application.Batches.Commands.RunReconciliation.RunReconciliationCommand).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        Endpoints.ReconciliationEndpoints.Map(endpoints);
        return endpoints;
    }

    /// <summary>Demo batch + a few matched/mismatched transactions so the Reconciliation
    /// screens have something to show on first run against the in-memory database.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ReconciliationDbContext>();
        if (await db.Batches.AnyAsync()) return;

        var batch = ReconciliationBatch.Create("SCB_DEWS_20260117.csv", "DEWS");
        db.Batches.Add(batch);

        var matched = PaymentTransaction.Create(batch.Id, PaymentDirection.In, "TXN-1001", 125_000m, "AED", DateTime.UtcNow.AddDays(-1));
        matched.MarkMatched("CPTY-1001");

        var mismatched = PaymentTransaction.Create(batch.Id, PaymentDirection.In, "TXN-1002", 48_500m, "AED", DateTime.UtcNow.AddDays(-1));
        mismatched.MarkMismatched("Amount exceeds tolerance limit for scheme DEWS.");

        db.Transactions.AddRange(matched, mismatched);
        batch.CompleteReconciliation(matchedCount: 1, mismatchedCount: 1);
        batch.ClearDomainEvents(); // seeding shouldn't fan out real notifications/integration events

        await db.SaveChangesAsync();
    }
}
