using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Paycon.Modules.Reconciliation.Application.Batches.Commands.RunReconciliation;
using Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMatches;
using Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMismatches;

namespace Paycon.Modules.Reconciliation.Api.Endpoints;

public static class ReconciliationEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/reconciliation").WithTags("Reconciliation");

        group.MapGet("/matches", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetMatchesQuery(), ct)));

        group.MapGet("/mismatches", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetMismatchesQuery(), ct)));

        group.MapPost("/batches/{batchId:guid}/run", async (Guid batchId, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new RunReconciliationCommand(batchId), ct)));
    }
}
