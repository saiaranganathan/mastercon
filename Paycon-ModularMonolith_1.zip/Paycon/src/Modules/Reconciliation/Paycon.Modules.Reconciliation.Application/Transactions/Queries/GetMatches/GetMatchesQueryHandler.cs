using MediatR;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Domain.Enums;

namespace Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMatches;

public class GetMatchesQueryHandler : IRequestHandler<GetMatchesQuery, IReadOnlyList<TransactionDto>>
{
    private readonly IReconciliationRepository _repository;
    public GetMatchesQueryHandler(IReconciliationRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<TransactionDto>> Handle(GetMatchesQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetByStatusAsync(MatchStatus.Matched, cancellationToken);
        return items.Select(t => new TransactionDto(t.Id, t.BatchId, t.Direction.ToString(), t.Reference, t.Amount, t.CurrencyCode, t.ValueDateUtc, t.Status.ToString())).ToList();
    }
}
