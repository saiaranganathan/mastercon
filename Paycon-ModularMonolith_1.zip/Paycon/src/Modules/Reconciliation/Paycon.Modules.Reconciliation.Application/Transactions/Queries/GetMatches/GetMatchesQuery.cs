using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMatches;

public record TransactionDto(Guid Id, Guid BatchId, string Direction, string Reference, decimal Amount, string CurrencyCode, DateTime ValueDateUtc, string Status);

public record GetMatchesQuery : IRequest<IReadOnlyList<TransactionDto>>, ICacheableQuery
{
    public string CacheKey => "reconciliation:matches";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(1);
}
