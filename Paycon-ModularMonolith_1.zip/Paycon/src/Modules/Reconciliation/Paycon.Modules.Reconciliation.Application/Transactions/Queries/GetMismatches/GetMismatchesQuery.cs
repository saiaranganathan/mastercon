using MediatR;
using Paycon.Behaviors;
using Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMatches;

namespace Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMismatches;

public record GetMismatchesQuery : IRequest<IReadOnlyList<TransactionDto>>, ICacheableQuery
{
    public string CacheKey => "reconciliation:mismatches";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(1);
}
