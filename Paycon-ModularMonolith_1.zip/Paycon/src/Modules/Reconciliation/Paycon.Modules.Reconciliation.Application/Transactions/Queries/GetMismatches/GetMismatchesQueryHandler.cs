using MediatR;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMatches;
using Paycon.Modules.Reconciliation.Domain.Enums;

namespace Paycon.Modules.Reconciliation.Application.Transactions.Queries.GetMismatches;

public class GetMismatchesQueryHandler : IRequestHandler<GetMismatchesQuery, IReadOnlyList<TransactionDto>>
{
    private readonly IReconciliationRepository _repository;
    public GetMismatchesQueryHandler(IReconciliationRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<TransactionDto>> Handle(GetMismatchesQuery request, CancellationToken cancellationToken)
    {
        var items = await _repository.GetByStatusAsync(MatchStatus.Mismatched, cancellationToken);
        return items.Select(t => new TransactionDto(t.Id, t.BatchId, t.Direction.ToString(), t.Reference, t.Amount, t.CurrencyCode, t.ValueDateUtc, t.Status.ToString())).ToList();
    }
}
