using Paycon.Modules.Reconciliation.Domain.Entities;
using Paycon.Modules.Reconciliation.Domain.Enums;

namespace Paycon.Modules.Reconciliation.Application.Abstractions;

public interface IReconciliationRepository
{
    Task<ReconciliationBatch?> GetBatchAsync(Guid batchId, CancellationToken cancellationToken);
    Task AddBatchAsync(ReconciliationBatch batch, CancellationToken cancellationToken);
    Task<IReadOnlyList<PaymentTransaction>> GetByBatchAsync(Guid batchId, CancellationToken cancellationToken);
    Task<IReadOnlyList<PaymentTransaction>> GetByStatusAsync(MatchStatus status, CancellationToken cancellationToken);
    Task AddTransactionsAsync(IEnumerable<PaymentTransaction> transactions, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}

/// <summary>Pushes live progress to connected Blazor clients. Implemented in the Host
/// (which owns the SignalR hub) and injected into this module via DI - the module itself
/// has no dependency on ASP.NET Core SignalR packages, only on this thin interface.</summary>
public interface IReconciliationNotifier
{
    Task NotifyBatchCompletedAsync(Guid batchId, int matchedCount, int mismatchedCount, CancellationToken cancellationToken);
}
