using Paycon.EventBus;

namespace Paycon.Modules.Reconciliation.Application.IntegrationEvents;

/// <summary>Published so Notifications can raise "Reconciliation Completed" (seen on the
/// dashboard's Notifications panel) and Insights can refresh payout eligibility.</summary>
public record ReconciliationCompletedIntegrationEvent(Guid BatchId, int MatchedCount, int MismatchedCount) : IntegrationEvent
{
    public override string RoutingKey => "reconciliation.batch.completed";
}
