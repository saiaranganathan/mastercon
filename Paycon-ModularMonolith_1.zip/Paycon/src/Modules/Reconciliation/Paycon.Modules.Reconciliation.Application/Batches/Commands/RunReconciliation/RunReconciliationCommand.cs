using MediatR;

namespace Paycon.Modules.Reconciliation.Application.Batches.Commands.RunReconciliation;

public record RunReconciliationCommand(Guid BatchId) : IRequest<ReconciliationResultDto>;

public record ReconciliationResultDto(Guid BatchId, int MatchedCount, int MismatchedCount);
