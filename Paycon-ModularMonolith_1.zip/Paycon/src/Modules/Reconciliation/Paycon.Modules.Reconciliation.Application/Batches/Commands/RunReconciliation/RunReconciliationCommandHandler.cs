using MediatR;
using Paycon.EventBus;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Application.IntegrationEvents;
using Paycon.Modules.Reconciliation.Domain.Enums;

namespace Paycon.Modules.Reconciliation.Application.Batches.Commands.RunReconciliation;

/// <summary>Matches a batch's transactions against counterparty records. The actual
/// matching algorithm (tolerance limits, exchange-rate normalisation, etc.) reads
/// SchemeManagement master data through that module's own API/read model - never a
/// direct join across DbContexts.</summary>
public class RunReconciliationCommandHandler : IRequestHandler<RunReconciliationCommand, ReconciliationResultDto>
{
    private readonly IReconciliationRepository _repository;
    private readonly IReconciliationNotifier _notifier;
    private readonly IEventBus _eventBus;

    public RunReconciliationCommandHandler(IReconciliationRepository repository, IReconciliationNotifier notifier, IEventBus eventBus)
    {
        _repository = repository;
        _notifier = notifier;
        _eventBus = eventBus;
    }

    public async Task<ReconciliationResultDto> Handle(RunReconciliationCommand request, CancellationToken cancellationToken)
    {
        var batch = await _repository.GetBatchAsync(request.BatchId, cancellationToken)
            ?? throw new KeyNotFoundException($"Reconciliation batch {request.BatchId} not found.");

        var transactions = await _repository.GetByBatchAsync(request.BatchId, cancellationToken);

        // Placeholder matching rule - replace with real tolerance/exchange-rate aware logic.
        var matched = 0;
        var mismatched = 0;
        foreach (var tx in transactions)
        {
            if (tx.Amount > 0)
            {
                tx.MarkMatched(tx.Reference);
                matched++;
            }
            else
            {
                tx.MarkMismatched("Amount could not be verified against counterparty record.");
                mismatched++;
            }
        }

        batch.CompleteReconciliation(matched, mismatched);
        await _repository.SaveChangesAsync(cancellationToken);

        // Real-time push to any Blazor client subscribed to this batch/dashboard via SignalR.
        await _notifier.NotifyBatchCompletedAsync(batch.Id, matched, mismatched, cancellationToken);

        // Cross-module notification over RabbitMQ.
        await _eventBus.PublishAsync(new ReconciliationCompletedIntegrationEvent(batch.Id, matched, mismatched), cancellationToken);

        return new ReconciliationResultDto(batch.Id, matched, mismatched);
    }
}
