using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Reconciliation.Application.Abstractions;
using Paycon.Modules.Reconciliation.Domain.Entities;
using Paycon.Modules.Reconciliation.Domain.Enums;

namespace Paycon.Modules.Reconciliation.Infrastructure.Persistence.Repositories;

public class ReconciliationRepository : IReconciliationRepository
{
    private readonly ReconciliationDbContext _db;
    public ReconciliationRepository(ReconciliationDbContext db) => _db = db;

    public Task<ReconciliationBatch?> GetBatchAsync(Guid batchId, CancellationToken cancellationToken) =>
        _db.Batches.FirstOrDefaultAsync(b => b.Id == batchId, cancellationToken);

    public Task AddBatchAsync(ReconciliationBatch batch, CancellationToken cancellationToken)
    {
        _db.Batches.Add(batch);
        return Task.CompletedTask;
    }

    public async Task<IReadOnlyList<PaymentTransaction>> GetByBatchAsync(Guid batchId, CancellationToken cancellationToken) =>
        await _db.Transactions.Where(t => t.BatchId == batchId).ToListAsync(cancellationToken);

    public async Task<IReadOnlyList<PaymentTransaction>> GetByStatusAsync(MatchStatus status, CancellationToken cancellationToken) =>
        await _db.Transactions.AsNoTracking().Where(t => t.Status == status).ToListAsync(cancellationToken);

    public Task AddTransactionsAsync(IEnumerable<PaymentTransaction> transactions, CancellationToken cancellationToken)
    {
        _db.Transactions.AddRange(transactions);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
