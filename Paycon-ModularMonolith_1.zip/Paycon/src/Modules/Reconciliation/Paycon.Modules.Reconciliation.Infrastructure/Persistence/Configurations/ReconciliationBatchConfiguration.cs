using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Reconciliation.Domain.Entities;

namespace Paycon.Modules.Reconciliation.Infrastructure.Persistence.Configurations;

public class ReconciliationBatchConfiguration : IEntityTypeConfiguration<ReconciliationBatch>
{
    public void Configure(EntityTypeBuilder<ReconciliationBatch> builder)
    {
        builder.ToTable("ReconciliationBatches", ReconciliationDbContext.Schema);
        builder.HasKey(b => b.Id);
        builder.Property(b => b.FileName).HasMaxLength(260).IsRequired();
        builder.Property(b => b.SourceSystem).HasMaxLength(50).IsRequired();
        builder.Ignore(b => b.DomainEvents);
    }
}
