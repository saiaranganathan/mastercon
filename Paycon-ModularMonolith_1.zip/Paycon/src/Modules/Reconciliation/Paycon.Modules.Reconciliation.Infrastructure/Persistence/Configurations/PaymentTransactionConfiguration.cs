using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Reconciliation.Domain.Entities;

namespace Paycon.Modules.Reconciliation.Infrastructure.Persistence.Configurations;

public class PaymentTransactionConfiguration : IEntityTypeConfiguration<PaymentTransaction>
{
    public void Configure(EntityTypeBuilder<PaymentTransaction> builder)
    {
        builder.ToTable("PaymentTransactions", ReconciliationDbContext.Schema);
        builder.HasKey(t => t.Id);
        builder.HasIndex(t => t.BatchId);
        builder.Property(t => t.Direction).HasConversion<string>().HasMaxLength(10);
        builder.Property(t => t.Reference).HasMaxLength(100).IsRequired();
        builder.Property(t => t.Amount).HasColumnType("decimal(18,2)");
        builder.Property(t => t.CurrencyCode).HasMaxLength(3);
        builder.Property(t => t.Status).HasConversion<string>().HasMaxLength(20);
        builder.Property(t => t.MismatchReason).HasMaxLength(500);
        builder.Ignore(t => t.DomainEvents);
    }
}
