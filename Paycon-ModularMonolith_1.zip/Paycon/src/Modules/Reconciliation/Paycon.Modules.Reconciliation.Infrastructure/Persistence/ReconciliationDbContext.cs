using MediatR;
using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Reconciliation.Domain.Entities;
using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Infrastructure.Persistence;

/// <summary>This module's own DbContext, mapped to the "reconciliation" schema. Same
/// DbContext-per-module pattern as Identity: nobody outside this module resolves it.</summary>
public class ReconciliationDbContext : DbContext
{
    public const string Schema = "reconciliation";

    private readonly IPublisher? _publisher;

    public ReconciliationDbContext(DbContextOptions<ReconciliationDbContext> options, IPublisher? publisher = null) : base(options)
    {
        _publisher = publisher;
    }

    public DbSet<ReconciliationBatch> Batches => Set<ReconciliationBatch>();
    public DbSet<PaymentTransaction> Transactions => Set<PaymentTransaction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ReconciliationDbContext).Assembly);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var entitiesWithEvents = ChangeTracker.Entries<Entity<Guid>>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Count != 0)
            .ToList();

        var result = await base.SaveChangesAsync(cancellationToken);

        if (_publisher is not null)
        {
            foreach (var entity in entitiesWithEvents)
            {
                var events = entity.DomainEvents.ToList();
                entity.ClearDomainEvents();
                foreach (var domainEvent in events)
                    await _publisher.Publish(domainEvent, cancellationToken);
            }
        }

        return result;
    }
}
