using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Domain.Events;

public record ReconciliationMatchCompletedDomainEvent(Guid BatchId, int MatchedCount, int MismatchedCount) : IDomainEvent
{
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
}
