namespace Paycon.Modules.Reconciliation.Domain.Enums;

public enum MatchStatus { Pending, Matched, Mismatched, Processed, UnderReview }
public enum PaymentDirection { In, Out }
