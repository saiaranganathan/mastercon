using Paycon.Modules.Reconciliation.Domain.Enums;
using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Domain.Entities;

/// <summary>A single line from an uploaded bank/contribution file, awaiting or resolved
/// by reconciliation against internal records (Payments In / Payments Out screens).</summary>
public class PaymentTransaction : AggregateRoot<Guid>
{
    public Guid BatchId { get; private set; }
    public PaymentDirection Direction { get; private set; }
    public string Reference { get; private set; } = default!;
    public decimal Amount { get; private set; }
    public string CurrencyCode { get; private set; } = "AED";
    public DateTime ValueDateUtc { get; private set; }
    public MatchStatus Status { get; private set; } = MatchStatus.Pending;
    public string? CounterpartyReference { get; private set; }
    public string? MismatchReason { get; private set; }

    private PaymentTransaction() { }

    public static PaymentTransaction Create(Guid batchId, PaymentDirection direction, string reference, decimal amount, string currencyCode, DateTime valueDateUtc) =>
        new()
        {
            Id = Guid.NewGuid(),
            BatchId = batchId,
            Direction = direction,
            Reference = reference,
            Amount = amount,
            CurrencyCode = currencyCode,
            ValueDateUtc = valueDateUtc,
            Status = MatchStatus.Pending
        };

    public void MarkMatched(string counterpartyReference)
    {
        Status = MatchStatus.Matched;
        CounterpartyReference = counterpartyReference;
        MismatchReason = null;
    }

    public void MarkMismatched(string reason)
    {
        Status = MatchStatus.Mismatched;
        MismatchReason = reason;
    }
}
