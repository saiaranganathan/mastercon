using Paycon.Modules.Reconciliation.Domain.Events;
using Paycon.SharedKernel;

namespace Paycon.Modules.Reconciliation.Domain.Entities;

/// <summary>One uploaded-file run, e.g. "SCB File - DEWS" from the Quick Actions panel.</summary>
public class ReconciliationBatch : AggregateRoot<Guid>
{
    public string FileName { get; private set; } = default!;
    public string SourceSystem { get; private set; } = default!; // e.g. DEWS, DAMAN
    public DateTime UploadedAtUtc { get; private set; }
    public int MatchedCount { get; private set; }
    public int MismatchedCount { get; private set; }
    public bool IsComplete { get; private set; }

    private ReconciliationBatch() { }

    public static ReconciliationBatch Create(string fileName, string sourceSystem) =>
        new()
        {
            Id = Guid.NewGuid(),
            FileName = fileName,
            SourceSystem = sourceSystem,
            UploadedAtUtc = DateTime.UtcNow
        };

    public void CompleteReconciliation(int matchedCount, int mismatchedCount)
    {
        MatchedCount = matchedCount;
        MismatchedCount = mismatchedCount;
        IsComplete = true;
        Raise(new ReconciliationMatchCompletedDomainEvent(Id, matchedCount, mismatchedCount));
    }
}
