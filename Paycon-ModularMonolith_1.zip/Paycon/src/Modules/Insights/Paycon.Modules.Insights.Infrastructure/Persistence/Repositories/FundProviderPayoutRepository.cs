using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Insights.Application.Abstractions;
using Paycon.Modules.Insights.Domain.Entities;
using Paycon.Modules.Insights.Domain.Enums;

namespace Paycon.Modules.Insights.Infrastructure.Persistence.Repositories;

public class FundProviderPayoutRepository : IFundProviderPayoutRepository
{
    private readonly InsightsDbContext _db;
    public FundProviderPayoutRepository(InsightsDbContext db) => _db = db;

    public async Task<IReadOnlyList<FundProviderPayout>> GetByStatusAsync(PayoutStatus status, CancellationToken cancellationToken) =>
        await _db.Payouts.Where(p => p.Status == status).ToListAsync(cancellationToken);

    public Task<FundProviderPayout?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Payouts.FirstOrDefaultAsync(p => p.Id == id, cancellationToken);

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
