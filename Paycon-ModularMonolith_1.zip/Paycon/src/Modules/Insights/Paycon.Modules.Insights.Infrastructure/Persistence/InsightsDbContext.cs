using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Insights.Domain.Entities;

namespace Paycon.Modules.Insights.Infrastructure.Persistence;

/// <summary>This module's own DbContext ("insights" schema): Fund Provider Management,
/// Fund Provider Payout (DEWS/DAMAN) and the Approval Queue.</summary>
public class InsightsDbContext : DbContext
{
    public const string Schema = "insights";

    public InsightsDbContext(DbContextOptions<InsightsDbContext> options) : base(options) { }

    public DbSet<FundProvider> FundProviders => Set<FundProvider>();
    public DbSet<FundProviderPayout> Payouts => Set<FundProviderPayout>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(InsightsDbContext).Assembly);
    }
}
