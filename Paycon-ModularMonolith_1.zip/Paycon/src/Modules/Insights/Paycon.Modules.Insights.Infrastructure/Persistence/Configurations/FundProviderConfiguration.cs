using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Insights.Domain.Entities;

namespace Paycon.Modules.Insights.Infrastructure.Persistence.Configurations;

public class FundProviderConfiguration : IEntityTypeConfiguration<FundProvider>
{
    public void Configure(EntityTypeBuilder<FundProvider> builder)
    {
        builder.ToTable("FundProviders", InsightsDbContext.Schema);
        builder.HasKey(f => f.Id);
        builder.Property(f => f.Code).HasMaxLength(50).IsRequired();
        builder.HasIndex(f => f.Code).IsUnique();
        builder.Property(f => f.Name).HasMaxLength(200).IsRequired();
        builder.Ignore(f => f.DomainEvents);
    }
}
