using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Insights.Domain.Entities;

namespace Paycon.Modules.Insights.Infrastructure.Persistence.Configurations;

public class FundProviderPayoutConfiguration : IEntityTypeConfiguration<FundProviderPayout>
{
    public void Configure(EntityTypeBuilder<FundProviderPayout> builder)
    {
        builder.ToTable("FundProviderPayouts", InsightsDbContext.Schema);
        builder.HasKey(p => p.Id);
        builder.HasIndex(p => p.FundProviderId);
        builder.Property(p => p.Amount).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Status).HasConversion<string>().HasMaxLength(30);
        builder.Ignore(p => p.DomainEvents);
    }
}
