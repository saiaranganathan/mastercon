using MediatR;
using Paycon.Modules.Insights.Application.Abstractions;

namespace Paycon.Modules.Insights.Application.Payouts.Commands.ApprovePayout;

public class ApprovePayoutCommandHandler : IRequestHandler<ApprovePayoutCommand>
{
    private readonly IFundProviderPayoutRepository _repository;
    public ApprovePayoutCommandHandler(IFundProviderPayoutRepository repository) => _repository = repository;

    public async Task Handle(ApprovePayoutCommand request, CancellationToken cancellationToken)
    {
        var payout = await _repository.GetByIdAsync(request.PayoutId, cancellationToken)
            ?? throw new KeyNotFoundException($"Payout {request.PayoutId} not found.");
        payout.Approve();
        await _repository.SaveChangesAsync(cancellationToken);
    }
}
