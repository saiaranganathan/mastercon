using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Insights.Application.Payouts.Commands.ApprovePayout;

public record ApprovePayoutCommand(Guid PayoutId) : IRequest, ICacheInvalidatingCommand
{
    public IEnumerable<string> CacheKeysToInvalidate => new[] { "insights:approval-queue" };
}
