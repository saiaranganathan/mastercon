using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Insights.Application.Payouts.Queries.GetApprovalQueue;

public record PayoutDto(Guid Id, Guid FundProviderId, decimal Amount, string Status, DateTime CreatedAtUtc);

public record GetApprovalQueueQuery : IRequest<IReadOnlyList<PayoutDto>>, ICacheableQuery
{
    public string CacheKey => "insights:approval-queue";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(1);
}
