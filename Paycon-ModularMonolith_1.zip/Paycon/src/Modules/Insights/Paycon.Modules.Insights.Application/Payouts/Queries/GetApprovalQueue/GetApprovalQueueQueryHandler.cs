using MediatR;
using Paycon.Modules.Insights.Application.Abstractions;
using Paycon.Modules.Insights.Domain.Enums;

namespace Paycon.Modules.Insights.Application.Payouts.Queries.GetApprovalQueue;

public class GetApprovalQueueQueryHandler : IRequestHandler<GetApprovalQueueQuery, IReadOnlyList<PayoutDto>>
{
    private readonly IFundProviderPayoutRepository _repository;
    public GetApprovalQueueQueryHandler(IFundProviderPayoutRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<PayoutDto>> Handle(GetApprovalQueueQuery request, CancellationToken cancellationToken)
    {
        var payouts = await _repository.GetByStatusAsync(PayoutStatus.PendingApproval, cancellationToken);
        return payouts.Select(p => new PayoutDto(p.Id, p.FundProviderId, p.Amount, p.Status.ToString(), p.CreatedAtUtc)).ToList();
    }
}
