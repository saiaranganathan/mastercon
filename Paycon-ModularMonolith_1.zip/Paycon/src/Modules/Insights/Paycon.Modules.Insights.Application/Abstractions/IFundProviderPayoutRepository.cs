using Paycon.Modules.Insights.Domain.Entities;
using Paycon.Modules.Insights.Domain.Enums;

namespace Paycon.Modules.Insights.Application.Abstractions;

public interface IFundProviderPayoutRepository
{
    Task<IReadOnlyList<FundProviderPayout>> GetByStatusAsync(PayoutStatus status, CancellationToken cancellationToken);
    Task<FundProviderPayout?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
