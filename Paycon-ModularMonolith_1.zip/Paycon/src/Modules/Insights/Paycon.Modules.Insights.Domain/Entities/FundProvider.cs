using Paycon.SharedKernel;

namespace Paycon.Modules.Insights.Domain.Entities;

/// <summary>Backs "Fund Provider Management" - e.g. DEWS, DAMAN.</summary>
public class FundProvider : AggregateRoot<Guid>
{
    public string Code { get; private set; } = default!;
    public string Name { get; private set; } = default!;
    public bool IsActive { get; private set; } = true;

    private FundProvider() { }

    public static FundProvider Create(string code, string name) =>
        new() { Id = Guid.NewGuid(), Code = code, Name = name };
}
