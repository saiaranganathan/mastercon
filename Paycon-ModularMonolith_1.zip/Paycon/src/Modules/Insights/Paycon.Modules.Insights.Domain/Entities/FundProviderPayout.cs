using Paycon.Modules.Insights.Domain.Enums;
using Paycon.SharedKernel;

namespace Paycon.Modules.Insights.Domain.Entities;

/// <summary>Backs the "Insights - Fund Provider Payout DEWS/DAMAN" and
/// "Insights - Approval Queue" screens.</summary>
public class FundProviderPayout : AggregateRoot<Guid>
{
    public Guid FundProviderId { get; private set; }
    public decimal Amount { get; private set; }
    public PayoutStatus Status { get; private set; } = PayoutStatus.PendingApproval;
    public DateTime CreatedAtUtc { get; private set; } = DateTime.UtcNow;

    private FundProviderPayout() { }

    public static FundProviderPayout Create(Guid fundProviderId, decimal amount) =>
        new() { Id = Guid.NewGuid(), FundProviderId = fundProviderId, Amount = amount };

    public void Approve() => Status = PayoutStatus.ReadyForPayment;
    public void Reject() => Status = PayoutStatus.Rejected;
    public void MarkPaid() => Status = PayoutStatus.Paid;
}
