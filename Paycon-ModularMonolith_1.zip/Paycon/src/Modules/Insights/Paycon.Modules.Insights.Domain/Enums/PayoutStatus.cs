namespace Paycon.Modules.Insights.Domain.Enums;

public enum PayoutStatus { PendingApproval, ReadyForPayment, Processing, Paid, Rejected }
