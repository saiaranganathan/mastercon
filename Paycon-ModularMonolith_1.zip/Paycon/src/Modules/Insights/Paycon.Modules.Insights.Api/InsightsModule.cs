using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Insights.Application.Abstractions;
using Paycon.Modules.Insights.Application.Payouts.Commands.ApprovePayout;
using Paycon.Modules.Insights.Application.Payouts.Queries.GetApprovalQueue;
using Paycon.Modules.Insights.Domain.Entities;
using Paycon.Modules.Insights.Infrastructure.Persistence;
using Paycon.Modules.Insights.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.Insights.Api;

public class InsightsModule : IModule
{
    public string Name => "Insights";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<InsightsDbContext>(configuration, "InsightsDb", InsightsDbContext.Schema);

        services.AddScoped<IFundProviderPayoutRepository, FundProviderPayoutRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetApprovalQueueQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/insights").WithTags("Insights");

        group.MapGet("/approval-queue", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetApprovalQueueQuery(), ct)));

        group.MapPost("/payouts/{id:guid}/approve", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            await sender.Send(new ApprovePayoutCommand(id), ct);
            return Results.NoContent();
        });

        return endpoints;
    }

    /// <summary>Demo fund providers (DEWS, DAMAN) with a pending payout each, so the
    /// Approval Queue screen isn't empty on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<InsightsDbContext>();
        if (await db.FundProviders.AnyAsync()) return;

        var dews = FundProvider.Create("DEWS", "DIFC Employee Workplace Savings");
        var daman = FundProvider.Create("DAMAN", "National Health Insurance Company - DAMAN");
        db.FundProviders.AddRange(dews, daman);

        db.Payouts.AddRange(
            FundProviderPayout.Create(dews.Id, 182_400m),
            FundProviderPayout.Create(daman.Id, 64_950m));

        await db.SaveChangesAsync();
    }
}
