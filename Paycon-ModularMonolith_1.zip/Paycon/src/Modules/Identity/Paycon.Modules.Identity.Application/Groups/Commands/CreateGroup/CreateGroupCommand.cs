using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Groups.Commands.CreateGroup;

public record CreateGroupCommand(string Name, string? Description) : IRequest<Guid>, ICacheInvalidatingCommand
{
    public IEnumerable<string> CacheKeysToInvalidate => new[] { "identity:groups:all" };
}
