using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Groups.Commands.CreateGroup;

public class CreateGroupCommandHandler : IRequestHandler<CreateGroupCommand, Guid>
{
    private readonly IGroupRepository _groups;
    public CreateGroupCommandHandler(IGroupRepository groups) => _groups = groups;

    public async Task<Guid> Handle(CreateGroupCommand request, CancellationToken cancellationToken)
    {
        var group = Group.Create(request.Name, request.Description);
        await _groups.AddAsync(group, cancellationToken);
        await _groups.SaveChangesAsync(cancellationToken);
        return group.Id;
    }
}
