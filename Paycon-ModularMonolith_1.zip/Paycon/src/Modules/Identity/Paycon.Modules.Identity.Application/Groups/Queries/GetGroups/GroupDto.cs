namespace Paycon.Modules.Identity.Application.Groups.Queries.GetGroups;

public record GroupDto(Guid Id, string Name, string? Description);
