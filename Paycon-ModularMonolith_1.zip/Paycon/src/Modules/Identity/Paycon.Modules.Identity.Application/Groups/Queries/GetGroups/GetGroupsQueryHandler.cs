using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;

namespace Paycon.Modules.Identity.Application.Groups.Queries.GetGroups;

public class GetGroupsQueryHandler : IRequestHandler<GetGroupsQuery, IReadOnlyList<GroupDto>>
{
    private readonly IGroupRepository _groups;
    public GetGroupsQueryHandler(IGroupRepository groups) => _groups = groups;

    public async Task<IReadOnlyList<GroupDto>> Handle(GetGroupsQuery request, CancellationToken cancellationToken)
    {
        var groups = await _groups.GetAllAsync(cancellationToken);
        return groups.Select(g => new GroupDto(g.Id, g.Name, g.Description)).ToList();
    }
}
