using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Groups.Queries.GetGroups;

public record GetGroupsQuery : IRequest<IReadOnlyList<GroupDto>>, ICacheableQuery
{
    public string CacheKey => "identity:groups:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
