using Paycon.EventBus;

namespace Paycon.Modules.Identity.Application.IntegrationEvents;

/// <summary>Published on RabbitMQ after a user is created so other modules (e.g.
/// Notifications, for a welcome email) can react without a direct reference to Identity.</summary>
public record UserProvisionedIntegrationEvent(Guid UserId, string Email, string FullName) : IntegrationEvent
{
    public override string RoutingKey => "identity.user.provisioned";
}
