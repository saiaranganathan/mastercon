using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

namespace Paycon.Modules.Identity.Application.Users.Queries.GetUserById;

public class GetUserByIdQueryHandler : IRequestHandler<GetUserByIdQuery, UserDto?>
{
    private readonly IUserRepository _users;
    public GetUserByIdQueryHandler(IUserRepository users) => _users = users;

    public async Task<UserDto?> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
    {
        var user = await _users.GetByIdAsync(request.UserId, cancellationToken);
        return user is null ? null : new UserDto(user.Id, user.Email, user.FirstName, user.LastName, user.Status.ToString(), user.CreatedAtUtc);
    }
}
