namespace Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

public record UserDto(Guid Id, string Email, string FirstName, string LastName, string Status, DateTime CreatedAtUtc);
