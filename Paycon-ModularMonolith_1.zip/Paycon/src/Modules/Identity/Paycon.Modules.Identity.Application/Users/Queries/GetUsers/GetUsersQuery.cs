using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

public record GetUsersQuery : IRequest<IReadOnlyList<UserDto>>, ICacheableQuery
{
    public string CacheKey => "identity:users:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(5);
}
