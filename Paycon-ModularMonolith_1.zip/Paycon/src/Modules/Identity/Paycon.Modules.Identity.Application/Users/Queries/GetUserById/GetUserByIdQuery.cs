using MediatR;
using Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

namespace Paycon.Modules.Identity.Application.Users.Queries.GetUserById;

public record GetUserByIdQuery(Guid UserId) : IRequest<UserDto?>;
