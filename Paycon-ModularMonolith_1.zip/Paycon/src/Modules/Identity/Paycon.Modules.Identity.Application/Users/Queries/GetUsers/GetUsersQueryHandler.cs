using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;

namespace Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

public class GetUsersQueryHandler : IRequestHandler<GetUsersQuery, IReadOnlyList<UserDto>>
{
    private readonly IUserRepository _users;
    public GetUsersQueryHandler(IUserRepository users) => _users = users;

    public async Task<IReadOnlyList<UserDto>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
    {
        var users = await _users.GetAllAsync(cancellationToken);
        return users
            .Select(u => new UserDto(u.Id, u.Email, u.FirstName, u.LastName, u.Status.ToString(), u.CreatedAtUtc))
            .ToList();
    }
}
