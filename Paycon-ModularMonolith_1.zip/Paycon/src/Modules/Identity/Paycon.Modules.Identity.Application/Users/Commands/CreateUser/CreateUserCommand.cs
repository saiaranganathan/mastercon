using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Users.Commands.CreateUser;

public record CreateUserCommand(string Email, string FirstName, string LastName, IReadOnlyList<Guid> RoleIds)
    : IRequest<Guid>, ICacheInvalidatingCommand
{
    public IEnumerable<string> CacheKeysToInvalidate => new[] { "identity:users:all" };
}
