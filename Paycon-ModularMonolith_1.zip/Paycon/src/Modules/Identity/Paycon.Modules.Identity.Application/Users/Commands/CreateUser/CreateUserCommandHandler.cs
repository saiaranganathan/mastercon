using MediatR;
using Paycon.EventBus;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Application.IntegrationEvents;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Users.Commands.CreateUser;

public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, Guid>
{
    private readonly IUserRepository _users;
    private readonly IEventBus _eventBus;

    public CreateUserCommandHandler(IUserRepository users, IEventBus eventBus)
    {
        _users = users;
        _eventBus = eventBus;
    }

    public async Task<Guid> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        var user = User.Create(request.Email, request.FirstName, request.LastName);
        user.AssignRoles(request.RoleIds);

        await _users.AddAsync(user, cancellationToken);
        await _users.SaveChangesAsync(cancellationToken);

        await _eventBus.PublishAsync(
            new UserProvisionedIntegrationEvent(user.Id, user.Email, $"{user.FirstName} {user.LastName}"),
            cancellationToken);

        return user.Id;
    }
}
