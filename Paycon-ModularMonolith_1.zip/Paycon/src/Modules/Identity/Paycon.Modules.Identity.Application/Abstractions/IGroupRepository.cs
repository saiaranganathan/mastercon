using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Abstractions;

public interface IGroupRepository
{
    Task<Group?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyList<Group>> GetAllAsync(CancellationToken cancellationToken);
    Task AddAsync(Group group, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
