using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Abstractions;

public interface IRoleRepository
{
    Task<Role?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyList<Role>> GetAllAsync(CancellationToken cancellationToken);
    Task AddAsync(Role role, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
