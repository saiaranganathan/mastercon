using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Abstractions;

/// <summary>
/// Repository abstraction owned by Application, implemented by Infrastructure against
/// this module's own DbContext (IdentityDbContext). No other module may implement or
/// bypass this interface to touch Identity's tables directly.
/// </summary>
public interface IUserRepository
{
    Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyList<User>> GetAllAsync(CancellationToken cancellationToken);
    Task AddAsync(User user, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
