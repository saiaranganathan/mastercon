using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Abstractions;

public interface IPermissionRepository
{
    Task<IReadOnlyList<Permission>> GetAllAsync(CancellationToken cancellationToken);
    Task AddAsync(Permission permission, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
