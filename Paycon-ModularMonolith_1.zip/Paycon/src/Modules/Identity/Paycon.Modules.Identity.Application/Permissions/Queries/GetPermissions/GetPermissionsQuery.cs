using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Permissions.Queries.GetPermissions;

// Backs "Users - View - Permissions - Available/Selected" and the Roles permission
// picker - the full catalog of assignable permissions, grouped by Category client-side.
public record GetPermissionsQuery : IRequest<IReadOnlyList<PermissionDto>>, ICacheableQuery
{
    public string CacheKey => "identity:permissions:all";
    public TimeSpan? Expiration => TimeSpan.FromHours(1);
}
