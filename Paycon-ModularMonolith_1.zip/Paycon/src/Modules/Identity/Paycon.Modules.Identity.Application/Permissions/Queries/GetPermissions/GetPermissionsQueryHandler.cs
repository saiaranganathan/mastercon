using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;

namespace Paycon.Modules.Identity.Application.Permissions.Queries.GetPermissions;

public class GetPermissionsQueryHandler : IRequestHandler<GetPermissionsQuery, IReadOnlyList<PermissionDto>>
{
    private readonly IPermissionRepository _permissions;
    public GetPermissionsQueryHandler(IPermissionRepository permissions) => _permissions = permissions;

    public async Task<IReadOnlyList<PermissionDto>> Handle(GetPermissionsQuery request, CancellationToken cancellationToken)
    {
        var permissions = await _permissions.GetAllAsync(cancellationToken);
        return permissions.Select(p => new PermissionDto(p.Id, p.Code, p.Category, p.Description)).ToList();
    }
}
