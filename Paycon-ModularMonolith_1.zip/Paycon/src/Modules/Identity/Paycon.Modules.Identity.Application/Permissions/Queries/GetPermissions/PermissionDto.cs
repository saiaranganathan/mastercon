namespace Paycon.Modules.Identity.Application.Permissions.Queries.GetPermissions;

public record PermissionDto(Guid Id, string Code, string Category, string? Description);
