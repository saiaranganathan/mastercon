using MediatR;
using Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

namespace Paycon.Modules.Identity.Application.Roles.Queries.GetRoleById;

public record GetRoleByIdQuery(Guid RoleId) : IRequest<RoleDto?>;
