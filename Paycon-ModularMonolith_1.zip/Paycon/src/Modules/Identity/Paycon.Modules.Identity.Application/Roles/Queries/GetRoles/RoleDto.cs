namespace Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

public record RoleDto(Guid Id, string Name, string? Description, IReadOnlyCollection<Guid> PermissionIds, IReadOnlyCollection<Guid> GroupIds);
