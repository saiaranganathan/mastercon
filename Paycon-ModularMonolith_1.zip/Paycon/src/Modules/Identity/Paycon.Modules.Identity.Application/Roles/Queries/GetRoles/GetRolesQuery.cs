using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

public record GetRolesQuery : IRequest<IReadOnlyList<RoleDto>>, ICacheableQuery
{
    public string CacheKey => "identity:roles:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
