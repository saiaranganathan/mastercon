using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;

namespace Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

public class GetRolesQueryHandler : IRequestHandler<GetRolesQuery, IReadOnlyList<RoleDto>>
{
    private readonly IRoleRepository _roles;
    public GetRolesQueryHandler(IRoleRepository roles) => _roles = roles;

    public async Task<IReadOnlyList<RoleDto>> Handle(GetRolesQuery request, CancellationToken cancellationToken)
    {
        var roles = await _roles.GetAllAsync(cancellationToken);
        return roles.Select(r => new RoleDto(r.Id, r.Name, r.Description, r.PermissionIds, r.GroupIds)).ToList();
    }
}
