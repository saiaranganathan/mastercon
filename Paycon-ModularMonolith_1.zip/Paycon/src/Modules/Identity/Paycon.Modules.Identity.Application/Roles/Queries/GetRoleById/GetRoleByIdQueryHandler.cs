using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

namespace Paycon.Modules.Identity.Application.Roles.Queries.GetRoleById;

public class GetRoleByIdQueryHandler : IRequestHandler<GetRoleByIdQuery, RoleDto?>
{
    private readonly IRoleRepository _roles;
    public GetRoleByIdQueryHandler(IRoleRepository roles) => _roles = roles;

    public async Task<RoleDto?> Handle(GetRoleByIdQuery request, CancellationToken cancellationToken)
    {
        var role = await _roles.GetByIdAsync(request.RoleId, cancellationToken);
        return role is null ? null : new RoleDto(role.Id, role.Name, role.Description, role.PermissionIds, role.GroupIds);
    }
}
