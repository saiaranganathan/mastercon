using MediatR;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Application.Roles.Commands.CreateRole;

public class CreateRoleCommandHandler : IRequestHandler<CreateRoleCommand, Guid>
{
    private readonly IRoleRepository _roles;
    public CreateRoleCommandHandler(IRoleRepository roles) => _roles = roles;

    public async Task<Guid> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
    {
        var role = Role.Create(request.Name, request.Description);
        role.SetPermissions(request.PermissionIds);
        role.SetGroups(request.GroupIds);

        await _roles.AddAsync(role, cancellationToken);
        await _roles.SaveChangesAsync(cancellationToken);
        return role.Id;
    }
}
