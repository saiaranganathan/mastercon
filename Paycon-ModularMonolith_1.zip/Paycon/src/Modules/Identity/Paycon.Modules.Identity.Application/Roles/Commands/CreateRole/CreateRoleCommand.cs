using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.Identity.Application.Roles.Commands.CreateRole;

// Backs "Roles - Create Expanded": name/description plus the permission and group
// selections made on the "Set Permissions" / "Set Groups" steps of that screen.
public record CreateRoleCommand(string Name, string? Description, IReadOnlyList<Guid> PermissionIds, IReadOnlyList<Guid> GroupIds)
    : IRequest<Guid>, ICacheInvalidatingCommand
{
    public IEnumerable<string> CacheKeysToInvalidate => new[] { "identity:roles:all" };
}
