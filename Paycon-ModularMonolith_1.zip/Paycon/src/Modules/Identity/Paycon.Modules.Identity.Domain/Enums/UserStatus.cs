namespace Paycon.Modules.Identity.Domain.Enums;

public enum UserStatus { Active, Inactive, Locked, PendingActivation }
