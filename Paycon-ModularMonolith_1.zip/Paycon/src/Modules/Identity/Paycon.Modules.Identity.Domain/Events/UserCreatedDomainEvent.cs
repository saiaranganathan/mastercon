using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Domain.Events;

public record UserCreatedDomainEvent(Guid UserId, string Email) : IDomainEvent
{
    public DateTime OccurredOnUtc { get; init; } = DateTime.UtcNow;
}
