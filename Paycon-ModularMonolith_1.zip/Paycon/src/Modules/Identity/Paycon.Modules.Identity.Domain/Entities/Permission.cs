using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Domain.Entities;

/// <summary>A fine-grained permission, e.g. "reconciliation.matches.approve".</summary>
public class Permission : AggregateRoot<Guid>
{
    public string Code { get; private set; } = default!;
    public string Category { get; private set; } = default!;
    public string? Description { get; private set; }

    private Permission() { }

    public static Permission Create(string code, string category, string? description) =>
        new() { Id = Guid.NewGuid(), Code = code, Category = category, Description = description };
}
