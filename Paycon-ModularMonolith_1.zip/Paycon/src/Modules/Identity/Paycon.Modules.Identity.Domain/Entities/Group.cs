using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Domain.Entities;

public class Group : AggregateRoot<Guid>
{
    public string Name { get; private set; } = default!;
    public string? Description { get; private set; }

    private Group() { }

    public static Group Create(string name, string? description)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Group name is required.", nameof(name));
        return new Group { Id = Guid.NewGuid(), Name = name, Description = description };
    }
}
