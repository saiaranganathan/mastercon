using Paycon.Modules.Identity.Domain.Enums;
using Paycon.Modules.Identity.Domain.Events;
using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Domain.Entities;

public class User : AggregateRoot<Guid>
{
    public string Email { get; private set; } = default!;
    public string FirstName { get; private set; } = default!;
    public string LastName { get; private set; } = default!;
    public UserStatus Status { get; private set; }
    public DateTime CreatedAtUtc { get; private set; }

    private readonly List<Guid> _roleIds = new();
    public IReadOnlyCollection<Guid> RoleIds => _roleIds.AsReadOnly();

    private readonly List<Guid> _groupIds = new();
    public IReadOnlyCollection<Guid> GroupIds => _groupIds.AsReadOnly();

    private User() { }

    public static User Create(string email, string firstName, string lastName)
    {
        if (string.IsNullOrWhiteSpace(email)) throw new ArgumentException("Email is required.", nameof(email));

        var user = new User
        {
            Id = Guid.NewGuid(),
            Email = email,
            FirstName = firstName,
            LastName = lastName,
            Status = UserStatus.PendingActivation,
            CreatedAtUtc = DateTime.UtcNow
        };

        user.Raise(new UserCreatedDomainEvent(user.Id, user.Email));
        return user;
    }

    public void AssignRoles(IEnumerable<Guid> roleIds)
    {
        _roleIds.Clear();
        _roleIds.AddRange(roleIds.Distinct());
    }

    public void AssignGroups(IEnumerable<Guid> groupIds)
    {
        _groupIds.Clear();
        _groupIds.AddRange(groupIds.Distinct());
    }

    public void Activate() => Status = UserStatus.Active;
    public void Lock() => Status = UserStatus.Locked;
}
