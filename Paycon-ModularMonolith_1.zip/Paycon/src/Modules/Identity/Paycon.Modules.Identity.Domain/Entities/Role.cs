using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Domain.Entities;

public class Role : AggregateRoot<Guid>
{
    public string Name { get; private set; } = default!;
    public string? Description { get; private set; }

    private readonly List<Guid> _permissionIds = new();
    public IReadOnlyCollection<Guid> PermissionIds => _permissionIds.AsReadOnly();

    private readonly List<Guid> _groupIds = new();
    public IReadOnlyCollection<Guid> GroupIds => _groupIds.AsReadOnly();

    private Role() { }

    public static Role Create(string name, string? description)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Role name is required.", nameof(name));
        return new Role { Id = Guid.NewGuid(), Name = name, Description = description };
    }

    public void SetPermissions(IEnumerable<Guid> permissionIds)
    {
        _permissionIds.Clear();
        _permissionIds.AddRange(permissionIds.Distinct());
    }

    public void SetGroups(IEnumerable<Guid> groupIds)
    {
        _groupIds.Clear();
        _groupIds.AddRange(groupIds.Distinct());
    }
}
