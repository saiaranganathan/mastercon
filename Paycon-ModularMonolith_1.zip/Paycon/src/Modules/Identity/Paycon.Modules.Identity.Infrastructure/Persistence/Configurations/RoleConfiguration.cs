using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Configurations;

public class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.ToTable("Roles", IdentityDbContext.Schema);
        builder.HasKey(r => r.Id);
        builder.Property(r => r.Name).HasMaxLength(150).IsRequired();
        builder.Property(r => r.Description).HasMaxLength(500);
        builder.Ignore(r => r.PermissionIds);
        builder.Ignore(r => r.GroupIds);
        builder.Ignore(r => r.DomainEvents);
    }
}
