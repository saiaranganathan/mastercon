using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("Users", IdentityDbContext.Schema);
        builder.HasKey(u => u.Id);
        builder.Property(u => u.Email).HasMaxLength(256).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique();
        builder.Property(u => u.FirstName).HasMaxLength(100).IsRequired();
        builder.Property(u => u.LastName).HasMaxLength(100).IsRequired();
        builder.Property(u => u.Status).HasConversion<string>().HasMaxLength(30);

        builder.Property<List<Guid>>("_roleIds")
            .HasField("_roleIds")
            .UsePropertyAccessMode(PropertyAccessMode.Field)
            .HasColumnName("RoleIds")
            .HasConversion(
                v => string.Join(',', v),
                v => v.Length == 0 ? new List<Guid>() : v.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(Guid.Parse).ToList());

        builder.Property<List<Guid>>("_groupIds")
            .HasField("_groupIds")
            .UsePropertyAccessMode(PropertyAccessMode.Field)
            .HasColumnName("GroupIds")
            .HasConversion(
                v => string.Join(',', v),
                v => v.Length == 0 ? new List<Guid>() : v.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(Guid.Parse).ToList());

        builder.Ignore(u => u.RoleIds);
        builder.Ignore(u => u.GroupIds);
        builder.Ignore(u => u.DomainEvents);
    }
}
