using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Configurations;

public class GroupConfiguration : IEntityTypeConfiguration<Group>
{
    public void Configure(EntityTypeBuilder<Group> builder)
    {
        builder.ToTable("Groups", IdentityDbContext.Schema);
        builder.HasKey(g => g.Id);
        builder.Property(g => g.Name).HasMaxLength(150).IsRequired();
        builder.Property(g => g.Description).HasMaxLength(500);
        builder.Ignore(g => g.DomainEvents);
    }
}
