using MediatR;
using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Identity.Domain.Entities;
using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Infrastructure.Persistence;

/// <summary>
/// This module's OWN DbContext. It maps only to the "identity" schema in Azure SQL and
/// is never injected into any other module. Cross-module data needs are served through
/// the module's Api (HTTP) or through integration events - never through EF navigation
/// properties that reach into another module's tables.
/// </summary>
public class IdentityDbContext : DbContext
{
    public const string Schema = "identity";

    private readonly IPublisher? _publisher;

    public IdentityDbContext(DbContextOptions<IdentityDbContext> options, IPublisher? publisher = null) : base(options)
    {
        _publisher = publisher;
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<Permission> Permissions => Set<Permission>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(IdentityDbContext).Assembly);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        // Dispatch domain events raised on aggregates in this module before committing -
        // still entirely in-process and scoped to this module's own MediatR pipeline.
        var entitiesWithEvents = ChangeTracker.Entries<Entity<Guid>>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Count != 0)
            .ToList();

        var result = await base.SaveChangesAsync(cancellationToken);

        if (_publisher is not null)
        {
            foreach (var entity in entitiesWithEvents)
            {
                var events = entity.DomainEvents.ToList();
                entity.ClearDomainEvents();
                foreach (var domainEvent in events)
                    await _publisher.Publish(domainEvent, cancellationToken);
            }
        }

        return result;
    }
}
