using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Repositories;

public class RoleRepository : IRoleRepository
{
    private readonly IdentityDbContext _db;
    public RoleRepository(IdentityDbContext db) => _db = db;

    public Task<Role?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Roles.FirstOrDefaultAsync(r => r.Id == id, cancellationToken);

    public async Task<IReadOnlyList<Role>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Roles.AsNoTracking().OrderBy(r => r.Name).ToListAsync(cancellationToken);

    public Task AddAsync(Role role, CancellationToken cancellationToken)
    {
        _db.Roles.Add(role);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
