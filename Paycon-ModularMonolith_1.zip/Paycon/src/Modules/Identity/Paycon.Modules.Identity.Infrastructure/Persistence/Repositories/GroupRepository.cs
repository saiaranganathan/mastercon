using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Repositories;

public class GroupRepository : IGroupRepository
{
    private readonly IdentityDbContext _db;
    public GroupRepository(IdentityDbContext db) => _db = db;

    public Task<Group?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Groups.FirstOrDefaultAsync(g => g.Id == id, cancellationToken);

    public async Task<IReadOnlyList<Group>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Groups.AsNoTracking().OrderBy(g => g.Name).ToListAsync(cancellationToken);

    public Task AddAsync(Group group, CancellationToken cancellationToken)
    {
        _db.Groups.Add(group);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
