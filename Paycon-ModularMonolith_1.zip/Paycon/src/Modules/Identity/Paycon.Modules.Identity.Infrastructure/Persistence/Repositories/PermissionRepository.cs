using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;

namespace Paycon.Modules.Identity.Infrastructure.Persistence.Repositories;

public class PermissionRepository : IPermissionRepository
{
    private readonly IdentityDbContext _db;
    public PermissionRepository(IdentityDbContext db) => _db = db;

    public async Task<IReadOnlyList<Permission>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Permissions.AsNoTracking().OrderBy(p => p.Category).ThenBy(p => p.Code).ToListAsync(cancellationToken);

    public Task AddAsync(Permission permission, CancellationToken cancellationToken)
    {
        _db.Permissions.Add(permission);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
