using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Identity.Application.Abstractions;
using Paycon.Modules.Identity.Domain.Entities;
using Paycon.Modules.Identity.Infrastructure.Persistence;
using Paycon.Modules.Identity.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.Identity.Api;

/// <summary>
/// The ONE public seam of the Identity module. The Host discovers this class via
/// reflection/assembly scanning and calls RegisterModule + MapEndpoints - it never
/// touches IdentityDbContext, repositories or handlers directly.
///
/// This module backs the whole "User Management" area of the design: Users, Groups,
/// Roles and the Permission catalog they're all built from (Users/Roles/Groups screens,
/// including the Create/Edit/View Expanded variants and the permission picker).
/// </summary>
public class IdentityModule : IModule
{
    public string Name => "Identity";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        // DbContext-per-module, switchable between Azure SQL and EF Core's InMemory
        // provider via Infrastructure:UseInMemory (see Paycon.Persistence). Same connection
        // string key / schema name convention as every other module.
        services.AddModuleDbContext<IdentityDbContext>(configuration, "IdentityDb", IdentityDbContext.Schema);

        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IGroupRepository, GroupRepository>();
        services.AddScoped<IPermissionRepository, PermissionRepository>();

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(
            typeof(Application.Users.Commands.CreateUser.CreateUserCommand).Assembly));

        services.AddValidatorsFromModule();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        Endpoints.UserEndpoints.Map(endpoints);
        Endpoints.RoleEndpoints.Map(endpoints);
        Endpoints.GroupEndpoints.Map(endpoints);
        Endpoints.PermissionEndpoints.Map(endpoints);
        return endpoints;
    }

    /// <summary>Demo data so the Users/Roles/Groups/Permissions screens aren't empty on
    /// first run against the in-memory database. Never runs against a real database.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<IdentityDbContext>();
        if (await db.Users.AnyAsync()) return;

        var viewPermission = Permission.Create("reconciliation.matches.view", "Reconciliation", "View matched/mismatched transactions");
        var approvePermission = Permission.Create("insights.payouts.approve", "Insights", "Approve fund provider payouts");
        db.Permissions.AddRange(viewPermission, approvePermission);

        var opsGroup = Group.Create("Operations", "Day-to-day reconciliation and payout operations");
        db.Groups.Add(opsGroup);

        var adminRole = Role.Create("Administrator", "Full access across all modules");
        adminRole.SetPermissions(new[] { viewPermission.Id, approvePermission.Id });
        adminRole.SetGroups(new[] { opsGroup.Id });
        db.Roles.Add(adminRole);

        var admin = User.Create("admin@paycon.local", "System", "Administrator");
        admin.AssignRoles(new[] { adminRole.Id });
        admin.AssignGroups(new[] { opsGroup.Id });
        admin.Activate();
        db.Users.Add(admin);

        await db.SaveChangesAsync();
    }
}

file static class ServiceCollectionExtensions
{
    public static IServiceCollection AddValidatorsFromModule(this IServiceCollection services)
    {
        FluentValidation.AssemblyScanner
            .FindValidatorsInAssembly(typeof(Application.Users.Commands.CreateUser.CreateUserCommand).Assembly)
            .ForEach(result => services.AddScoped(result.InterfaceType, result.ValidatorType));
        return services;
    }
}
