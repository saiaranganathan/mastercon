using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Paycon.Modules.Identity.Application.Permissions.Queries.GetPermissions;

namespace Paycon.Modules.Identity.Api.Endpoints;

/// <summary>Backs the "Available/Selected Permissions" picker on the Roles and Users
/// screens - read-only, since the permission catalog is seeded, not user-authored.</summary>
public static class PermissionEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/identity/permissions", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetPermissionsQuery(), ct)))
            .WithTags("Identity - Permissions");
    }
}
