using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Paycon.Modules.Identity.Application.Roles.Commands.CreateRole;
using Paycon.Modules.Identity.Application.Roles.Queries.GetRoleById;
using Paycon.Modules.Identity.Application.Roles.Queries.GetRoles;

namespace Paycon.Modules.Identity.Api.Endpoints;

/// <summary>Backs the "Roles" / "Roles - Create/Edit/View Expanded" screens.</summary>
public static class RoleEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/identity/roles").WithTags("Identity - Roles");

        group.MapGet("/", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetRolesQuery(), ct)));

        group.MapGet("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            var role = await sender.Send(new GetRoleByIdQuery(id), ct);
            return role is null ? Results.NotFound() : Results.Ok(role);
        });

        group.MapPost("/", async (CreateRoleCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/identity/roles/{id}", new { id });
        });
    }
}
