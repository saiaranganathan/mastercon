using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Paycon.Modules.Identity.Application.Groups.Commands.CreateGroup;
using Paycon.Modules.Identity.Application.Groups.Queries.GetGroups;

namespace Paycon.Modules.Identity.Api.Endpoints;

/// <summary>Backs the "Groups" / "Groups - Create/Edit/View Expanded" screens.</summary>
public static class GroupEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/identity/groups").WithTags("Identity - Groups");

        group.MapGet("/", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetGroupsQuery(), ct)));

        group.MapPost("/", async (CreateGroupCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/identity/groups/{id}", new { id });
        });
    }
}
