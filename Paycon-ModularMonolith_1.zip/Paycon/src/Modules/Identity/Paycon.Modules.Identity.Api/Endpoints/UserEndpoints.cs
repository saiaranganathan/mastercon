using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Paycon.Modules.Identity.Application.Users.Commands.CreateUser;
using Paycon.Modules.Identity.Application.Users.Queries.GetUserById;
using Paycon.Modules.Identity.Application.Users.Queries.GetUsers;

namespace Paycon.Modules.Identity.Api.Endpoints;

/// <summary>Minimal-API endpoints, mounted by the Host under /api/identity/*.
/// Controllers are unnecessary for a module this size - swap for MapControllers-per-module
/// if a module grows complex enough to want them.</summary>
public static class UserEndpoints
{
    public static void Map(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/identity/users").WithTags("Identity - Users");

        group.MapGet("/", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetUsersQuery(), ct)));

        group.MapGet("/{id:guid}", async (Guid id, ISender sender, CancellationToken ct) =>
        {
            var user = await sender.Send(new GetUserByIdQuery(id), ct);
            return user is null ? Results.NotFound() : Results.Ok(user);
        });

        group.MapPost("/", async (CreateUserCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/identity/users/{id}", new { id });
        });
    }
}
