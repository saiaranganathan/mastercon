using MediatR;
using Paycon.Modules.Notifications.Application.Abstractions;

namespace Paycon.Modules.Notifications.Application.Notifications.Queries.GetRecentNotifications;

public class GetRecentNotificationsQueryHandler : IRequestHandler<GetRecentNotificationsQuery, IReadOnlyList<NotificationDto>>
{
    private readonly INotificationLogRepository _repository;
    public GetRecentNotificationsQueryHandler(INotificationLogRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<NotificationDto>> Handle(GetRecentNotificationsQuery request, CancellationToken cancellationToken)
    {
        var logs = await _repository.GetRecentAsync(request.Count, cancellationToken);
        return logs.Select(l => new NotificationDto(l.Id, l.Title, l.Description, l.Category, l.IsRead, l.CreatedAtUtc)).ToList();
    }
}
