using MediatR;

namespace Paycon.Modules.Notifications.Application.Notifications.Queries.GetRecentNotifications;

public record NotificationDto(Guid Id, string Title, string Description, string Category, bool IsRead, DateTime CreatedAtUtc);

public record GetRecentNotificationsQuery(int Count = 10) : IRequest<IReadOnlyList<NotificationDto>>;
