using Paycon.EventBus;
using Paycon.Modules.Notifications.Application.Abstractions;
using Paycon.Modules.Notifications.Domain.Entities;

namespace Paycon.Modules.Notifications.Application.EventHandlers;

/// <summary>Mirrors Reconciliation's public IntegrationEvent contract locally so this
/// module has zero project reference to Paycon.Modules.Reconciliation.* - the routing
/// key + payload shape is the only coupling between the two modules.</summary>
public record ReconciliationCompletedIntegrationEvent(Guid BatchId, int MatchedCount, int MismatchedCount) : IntegrationEvent
{
    public override string RoutingKey => "reconciliation.batch.completed";
}

public class ReconciliationCompletedIntegrationEventHandler : IIntegrationEventHandler<ReconciliationCompletedIntegrationEvent>
{
    private readonly INotificationLogRepository _repository;
    private readonly INotificationPusher _pusher;

    public ReconciliationCompletedIntegrationEventHandler(INotificationLogRepository repository, INotificationPusher pusher)
    {
        _repository = repository;
        _pusher = pusher;
    }

    public async Task Handle(ReconciliationCompletedIntegrationEvent @event, CancellationToken cancellationToken)
    {
        var log = NotificationLog.Create(
            "Reconciliation Completed",
            $"{@event.MatchedCount} matched, {@event.MismatchedCount} mismatched for batch {@event.BatchId}.",
            "ReconciliationCompleted");

        await _repository.AddAsync(log, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        await _pusher.PushAsync(log.Id, log.Title, log.Description, cancellationToken);
    }
}
