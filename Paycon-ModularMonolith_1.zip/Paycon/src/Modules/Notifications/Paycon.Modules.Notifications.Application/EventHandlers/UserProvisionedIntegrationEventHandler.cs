using Paycon.EventBus;
using Paycon.Modules.Notifications.Application.Abstractions;
using Paycon.Modules.Notifications.Domain.Entities;

namespace Paycon.Modules.Notifications.Application.EventHandlers;

public record UserProvisionedIntegrationEvent(Guid UserId, string Email, string FullName) : IntegrationEvent
{
    public override string RoutingKey => "identity.user.provisioned";
}

/// <summary>Reacts to a new user (published by Identity) by queuing a welcome email
/// (via the module's own Email Template Config, wired in Infrastructure).</summary>
public class UserProvisionedIntegrationEventHandler : IIntegrationEventHandler<UserProvisionedIntegrationEvent>
{
    private readonly INotificationLogRepository _repository;
    public UserProvisionedIntegrationEventHandler(INotificationLogRepository repository) => _repository = repository;

    public async Task Handle(UserProvisionedIntegrationEvent @event, CancellationToken cancellationToken)
    {
        var log = NotificationLog.Create("Welcome Email Queued", $"Welcome email queued for {@event.FullName} ({@event.Email}).", "UserProvisioned");
        await _repository.AddAsync(log, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
    }
}
