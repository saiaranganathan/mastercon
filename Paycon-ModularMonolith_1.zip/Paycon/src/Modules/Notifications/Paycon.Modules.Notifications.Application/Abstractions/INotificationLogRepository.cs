using Paycon.Modules.Notifications.Domain.Entities;

namespace Paycon.Modules.Notifications.Application.Abstractions;

public interface INotificationLogRepository
{
    Task<IReadOnlyList<NotificationLog>> GetRecentAsync(int count, CancellationToken cancellationToken);
    Task AddAsync(NotificationLog log, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}

/// <summary>Live push to the Blazor dashboard's Notifications panel, implemented in the
/// Host against the shared SignalR hub - same seam pattern as IReconciliationNotifier.</summary>
public interface INotificationPusher
{
    Task PushAsync(Guid id, string title, string description, CancellationToken cancellationToken);
}
