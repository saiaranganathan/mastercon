using Paycon.SharedKernel;

namespace Paycon.Modules.Notifications.Domain.Entities;

/// <summary>Backs the Dashboard's "Notifications" panel (Reconciliation Completed,
/// Workflow Failed, Month-End Close Reminder, ...). Populated exclusively by integration
/// events consumed off RabbitMQ - this module never queries another module's tables.</summary>
public class NotificationLog : AggregateRoot<Guid>
{
    public string Title { get; private set; } = default!;
    public string Description { get; private set; } = default!;
    public string Category { get; private set; } = default!; // e.g. "ReconciliationCompleted", "WorkflowFailed"
    public bool IsRead { get; private set; }
    public DateTime CreatedAtUtc { get; private set; } = DateTime.UtcNow;

    private NotificationLog() { }

    public static NotificationLog Create(string title, string description, string category) =>
        new() { Id = Guid.NewGuid(), Title = title, Description = description, Category = category };

    public void MarkRead() => IsRead = true;
}
