using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.EventBus;
using Paycon.Modules.Notifications.Application.Abstractions;
using Paycon.Modules.Notifications.Application.EventHandlers;
using Paycon.Modules.Notifications.Application.Notifications.Queries.GetRecentNotifications;
using Paycon.Modules.Notifications.Domain.Entities;
using Paycon.Modules.Notifications.Infrastructure.Persistence;
using Paycon.Modules.Notifications.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.Notifications.Api;

public class NotificationsModule : IModule
{
    public string Name => "Notifications";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<NotificationsDbContext>(configuration, "NotificationsDb", NotificationsDbContext.Schema);

        services.AddScoped<INotificationLogRepository, NotificationLogRepository>();
        services.AddScoped<ReconciliationCompletedIntegrationEventHandler>();
        services.AddScoped<UserProvisionedIntegrationEventHandler>();

        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetRecentNotificationsQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/notifications/recent", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetRecentNotificationsQuery(), ct)))
            .WithTags("Notifications");

        return endpoints;
    }

    /// <summary>Called once by the Host after the RabbitMQ IEventBus is registered, to bind
    /// this module's queue to the routing keys it cares about.</summary>
    public static void SubscribeToIntegrationEvents(IEventBus eventBus)
    {
        eventBus.Subscribe<ReconciliationCompletedIntegrationEvent, ReconciliationCompletedIntegrationEventHandler>();
        eventBus.Subscribe<UserProvisionedIntegrationEvent, UserProvisionedIntegrationEventHandler>();
    }

    /// <summary>A couple of demo log entries matching what Reconciliation/Identity would
    /// normally produce via integration events, so the dashboard's Notifications panel
    /// isn't empty on first run against the in-memory database.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<NotificationsDbContext>();
        if (await db.NotificationLogs.AnyAsync()) return;

        db.NotificationLogs.AddRange(
            NotificationLog.Create("Reconciliation Completed", "1 matched, 1 mismatched for batch SCB_DEWS_20260117.csv.", "ReconciliationCompleted"),
            NotificationLog.Create("Month-End Close Reminder", "DEWS scheme close scheduled for the 28th.", "Reminder"));

        await db.SaveChangesAsync();
    }
}
