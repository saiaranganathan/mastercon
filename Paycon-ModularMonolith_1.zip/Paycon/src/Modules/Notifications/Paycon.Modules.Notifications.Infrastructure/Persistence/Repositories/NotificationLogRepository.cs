using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Notifications.Application.Abstractions;
using Paycon.Modules.Notifications.Domain.Entities;

namespace Paycon.Modules.Notifications.Infrastructure.Persistence.Repositories;

public class NotificationLogRepository : INotificationLogRepository
{
    private readonly NotificationsDbContext _db;
    public NotificationLogRepository(NotificationsDbContext db) => _db = db;

    public async Task<IReadOnlyList<NotificationLog>> GetRecentAsync(int count, CancellationToken cancellationToken) =>
        await _db.NotificationLogs.AsNoTracking().OrderByDescending(n => n.CreatedAtUtc).Take(count).ToListAsync(cancellationToken);

    public Task AddAsync(NotificationLog log, CancellationToken cancellationToken)
    {
        _db.NotificationLogs.Add(log);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
