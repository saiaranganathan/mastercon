using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Notifications.Domain.Entities;

namespace Paycon.Modules.Notifications.Infrastructure.Persistence;

/// <summary>This module's own DbContext ("notifications" schema).</summary>
public class NotificationsDbContext : DbContext
{
    public const string Schema = "notifications";

    public NotificationsDbContext(DbContextOptions<NotificationsDbContext> options) : base(options) { }

    public DbSet<NotificationLog> NotificationLogs => Set<NotificationLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(NotificationsDbContext).Assembly);
    }
}
