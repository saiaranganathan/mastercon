using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.SchemeManagement.Application.Schemes.Queries.GetSchemes;

public record SchemeDto(Guid Id, string SchemeCode, string SchemeName, string OperatingBankCode, bool IsActive);

public record GetSchemesQuery : IRequest<IReadOnlyList<SchemeDto>>, ICacheableQuery
{
    public string CacheKey => "schememanagement:schemes:all";
    public TimeSpan? Expiration => TimeSpan.FromMinutes(10);
}
