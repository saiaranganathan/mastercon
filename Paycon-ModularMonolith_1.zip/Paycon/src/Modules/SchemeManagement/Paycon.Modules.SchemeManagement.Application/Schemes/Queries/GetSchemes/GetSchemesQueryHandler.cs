using MediatR;
using Paycon.Modules.SchemeManagement.Application.Abstractions;

namespace Paycon.Modules.SchemeManagement.Application.Schemes.Queries.GetSchemes;

public class GetSchemesQueryHandler : IRequestHandler<GetSchemesQuery, IReadOnlyList<SchemeDto>>
{
    private readonly ISchemeRepository _repository;
    public GetSchemesQueryHandler(ISchemeRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<SchemeDto>> Handle(GetSchemesQuery request, CancellationToken cancellationToken)
    {
        var schemes = await _repository.GetAllAsync(cancellationToken);
        return schemes.Select(s => new SchemeDto(s.Id, s.SchemeCode, s.SchemeName, s.OperatingBankCode, s.IsActive)).ToList();
    }
}
