using MediatR;
using Paycon.Modules.SchemeManagement.Application.Abstractions;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Application.Schemes.Commands.CreateScheme;

public class CreateSchemeCommandHandler : IRequestHandler<CreateSchemeCommand, Guid>
{
    private readonly ISchemeRepository _repository;
    public CreateSchemeCommandHandler(ISchemeRepository repository) => _repository = repository;

    public async Task<Guid> Handle(CreateSchemeCommand request, CancellationToken cancellationToken)
    {
        var scheme = SchemeMaster.Create(request.SchemeCode, request.SchemeName, request.OperatingBankCode);
        await _repository.AddAsync(scheme, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        return scheme.Id;
    }
}
