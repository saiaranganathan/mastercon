using MediatR;
using Paycon.Behaviors;

namespace Paycon.Modules.SchemeManagement.Application.Schemes.Commands.CreateScheme;

public record CreateSchemeCommand(string SchemeCode, string SchemeName, string OperatingBankCode) : IRequest<Guid>, ICacheInvalidatingCommand
{
    public IEnumerable<string> CacheKeysToInvalidate => new[] { "schememanagement:schemes:all" };
}
