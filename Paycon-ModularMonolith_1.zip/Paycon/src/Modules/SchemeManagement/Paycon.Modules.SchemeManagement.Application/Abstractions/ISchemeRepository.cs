using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Application.Abstractions;

public interface ISchemeRepository
{
    Task<IReadOnlyList<SchemeMaster>> GetAllAsync(CancellationToken cancellationToken);
    Task<SchemeMaster?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task AddAsync(SchemeMaster scheme, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
