using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.SchemeManagement.Application.Abstractions;
using Paycon.Modules.SchemeManagement.Application.Schemes.Commands.CreateScheme;
using Paycon.Modules.SchemeManagement.Application.Schemes.Queries.GetSchemes;
using Paycon.Modules.SchemeManagement.Domain.Entities;
using Paycon.Modules.SchemeManagement.Infrastructure.Persistence;
using Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Api;

public class SchemeManagementModule : IModule
{
    public string Name => "SchemeManagement";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<SchemeManagementDbContext>(configuration, "SchemeManagementDb", SchemeManagementDbContext.Schema);

        services.AddScoped<ISchemeRepository, SchemeRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetSchemesQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/scheme-management").WithTags("Scheme Management");

        group.MapGet("/schemes", async (ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetSchemesQuery(), ct)));

        group.MapPost("/schemes", async (CreateSchemeCommand command, ISender sender, CancellationToken ct) =>
        {
            var id = await sender.Send(command, ct);
            return Results.Created($"/api/scheme-management/schemes/{id}", new { id });
        });

        return endpoints;
    }

    /// <summary>Demo master data: one scheme with its tolerance limit, an exchange rate,
    /// and an operating bank, so the Masters screens aren't empty on first run.</summary>
    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<SchemeManagementDbContext>();
        if (await db.Schemes.AnyAsync()) return;

        var bank = OperatingBank.Create("SCB-AE", "Standard Chartered Bank - UAE", "SCBLAEADXXX");
        db.OperatingBanks.Add(bank);

        var scheme = SchemeMaster.Create("DEWS", "DIFC Employee Workplace Savings", bank.BankCode);
        db.Schemes.Add(scheme);

        db.ToleranceLimits.Add(ToleranceLimit.Create(scheme.Id, absoluteAmount: 50m, percentageTolerance: 1.5m));
        db.ExchangeRates.Add(ExchangeRate.Create("USD", "AED", 3.6725m, DateTime.UtcNow.Date));

        await db.SaveChangesAsync();
    }
}
