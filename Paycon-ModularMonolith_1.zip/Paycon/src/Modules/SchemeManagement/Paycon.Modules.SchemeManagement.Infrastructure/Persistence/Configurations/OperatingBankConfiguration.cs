using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Configurations;

public class OperatingBankConfiguration : IEntityTypeConfiguration<OperatingBank>
{
    public void Configure(EntityTypeBuilder<OperatingBank> builder)
    {
        builder.ToTable("OperatingBanks", SchemeManagementDbContext.Schema);
        builder.HasKey(b => b.Id);
        builder.Property(b => b.BankCode).HasMaxLength(50).IsRequired();
        builder.Property(b => b.BankName).HasMaxLength(200).IsRequired();
        builder.Property(b => b.SwiftCode).HasMaxLength(20);
        builder.Ignore(b => b.DomainEvents);
    }
}
