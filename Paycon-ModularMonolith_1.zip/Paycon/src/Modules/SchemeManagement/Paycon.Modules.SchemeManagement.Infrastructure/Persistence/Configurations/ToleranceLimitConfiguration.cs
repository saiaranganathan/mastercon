using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Configurations;

public class ToleranceLimitConfiguration : IEntityTypeConfiguration<ToleranceLimit>
{
    public void Configure(EntityTypeBuilder<ToleranceLimit> builder)
    {
        builder.ToTable("ToleranceLimits", SchemeManagementDbContext.Schema);
        builder.HasKey(t => t.Id);
        builder.Property(t => t.AbsoluteAmount).HasColumnType("decimal(18,2)");
        builder.Property(t => t.PercentageTolerance).HasColumnType("decimal(5,2)");
        builder.Ignore(t => t.DomainEvents);
    }
}
