using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Configurations;

public class ExchangeRateConfiguration : IEntityTypeConfiguration<ExchangeRate>
{
    public void Configure(EntityTypeBuilder<ExchangeRate> builder)
    {
        builder.ToTable("ExchangeRates", SchemeManagementDbContext.Schema);
        builder.HasKey(e => e.Id);
        builder.Property(e => e.FromCurrency).HasMaxLength(3);
        builder.Property(e => e.ToCurrency).HasMaxLength(3);
        builder.Property(e => e.Rate).HasColumnType("decimal(18,6)");
        builder.Ignore(e => e.DomainEvents);
    }
}
