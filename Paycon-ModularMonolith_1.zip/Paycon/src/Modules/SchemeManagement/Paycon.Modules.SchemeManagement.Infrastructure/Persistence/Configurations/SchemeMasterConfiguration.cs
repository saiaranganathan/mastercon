using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Configurations;

public class SchemeMasterConfiguration : IEntityTypeConfiguration<SchemeMaster>
{
    public void Configure(EntityTypeBuilder<SchemeMaster> builder)
    {
        builder.ToTable("Schemes", SchemeManagementDbContext.Schema);
        builder.HasKey(s => s.Id);
        builder.Property(s => s.SchemeCode).HasMaxLength(50).IsRequired();
        builder.HasIndex(s => s.SchemeCode).IsUnique();
        builder.Property(s => s.SchemeName).HasMaxLength(200).IsRequired();
        builder.Property(s => s.OperatingBankCode).HasMaxLength(50);
        builder.Ignore(s => s.DomainEvents);
    }
}
