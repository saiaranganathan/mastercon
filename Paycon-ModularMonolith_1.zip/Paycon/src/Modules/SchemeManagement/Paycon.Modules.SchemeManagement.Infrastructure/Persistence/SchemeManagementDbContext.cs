using Microsoft.EntityFrameworkCore;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence;

/// <summary>This module's own DbContext ("schememanagement" schema). Holds every master
/// data table shown under Settings > Masters: Scheme, Tolerance Limit, Exchange Rate,
/// Operating Bank (plus File/Email Template Config, omitted here for brevity - same pattern).</summary>
public class SchemeManagementDbContext : DbContext
{
    public const string Schema = "schememanagement";

    public SchemeManagementDbContext(DbContextOptions<SchemeManagementDbContext> options) : base(options) { }

    public DbSet<SchemeMaster> Schemes => Set<SchemeMaster>();
    public DbSet<ToleranceLimit> ToleranceLimits => Set<ToleranceLimit>();
    public DbSet<ExchangeRate> ExchangeRates => Set<ExchangeRate>();
    public DbSet<OperatingBank> OperatingBanks => Set<OperatingBank>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(SchemeManagementDbContext).Assembly);
    }
}
