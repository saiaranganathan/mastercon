using Microsoft.EntityFrameworkCore;
using Paycon.Modules.SchemeManagement.Application.Abstractions;
using Paycon.Modules.SchemeManagement.Domain.Entities;

namespace Paycon.Modules.SchemeManagement.Infrastructure.Persistence.Repositories;

public class SchemeRepository : ISchemeRepository
{
    private readonly SchemeManagementDbContext _db;
    public SchemeRepository(SchemeManagementDbContext db) => _db = db;

    public async Task<IReadOnlyList<SchemeMaster>> GetAllAsync(CancellationToken cancellationToken) =>
        await _db.Schemes.AsNoTracking().OrderBy(s => s.SchemeName).ToListAsync(cancellationToken);

    public Task<SchemeMaster?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        _db.Schemes.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);

    public Task AddAsync(SchemeMaster scheme, CancellationToken cancellationToken)
    {
        _db.Schemes.Add(scheme);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
