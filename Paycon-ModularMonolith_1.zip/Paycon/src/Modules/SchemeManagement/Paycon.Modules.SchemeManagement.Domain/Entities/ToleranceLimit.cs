using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Domain.Entities;

/// <summary>Backs "Tolerance Limit Master" - the acceptable variance Reconciliation's
/// matching algorithm allows between a bank record and an internal record.</summary>
public class ToleranceLimit : AggregateRoot<Guid>
{
    public Guid SchemeId { get; private set; }
    public decimal AbsoluteAmount { get; private set; }
    public decimal PercentageTolerance { get; private set; }

    private ToleranceLimit() { }

    public static ToleranceLimit Create(Guid schemeId, decimal absoluteAmount, decimal percentageTolerance) =>
        new() { Id = Guid.NewGuid(), SchemeId = schemeId, AbsoluteAmount = absoluteAmount, PercentageTolerance = percentageTolerance };
}
