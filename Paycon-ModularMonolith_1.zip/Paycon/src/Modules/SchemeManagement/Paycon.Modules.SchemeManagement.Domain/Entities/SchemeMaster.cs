using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Domain.Entities;

/// <summary>Backs the "Scheme Master" screen - the top-level workplace-savings/pension
/// scheme definition that Reconciliation and Insights reference (by Id only, via their
/// own read models - never a cross-DbContext foreign key) when processing a scheme.</summary>
public class SchemeMaster : AggregateRoot<Guid>
{
    public string SchemeCode { get; private set; } = default!;
    public string SchemeName { get; private set; } = default!;
    public string OperatingBankCode { get; private set; } = default!;
    public bool IsActive { get; private set; } = true;

    private SchemeMaster() { }

    public static SchemeMaster Create(string schemeCode, string schemeName, string operatingBankCode) =>
        new() { Id = Guid.NewGuid(), SchemeCode = schemeCode, SchemeName = schemeName, OperatingBankCode = operatingBankCode };

    public void Deactivate() => IsActive = false;
}
