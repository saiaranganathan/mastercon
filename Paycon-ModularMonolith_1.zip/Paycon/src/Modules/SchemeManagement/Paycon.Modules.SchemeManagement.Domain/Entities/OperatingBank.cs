using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Domain.Entities;

/// <summary>Backs "Operating Bank Master".</summary>
public class OperatingBank : AggregateRoot<Guid>
{
    public string BankCode { get; private set; } = default!;
    public string BankName { get; private set; } = default!;
    public string SwiftCode { get; private set; } = default!;

    private OperatingBank() { }

    public static OperatingBank Create(string bankCode, string bankName, string swiftCode) =>
        new() { Id = Guid.NewGuid(), BankCode = bankCode, BankName = bankName, SwiftCode = swiftCode };
}
