using Paycon.SharedKernel;

namespace Paycon.Modules.SchemeManagement.Domain.Entities;

/// <summary>Backs "Exchange Rate Master".</summary>
public class ExchangeRate : AggregateRoot<Guid>
{
    public string FromCurrency { get; private set; } = default!;
    public string ToCurrency { get; private set; } = default!;
    public decimal Rate { get; private set; }
    public DateTime EffectiveDateUtc { get; private set; }

    private ExchangeRate() { }

    public static ExchangeRate Create(string from, string to, decimal rate, DateTime effectiveDateUtc) =>
        new() { Id = Guid.NewGuid(), FromCurrency = from, ToCurrency = to, Rate = rate, EffectiveDateUtc = effectiveDateUtc };
}
