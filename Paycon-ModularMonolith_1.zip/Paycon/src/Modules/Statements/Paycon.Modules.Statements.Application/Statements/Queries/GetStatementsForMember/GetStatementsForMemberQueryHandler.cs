using MediatR;
using Paycon.Modules.Statements.Application.Abstractions;

namespace Paycon.Modules.Statements.Application.Statements.Queries.GetStatementsForMember;

public class GetStatementsForMemberQueryHandler : IRequestHandler<GetStatementsForMemberQuery, IReadOnlyList<StatementDto>>
{
    private readonly IStatementRepository _repository;
    public GetStatementsForMemberQueryHandler(IStatementRepository repository) => _repository = repository;

    public async Task<IReadOnlyList<StatementDto>> Handle(GetStatementsForMemberQuery request, CancellationToken cancellationToken)
    {
        var statements = await _repository.GetByMemberAsync(request.MemberId, cancellationToken);
        return statements.Select(s => new StatementDto(s.Id, s.Type.ToString(), s.Status.ToString(), s.PeriodStartUtc, s.PeriodEndUtc)).ToList();
    }
}
