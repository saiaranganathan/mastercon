using MediatR;

namespace Paycon.Modules.Statements.Application.Statements.Queries.GetStatementsForMember;

public record StatementDto(Guid Id, string Type, string Status, DateTime PeriodStartUtc, DateTime PeriodEndUtc);

public record GetStatementsForMemberQuery(Guid MemberId) : IRequest<IReadOnlyList<StatementDto>>;
