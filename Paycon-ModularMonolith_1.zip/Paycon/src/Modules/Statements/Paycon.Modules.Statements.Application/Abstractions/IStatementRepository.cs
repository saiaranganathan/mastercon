using Paycon.Modules.Statements.Domain.Entities;

namespace Paycon.Modules.Statements.Application.Abstractions;

public interface IStatementRepository
{
    Task<IReadOnlyList<MemberStatement>> GetByMemberAsync(Guid memberId, CancellationToken cancellationToken);
    Task SaveChangesAsync(CancellationToken cancellationToken);
}
