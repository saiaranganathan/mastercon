using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Paycon.Modules.Statements.Application.Abstractions;
using Paycon.Modules.Statements.Application.Statements.Queries.GetStatementsForMember;
using Paycon.Modules.Statements.Domain.Entities;
using Paycon.Modules.Statements.Domain.Enums;
using Paycon.Modules.Statements.Infrastructure.Persistence;
using Paycon.Modules.Statements.Infrastructure.Persistence.Repositories;
using Paycon.Persistence;
using Paycon.SharedKernel;

namespace Paycon.Modules.Statements.Api;

public class StatementsModule : IModule
{
    public string Name => "Statements";

    public IServiceCollection RegisterModule(IServiceCollection services, IConfiguration configuration)
    {
        services.AddModuleDbContext<StatementsDbContext>(configuration, "StatementsDb", StatementsDbContext.Schema);

        services.AddScoped<IStatementRepository, StatementRepository>();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetStatementsForMemberQuery).Assembly));

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/statements/members/{memberId:guid}", async (Guid memberId, ISender sender, CancellationToken ct) =>
            Results.Ok(await sender.Send(new GetStatementsForMemberQuery(memberId), ct)))
            .WithTags("Statements");

        return endpoints;
    }

    /// <summary>Demo member with an Annual and an Exit statement, using a fixed member id
    /// so it's easy to hit GET /api/statements/members/{memberId} right after startup.</summary>
    public static readonly Guid DemoMemberId = Guid.Parse("11111111-1111-1111-1111-111111111111");

    public async Task SeedAsync(IServiceProvider services, IConfiguration configuration)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<StatementsDbContext>();
        if (await db.Statements.AnyAsync()) return;

        db.Statements.AddRange(
            MemberStatement.Create(DemoMemberId, StatementType.Annual, new DateTime(2025, 1, 1), new DateTime(2025, 12, 31)),
            MemberStatement.Create(DemoMemberId, StatementType.Exit, new DateTime(2026, 1, 1), new DateTime(2026, 6, 30)));

        await db.SaveChangesAsync();
    }
}
