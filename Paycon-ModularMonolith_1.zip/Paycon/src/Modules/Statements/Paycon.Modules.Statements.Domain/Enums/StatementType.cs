namespace Paycon.Modules.Statements.Domain.Enums;

public enum StatementType { Annual, Exit }
public enum StatementStatus { Generated, Downloaded, Sent }
