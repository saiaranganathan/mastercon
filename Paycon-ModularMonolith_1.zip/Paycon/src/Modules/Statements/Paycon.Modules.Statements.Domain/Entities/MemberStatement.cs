using Paycon.Modules.Statements.Domain.Enums;
using Paycon.SharedKernel;

namespace Paycon.Modules.Statements.Domain.Entities;

/// <summary>Backs "Statements - Annual Statement" / "Statements - Exit Statement".</summary>
public class MemberStatement : AggregateRoot<Guid>
{
    public Guid MemberId { get; private set; }
    public StatementType Type { get; private set; }
    public StatementStatus Status { get; private set; } = StatementStatus.Generated;
    public DateTime PeriodStartUtc { get; private set; }
    public DateTime PeriodEndUtc { get; private set; }
    public DateTime GeneratedAtUtc { get; private set; } = DateTime.UtcNow;

    private MemberStatement() { }

    public static MemberStatement Create(Guid memberId, StatementType type, DateTime periodStartUtc, DateTime periodEndUtc) =>
        new() { Id = Guid.NewGuid(), MemberId = memberId, Type = type, PeriodStartUtc = periodStartUtc, PeriodEndUtc = periodEndUtc };

    public void MarkDownloaded() => Status = StatementStatus.Downloaded;
    public void MarkSent() => Status = StatementStatus.Sent;
}
