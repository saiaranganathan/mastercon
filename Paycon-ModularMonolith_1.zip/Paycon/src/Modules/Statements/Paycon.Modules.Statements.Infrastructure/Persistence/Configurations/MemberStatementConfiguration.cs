using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Paycon.Modules.Statements.Domain.Entities;

namespace Paycon.Modules.Statements.Infrastructure.Persistence.Configurations;

public class MemberStatementConfiguration : IEntityTypeConfiguration<MemberStatement>
{
    public void Configure(EntityTypeBuilder<MemberStatement> builder)
    {
        builder.ToTable("MemberStatements", StatementsDbContext.Schema);
        builder.HasKey(s => s.Id);
        builder.HasIndex(s => s.MemberId);
        builder.Property(s => s.Type).HasConversion<string>().HasMaxLength(20);
        builder.Property(s => s.Status).HasConversion<string>().HasMaxLength(20);
        builder.Ignore(s => s.DomainEvents);
    }
}
