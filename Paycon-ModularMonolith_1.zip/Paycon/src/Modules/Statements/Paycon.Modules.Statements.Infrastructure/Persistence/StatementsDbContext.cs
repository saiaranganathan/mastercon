using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Statements.Domain.Entities;

namespace Paycon.Modules.Statements.Infrastructure.Persistence;

/// <summary>This module's own DbContext ("statements" schema).</summary>
public class StatementsDbContext : DbContext
{
    public const string Schema = "statements";

    public StatementsDbContext(DbContextOptions<StatementsDbContext> options) : base(options) { }

    public DbSet<MemberStatement> Statements => Set<MemberStatement>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(StatementsDbContext).Assembly);
    }
}
