using Microsoft.EntityFrameworkCore;
using Paycon.Modules.Statements.Application.Abstractions;
using Paycon.Modules.Statements.Domain.Entities;

namespace Paycon.Modules.Statements.Infrastructure.Persistence.Repositories;

public class StatementRepository : IStatementRepository
{
    private readonly StatementsDbContext _db;
    public StatementRepository(StatementsDbContext db) => _db = db;

    public async Task<IReadOnlyList<MemberStatement>> GetByMemberAsync(Guid memberId, CancellationToken cancellationToken) =>
        await _db.Statements.AsNoTracking().Where(s => s.MemberId == memberId).ToListAsync(cancellationToken);

    public Task SaveChangesAsync(CancellationToken cancellationToken) => _db.SaveChangesAsync(cancellationToken);
}
