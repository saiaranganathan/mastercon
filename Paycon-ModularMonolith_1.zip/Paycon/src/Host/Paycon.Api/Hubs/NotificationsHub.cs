using Microsoft.AspNetCore.SignalR;

namespace Paycon.Api.Hubs;

/// <summary>
/// The single SignalR hub for the whole monolith. Modules never reference this class -
/// they depend only on the module-owned interfaces (IReconciliationNotifier,
/// INotificationPusher, ...) that the Host implements against this hub below.
/// The Blazor client connects once to /hubs/notifications and listens for every
/// real-time event the backend raises, regardless of which module raised it.
/// </summary>
public class NotificationsHub : Hub
{
    public async Task JoinDashboardGroup() => await Groups.AddToGroupAsync(Context.ConnectionId, "dashboard");
}
