using Microsoft.AspNetCore.SignalR;
using Paycon.Modules.Reconciliation.Application.Abstractions;

namespace Paycon.Api.Hubs;

/// <summary>Host-side implementation of the Reconciliation module's abstraction. This is
/// the ONLY place SignalR-specific code exists for this module - Reconciliation.Application
/// never references Microsoft.AspNetCore.SignalR.</summary>
public class ReconciliationNotifierAdapter : IReconciliationNotifier
{
    private readonly IHubContext<NotificationsHub> _hub;
    public ReconciliationNotifierAdapter(IHubContext<NotificationsHub> hub) => _hub = hub;

    public Task NotifyBatchCompletedAsync(Guid batchId, int matchedCount, int mismatchedCount, CancellationToken cancellationToken) =>
        _hub.Clients.Group("dashboard").SendAsync("ReconciliationBatchCompleted",
            new { batchId, matchedCount, mismatchedCount }, cancellationToken);
}
