using Microsoft.AspNetCore.SignalR;
using Paycon.Modules.Notifications.Application.Abstractions;

namespace Paycon.Api.Hubs;

public class NotificationPusherAdapter : INotificationPusher
{
    private readonly IHubContext<NotificationsHub> _hub;
    public NotificationPusherAdapter(IHubContext<NotificationsHub> hub) => _hub = hub;

    public Task PushAsync(Guid id, string title, string description, CancellationToken cancellationToken) =>
        _hub.Clients.Group("dashboard").SendAsync("NotificationReceived",
            new { id, title, description }, cancellationToken);
}
