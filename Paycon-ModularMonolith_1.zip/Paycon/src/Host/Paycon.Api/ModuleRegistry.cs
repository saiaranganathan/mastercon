using Paycon.Modules.Identity.Api;
using Paycon.Modules.Insights.Api;
using Paycon.Modules.Notifications.Api;
using Paycon.Modules.Reconciliation.Api;
using Paycon.Modules.SchemeManagement.Api;
using Paycon.Modules.Statements.Api;
using Paycon.SharedKernel;

namespace Paycon.Api;

/// <summary>
/// The complete list of modules that make up the monolith. This is the single file you
/// touch to add or remove a module from the Host - nothing else in Program.cs changes.
/// (An alternative to this explicit list is reflection-based discovery: scan the bin
/// folder for assemblies implementing IModule. The explicit list is preferred here for
/// startup-order clarity and to fail fast at compile time if a module's .Api project
/// doesn't build - swap in scanning if modules end up shipped as separate NuGet/plugin
/// packages later.)
/// </summary>
public static class ModuleRegistry
{
    public static IReadOnlyList<IModule> AllModules { get; } = new IModule[]
    {
        new IdentityModule(),
        new SchemeManagementModule(),
        new ReconciliationModule(),
        new InsightsModule(),
        new StatementsModule(),
        new NotificationsModule(),
    };
}
