using Microsoft.AspNetCore.SignalR.Client;

namespace Paycon.Client.Services;

/// <summary>
/// One SignalR connection for the whole app, to the single Host-owned NotificationsHub.
/// Any module's real-time event (reconciliation completed, a new notification, ...)
/// arrives through this same connection - the client never opens a hub connection
/// per module.
/// </summary>
public class NotificationHubService : IAsyncDisposable
{
    private readonly IConfiguration _configuration;
    private HubConnection? _connection;

    public event Action<Guid, int, int>? ReconciliationBatchCompleted;
    public event Action<Guid, string, string>? NotificationReceived;

    public NotificationHubService(IConfiguration configuration) => _configuration = configuration;

    public async Task StartAsync()
    {
        var hubUrl = _configuration["NotificationsHubUrl"] ?? "https://localhost:7031/hubs/notifications";

        _connection = new HubConnectionBuilder()
            .WithUrl(hubUrl)
            .WithAutomaticReconnect()
            .Build();

        _connection.On<BatchCompletedPayload>("ReconciliationBatchCompleted", payload =>
            ReconciliationBatchCompleted?.Invoke(payload.BatchId, payload.MatchedCount, payload.MismatchedCount));

        _connection.On<NotificationPayload>("NotificationReceived", payload =>
            NotificationReceived?.Invoke(payload.Id, payload.Title, payload.Description));

        await _connection.StartAsync();
        await _connection.InvokeAsync("JoinDashboardGroup");
    }

    public async ValueTask DisposeAsync()
    {
        if (_connection is not null)
            await _connection.DisposeAsync();
    }

    private record BatchCompletedPayload(Guid BatchId, int MatchedCount, int MismatchedCount);
    private record NotificationPayload(Guid Id, string Title, string Description);
}
