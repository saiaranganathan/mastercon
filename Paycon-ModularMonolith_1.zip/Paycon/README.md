# PayCon — Modular Monolith

A modular-monolith backend + Blazor WebAssembly front end for **PayCon** (Zurich
Workplace Savings), scaffolded from the Figma file *"Paycon UI Revamp 2"*. The module
boundaries below are drawn directly from that design's screen inventory (Homescreen,
Reconciliation, Insights, User Management, Scheme Management masters, Statements),
not invented generically.

## Tech stack

| Concern | Technology |
|---|---|
| UI | ASP.NET Core **Blazor WebAssembly** |
| Real-time | **SignalR** (one hub, shared by every module) |
| API / backend | **.NET 9** minimal APIs |
| Database | **Azure SQL Database** — one schema per module, one `DbContext` per module |
| In-process mediation | **MediatR** (CQRS: commands/queries + pipeline behaviors) |
| Cross-module messaging | **RabbitMQ** (topic exchange, one durable queue per module) |
| Cache | **Azure Cache for Redis** (via `IDistributedCache`) |

## Why this structure

A modular monolith gets its value from **enforced seams**, not from folders that merely
look separated. Three rules are enforced structurally, not just by convention:

1. **DbContext per module.** Each module's `Infrastructure` project owns exactly one
   `DbContext`, mapped to its own schema (`identity`, `reconciliation`,
   `schememanagement`, `insights`, `statements`, `notifications`). No project outside a
   module ever resolves that module's `DbContext` from DI — not even another module.
   Project references make this a compile-time guarantee: only `X.Infrastructure`
   references `X.Domain`'s persistence needs; nothing else can.

2. **One public seam per module: `IModule`.** Every module's `.Api` project implements
   `Paycon.SharedKernel.IModule` (`RegisterModule` + `MapEndpoints`). The Host
   (`Paycon.Api`) only ever talks to modules through this interface — see
   `ModuleRegistry.cs` and `Program.cs`. The Host never references a module's
   `Domain`/`Application`/`Infrastructure` project.

3. **Two different event types, on purpose.**
   - `IDomainEvent` (MediatR `INotification`) — raised and handled **inside** one
     module, in the same DbContext transaction (see `SaveChangesAsync` in each
     `DbContext`).
   - `IntegrationEvent` (published on **RabbitMQ**) — the only way one module tells
     another module something happened. See `Reconciliation` publishing
     `ReconciliationCompletedIntegrationEvent` and `Notifications` subscribing to it
     in `NotificationsModule.SubscribeToIntegrationEvents`. Notice `Notifications`
     re-declares the event record locally instead of referencing
     `Paycon.Modules.Reconciliation.*` — the routing key + JSON shape is the contract,
     not a shared assembly.

If a module is ever pulled out into its own service, steps 2 and 3 are already exactly
what a service boundary needs — the RabbitMQ contracts don't change, only the process
topology does.

## Solution layout

```
Paycon.sln
src/
  Host/
    Paycon.Api/                     # composition root: wires every module, owns Program.cs,
                                     # the SignalR hub, Swagger, CORS. References every
                                     # module's .Api project ONLY.
  BuildingBlocks/                   # shared, dependency-free primitives - the one
                                     # deliberate exception to module isolation
    Paycon.SharedKernel/            # Entity/AggregateRoot, IDomainEvent, Result, IModule
    Paycon.EventBus/                # IEventBus, IntegrationEvent, RabbitMqEventBus
    Paycon.Caching/                 # ICacheService over Azure Redis
    Paycon.Behaviors/                # MediatR pipeline: Logging, Validation, Caching
  Modules/
    Identity/                       # User Management: Users, Groups, Roles, Permissions
    Reconciliation/                 # Payments In/Out, Matches, Mismatches, batches
    SchemeManagement/               # Scheme/Tolerance/ExchangeRate/OperatingBank masters
    Insights/                       # Fund Provider Management, Payouts, Approval Queue
    Statements/                     # Annual / Exit member statements
    Notifications/                  # Dashboard notification feed; subscribes to other
                                     # modules' integration events
  Client/
    Paycon.Client/                  # Blazor WebAssembly app
```

Every module follows the same four-project shape:

```
Paycon.Modules.<Name>.Domain/           # entities, value objects, domain events - no EF, no MediatR package refs beyond SharedKernel
Paycon.Modules.<Name>.Application/      # CQRS commands/queries, repository interfaces, DTOs
Paycon.Modules.<Name>.Infrastructure/   # the module's OWN DbContext, EF configs, repository implementations
Paycon.Modules.<Name>.Api/              # implements IModule; minimal-API endpoints
```

`Identity` and `Reconciliation` are built out in full depth (validators, integration
events, a SignalR-backed real-time notifier abstraction) to show the pattern completely.
`SchemeManagement`, `Insights`, `Statements`, and `Notifications` follow the identical
shape at a size that matches their current screen count — extend them the same way.

## Adding a new module

1. Create the four projects (`Domain`, `Application`, `Infrastructure`, `Api`) following
   an existing module's `.csproj` references.
2. Give it its own `DbContext` with `HasDefaultSchema("<yourmodule>")`.
3. Implement `IModule` in the `Api` project.
4. Add a connection-string entry (`ConnectionStrings:<YourModule>Db`) in
   `Paycon.Api/appsettings.json`.
5. Add one line to `ModuleRegistry.AllModules` in `Paycon.Api`.
6. Add the four `.csproj` files to `Paycon.sln` (or reopen the folder in an IDE that
   supports open-folder / SDK-style projects).

Nothing else in `Program.cs` changes.

## Running locally

**Option A — zero external dependencies (in-memory database, cache, and message bus):**

```bash
dotnet run --project src/Host/Paycon.Api --environment Local
```

This uses the `Local` profile (`appsettings.Local.json`, `Infrastructure:UseInMemory:
true`), which switches all three infrastructure dependencies at once:

| Concern | Real environment | `Infrastructure:UseInMemory = true` |
|---|---|---|
| Database | Azure SQL, one schema per module | EF Core's **InMemory** provider — every module's schema (as defined by its own `OnModelCreating`) still applies; only relational-only concerns (`HasDefaultSchema`, column types, migrations history table) are silently ignored |
| Cache | Azure Cache for Redis | ASP.NET Core's in-process `IDistributedCache` (`AddDistributedMemoryCache`) |
| Messaging | RabbitMQ | `InMemoryEventBus` — publishes call subscribed handlers directly, in-process, no broker |

Each module also seeds a small amount of demo data the first time it runs in this mode
(see each module's `SeedAsync` in its `.Api` project) — enough to open Swagger or the
Blazor client and see non-empty screens immediately. `SeedAsync` is a no-op unless a
module implements it, and it never runs against a real database.

This mode is for local exploration and smoke-testing only — it doesn't replace testing
against real Azure SQL / Redis / RabbitMQ before shipping, and the in-memory event bus
in particular has none of RabbitMQ's durability or retry behavior.

**Option B — real dependencies (matches production topology):**

```bash
# 1. Start local dependencies (SQL Server, Redis, RabbitMQ)
docker compose up -d

# 2. Apply each module's migrations (from the Infrastructure project, targeting the Api's connection string)
dotnet ef database update --project src/Modules/Identity/Paycon.Modules.Identity.Infrastructure --startup-project src/Host/Paycon.Api
# ...repeat per module, or script this into a single command in your build pipeline.

# 3. Run the API (Infrastructure:UseInMemory is false by default in appsettings.json)
dotnet run --project src/Host/Paycon.Api

# 4. Run the Blazor client (separate terminal)
dotnet run --project src/Client/Paycon.Client
```

Swagger is available at `/swagger` in both `Development` and `Local`. The Blazor client
expects the API at the URL configured in
`src/Client/Paycon.Client/wwwroot/appsettings.json` (`ApiBaseUrl`,
`NotificationsHubUrl`).

## Real-time flow (SignalR)

`Paycon.Api` owns the single `NotificationsHub` (`/hubs/notifications`). Modules never
reference SignalR directly — they depend on a small interface
(`IReconciliationNotifier`, `INotificationPusher`, ...) that the Host implements against
the hub (`src/Host/Paycon.Api/Hubs/*Adapter.cs`). The Blazor client opens **one**
connection and reacts to events from any module.

## What's deliberately left as a extension point

- **Auth**: `app.UseAuthentication()/UseAuthorization()` is wired but no scheme is
  configured — plug in Entra ID / Azure AD B2C via `AddMicrosoftIdentityWebApi` (the
  `Identity` module's `Users`/`Roles`/`Permissions` model is designed to back
  authorization policies once a scheme is added).
- **File upload + virus scanning** for the Reconciliation "Payments In/Out" upload flow
  (currently a `RunReconciliationCommand` operating on already-persisted transactions).
- **File/Email Template Config masters** in `SchemeManagement` (two more entities +
  configs following the exact same pattern as `SchemeMaster`/`ExchangeRate`).
- **EF Core migrations** — not generated here since this environment has no `dotnet`
  SDK; run `dotnet ef migrations add Initial --project <Module>.Infrastructure
  --startup-project src/Host/Paycon.Api` per module once you have the SDK locally.
  (You don't need migrations at all to explore the app first — see "Running locally,
  Option A" above for the zero-dependency in-memory mode.)
