namespace ZWS.BuildingBlocks.Persistence;

/// <summary>One of these is registered per module DbContext when running against the
/// in-memory/test profile, so ZWS.Host (or a test's WebApplicationFactory) can create
/// every module's schema without EF Core migrations. Never registered against a real
/// SQL Server connection - that path uses proper migrations instead (section 26).</summary>
public interface IModuleDbInitializer
{
    Task InitializeAsync(IServiceProvider serviceProvider);
}

public class ModuleDbInitializer<TContext> : IModuleDbInitializer where TContext : Microsoft.EntityFrameworkCore.DbContext
{
    public async Task InitializeAsync(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<TContext>();
        await db.Database.EnsureCreatedAsync();
    }
}
