using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Repositories;

public interface IUserRepository
{
    Task<(IReadOnlyCollection<User> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    Task<User?> FindByEmailAsync(string email, CancellationToken cancellationToken);
    Task<bool> ExistsByEmailAsync(string email, Guid? excludeId, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<User>> GetSupervisorCandidatesAsync(CancellationToken cancellationToken);
    /// <summary>Active users only, for the Master Auth module's dev-mode login picker - see
    /// GetLoginCandidatesQuery. Not a general-purpose "list all users" method; UsersController's
    /// GetUsersQuery/SearchAsync already covers that (paged, all states, full graph).</summary>
    Task<IReadOnlyCollection<User>> GetActiveForLoginAsync(CancellationToken cancellationToken);
    /// <summary>
    /// The human-readable User ID (U-001, U-002, ...) of every user. It is the user's position in
    /// creation order - soft-deleted users keep their slot, so an ID is never reused or shifted.
    /// </summary>
    Task<IReadOnlyDictionary<Guid, string>> GetUserCodesAsync(CancellationToken cancellationToken);
    void Add(User user);
    void Remove(User user);
}
