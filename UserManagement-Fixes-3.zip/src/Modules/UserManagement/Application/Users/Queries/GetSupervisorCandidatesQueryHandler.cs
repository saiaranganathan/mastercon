using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Users.Queries;

public sealed class GetSupervisorCandidatesQueryHandler(IUserRepository userRepository)
    : IQueryHandler<GetSupervisorCandidatesQuery, IReadOnlyCollection<SupervisorOptionDto>>
{
    public async Task<Result<IReadOnlyCollection<SupervisorOptionDto>>> Handle(GetSupervisorCandidatesQuery request, CancellationToken cancellationToken)
    {
        var candidates = await userRepository.GetSupervisorCandidatesAsync(cancellationToken);
        var codes = await userRepository.GetUserCodesAsync(cancellationToken);
        var dtos = candidates
            .OrderBy(u => u.FullName)
            .Select(u => new SupervisorOptionDto(u.Id, codes.GetValueOrDefault(u.Id, string.Empty), u.FullName))
            .ToList();
        return Result.Success<IReadOnlyCollection<SupervisorOptionDto>>(dtos);
    }
}
