using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
{
    /// <summary>local@domain.tld - no spaces, a dotted domain, and an alphabetic TLD of 2+ letters.</summary>
    private const string EmailPattern = @"^[A-Za-z0-9._%+'\-]+@(?:[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,}$";

    public CreateUserCommandValidator(IUserRepository userRepository)
    {
        RuleFor(x => x.FullName)
            .NotEmpty().WithMessage("Full Name is required.")
            .Length(3, 150).WithMessage("Full Name must be between 3 and 150 characters.")
            .Matches(@"^[A-Za-z' ]+$").WithMessage("Full Name may only contain letters, spaces and an apostrophe (e.g. D'souza).");

        // Email validation: FluentValidation's EmailAddress() alone accepts things like "a@b" or
        // "name@domain" (no TLD), so a stricter pattern is applied on top of it.
        RuleFor(x => x.Email)
            .Cascade(CascadeMode.Stop)
            .NotEmpty().WithMessage("Email Address is required.")
            .MaximumLength(254).WithMessage("Email Address must be 254 characters or fewer.")
            .EmailAddress().WithMessage("Enter a valid email address (for example name@company.com).")
            .Matches(EmailPattern).WithMessage("Enter a valid email address (for example name@company.com).")
            .MustAsync(async (email, ct) => !await userRepository.ExistsByEmailAsync(email, null, ct))
            .WithMessage("A user with this email address already exists.");

        RuleFor(x => x.GroupIds).NotEmpty().WithMessage("At least one Group must be selected.");
        RuleFor(x => x.RoleIds).NotEmpty().WithMessage("At least one Role must be selected.");
        // BUS-4565: the direct list may be empty - permissions also come from the selected Roles;
        // the handler enforces "at least one permission overall".
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
        RuleFor(x => x.State).IsInEnum();
    }
}
