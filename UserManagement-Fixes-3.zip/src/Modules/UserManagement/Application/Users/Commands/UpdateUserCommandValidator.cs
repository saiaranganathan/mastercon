using FluentValidation;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class UpdateUserCommandValidator : AbstractValidator<UpdateUserCommand>
{
    public UpdateUserCommandValidator()
    {
        RuleFor(x => x.GroupIds).NotEmpty().WithMessage("At least one Group must be selected.");
        RuleFor(x => x.RoleIds).NotEmpty().WithMessage("At least one Role must be selected.");
        // BUS-4565: the direct list may be empty - permissions also come from the selected Roles;
        // the handler enforces "at least one permission overall".
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
        RuleFor(x => x.State).IsInEnum();

        // PR_UM 3.2: a user must not be able to choose themselves as their own supervisor.
        RuleFor(x => x).Must(x => x.SupervisorId is null || x.SupervisorId != x.Id)
            .WithMessage("A user cannot be their own supervisor.")
            .OverridePropertyName(nameof(UpdateUserCommand.SupervisorId));
    }
}
