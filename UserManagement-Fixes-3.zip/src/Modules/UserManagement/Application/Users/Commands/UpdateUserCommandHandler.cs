using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Messaging;
using ZWS.BuildingBlocks.Messaging.Contracts;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

public sealed class UpdateUserCommandHandler(
    IUserRepository userRepository,
    IGroupRepository groupRepository,
    IRoleRepository roleRepository,
    ISchemeReferenceService schemeReferenceService,
    IUserManagementDbContext dbContext,
    IEventBus eventBus,
    ICurrentUserService currentUser) : ICommandHandler<UpdateUserCommand>
{
    public async Task<Result> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByIdAsync(request.Id, cancellationToken);
        if (user is null)
            return Result.Failure(Error.NotFound("User.NotFound", $"User '{request.Id}' was not found."));

        if (request.SupervisorId == request.Id)
            return Result.Failure(Error.Validation("User.InvalidSupervisor", "A user cannot be their own supervisor."));

        // BUS-4564: a Terminated user cannot be brought back to Active / Inactive.
        if (user.State == UserState.Terminated && request.State != UserState.Terminated)
            return Result.Failure(Error.Validation("User.TerminatedLocked", "A terminated user cannot be reactivated."));

        var previousState = user.State.ToString();

        var groups = new List<(Guid, string)>();
        var anyGroupAllowsPlanOverride = false;
        foreach (var groupId in request.GroupIds)
        {
            var group = await groupRepository.GetByIdAsync(groupId, cancellationToken);
            if (group is null) continue;
            // BUS-4563: inactive groups cannot be newly assigned (a membership the user already
            // has in a since-deactivated group is left alone).
            if (group.State != GroupState.Active && user.Groups.All(g => g.GroupId != groupId))
                return Result.Failure(Error.Validation("User.GroupInactive", $"Group '{group.Name}' is inactive and cannot be assigned to a user."));
            groups.Add((group.Id, group.Name));
            anyGroupAllowsPlanOverride |= group.OverridePlanPermissionAtUserLevel;
        }

        // BUS-4534: plan overrides at user level are only allowed when at least one of the user's
        // Groups has "Override Plan Permission at user level" switched on - previously nothing
        // checked this, so the plan update was accepted and saved regardless.
        if (request.SchemeOverrideIds.Count > 0 && !anyGroupAllowsPlanOverride)
            return Result.Failure(Error.Validation("User.PlanOverrideNotAllowed",
                "Plans cannot be overridden at user level - none of the selected Groups allows it."));

        var roles = new List<(Guid, string)>();
        var anyRoleGrantsPermissions = false;
        foreach (var roleId in request.RoleIds)
        {
            var role = await roleRepository.GetByIdAsync(roleId, cancellationToken);
            if (role is null) continue;
            roles.Add((role.Id, role.Name));
            anyRoleGrantsPermissions |= role.Permissions.Count > 0;
        }

        // BUS-4565: see CreateUserCommandHandler - role-derived permissions count.
        if (request.Permissions.Count == 0 && !anyRoleGrantsPermissions)
            return Result.Failure(Error.Validation("User.NoPermissions", "At least one page permission must be selected."));

        // BUS-4569 / BUS-4570: Supervisor is mandatory (except SuperAdmin / SEO) and must be an
        // active user flagged as Supervisor (and never the user themself).
        User? supervisorUser = null;
        if (request.SupervisorId is { } supervisorId)
            supervisorUser = await userRepository.GetByIdAsync(supervisorId, cancellationToken);
        if (SupervisorRules.Validate(request.Id, request.SupervisorId, supervisorUser, roles.Select(r => r.Item2)) is { } supervisorError)
            return Result.Failure(supervisorError);
        var supervisorName = supervisorUser?.FullName;

        var allSchemes = await schemeReferenceService.GetActiveSchemesAsync(cancellationToken);
        var schemeOverrides = allSchemes
            .Where(s => request.SchemeOverrideIds.Contains(s.SchemeId))
            .Select(s => (s.SchemeId, s.SchemeName));

        // Snapshot the child rows being replaced BEFORE UpdateDetails clears them from the
        // navigation - needed below only to detach the change tracker's now-stale copies once
        // their rows have been deleted directly via SQL (see IUserManagementDbContext.
        // DeleteChildRowsAsync/DetachRange for why going through the change tracker for this
        // "replace all children" operation was producing DbUpdateConcurrencyException even for a
        // single, isolated request with no concurrent access at all).
        var oldGroups = user.Groups.ToList();
        var oldRoles = user.Roles.ToList();
        var oldPermissions = user.Permissions.ToList();
        var oldSchemeOverrides = user.SchemeOverrides.ToList();

        user.UpdateDetails(request.SupervisorId, supervisorName, request.IsSupervisor, request.State, groups, roles, request.Permissions, schemeOverrides);

        // Snapshot the freshly-created replacement children too - see IUserManagementDbContext.
        // AddRange for why these must be explicitly marked Added: their Id is a client-generated
        // Guid set in Create(), and being discovered only via graph-fixup from the already-tracked
        // `user` (rather than an explicit dbContext.Add call) makes EF's IsKeySet heuristic assume
        // they already exist in the database and track them as Modified instead - the actual root
        // cause of the DbUpdateConcurrencyException this module kept hitting no matter how the OLD
        // rows were removed.
        var newGroups = user.Groups.ToList();
        var newRoles = user.Roles.ToList();
        var newPermissions = user.Permissions.ToList();
        var newSchemeOverrides = user.SchemeOverrides.ToList();

        await dbContext.DeleteChildRowsAsync<UserGroupAssignment>(x => x.UserId == user.Id, cancellationToken);
        await dbContext.DeleteChildRowsAsync<UserRoleAssignment>(x => x.UserId == user.Id, cancellationToken);
        await dbContext.DeleteChildRowsAsync<UserPagePermission>(x => x.UserId == user.Id, cancellationToken);
        await dbContext.DeleteChildRowsAsync<UserSchemeOverride>(x => x.UserId == user.Id, cancellationToken);

        dbContext.DetachRange(oldGroups);
        dbContext.DetachRange(oldRoles);
        dbContext.DetachRange(oldPermissions);
        dbContext.DetachRange(oldSchemeOverrides);

        dbContext.AddRange(newGroups);
        dbContext.AddRange(newRoles);
        dbContext.AddRange(newPermissions);
        dbContext.AddRange(newSchemeOverrides);

        await dbContext.SaveChangesAsync(cancellationToken);

        if (previousState != request.State.ToString())
        {
            await eventBus.PublishAsync(
                new UserStateChangedIntegrationEvent(user.Id, user.FullName, previousState, request.State.ToString(), currentUser.IsAuthenticated ? currentUser.UserId : "system"),
                cancellationToken);
        }

        return Result.Success();
    }
}
