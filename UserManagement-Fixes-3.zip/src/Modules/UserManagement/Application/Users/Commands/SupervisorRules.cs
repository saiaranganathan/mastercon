using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Users.Commands;

/// <summary>BUS-4569 / BUS-4570: the Supervisor field rules shared by Create and Update User.</summary>
public static class SupervisorRules
{
    /// <summary>Roles whose holders do not need a supervisor.</summary>
    public static readonly string[] ExemptRoleNames = ["SuperAdmin", "SEO"];

    public static bool IsExempt(IEnumerable<string> roleNames) =>
        roleNames.Any(r => ExemptRoleNames.Contains(r, StringComparer.OrdinalIgnoreCase));

    /// <summary>
    /// Returns the first rule the selection breaks, or null when it is fine.
    /// <paramref name="userId"/> is null on create (a brand-new user cannot be their own supervisor).
    /// </summary>
    public static Error? Validate(Guid? userId, Guid? supervisorId, User? supervisor, IEnumerable<string> roleNames)
    {
        if (supervisorId is null)
            return IsExempt(roleNames)
                ? null
                : Error.Validation("User.SupervisorRequired", "Supervisor is required (not required for the SuperAdmin or SEO roles).");

        if (userId is not null && supervisorId == userId)
            return Error.Validation("User.InvalidSupervisor", "A user cannot be their own supervisor.");

        if (supervisor is null)
            return Error.Validation("User.SupervisorNotFound", "The selected supervisor does not exist.");

        if (!supervisor.IsSupervisor || supervisor.State != UserState.Active)
            return Error.Validation("User.SupervisorNotEligible", "Only active users marked as Supervisor can be selected as a supervisor.");

        return null;
    }
}
