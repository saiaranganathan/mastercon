using Microsoft.EntityFrameworkCore;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;
using ZWS.Modules.UserManagement.Infrastructure.Persistence;

namespace ZWS.Modules.UserManagement.Infrastructure.Repositories;

public sealed class UserRepository(UserManagementDbContext context) : IUserRepository
{
    private IQueryable<User> FullGraph() => context.Users
        .Include(u => u.Groups)
        .Include(u => u.Roles)
        .Include(u => u.Permissions)
        .Include(u => u.SchemeOverrides);

    public async Task<(IReadOnlyCollection<User> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken)
    {
        var query = FullGraph().AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();

            // BUS-4561: search by User ID too (U-003, u-3, "003", or the raw Guid).
            var codes = await GetUserCodesAsync(cancellationToken);
            var idMatches = codes.Where(kv => kv.Value.Contains(term, StringComparison.OrdinalIgnoreCase)).Select(kv => kv.Key).ToList();
            if (Guid.TryParse(term, out var guid)) idMatches.Add(guid);

            query = query.Where(u =>
                idMatches.Contains(u.Id) ||
                EF.Functions.Like(u.FullName, $"%{term}%") ||
                EF.Functions.Like(u.Email, $"%{term}%") ||
                u.Groups.Any(g => EF.Functions.Like(g.GroupName, $"%{term}%")) ||
                u.Roles.Any(r => EF.Functions.Like(r.RoleName, $"%{term}%")));
        }

        query = (request.SortBy?.ToLowerInvariant(), request.SortDescending) switch
        {
            ("fullname", true) => query.OrderByDescending(u => u.FullName),
            ("email", false) => query.OrderBy(u => u.Email),
            ("email", true) => query.OrderByDescending(u => u.Email),
            ("createdat", true) => query.OrderByDescending(u => u.CreatedAt),
            ("createdat", false) => query.OrderBy(u => u.CreatedAt),
            _ => query.OrderBy(u => u.FullName)
        };

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToListAsync(cancellationToken);
        return (items, totalCount);
    }

    public Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken) =>
        FullGraph().FirstOrDefaultAsync(u => u.Id == id, cancellationToken);

    public Task<User?> FindByEmailAsync(string email, CancellationToken cancellationToken) =>
        FullGraph().FirstOrDefaultAsync(u => u.Email == email, cancellationToken);

    public Task<bool> ExistsByEmailAsync(string email, Guid? excludeId, CancellationToken cancellationToken) =>
        context.Users.AnyAsync(u => u.Email == email && (excludeId == null || u.Id != excludeId), cancellationToken);

    public async Task<IReadOnlyCollection<User>> GetActiveForLoginAsync(CancellationToken cancellationToken) =>
        await context.Users
            .Where(u => u.State == UserState.Active)
            .OrderBy(u => u.FullName)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

    public async Task<IReadOnlyDictionary<Guid, string>> GetUserCodesAsync(CancellationToken cancellationToken)
    {
        // IgnoreQueryFilters: deleted users still occupy their number so IDs stay stable.
        var ids = await context.Users.IgnoreQueryFilters()
            .OrderBy(u => u.CreatedAt).ThenBy(u => u.Id)
            .Select(u => u.Id)
            .ToListAsync(cancellationToken);

        var codes = new Dictionary<Guid, string>(ids.Count);
        for (var i = 0; i < ids.Count; i++) codes[ids[i]] = $"U-{i + 1:000}";
        return codes;
    }

    public async Task<IReadOnlyCollection<User>> GetSupervisorCandidatesAsync(CancellationToken cancellationToken) =>
        await context.Users
            .Where(u => u.IsSupervisor && u.State == UserState.Active)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

    public void Add(User user) => context.Users.Add(user);
    public void Remove(User user) => context.Users.Remove(user);
}
