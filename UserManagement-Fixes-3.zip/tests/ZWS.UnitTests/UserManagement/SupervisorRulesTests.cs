using FluentAssertions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Users.Commands;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>BUS-4569 (mandatory unless SuperAdmin / SEO) and BUS-4570 (eligibility, not self).</summary>
public class SupervisorRulesTests
{
    private static User MakeUser(bool isSupervisor, UserState state) =>
        User.Create("Anna Aiden", "anna@example.com", null, null, isSupervisor, state, [], [], [], []);

    [Fact]
    public void Validate_WithoutSupervisor_ShouldFailForOrdinaryRoles()
    {
        var error = SupervisorRules.Validate(null, null, null, ["FinanceAnalyst"]);

        error.Should().NotBeNull();
        error!.Code.Should().Be("User.SupervisorRequired");
    }

    [Theory]
    [InlineData("SuperAdmin")]
    [InlineData("superadmin")]
    [InlineData("SEO")]
    public void Validate_WithoutSupervisor_ShouldPassForExemptRoles(string role) =>
        SupervisorRules.Validate(null, null, null, ["FinanceAnalyst", role]).Should().BeNull();

    [Fact]
    public void Validate_WhenSupervisorIsSelf_ShouldFail()
    {
        var id = Guid.NewGuid();

        var error = SupervisorRules.Validate(id, id, MakeUser(true, UserState.Active), ["FinanceAnalyst"]);

        error!.Code.Should().Be("User.InvalidSupervisor");
    }

    [Theory]
    [InlineData(false, UserState.Active)]   // not flagged as supervisor
    [InlineData(true, UserState.Inactive)]  // flagged but inactive
    [InlineData(true, UserState.Terminated)]
    public void Validate_WhenSupervisorNotEligible_ShouldFail(bool isSupervisor, UserState state)
    {
        var supervisor = MakeUser(isSupervisor, state);

        var error = SupervisorRules.Validate(Guid.NewGuid(), supervisor.Id, supervisor, ["FinanceAnalyst"]);

        error!.Code.Should().Be("User.SupervisorNotEligible");
        error.Type.Should().Be(ErrorType.Validation);
    }

    [Fact]
    public void Validate_WhenSupervisorIsActiveAndFlagged_ShouldPass()
    {
        var supervisor = MakeUser(true, UserState.Active);

        SupervisorRules.Validate(Guid.NewGuid(), supervisor.Id, supervisor, ["FinanceAnalyst"]).Should().BeNull();
    }
}
