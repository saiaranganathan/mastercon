using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using ZWS.Modules.Paycon.QaManagement.Application.Abstractions;

namespace ZWS.Modules.Paycon.QaManagement.Infrastructure;

/// <summary>
/// Runs [ANNUAL].[Generate_AnnualStatement] against the Paycon database
/// (ConnectionStrings:Paycon). The procedure takes @currentDate DATE, @monthOffset INT,
/// @dayOffset INT, @isTruncate BIT and returns no result set. Parameters are always bound - never concatenated.
/// </summary>
public sealed class SqlAnnualStatementGenerationRunner(IConfiguration configuration) : IAnnualStatementGenerationRunner
{
    // The procedure can touch every employee, so allow far longer than the 30s ADO.NET default.
    private const int CommandTimeoutSeconds = 600;

    public async Task RunAsync(DateOnly currentDate, int monthOffset, int dayOffset, bool isTruncate, CancellationToken cancellationToken)
    {
        var connectionString = configuration.GetConnectionString("Paycon");
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new AnnualStatementGenerationException(
                "QaManagement.NotConfigured",
                "The Paycon SQL Server connection string is not configured, so the stored procedure cannot be run in this environment.");

        try
        {
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync(cancellationToken);

            await using var command = connection.CreateCommand();
            command.CommandText = "[ANNUAL].[Generate_AnnualStatement]";
            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = CommandTimeoutSeconds;
            command.Parameters.Add(new SqlParameter("@currentDate", SqlDbType.Date) { Value = currentDate.ToDateTime(TimeOnly.MinValue) });
            command.Parameters.Add(new SqlParameter("@monthOffset", SqlDbType.Int) { Value = monthOffset });
            command.Parameters.Add(new SqlParameter("@dayOffset", SqlDbType.Int) { Value = dayOffset });
            command.Parameters.Add(new SqlParameter("@isTruncate", SqlDbType.Bit) { Value = isTruncate });

            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (SqlException ex)
        {
            throw new AnnualStatementGenerationException(
                "QaManagement.ProcedureFailed",
                $"SQL Server rejected the stored procedure call: {ex.Message}",
                ex);
        }
    }
}
