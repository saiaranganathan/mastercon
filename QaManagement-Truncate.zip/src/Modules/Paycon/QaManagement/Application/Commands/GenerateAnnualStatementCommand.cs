using ZWS.BuildingBlocks.Application.Abstractions;

namespace ZWS.Modules.Paycon.QaManagement.Application.Commands;

/// <summary>
/// QA-only: runs [ANNUAL].[Generate_AnnualStatement] with the supplied values.
/// MonthOffset and DayOffset are mutually exclusive - at most one may be non-zero.
/// IsTruncate (the @isTruncate BIT parameter) asks the procedure to truncate / purge the
/// existing generated annual statements before generating.
/// </summary>
public sealed record GenerateAnnualStatementCommand(DateOnly CurrentDate, int MonthOffset, int DayOffset, bool IsTruncate = false) : ICommand;
