using FluentAssertions;
using Moq;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Application.Roles.Commands;
using ZWS.Modules.UserManagement.Domain;
using Xunit;

namespace ZWS.UnitTests.UserManagement;

/// <summary>The Role Name must be unique across all roles (not just within a Group).</summary>
public class CreateRoleCommandValidatorTests
{
    private readonly Mock<IRoleRepository> _roles = new();
    private readonly Mock<IGroupRepository> _groups = new();
    private static readonly PagePermissionAssignment[] Permissions = [new("statements.annual-statements", AccessLevel.View)];

    private CreateRoleCommandValidator CreateValidator(Guid groupId)
    {
        var group = Group.Create("Finance", GroupState.Active, false, []);
        _groups.Setup(g => g.GetByIdAsync(groupId, It.IsAny<CancellationToken>())).ReturnsAsync(group);
        return new CreateRoleCommandValidator(_roles.Object, _groups.Object);
    }

    [Fact]
    public async Task Validate_WhenNameAlreadyUsedByAnotherRole_ShouldFailWithUniqueMessage()
    {
        var groupId = Guid.NewGuid();
        _roles.Setup(r => r.IsNameTakenAsync("FinanceAnalyst", null, It.IsAny<CancellationToken>())).ReturnsAsync(true);

        var result = await CreateValidator(groupId).ValidateAsync(
            new CreateRoleCommand("FinanceAnalyst", groupId, null, RoleState.Active, Permissions));

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(CreateRoleCommand.Name) && e.ErrorMessage.Contains("must be unique"));
    }

    [Fact]
    public async Task Validate_WhenNameIsFree_ShouldNotReportANameError()
    {
        var groupId = Guid.NewGuid();
        _roles.Setup(r => r.IsNameTakenAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>())).ReturnsAsync(false);

        var result = await CreateValidator(groupId).ValidateAsync(
            new CreateRoleCommand("FinanceAnalyst", groupId, null, RoleState.Active, Permissions));

        result.Errors.Should().NotContain(e => e.ErrorMessage.Contains("must be unique"));
    }
}
