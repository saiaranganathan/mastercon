namespace ZWS.BuildingBlocks.Caching;

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);

    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);

    Task RemoveAsync(string key, CancellationToken cancellationToken = default);

    Task RemoveByPrefixAsync(string prefix, CancellationToken cancellationToken = default);

    /// <summary>Cache-aside helper: return the cached value, or compute + cache it via <paramref name="factory"/>.</summary>
    Task<T> GetOrCreateAsync<T>(
        string key,
        Func<CancellationToken, Task<T>> factory,
        TimeSpan? expiration = null,
        CancellationToken cancellationToken = default);
}

public static class CacheKeys
{
    public const string ApplicationHubCards = "zws:hub:applications";
    /// <summary>Prefix shared by every per-permission-set sidebar cache entry - clear it whenever a navigation item changes.</summary>
    public const string PayconNavigationPrefix = "zws:paycon:navigation:";
    public static string PayconNavigation(string? permissionsHash = null) => $"zws:paycon:navigation:{permissionsHash ?? "all"}";
    public static string PayconDashboard(string userId) => $"zws:paycon:dashboard:{userId}";
    public static string SchemeReferenceData => "zws:paycon:schemes:reference";
}
