using FluentValidation;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.BuildingBlocks.Caching;
using ZWS.Modules.Paycon.Navigation.Application.Dtos;
using ZWS.Modules.Paycon.Navigation.Application.Repositories;
using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Application.Admin;

// ---------------------------------------------------------------------------------------------
// User Management > Permission tab: list / edit / soft-delete the navigation items.
// Edits and deletes clear the cached per-user sidebar trees (see GetPayconNavigationQuery) so the
// change shows up on the next navigation request instead of after the 30-minute cache expiry.
// ---------------------------------------------------------------------------------------------

/// <summary>All non-deleted items of one application (default PAYCON), inactive and hidden ones
/// included, flattened depth-first with an indent Level.</summary>
public sealed record GetNavigationAdminItemsQuery(string ApplicationCode) : IQuery<IReadOnlyCollection<NavigationAdminItemDto>>;

public sealed class GetNavigationAdminItemsQueryHandler(INavigationItemRepository repository)
    : IQueryHandler<GetNavigationAdminItemsQuery, IReadOnlyCollection<NavigationAdminItemDto>>
{
    public async Task<Result<IReadOnlyCollection<NavigationAdminItemDto>>> Handle(GetNavigationAdminItemsQuery request, CancellationToken cancellationToken)
    {
        var all = await repository.GetAllAsync(NormalizeCode(request.ApplicationCode), cancellationToken);
        var ids = all.Select(i => i.Id).ToHashSet();
        var result = new List<NavigationAdminItemDto>(all.Count);

        // Depth-first from the roots; an item whose parent is missing (e.g. the parent was soft
        // deleted) is treated as a root rather than silently dropped.
        void Walk(Guid? parentId, int level)
        {
            var children = all
                .Where(i => parentId is null ? (i.ParentId is null || !ids.Contains(i.ParentId.Value)) : i.ParentId == parentId)
                .OrderBy(i => i.DisplayOrder)
                .ThenBy(i => i.Name, StringComparer.OrdinalIgnoreCase);
            foreach (var item in children)
            {
                result.Add(new NavigationAdminItemDto(item.Id, item.ParentId, item.ApplicationCode, item.Name, item.Route, item.DisplayOrder, item.IsActive, item.IsVisible, level));
                Walk(item.Id, level + 1);
            }
        }

        Walk(null, 0);
        return Result.Success<IReadOnlyCollection<NavigationAdminItemDto>>(result);
    }

    internal static string NormalizeCode(string? code) => string.IsNullOrWhiteSpace(code) ? "PAYCON" : code.Trim().ToUpperInvariant();
}

/// <summary>Only the Name, DisplayOrder, IsActive and IsVisible of an item can be edited.</summary>
public sealed record UpdateNavigationItemCommand(Guid Id, string Name, int DisplayOrder, bool IsActive, bool IsVisible) : ICommand;

public sealed class UpdateNavigationItemCommandValidator : AbstractValidator<UpdateNavigationItemCommand>
{
    public UpdateNavigationItemCommandValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Navigation Name is required.")
            .MaximumLength(150).WithMessage("Navigation Name must be 150 characters or fewer.");
        RuleFor(x => x.DisplayOrder)
            .InclusiveBetween(0, 9999).WithMessage("Display Order must be a whole number between 0 and 9999.");
    }
}

public sealed class UpdateNavigationItemCommandHandler(INavigationItemRepository repository, ICacheService cache)
    : ICommandHandler<UpdateNavigationItemCommand>
{
    public async Task<Result> Handle(UpdateNavigationItemCommand request, CancellationToken cancellationToken)
    {
        var item = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (item is null)
            return Result.Failure(Error.NotFound("Navigation.NotFound", "The navigation item was not found (it may have been deleted)."));

        item.UpdateDetails(request.Name.Trim(), request.DisplayOrder, request.IsActive, request.IsVisible);
        await repository.SaveChangesAsync(cancellationToken);
        await cache.RemoveByPrefixAsync(CacheKeys.PayconNavigationPrefix, cancellationToken);
        return Result.Success();
    }
}

/// <summary>Soft delete. The item's descendants go with it - a child without its parent could
/// never be reached from the sidebar anyway, and leaving it behind would resurface as a stray
/// top-level row on the admin screen.</summary>
public sealed record DeleteNavigationItemCommand(Guid Id) : ICommand;

public sealed class DeleteNavigationItemCommandHandler(INavigationItemRepository repository, ICacheService cache)
    : ICommandHandler<DeleteNavigationItemCommand>
{
    public async Task<Result> Handle(DeleteNavigationItemCommand request, CancellationToken cancellationToken)
    {
        var item = await repository.GetByIdAsync(request.Id, cancellationToken);
        if (item is null)
            return Result.Failure(Error.NotFound("Navigation.NotFound", "The navigation item was not found (it may already have been deleted)."));

        var all = await repository.GetAllTrackedAsync(item.ApplicationCode, cancellationToken);
        var toDelete = new List<NavigationItem> { all.FirstOrDefault(i => i.Id == item.Id) ?? item };
        for (var i = 0; i < toDelete.Count; i++)
            toDelete.AddRange(all.Where(c => c.ParentId == toDelete[i].Id && toDelete.All(d => d.Id != c.Id)).ToList());

        foreach (var doomed in toDelete) repository.Remove(doomed);

        await repository.SaveChangesAsync(cancellationToken);
        await cache.RemoveByPrefixAsync(CacheKeys.PayconNavigationPrefix, cancellationToken);
        return Result.Success();
    }
}
