namespace ZWS.Modules.Paycon.Navigation.Application.Dtos;

/// <summary>
/// One row of the User Management > Permission tab. Unlike <see cref="NavigationItemDto"/> (the
/// pruned sidebar tree) this is FLAT and includes inactive / hidden items, ordered depth-first so
/// a child always follows its parent; Level (0 = top level) is what the UI indents by.
/// </summary>
public sealed record NavigationAdminItemDto(
    Guid Id,
    Guid? ParentId,
    string ApplicationCode,
    string Name,
    string? Route,
    int DisplayOrder,
    bool IsActive,
    bool IsVisible,
    int Level);
