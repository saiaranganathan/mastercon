using ZWS.Modules.Paycon.Navigation.Domain;

namespace ZWS.Modules.Paycon.Navigation.Application.Repositories;

public interface INavigationItemRepository
{
    /// <summary>The sidebar tree source: ONLY items that are active and visible (soft-deleted rows are
    /// excluded by the DbContext's global query filter). A child of an inactive/hidden parent is
    /// therefore never reachable when the tree is built from the top.</summary>
    Task<IReadOnlyCollection<NavigationItem>> GetTreeAsync(string applicationCode, CancellationToken cancellationToken);

    /// <summary>Every non-deleted item of the application, including inactive / hidden ones -
    /// backs the admin screen. Read-only (AsNoTracking).</summary>
    Task<IReadOnlyCollection<NavigationItem>> GetAllAsync(string applicationCode, CancellationToken cancellationToken);

    /// <summary>Tracked load of the application's non-deleted items - for edits / cascading deletes.</summary>
    Task<IReadOnlyCollection<NavigationItem>> GetAllTrackedAsync(string applicationCode, CancellationToken cancellationToken);

    Task<NavigationItem?> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    void Add(NavigationItem item);

    /// <summary>Soft delete (AuditableEntitySaveChangesInterceptor turns the delete into IsDeleted = true).</summary>
    void Remove(NavigationItem item);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
