using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.Navigation.Application.Admin;

namespace ZWS.Modules.Paycon.Navigation.Presentation.Controllers;

/// <summary>
/// Admin API behind Master's User Management > Permission tab. Master's UserManagement module
/// calls it server-to-server, forwarding the signed-in user's JWT, so the same permission claims
/// are enforced here: View to read, Edit to change or delete.
/// </summary>
[ApiController]
[Route("api/paycon/navigation/admin")]
[RequirePermission("settings.user-management.permissions")]
public sealed class NavigationAdminController(ISender sender) : ControllerBase
{
    [HttpGet("items")]
    public async Task<IActionResult> GetItems([FromQuery] string? applicationCode, CancellationToken cancellationToken) =>
        (await sender.Send(new GetNavigationAdminItemsQuery(applicationCode ?? "PAYCON"), cancellationToken)).ToActionResult();

    [HttpPut("items/{id:guid}")]
    [RequirePermission("settings.user-management.permissions", PermissionAccess.Edit)]
    public async Task<IActionResult> UpdateItem(Guid id, [FromBody] UpdateNavigationItemRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateNavigationItemCommand(id, request.Name, request.DisplayOrder, request.IsActive, request.IsVisible), cancellationToken)).ToActionResult();

    [HttpDelete("items/{id:guid}")]
    [RequirePermission("settings.user-management.permissions", PermissionAccess.Edit)]
    public async Task<IActionResult> DeleteItem(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteNavigationItemCommand(id), cancellationToken)).ToActionResult();
}

public sealed record UpdateNavigationItemRequest(string Name, int DisplayOrder, bool IsActive, bool IsVisible);
