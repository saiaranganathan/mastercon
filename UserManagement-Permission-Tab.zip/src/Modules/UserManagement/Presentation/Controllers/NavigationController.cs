using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.UserManagement.Application.Navigation;

namespace ZWS.Modules.UserManagement.Presentation.Controllers;

/// <summary>/settings/user-management -> Permission tab: manage the navigation items (name, display
/// order, active / visible flags, soft delete). The items live in Paycon's database; this
/// controller proxies to Paycon's own admin API, forwarding the caller's JWT.</summary>
[ApiController]
[Route("api/paycon/settings/user-management/navigation")]
[RequirePermission("settings.user-management.permissions")]
public sealed class NavigationController(ISender sender) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetItems([FromQuery] string? applicationCode, CancellationToken cancellationToken) =>
        (await sender.Send(new GetNavigationItemsQuery(applicationCode ?? "PAYCON"), cancellationToken)).ToActionResult();

    [HttpPut("{id:guid}")]
    [RequirePermission("settings.user-management.permissions", PermissionAccess.Edit)]
    public async Task<IActionResult> UpdateItem(Guid id, [FromBody] UpdateNavigationItemRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new UpdateNavigationItemCommand(id, request.Name, request.DisplayOrder, request.IsActive, request.IsVisible), cancellationToken)).ToActionResult();

    [HttpDelete("{id:guid}")]
    [RequirePermission("settings.user-management.permissions", PermissionAccess.Edit)]
    public async Task<IActionResult> DeleteItem(Guid id, CancellationToken cancellationToken) =>
        (await sender.Send(new DeleteNavigationItemCommand(id), cancellationToken)).ToActionResult();
}

public sealed record UpdateNavigationItemRequest(string Name, int DisplayOrder, bool IsActive, bool IsVisible);
