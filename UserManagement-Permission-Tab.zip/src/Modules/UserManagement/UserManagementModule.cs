using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ZWS.BuildingBlocks.Persistence;
using ZWS.Modules.UserManagement.Application.Abstractions;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Infrastructure.ExternalServices;
using ZWS.Modules.UserManagement.Infrastructure.Persistence;
using ZWS.Modules.UserManagement.Infrastructure.Repositories;

namespace ZWS.Modules.UserManagement;

public static class UserManagementModule
{
    public static IServiceCollection AddUserManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        // Own connection string now that UserManagement is a Master module, not a Paycon one -
        // it no longer shares Paycon's "Paycon" connection string / database.
        var connectionString = configuration.GetConnectionString("UserManagement");

        services.AddDbContext<UserManagementDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetRequiredService<AuditableEntitySaveChangesInterceptor>());
            if (string.IsNullOrWhiteSpace(connectionString))
                options.UseSqlite("Data Source=user_management.dev.db");
            else
                options.UseSqlServer(connectionString, sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "user_management"));
        });

        services.AddScoped<IUserManagementDbContext>(sp => sp.GetRequiredService<UserManagementDbContext>());
        services.AddScoped<IGroupRepository, GroupRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IUserRepository, UserRepository>();

        // Typed HttpClient into Paycon's own API (see SchemeReferenceService) - UserManagement
        // and SchemeManagement are two different App Services now, so this replaces what used
        // to be an in-process MediatR call. Falls back to the ambient BaseAddress (none - see
        // SchemeReferenceService's try/catch) if PayconApiBaseUrl isn't configured, e.g. in tests.
        services.AddHttpClient<ISchemeReferenceService, SchemeReferenceService>((sp, client) =>
        {
            var payconApiBaseUrl = configuration["PayconApiBaseUrl"];
            if (!string.IsNullOrWhiteSpace(payconApiBaseUrl))
                client.BaseAddress = new Uri(payconApiBaseUrl);
        })
        .ConfigurePrimaryHttpMessageHandler(CreatePayconHandler);

        // Same Paycon base address + handler, but for the navigation admin calls behind the
        // Permission tab. That API is protected, so NavigationAdminService forwards the signed-in
        // user's JWT (via IHttpContextAccessor) instead of calling anonymously.
        services.AddHttpContextAccessor();
        services.AddHttpClient<INavigationAdminService, NavigationAdminService>((sp, client) =>
        {
            var payconApiBaseUrl = configuration["PayconApiBaseUrl"];
            if (!string.IsNullOrWhiteSpace(payconApiBaseUrl))
                client.BaseAddress = new Uri(payconApiBaseUrl);
        })
        .ConfigurePrimaryHttpMessageHandler(CreatePayconHandler);

        return services;
    }

    /// <summary>Primary handler for every typed HttpClient that calls Paycon's API server-to-server.</summary>
    private static HttpClientHandler CreatePayconHandler(IServiceProvider sp)
    {
        var handler = new HttpClientHandler();

        // Root cause of "SSL connection could not be established... UntrustedRoot" here:
        // this is Master.Host calling Paycon's Host directly over HTTPS, server-to-server -
        // its own independent TLS handshake, validated against the OS certificate trust
        // store, completely separate from the browser's. `dotnet dev-certs https --trust`
        // (run once per machine) gets the *browser* to trust ASP.NET Core's self-signed
        // localhost dev certificate for ZWS.Web/Master.Web's own calls to their Host - it
        // does NOT make a plain HttpClient inside another ASP.NET Core process trust that
        // same certificate for a call like this one; on many dev machines (or whenever the
        // dev cert has been regenerated/expired) that chain validation still fails here even
        // after trusting it for the browser. SchemeReferenceService's own try/catch turns
        // that failure into an empty list rather than crashing the Users/Groups screen, but
        // the practical effect was the "Assigned Plans" picker silently showing nothing.
        //
        // Bypassing certificate validation only for Development, and only on this one
        // internal Paycon-reference HttpClient (not app-wide), is the standard fix for this -
        // see https://learn.microsoft.com/aspnet/core/security/enforcing-ssl#trust-the-aspnet-core-https-development-certificate.
        // Production's own PayconApiBaseUrl (appsettings.json) is a real https:// host with a
        // real, CA-issued certificate, and IsDevelopment() is false there, so this callback
        // is never installed outside local development.
        if (sp.GetRequiredService<IHostEnvironment>().IsDevelopment())
        {
            handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
        }

        return handler;
    }

    public static async Task SeedUserManagementModuleAsync(this IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<UserManagementDbContext>();
        await UserManagementDbContextSeed.SeedAsync(context, cancellationToken);
    }
}
