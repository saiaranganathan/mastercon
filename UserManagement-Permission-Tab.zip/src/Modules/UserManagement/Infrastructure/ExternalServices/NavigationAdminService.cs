using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Infrastructure.ExternalServices;

/// <summary>
/// Calls Paycon's navigation admin API (api/paycon/navigation/admin/...) on behalf of the
/// signed-in user: the incoming request's Authorization header is forwarded, because those
/// endpoints are protected with the caller's own permission claims. The HttpClient's BaseAddress
/// is "PayconApiBaseUrl" (see AddUserManagementModule).
/// </summary>
public sealed class NavigationAdminService(HttpClient http, IHttpContextAccessor httpContextAccessor, ILogger<NavigationAdminService> logger)
    : INavigationAdminService
{
    private const string Route = "api/paycon/navigation/admin/items";
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<Result<IReadOnlyCollection<NavigationItemAdminDto>>> GetItemsAsync(string applicationCode, CancellationToken cancellationToken)
    {
        try
        {
            using var request = CreateRequest(HttpMethod.Get, $"{Route}?applicationCode={Uri.EscapeDataString(applicationCode)}");
            using var response = await http.SendAsync(request, cancellationToken);
            if (!response.IsSuccessStatusCode)
                return Result.Failure<IReadOnlyCollection<NavigationItemAdminDto>>(await ToErrorAsync(response, cancellationToken));

            var items = await response.Content.ReadFromJsonAsync<List<NavigationItemAdminDto>>(JsonOptions, cancellationToken) ?? [];
            return Result.Success<IReadOnlyCollection<NavigationItemAdminDto>>(items);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not reach Paycon's navigation admin API.");
            return Result.Failure<IReadOnlyCollection<NavigationItemAdminDto>>(Unreachable());
        }
    }

    public async Task<Result> UpdateItemAsync(Guid id, string name, int displayOrder, bool isActive, bool isVisible, CancellationToken cancellationToken)
    {
        try
        {
            using var request = CreateRequest(HttpMethod.Put, $"{Route}/{id}");
            request.Content = JsonContent.Create(new { Name = name, DisplayOrder = displayOrder, IsActive = isActive, IsVisible = isVisible }, options: JsonOptions);
            using var response = await http.SendAsync(request, cancellationToken);
            return response.IsSuccessStatusCode ? Result.Success() : Result.Failure(await ToErrorAsync(response, cancellationToken));
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not reach Paycon's navigation admin API.");
            return Result.Failure(Unreachable());
        }
    }

    public async Task<Result> DeleteItemAsync(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            using var request = CreateRequest(HttpMethod.Delete, $"{Route}/{id}");
            using var response = await http.SendAsync(request, cancellationToken);
            return response.IsSuccessStatusCode ? Result.Success() : Result.Failure(await ToErrorAsync(response, cancellationToken));
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not reach Paycon's navigation admin API.");
            return Result.Failure(Unreachable());
        }
    }

    private HttpRequestMessage CreateRequest(HttpMethod method, string uri)
    {
        var request = new HttpRequestMessage(method, uri);
        var authorization = httpContextAccessor.HttpContext?.Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(authorization) && AuthenticationHeaderValue.TryParse(authorization, out var header))
            request.Headers.Authorization = header;
        return request;
    }

    private static Error Unreachable() =>
        Error.Validation("Navigation.Unreachable", "The navigation service (Paycon) could not be reached. Please try again in a moment.");

    private sealed record PayconApiError(string? Message);

    private static async Task<Error> ToErrorAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        string? message = null;
        try
        {
            message = (await response.Content.ReadFromJsonAsync<PayconApiError>(JsonOptions, cancellationToken))?.Message;
        }
        catch
        {
            // Not an ApiError body (e.g. a bare 401/403) - use the status-based message below.
        }

        return response.StatusCode switch
        {
            HttpStatusCode.NotFound => Error.NotFound("Navigation.NotFound", message ?? "The navigation item was not found."),
            HttpStatusCode.BadRequest => Error.Validation("Navigation.Invalid", message ?? "The request was not valid."),
            HttpStatusCode.Conflict => Error.Conflict("Navigation.Conflict", message ?? "The request conflicts with the current state."),
            HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized =>
                Error.Forbidden("Navigation.Forbidden", message ?? "You do not have permission to perform this action."),
            _ => Error.Validation("Navigation.Failed", message ?? $"The navigation service returned an error ({(int)response.StatusCode}).")
        };
    }
}
