using FluentValidation;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Navigation;

// User Management > Permission tab. The navigation items live in Paycon's database, so these
// handlers are thin: validate here (fast, friendly messages), then delegate to
// INavigationAdminService, which calls Paycon with the caller's JWT.

public sealed record GetNavigationItemsQuery(string ApplicationCode) : IQuery<IReadOnlyCollection<NavigationItemAdminDto>>;

public sealed class GetNavigationItemsQueryHandler(INavigationAdminService service)
    : IQueryHandler<GetNavigationItemsQuery, IReadOnlyCollection<NavigationItemAdminDto>>
{
    public Task<Result<IReadOnlyCollection<NavigationItemAdminDto>>> Handle(GetNavigationItemsQuery request, CancellationToken cancellationToken) =>
        service.GetItemsAsync(string.IsNullOrWhiteSpace(request.ApplicationCode) ? "PAYCON" : request.ApplicationCode.Trim(), cancellationToken);
}

/// <summary>Only Name, DisplayOrder, IsActive and IsVisible can be edited.</summary>
public sealed record UpdateNavigationItemCommand(Guid Id, string Name, int DisplayOrder, bool IsActive, bool IsVisible) : ICommand;

public sealed class UpdateNavigationItemCommandValidator : AbstractValidator<UpdateNavigationItemCommand>
{
    public UpdateNavigationItemCommandValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Navigation Name is required.")
            .MaximumLength(150).WithMessage("Navigation Name must be 150 characters or fewer.");
        RuleFor(x => x.DisplayOrder)
            .InclusiveBetween(0, 9999).WithMessage("Display Order must be a whole number between 0 and 9999.");
    }
}

public sealed class UpdateNavigationItemCommandHandler(INavigationAdminService service) : ICommandHandler<UpdateNavigationItemCommand>
{
    public Task<Result> Handle(UpdateNavigationItemCommand request, CancellationToken cancellationToken) =>
        service.UpdateItemAsync(request.Id, request.Name.Trim(), request.DisplayOrder, request.IsActive, request.IsVisible, cancellationToken);
}

/// <summary>Soft delete (the item's children go with it).</summary>
public sealed record DeleteNavigationItemCommand(Guid Id) : ICommand;

public sealed class DeleteNavigationItemCommandHandler(INavigationAdminService service) : ICommandHandler<DeleteNavigationItemCommand>
{
    public Task<Result> Handle(DeleteNavigationItemCommand request, CancellationToken cancellationToken) =>
        service.DeleteItemAsync(request.Id, cancellationToken);
}
