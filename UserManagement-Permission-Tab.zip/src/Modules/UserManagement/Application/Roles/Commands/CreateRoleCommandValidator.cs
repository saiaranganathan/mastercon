using FluentValidation;
using ZWS.Modules.UserManagement.Application.Repositories;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Roles.Commands;

public sealed class CreateRoleCommandValidator : AbstractValidator<CreateRoleCommand>
{
    public CreateRoleCommandValidator(IRoleRepository roleRepository, IGroupRepository groupRepository)
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Role Name is required.")
            .Matches("^[A-Za-z0-9]+$").WithMessage("Role Name must be alphanumeric only.")
            .Length(4, 150).WithMessage("Role Name must be between 4 and 150 characters.");

        RuleFor(x => x.GroupId)
            .Cascade(CascadeMode.Stop)
            .NotEmpty().WithMessage("Group is required.")
            .MustAsync(async (id, ct) => await groupRepository.GetByIdAsync(id, ct) is not null)
            .WithMessage("Selected Group does not exist.")
            // BUS-4542: an Inactive group must never be associated with a (new) role.
            .MustAsync(async (id, ct) => (await groupRepository.GetByIdAsync(id, ct))?.State == GroupState.Active)
            .WithMessage("Selected Group is inactive. Choose an active Group.");

        // The Role Name must be unique across all roles (case-insensitive), whichever Group they belong to.
        RuleFor(x => x.Name)
            .MustAsync(async (name, ct) => !await roleRepository.IsNameTakenAsync(name.Trim(), null, ct))
            .When(x => !string.IsNullOrWhiteSpace(x.Name))
            .WithMessage(x => $"Role Name must be unique. A role named '{x.Name.Trim()}' already exists.");

        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.State).IsInEnum();
        RuleFor(x => x.Permissions).NotEmpty().WithMessage("At least one page permission must be selected.");
        RuleForEach(x => x.Permissions).ChildRules(page =>
        {
            page.RuleFor(p => p.PageKey).Must(PermissionPageCatalog.IsValidKey).WithMessage("Unknown permission page.");
            page.RuleFor(p => p.Access).IsInEnum();
        });
    }
}
