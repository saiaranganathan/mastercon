namespace ZWS.Modules.UserManagement.Application.Dtos;

/// <summary>One navigation item as shown on the Permission tab (see Paycon's NavigationAdminItemDto).
/// Level is the indent depth - 0 for a top-level item, 1 for its children, and so on.</summary>
public sealed record NavigationItemAdminDto(
    Guid Id,
    Guid? ParentId,
    string ApplicationCode,
    string Name,
    string? Route,
    int DisplayOrder,
    bool IsActive,
    bool IsVisible,
    int Level);
