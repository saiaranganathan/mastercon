using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Repositories;

/// <summary>
/// UserManagement's window into the navigation items, which live in Paycon's database (the
/// Paycon Navigation module). Master and Paycon are separate App Services, so - like
/// <see cref="ISchemeReferenceService"/> - this is an HTTP call to Paycon's API. Unlike the scheme
/// reference call it is NOT anonymous: the signed-in user's JWT is forwarded, so Paycon enforces
/// the same "settings.user-management.permissions" View / Edit claims. Failures come back as a
/// failed <see cref="Result"/> (with the right error type) rather than an empty list, so the UI
/// can tell "Paycon is unreachable" from "no navigation items".
/// </summary>
public interface INavigationAdminService
{
    Task<Result<IReadOnlyCollection<NavigationItemAdminDto>>> GetItemsAsync(string applicationCode, CancellationToken cancellationToken);
    Task<Result> UpdateItemAsync(Guid id, string name, int displayOrder, bool isActive, bool isVisible, CancellationToken cancellationToken);
    Task<Result> DeleteItemAsync(Guid id, CancellationToken cancellationToken);
}
