using ZWS.Modules.UserManagement.Application.Dtos;

namespace ZWS.Modules.UserManagement.Application.Repositories;

/// <summary>
/// UserManagement's window into Paycon's SchemeManagement module. UserManagement lives in the
/// Master app now; SchemeManagement stays in Paycon - a different App Service - so this is
/// implemented in Infrastructure as an HTTP call to Paycon's public API rather than the
/// in-process MediatR query it used to be when both lived in the same process.
/// </summary>
public interface ISchemeReferenceService
{
    Task<IReadOnlyCollection<SchemeRefDto>> GetActiveSchemesAsync(CancellationToken cancellationToken);

    /// <summary>
    /// Like <see cref="GetActiveSchemesAsync"/>, but returns null (instead of an empty list) when
    /// Paycon could not be reached. Callers that HIDE plans Paycon no longer lists (deleted /
    /// inactive plans) use this so a Paycon outage does not make every assigned plan vanish.
    /// </summary>
    Task<IReadOnlyCollection<SchemeRefDto>?> TryGetActiveSchemesAsync(CancellationToken cancellationToken);
}
