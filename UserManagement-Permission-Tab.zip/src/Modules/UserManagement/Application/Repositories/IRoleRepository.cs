using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Domain;

namespace ZWS.Modules.UserManagement.Application.Repositories;

public interface IRoleRepository
{
    Task<(IReadOnlyCollection<Role> Items, int TotalCount)> SearchAsync(PagedRequest request, CancellationToken cancellationToken);
    Task<Role?> GetByIdAsync(Guid id, CancellationToken cancellationToken);
    /// <summary>True if another (non-deleted) role already uses this name. Role names are unique
    /// across ALL groups, compared case-insensitively. <paramref name="excludeId"/> skips the role being edited.</summary>
    Task<bool> IsNameTakenAsync(string name, Guid? excludeId, CancellationToken cancellationToken);
    Task<int> CountActiveUsersAsync(Guid roleId, CancellationToken cancellationToken);
    void Add(Role role);
    void Remove(Role role);
}
