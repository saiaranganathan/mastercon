using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Groups.Queries;

public sealed class GetGroupsQueryHandler(IGroupRepository groupRepository, ISchemeReferenceService schemeReferenceService)
    : IQueryHandler<GetGroupsQuery, PagedResult<GroupListItemDto>>
{
    public async Task<Result<PagedResult<GroupListItemDto>>> Handle(GetGroupsQuery request, CancellationToken cancellationToken)
    {
        var (groups, totalCount) = await groupRepository.SearchAsync(request.Paging, cancellationToken);

        // Hide plans Paycon no longer lists as active (null = Paycon unreachable: hide nothing).
        var activePlanIds = (await schemeReferenceService.TryGetActiveSchemesAsync(cancellationToken))?.Select(s => s.SchemeId).ToHashSet();

        var items = new List<GroupListItemDto>();
        foreach (var group in groups)
        {
            var activeUsers = await groupRepository.CountActiveUsersAsync(group.Id, cancellationToken);
            var plans = string.Join(", ", group.SchemeAssignments.Where(s => activePlanIds is null || activePlanIds.Contains(s.SchemeId)).Select(s => s.SchemeName));
            items.Add(new GroupListItemDto(
                group.Id, group.Name, plans, activeUsers, group.State.ToString(),
                group.OverridePlanPermissionAtUserLevel, group.CreatedAt, group.CreatedBy, group.UpdatedAt, group.UpdatedBy));
        }

        var result = new PagedResult<GroupListItemDto>(items, totalCount, request.Paging.Page, request.Paging.PageSize);
        return Result.Success(result);
    }
}
