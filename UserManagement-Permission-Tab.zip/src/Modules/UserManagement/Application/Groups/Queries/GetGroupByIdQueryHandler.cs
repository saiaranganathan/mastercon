using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.UserManagement.Application.Dtos;
using ZWS.Modules.UserManagement.Application.Repositories;

namespace ZWS.Modules.UserManagement.Application.Groups.Queries;

public sealed class GetGroupByIdQueryHandler(IGroupRepository groupRepository, ISchemeReferenceService schemeReferenceService)
    : IQueryHandler<GetGroupByIdQuery, GroupDetailDto>
{
    public async Task<Result<GroupDetailDto>> Handle(GetGroupByIdQuery request, CancellationToken cancellationToken)
    {
        var group = await groupRepository.GetByIdAsync(request.Id, cancellationToken);
        if (group is null)
            return Result.Failure<GroupDetailDto>(Error.NotFound("Group.NotFound", $"Group '{request.Id}' was not found."));

        var activeUsers = await groupRepository.CountActiveUsersAsync(group.Id, cancellationToken);
        // Hide plans Paycon no longer lists as active (null = Paycon unreachable: hide nothing).
        var activePlanIds = (await schemeReferenceService.TryGetActiveSchemesAsync(cancellationToken))?.Select(s => s.SchemeId).ToHashSet();
        var plans = group.SchemeAssignments
            .Where(s => activePlanIds is null || activePlanIds.Contains(s.SchemeId))
            .Select(s => new SchemeRefDto(s.SchemeId, s.SchemeName)).ToList();

        return Result.Success(new GroupDetailDto(
            group.Id, group.Name, plans, activeUsers, group.State.ToString(), group.OverridePlanPermissionAtUserLevel,
            group.CreatedAt, group.CreatedBy, group.UpdatedAt, group.UpdatedBy));
    }
}
