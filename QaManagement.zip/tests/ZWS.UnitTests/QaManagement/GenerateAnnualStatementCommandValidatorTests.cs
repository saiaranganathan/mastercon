using FluentAssertions;
using ZWS.Modules.Paycon.QaManagement.Application.Commands;
using Xunit;

namespace ZWS.UnitTests.QaManagement;

/// <summary>QA Management page rule: a value in @monthOffset forces @dayOffset to 0, and vice versa.</summary>
public class GenerateAnnualStatementCommandValidatorTests
{
    private readonly GenerateAnnualStatementCommandValidator _validator = new();
    private static readonly DateOnly Today = new(2026, 10, 7);

    [Theory]
    [InlineData(0, 0)]
    [InlineData(3, 0)]
    [InlineData(-3, 0)]
    [InlineData(0, 10)]
    [InlineData(0, -10)]
    public void Validate_WithAtMostOneOffset_ShouldSucceed(int monthOffset, int dayOffset)
    {
        var result = _validator.Validate(new GenerateAnnualStatementCommand(Today, monthOffset, dayOffset));

        result.IsValid.Should().BeTrue();
    }

    [Theory]
    [InlineData(1, 1)]
    [InlineData(-2, 5)]
    [InlineData(6, -6)]
    public void Validate_WithBothOffsets_ShouldFail(int monthOffset, int dayOffset)
    {
        var result = _validator.Validate(new GenerateAnnualStatementCommand(Today, monthOffset, dayOffset));

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.ErrorMessage.Contains("either a Month offset or a Day offset"));
    }

    [Fact]
    public void Validate_WithDefaultDate_ShouldFail()
    {
        var result = _validator.Validate(new GenerateAnnualStatementCommand(default, 0, 0));

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == nameof(GenerateAnnualStatementCommand.CurrentDate));
    }

    [Fact]
    public void Validate_WithOutOfRangeOffsets_ShouldFail()
    {
        _validator.Validate(new GenerateAnnualStatementCommand(Today, GenerateAnnualStatementCommandValidator.MaxMonthOffset + 1, 0))
            .IsValid.Should().BeFalse();
        _validator.Validate(new GenerateAnnualStatementCommand(Today, 0, -GenerateAnnualStatementCommandValidator.MaxDayOffset - 1))
            .IsValid.Should().BeFalse();
    }
}
