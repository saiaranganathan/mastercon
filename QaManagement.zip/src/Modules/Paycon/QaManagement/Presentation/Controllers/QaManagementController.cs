using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZWS.BuildingBlocks.Auth;
using ZWS.BuildingBlocks.Web;
using ZWS.Modules.Paycon.QaManagement.Application.Commands;

namespace ZWS.Modules.Paycon.QaManagement.Presentation.Controllers;

/// <summary>Route: /paycon/qa-management. Only roles granted the "qa-management" permission can reach it.</summary>
[ApiController]
[Route("api/paycon/qa-management")]
[RequirePermission("qa-management")]
public sealed class QaManagementController(ISender sender) : ControllerBase
{
    public sealed record GenerateAnnualStatementRequest(DateOnly CurrentDate, int MonthOffset, int DayOffset);

    [HttpPost("generate-annual-statement")]
    [RequirePermission("qa-management", PermissionAccess.Edit)]
    public async Task<IActionResult> GenerateAnnualStatement([FromBody] GenerateAnnualStatementRequest request, CancellationToken cancellationToken) =>
        (await sender.Send(new GenerateAnnualStatementCommand(request.CurrentDate, request.MonthOffset, request.DayOffset), cancellationToken)).ToActionResult();
}
