namespace ZWS.Modules.Paycon.QaManagement.Application.Abstractions;

/// <summary>
/// Executes the [ANNUAL].[Generate_AnnualStatement] stored procedure in the Paycon database.
/// The procedure returns no result set, so this only reports success / failure.
/// </summary>
public interface IAnnualStatementGenerationRunner
{
    Task RunAsync(DateOnly currentDate, int monthOffset, int dayOffset, CancellationToken cancellationToken);
}

/// <summary>Raised when the procedure cannot be run (no SQL Server configured, or SQL Server rejected the call).</summary>
public sealed class AnnualStatementGenerationException(string code, string message, Exception? inner = null)
    : Exception(message, inner)
{
    public string Code { get; } = code;
}
