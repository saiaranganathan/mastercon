using Microsoft.Extensions.Logging;
using ZWS.BuildingBlocks.Application.Abstractions;
using ZWS.BuildingBlocks.Application.Common;
using ZWS.Modules.Paycon.QaManagement.Application.Abstractions;

namespace ZWS.Modules.Paycon.QaManagement.Application.Commands;

public sealed class GenerateAnnualStatementCommandHandler(
    IAnnualStatementGenerationRunner runner,
    ILogger<GenerateAnnualStatementCommandHandler> logger)
    : ICommandHandler<GenerateAnnualStatementCommand>
{
    public async Task<Result> Handle(GenerateAnnualStatementCommand request, CancellationToken cancellationToken)
    {
        try
        {
            await runner.RunAsync(request.CurrentDate, request.MonthOffset, request.DayOffset, cancellationToken);
            logger.LogInformation(
                "QA annual statement generation executed (currentDate={CurrentDate}, monthOffset={MonthOffset}, dayOffset={DayOffset}).",
                request.CurrentDate, request.MonthOffset, request.DayOffset);
            return Result.Success();
        }
        catch (AnnualStatementGenerationException ex)
        {
            logger.LogWarning(ex, "QA annual statement generation failed: {Message}", ex.Message);
            return Result.Failure(new Error(ex.Code, ex.Message));
        }
    }
}
