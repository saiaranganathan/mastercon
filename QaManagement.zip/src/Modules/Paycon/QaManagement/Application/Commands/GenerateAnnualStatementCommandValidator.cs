using FluentValidation;

namespace ZWS.Modules.Paycon.QaManagement.Application.Commands;

public sealed class GenerateAnnualStatementCommandValidator : AbstractValidator<GenerateAnnualStatementCommand>
{
    public const int MaxMonthOffset = 1200;
    public const int MaxDayOffset = 36500;

    public GenerateAnnualStatementCommandValidator()
    {
        RuleFor(x => x.CurrentDate)
            .Must(d => d != default)
            .WithMessage("Current date is required.");

        RuleFor(x => x.MonthOffset)
            .InclusiveBetween(-MaxMonthOffset, MaxMonthOffset)
            .WithMessage($"Month offset must be between -{MaxMonthOffset} and {MaxMonthOffset}.");

        RuleFor(x => x.DayOffset)
            .InclusiveBetween(-MaxDayOffset, MaxDayOffset)
            .WithMessage($"Day offset must be between -{MaxDayOffset} and {MaxDayOffset}.");

        // Business rule: a value in one offset forces the other to 0.
        RuleFor(x => x)
            .Must(x => x.MonthOffset == 0 || x.DayOffset == 0)
            .WithName("Offset")
            .WithMessage("Provide either a Month offset or a Day offset, not both. When one has a value, the other must be 0.");
    }
}
