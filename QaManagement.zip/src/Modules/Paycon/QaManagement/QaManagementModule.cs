using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ZWS.Modules.Paycon.QaManagement.Application.Abstractions;
using ZWS.Modules.Paycon.QaManagement.Infrastructure;

namespace ZWS.Modules.Paycon.QaManagement;

/// <summary>
/// QA tooling for the Paycon app. No tables of its own - it only triggers stored procedures
/// that already live in the Paycon database, so there is no DbContext, migration or seed.
/// </summary>
public static class QaManagementModule
{
    public static IServiceCollection AddQaManagementModule(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<IAnnualStatementGenerationRunner, SqlAnnualStatementGenerationRunner>();
        return services;
    }
}
