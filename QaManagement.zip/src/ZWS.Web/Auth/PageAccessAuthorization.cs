using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace ZWS.Web.Auth;

/// <summary>
/// Client-side half of the route-protection gap identified alongside the API-level
/// [RequirePermission] fix in ZWS.BuildingBlocks.Auth (server-side; not referenced here on
/// purpose - ZWS.Web talks to ZWS.Host only over HTTP, see the ItemGroup comment in
/// ZWS.Web.csproj). Before this, typing an unauthorized page's URL directly rendered that page's
/// full component tree in the browser (it would then fail to load its data with a 401/403 from
/// the now-protected API, but only after the page itself, and everything a user might see just by
/// having it open, had already rendered) - there was no
/// Microsoft.AspNetCore.Components.Authorization usage anywhere in this project at all. Each
/// @page component now carries `@attribute [Authorize(Policy = PagePolicy.Dashboard)]` (see
/// App.razor's AuthorizeRouteView), resolved against the same "perm" claims already decoded by
/// JwtPermissions/PermissionService for menu-hiding - this is the identical source of truth, not
/// a second one to keep in sync.
///
/// The per-page fields below are `const string`, not a `For(pageKey)` method: a C# attribute
/// argument must be a compile-time constant expression (CS0182 - "An attribute argument must be
/// a constant expression..."), and a call to an ordinary static method doesn't qualify even
/// though its result is deterministic. `Prefix + "literal"` (const + literal) DOES qualify, since
/// the compiler constant-folds it - hence one named const per PermissionPageCatalog key Paycon
/// actually gates a page on, instead of a helper method.
/// </summary>
public static class PagePolicy
{
    public const string Prefix = "ZwsPage:";

    public const string Dashboard = Prefix + "dashboard";
    public const string Insights = Prefix + "insights";
    public const string ReconciliationPaymentsIn = Prefix + "reconciliation.payments-in";
    public const string ReconciliationPaymentsOut = Prefix + "reconciliation.payments-out";
    public const string StatementsExitStatements = Prefix + "statements.exit-statements";
    public const string StatementsAnnualStatements = Prefix + "statements.annual-statements";
    public const string SettingsSchemeManagement = Prefix + "settings.scheme-management";
    public const string SettingsInsightManagement = Prefix + "settings.insight-management";
    public const string QaManagement = Prefix + "qa-management";

    /// <summary>Runtime equivalent for the rare spot that needs a policy name built from a
    /// variable page key (e.g. inside an <c>&lt;AuthorizeView Policy="@(...)"&gt;</c> markup
    /// expression, which - unlike an attribute argument - is evaluated at run time, not compile
    /// time). Not usable inside an `[Authorize(...)]` attribute; use the const fields above there.</summary>
    public static string For(string pageKey) => $"{Prefix}{pageKey}";
}

public sealed class PageAccessRequirement(string pageKey) : IAuthorizationRequirement
{
    public string PageKey { get; } = pageKey;
}

public sealed class PageAccessHandler : AuthorizationHandler<PageAccessRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PageAccessRequirement requirement)
    {
        // Edit always implies View (expanded to both "perm" claims at token-mint time - see
        // JwtUserClaims/LoginCommandHandler), so a bare View-claim match is enough here.
        if (context.User.HasClaim("perm", $"{requirement.PageKey}:View"))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

public sealed class ZwsPagePolicyProvider(IOptions<AuthorizationOptions> options) : IAuthorizationPolicyProvider
{
    private readonly DefaultAuthorizationPolicyProvider _fallback = new(options);

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync() => _fallback.GetFallbackPolicyAsync();

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(PagePolicy.Prefix, StringComparison.Ordinal))
        {
            var pageKey = policyName[PagePolicy.Prefix.Length..];
            var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(new PageAccessRequirement(pageKey))
                .Build();
            return Task.FromResult<AuthorizationPolicy?>(policy);
        }

        return _fallback.GetPolicyAsync(policyName);
    }
}
