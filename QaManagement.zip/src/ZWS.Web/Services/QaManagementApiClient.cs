namespace ZWS.Web.Services;

public sealed class QaManagementApiClient(HttpClient http) : ApiClientBase(http)
{
    private const string BaseRoute = "api/paycon/qa-management";

    /// <summary>Runs [ANNUAL].[Generate_AnnualStatement]. The stored procedure returns no data,
    /// so success is just an empty 204.</summary>
    public Task<ApiResult> GenerateAnnualStatementAsync(DateOnly currentDate, int monthOffset, int dayOffset, CancellationToken cancellationToken = default) =>
        PostAsync($"{BaseRoute}/generate-annual-statement", new { CurrentDate = currentDate, MonthOffset = monthOffset, DayOffset = dayOffset }, cancellationToken);
}
